# reference/

`inspiration-01.jpg` was **not** present in the project, so per `R-REF-01` this file
carries the description instead. No TikTok page was fetched (they return HTTP 403).

## R-REF-02 — description of the inspiration

* **Near-black background.** The frame sits on `#0a0a0a` with a barely-there depth haze
  toward `#0f172a` in the centre, so black never looks flat or banded.
* **Glowing hot-white core subject.** The focal element is a white-hot core that falls
  off into colour at its edges — white centre, colour rim, long soft bloom. Used for the
  opening focal point, the hero star sphere and the impact flash.
* **Gradient display title, a different colour per letter.** The title is filled with the
  blue→orange gradient sampled *per letter*, so each glyph carries its own position in the
  ramp instead of one flat wash across the whole line.
* **Motion-blur tails on the final letters of a word.** The last two letters are drawn as
  a decaying stack of offset ghosts, giving directional blur without a blur pass.
* **Film grain and bloom.** One seeded 512×512 grain tile at 3.5 % over everything, plus a
  24 px additive bloom at 35 % from a half-scale glow buffer.

## Explicitly *not* taken from the inspiration

No creator handle, no watermark, no logo, no layout, no thumbnail composition, no
third-party UI chrome (`R-NEG-04`). Only the five rendering techniques above are reused.
