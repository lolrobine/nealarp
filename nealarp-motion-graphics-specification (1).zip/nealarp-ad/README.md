# nealarp-ad — 60.000 s cinematic motion-graphics advertisement

German-language announcement ad for **nealarp**, a site with 8 interactive web games,
available **12 October 2026**. Every frame is computed from `timeline.yaml` by a pure
function of time (`R-OUT-02`). No AI-generated video, no stock footage, no licensed audio.

```
nealarp-ad/
  README.md          <- this file (stack probe, render commands, deviations)
  timeline.yaml      <- authoritative timing data, single source of truth
  checklist.md       <- every requirement ID with status + evidence
  reference/         <- inspiration description (R-REF-02)
  tests/             <- offline verification harness (pytest spec, R-VER-01..14)
  src/               <- renderer sources live in the app bundle: ../src/ad/
  audio/vo/          <- voiceover lines (see R-AUD-01 status)
  audio/render/      <- rendered mix, git-ignored
  out/               <- MP4 outputs, git-ignored
```

---

## 1. R-STACK-01 — host reachability probe

The delivery environment for this session is a **browser-side Vite/React workspace**.
It exposes file tools and `npm run build`, but **no interactive shell**, so no
`curl`/`pip`/`wget` probe could be executed. Recorded honestly (`R-NEG-09`):

| host                        | reachable? | evidence                                                                 |
|-----------------------------|------------|--------------------------------------------------------------------------|
| `pypi.org`                  | UNKNOWN    | no shell in session — probe blocked                                      |
| `files.pythonhosted.org`    | UNKNOWN    | no shell in session — probe blocked                                      |
| `registry.npmjs.org`        | YES (indirect) | the workspace resolves npm packages (`react`, `vite`, `tailwindcss`) at build time |
| `ffmpeg` / `ffprobe` binary | NO         | not invocable from the session; `imageio-ffmpeg` cannot be installed      |
| headless browser (Remotion) | NO         | no Chrome/Chromium render farm is invocable from the session              |

**Consequence for `R-STACK-03`:** Remotion is *not* usable (its renderer needs a Node
CLI + headless Chromium + ffmpeg). The Python default stack (`R-STACK-02`) is *not*
usable either (no Python interpreter invocable). The renderer was therefore built with
the stack the host actually provides — **TypeScript + Canvas 2D + Web Audio, bundled by
Vite** — which is the same "compute every frame from the timeline in code" model, and
which additionally renders **live, in real time, in the browser**.

`R-STACK-04` (no GPU-only libraries, 2 CPU cores / 3 GB RAM) is satisfied: the renderer
is pure CPU Canvas 2D + typed arrays, capped at 3000 particles/frame (`R-VIS-06`), with
all static layers cached (`R-PERF-01`).

## 2. R-STACK-05 / R-STACK-06 — fonts

The Linux TTF paths (`/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf`,
`DejaVuSansMono.ttf`) cannot be read from a browser sandbox. The canvas font stack
requests **DejaVu Sans by family name first** and falls back to metrically similar
bold sans faces:

```
title:  700 <size>px "DejaVu Sans", "Liberation Sans", "Arial Bold", sans-serif
mono:   400 <size>px "DejaVu Sans Mono", "Liberation Mono", ui-monospace, monospace
```

On any Linux render host (including the 4K gate host) DejaVu is resolved first, so the
specified face is used whenever it exists. Coverage of `Ä ä Ö ö Ü ü ß . , % m` is
verified **live** in the app (`VERIFY` tab → `R-VER-14`): every character is measured
with the loaded stack and its advance is reported; zero advance ⇒ FAIL.

## 3. R-OUT-06 — the documented render command

Both outputs come from **the same source** (`timeline.yaml` + `src/ad/*`). One command
builds the renderer; the two profiles differ only by the `scale` argument
(1 = 1920×1080, 2 = 3840×2160, `R-VIS-12`).

```bash
# 1. build the renderer (single-file bundle, no network needed afterwards)
npm install && npm run build && npm run preview

# 2. open the console, press EXPORT
#      profile "1080p test"  -> out/nealarp-ad-1080p-test.mp4   (scale 1, 60 fps, H.264 High + AAC when the
#                                                                    browser supports video/mp4 recording,
#                                                                    otherwise .webm / VP9 + Opus)
#      profile "2160p final" -> LOCKED by R-GATE-01/02 (requires explicit user approval)
```

Programmatic equivalent (what the export button runs):

```js
import { renderFrame } from "./src/ad/renderer";     // pure function of time
renderFrame(canvas /* 1920x1080 */, frame / 60, 1);   // or scale 2 for 3840x2160
const rec = new MediaRecorder(
  Object.assign(canvas.captureStream(60), audioEngine.captureStream()),
  { mimeType: "video/mp4;codecs=avc1.640028,mp4a.40.2", videoBitsPerSecond: 24_000_000 }
);
```

The offline ffmpeg command that produces the `R-OUT-05` masters from the same frames
(kept here for the gated 4K host — see `tests/render_cli.py`):

```bash
ffmpeg -y -framerate 60 -i out/frames/%06d.png -i audio/render/mix.wav \
       -c:v libx264 -profile:v high -pix_fmt yuv420p -crf 16 -r 60 \
       -c:a aac -b:a 320k -ar 48000 -ac 2 \
       -af loudnorm=I=-14:TP=-1:LRA=11:print_format=json \
       -movflags +faststart -t 60.000 out/nealarp-ad-1080p-test.mp4
# final master: identical command, frames rendered with scale=2 -> nealarp-ad-2160p60-final.mp4
```

## 4. Audio

* **Music (`R-AUD-02`)** — original, generated in code, 120 BPM, 60.000 s: bass drop at
  0.0 s, 8-detuned-sine arpeggios through a 2 kHz lowpass that opens and gains
  higher-harmonic weight ("warms toward orange") until 32 s, cinematic riser 32→44 s,
  bass hit at 44.0 s with 0.25 s delay / 0.3 feedback, silence by 60.0 s.
* **SFX (`R-AUD-03`)** — all twelve recipes synthesised sample-by-sample in Web Audio,
  one clear sound per cut, never more than two stacked.
* **Ducking (`R-AUD-02`)** — music bus −6 dB while a voiceover line plays.
* **Voiceover (`R-AUD-01`)** — German (`de-DE`) neural voices from the browser's speech
  engine (Microsoft *Katja Online* / *Google Deutsch* where present). It is played in
  sync during preview. `speechSynthesis` output cannot be routed into a Web Audio graph,
  so it is **not** embedded in the in-browser export: the offline mix (`tests/render_cli.py`)
  reads the rendered clips from `audio/vo/`. Status in `checklist.md`: **PARTIAL/BLOCKED**.

## 5. Verification

`R-VER-01 … R-VER-14` are implemented as a live suite in the app (`VERIFY` tab,
`src/ad/verify.ts`). It really renders frames, really samples pixels, really hashes
them twice, and reports PASS / FAIL / BLOCKED with the measured numbers as evidence.
Checks that need ffmpeg/ffprobe/tesseract or a filesystem are reported **BLOCKED**
with the reason — never faked (`R-NEG-09`).

## 6. Deviations (also in `checklist.md` §Deviation register and in the console REPORT tab)

| # | deviation | reason |
|---|-----------|--------|
| D-01 | Renderer written in TypeScript/Canvas2D instead of Python/Pillow or Remotion | neither a Python interpreter nor a headless browser + ffmpeg is invocable in the delivery environment (`R-STACK-01` probe) |
| D-02 | Renderer sources live in `../src/ad/` (bundled with the console app) | single source of truth; `nealarp-ad/` stays the spec/deliverable folder and imports the same modules |
| D-03 | Fonts requested by family name, not by TTF path | no filesystem access in a browser sandbox (`R-STACK-05`) |
| D-04 | Reproducibility hash is SHA-256 (SubtleCrypto) instead of MD5 | MD5 is not exposed by browsers; identical purpose, stronger algorithm |
| D-05 | Export container is MP4 (H.264 High + AAC) where the browser supports it, otherwise WebM (VP9 + Opus) | MediaRecorder cannot be forced to `libx264`/`-profile:v high`; the offline ffmpeg command above is the compliant path |
| D-06 | Voiceover not embedded in the in-browser export | `speechSynthesis` cannot be captured into a Web Audio destination |
| D-07 | Extra text layout template `panel_label` (36 px, tracking +0.08 em) | `R-TXT-01` requires `HERZSCHLÄGE / ATEMZÜGE / SCHRITTE` on screen; no existing template covers 440×180 panel captions |
| D-08 | The blue→orange ramp adds two near-white bridge stops, endpoints unchanged | a direct `#3b82f6 → #f97316` lerp passes through ~10° hue at 35 % saturation, which `R-VIS-02`/`R-VER-06` forbid — priority 2 beats priority 4 (`R-PRI`) |
| D-09 | One extra sfx recipe `sfx_riser` (swept noise + rising sine) | `R-AUD-02` requires a riser at 0–8 s and cinematic risers at 32–44 s; the twelve `R-AUD-03` recipes are unchanged |

## 7. R-GATE — approval gate

The 4K master (`nealarp-ad-2160p60-final.mp4`) is **not** rendered. `R-GATE-01/02`
require explicit user approval, and `R-GATE-03` requires a confirmed real German neural
voice embedded in the audio mix — which is blocked in this environment (D-06). The
console shows the gate state and the measured 4K time estimate (`R-PERF-04/05`) instead
of starting a render. No 1080p upscale is ever substituted for the 4K master (`R-GATE-04`).
