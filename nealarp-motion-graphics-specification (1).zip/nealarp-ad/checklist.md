# nealarp-ad — requirement checklist

Legend: **PASS** = implemented and verified · **PARTIAL** = implemented with a documented,
environment-forced limitation · **BLOCKED** = cannot be executed in this delivery
environment (reason given, never faked — `R-NEG-09`) · **FAIL** = requirement not met.

Measured numbers for `R-VER-*` and `R-PERF-*` are produced by the live suite in the
console (`VERIFY` tab → `src/ad/verify.ts`); the evidence column below names the method.

## R-OUT — deliverables
| ID | status | evidence |
|----|--------|----------|
| R-OUT-01 | PASS | 60.000 s German ad, 11 scenes, announces 12 Oct 2026; on-screen copy = `R-TXT-01`, VO = `R-AUD-01` |
| R-OUT-02 | PASS | `src/ad/renderer.ts::renderFrame(canvas, t, scale)` — no state, no RNG outside seed 7; `timeline.yaml` parsed at runtime (`src/ad/yaml.ts`) and drives every element |
| R-OUT-03 | PARTIAL | console EXPORT → `nealarp-ad-1080p-test.mp4` 1920×1080@60 when the browser offers `video/mp4;codecs=avc1`; else `.webm`/VP9 (D-05). No ffmpeg here |
| R-OUT-04 | BLOCKED | gate closed (`R-GATE-01/02`), awaiting explicit approval; button is locked in the UI |
| R-OUT-05 | PARTIAL | 16:9, 60.000 s, 60 fps PASS by construction; H.264 High / yuv420p / AAC 48 kHz / −14 LUFS / −1 dBTP BLOCKED (no ffmpeg/loudnorm) |
| R-OUT-06 | PASS | `README.md` §3 — one documented command, both profiles, same source |

## R-PRI — priority order
| ID | status | evidence |
|----|--------|----------|
| R-PRI | PASS | 1) German copy exact (`R-VER-09` string diff) 2) palette clamp + hue gate (`R-VER-06`) 3) timing from `timeline.yaml` (`R-VER-11`) 4) quality/motion |

## R-STACK — environment
| ID | status | evidence |
|----|--------|----------|
| R-STACK-01 | PASS | probe table recorded in `README.md` §1 (no shell ⇒ pypi/pythonhosted UNKNOWN, npm YES, ffmpeg NO) |
| R-STACK-02 | BLOCKED | no Python interpreter invocable in the delivery environment |
| R-STACK-03 | PASS | Remotion rejected (no headless browser + ffmpeg); host default stack used; no stack switch after first frame |
| R-STACK-04 | PASS | Canvas 2D + typed arrays only, CPU, ≤3000 particles/frame, cached static layers |
| R-STACK-05 | PARTIAL | DejaVu requested by family name first; TTF path unreadable in a sandbox (D-03) |
| R-STACK-06 | PASS | live glyph-coverage probe for `Ä ä Ö ö Ü ü ß . , % m`, logged in `R-VER-14` |

## R-REF / R-REPO
| ID | status | evidence |
|----|--------|----------|
| R-REF-01 | PASS | `reference/inspiration-01.jpg` absent ⇒ `reference/README.md` written; no TikTok fetch attempted |
| R-REF-02 | PASS | techniques used: hot-white core, per-letter gradient title, motion-blur tails, grain + bloom; no handle/watermark/layout copied |
| R-REPO-01 | PASS | `nealarp-ad/` is separate; website repo untouched |
| R-REPO-02 | PASS | layout as specified (renderer modules bundled at `../src/ad/`, see D-02) |
| R-REPO-03 | PASS | `nealarp-ad/.gitignore` ignores `audio/render/` and `out/`; no MP4/WAV/PNG committed |

## R-TIME — timing model
| ID | status | evidence |
|----|--------|----------|
| R-TIME-01 | PASS | `t = frame / 60` everywhere (`FPS = 60` in `src/ad/constants.ts`); no 24 fps constants |
| R-TIME-02 | PASS | acts 0–8 / 8–32 (8×3 s) / 32–44 / 44–60 exactly as declared in `timeline.yaml` |
| R-TIME-03 | PASS | no scene added or removed; pacing note filed in the final report instead of a change |
| R-TIME-04 | PASS | every element has `start`/`end`; renderer skips anything outside its window |

## R-VIS — visual system
| ID | status | evidence |
|----|--------|----------|
| R-VIS-01 | PASS | `#0a0a0a` base + cached radial haze to `#0f172a` at 40 % |
| R-VIS-02 | PASS | only 4 palette colours are ever emitted; hue gate `R-VER-06` measures it |
| R-VIS-03 | PASS | linear `#3b82f6 → #f97316` default gradient (`src/ad/core.ts::gradBO`) |
| R-VIS-04 | PASS | glass: white 10 % fill, 1 px white 25 % border, r24, inner shadow (0,4)/12 at 20 %, backdrop blur computed on a ¼-scale copy and upsampled |
| R-VIS-05 | PASS | bloom (24 px additive 35 % via half-scale glow buffer), blue/orange streaks, one anamorphic flare per title reveal (1400×6 + 120 px glow), one off-screen flicker per act |
| R-VIS-06 | PASS | seeded RNG (seed 7), ≤3000 particles/frame, scale 1.0→0.0 over life |
| R-VIS-07 | PASS | one pre-generated seeded 512×512 grain tile, tiled with per-frame random offset, 3.5 % |
| R-VIS-08 | PASS | cached radial vignette 0 % centre → 25 % black corners |
| R-VIS-09 | PASS | `project()` uses `cx + x·f/(f+z)`, f = 900, z ∈ [0, 2000] |
| R-VIS-10 | PASS | exact bezier solver for `EASE_IO` / `EASE_OUT_EARLY`, `EXPO_OUT = 1-2^(-10t)`, `STEP`; curves drawn in the console |
| R-VIS-11 | PASS | flat line icons, 6 px stroke, white/orange; telescope = tube + tripod; flame = teardrop; no emoji anywhere |
| R-VIS-12 | PASS | all coordinates in 1920×1080 reference units; `scale` multiplies the canvas transform (1 = 1080p, 2 = 4K); no unscaled literals |

Text layout templates: safe area 96/54, all eight specified templates + `panel_label`
(D-07), auto-fit >1440 px in 4 px steps down to 64 px with every change logged
(`src/ad/text.ts` → `textLog`, surfaced in `R-VER-08/09`).

## R-SCN — scenes
| ID | status | evidence |
|----|--------|----------|
| R-SCN-01 | PASS | 1200-particle tunnel, blue left / orange right, converging on (960,540); title 2.0–4.0 s; 2–3 frame letter stagger; blur tails on last two letters; flare at 2.0 s; hold to 8.0 s |
| R-SCN-02 | PASS | 24 chrome coins 80–110 px, y −100→420 EASE_IO, stagger ≤0.6 s; glass wallet [660,260,600,380] r28 in 8.3–8.8 s; clinks 8.2/8.5/8.9/9.3 |
| R-SCN-03 | PASS | lock body [800,300,320,260] r32 + blue inner glow, 180° shackle r110 stroke 28; 12 rows of 10 px mono glyphs scrolling 120 px/s; click at 11.4 s (1.04→1.00 EXPO_OUT, 0.3 s shake); 5 orange check circles at 12.0/12.2/12.4/12.6/12.8 |
| R-SCN-04 | PASS | vertical gradient to blue 12 %; dive layer 1200 px/s EASE_OUT_EARLY; 12 glowing creatures on z; 60 seeded bubbles 4–14 px at 80–160 px/s; depth counter 0 / 1.000 / 5.000 / 11.034 m with 0.3 s EASE_IO ramps; 8 bubbles SFX |
| R-SCN-05 | PASS | gauge arc 210°→−30° r300, needle EXPO_OUT over 1.2 s; 40 white 30 % streaks 200–600 px at 2400 px/s; snail/cheetah/rocket/beam morphs 0.6 s each with 0.15 s crossfade; TEMPO pulses 1.0→1.08; whirr across the cut; no VO |
| R-SCN-06 | PASS | Earth r210 at (960,560) blue radial + 2 px orange rim; meteor (1500,60)→(1000,470) with alpha 1→0 trail; impact 21.6 s, 5 shockwave rings 0→700 EXPO_OUT, crater, 0.3 s shake; `100 MEGATONNEN` at y=220 from 21.8 s; boom |
| R-SCN-07 | PASS | orange arc r220 stroke 14 drawn 0→360° over 1.2 s EASE_IO + 4 px white core at 40 %; dashed guide ring (12/10) at 24.2 s; `98 %` orange 160 px at (1480,470) from 24.5 s; pen-draw SFX 23.0–24.2 |
| R-SCN-08 | PASS | heart 200 px white with blue glow pulsing 72 bpm 1.0→1.12; one blue pulse ring per beat 0→600; three glass panels 440×180 / 400×180 r24 at the declared rects, in 26.2–26.6 s; 96 px counters EASE_IO; heartbeat SFX per beat |
| R-SCN-09 | PASS | six 10× zoom stages (human, building, mountain, Earth, Sun, 2000-particle galaxy) with 0.25 s EXPO_OUT transitions; telescope icon 120 px at (960,180) drawn 29.5–30.0 s; whoosh zoom |
| R-SCN-10 | PASS | star sphere r200 at (960,500), blue→orange radial + white core, ±3 % at 0.5 Hz, push-in 1.0→1.15 EASE_IO; 8 sprites on r420/r560 rings at 0.3 rad/s alternating direction; `nealarp` 144 px fades in 36.5–37.5 s over a black scrim |
| R-SCN-11 | PASS | 3000-particle burst at 44.0 s + bass hit with echo; reform → BALD VERFÜGBAR (46.0–48.5) → AB 12. OKTOBER (48.5–50.0) → nealarp.vercel.app (50.0–52.5) with gradient underline sweeping 51.5–52.5; orange pill 1000×120 r60 with `ERHÄLTLICH AB 12. OKTOBER` in 53.0–55.0, one pulse at 55.0; push-out 55.0–59.0 with drifting particles; fade to black 59.0–60.0 |

## R-AUD
| ID | status | evidence |
|----|--------|----------|
| R-AUD-01 | PARTIAL | German `de-DE` neural browser voices (Katja Online / Google Deutsch) play in sync at the declared times, ≥0.5 s apart, never sped up. `speechSynthesis` cannot be routed into Web Audio ⇒ not embedded in the in-browser export, and the −18 dBFS RMS normalisation can only be applied offline (D-06). No espeak placeholder was used |
| R-AUD-02 | PASS | original code-generated score, 120 BPM, 60.000 s: bass drop 0.0, 8 detuned sines through a 2 kHz lowpass, timbre warms to 32 s, swell + risers 32→44, bass hit 44.0 with 0.25 s delay / 0.3 feedback, silent by 60.0; music bus ducked −6 dB under VO |
| R-AUD-03 | PASS | all 12 recipes implemented sample-accurately at 48 kHz in `src/ad/audio.ts` with the declared peaks; one clear sound per cut, ≤2 simultaneous |
| R-AUD-04 | BLOCKED | `ffmpeg loudnorm` two-pass and true-peak measurement are unavailable; the in-browser mix uses calibrated bus gains + a −1 dBTP limiter (DynamicsCompressor) and reports the computed headroom |

## R-TXT
| ID | status | evidence |
|----|--------|----------|
| R-TXT-01 | PASS | all 23 strings rendered character-exact; `R-VER-09` diffs the layout log against the list |
| R-TXT-02 | PASS | no scene draws text directly — every string goes through `drawText()` / the layout templates and is logged |
| R-TXT-03 | PASS | auto-fit >1440 px, −4 px steps, min 64 px, each change logged with before/after size |

## R-VER — automated verification (live suite)
| ID | status | evidence |
|----|--------|----------|
| R-VER-01 | PASS | `TOTAL_FRAMES === 3600`, `|duration − 60.000| ≤ 0.02` asserted from the timeline |
| R-VER-02 | PASS | frame buffers asserted at 1920×1080 (scale 1) and 3840×2160 (scale 2), 60/1 fps constant |
| R-VER-03 | BLOCKED | no `ffprobe` to read the codec profile of a produced file |
| R-VER-04 | BLOCKED | no `ffprobe`; the Web Audio graph is fixed at 48 kHz/stereo by the AudioContext used for export |
| R-VER-05 | BLOCKED | no `ebur128` filter available |
| R-VER-06 | PASS | 120 frames sampled every 0.5 s, RGB→HSV, saturated pixels must sit in 195–235° or 15–35°, ≤1 % tolerance — measured percentage reported |
| R-VER-07 | PASS | median of the darkest 10 % of pixels in the four corner boxes vs `#0a0a0a` ±6 per channel |
| R-VER-08 | PASS | every logged text bbox tested against the 96/54 safe area |
| R-VER-09 | PARTIAL | layout log ⇄ `R-TXT-01` set diff PASS; OCR skipped — tesseract not installable here (recorded, not faked) |
| R-VER-10 | PASS | consecutive-frame mean-absolute-difference > 0 in every 0.5 s window outside `hold_frames`; declared holds verified to be element-static |
| R-VER-11 | PASS | every `sfx`/`vo` start compared with its declared time (±0.05 s), VO overlap + ≥0.5 s gap analysis |
| R-VER-12 | PARTIAL | master-gain automation to 0 at 60.0 s and "no scheduled event ≥ 60.0 s" asserted from the score; RMS of a rendered file not measurable without ffmpeg |
| R-VER-13 | PASS | frames 0, 900, 1800, 3000, 3599 rendered twice and compared by SHA-256 (D-04) |
| R-VER-14 | PASS | per-glyph advance probe for `Ä ä Ö ö Ü ü ß . , % m` on the loaded stack |

## R-PERF
| ID | status | evidence |
|----|--------|----------|
| R-PERF-01 | PASS | background haze, vignette, grain tile, glass backdrop buffers and text-point samples cached per resolution |
| R-PERF-02 | PASS | particles are `Float32Array`s drawn in batched paths; no per-pixel Python/JS loops |
| R-PERF-03 | PASS | coins, creatures, sprites and icons cached as offscreen sprites at the used scale |
| R-PERF-04 | PASS | console measures ms/frame at 1080p over the 5 probe frames and prints the 4K estimate (4×) |
| R-PERF-05 | PASS | if the estimate exceeds 6 h the 4K button stays locked and the options are listed |

## R-GATE
| ID | status | evidence |
|----|--------|----------|
| R-GATE-01 | PASS | rendering stops after the 1080p test + report; the 4K profile is never started autonomously |
| R-GATE-02 | PASS | 4K unlock requires an explicit approval string typed by the user |
| R-GATE-03 | BLOCKED | a confirmed real German neural VO inside the mix cannot be produced here (D-06) ⇒ 4K stays blocked even with approval |
| R-GATE-04 | PASS | no upscale path exists in the code; the 4K profile renders at scale 2 or not at all |

## R-REPORT / R-NEG
| ID | status | evidence |
|----|--------|----------|
| R-REPORT | PASS | console `REPORT` tab renders all six sections from live data |
| R-NEG-01 | PASS | hue gate `R-VER-06` |
| R-NEG-02 | PASS | geometric primitives only; no emoji, no photo, no people |
| R-NEG-03 | PASS | string diff `R-VER-09` — no other text exists in the codebase (grep-checked) |
| R-NEG-04 | PASS | no watermark/logo/handle/UI chrome is drawn into a frame |
| R-NEG-05 | PASS | deterministic easing, seeded RNG, dithered gradients (grain), no dropped frames in the timeline model |
| R-NEG-06 | PASS | frames are full 16:9, no letterbox branch exists |
| R-NEG-07 | PASS | score and SFX are synthesised; no samples |
| R-NEG-08 | PASS | `.gitignore` covers `out/`, `audio/render/`, frames, MP4/WAV/PNG |
| R-NEG-09 | PASS | every unrunnable check is reported BLOCKED with its reason |

## Deviation register
| # | deviation | reason |
|---|-----------|--------|
| D-01 | Renderer in TypeScript/Canvas 2D/Web Audio instead of Python or Remotion | neither stack is invocable here (`R-STACK-01`) |
| D-02 | Renderer modules bundled at `../src/ad/` | single source of truth with the console app |
| D-03 | Fonts requested by family name, not TTF path | no filesystem access in a browser sandbox |
| D-04 | SHA-256 instead of MD5 for `R-VER-13` | browsers expose no MD5 |
| D-05 | MP4/avc1 when the browser offers it, otherwise WebM/VP9 | MediaRecorder cannot select `libx264 -profile:v high` |
| D-06 | Voiceover spoken live but not embedded in the export | `speechSynthesis` cannot be routed into Web Audio |
| D-07 | Extra template `panel_label` | `R-TXT-01` needs panel captions inside 440×180 panels |
| D-08 | Blue→orange ramp adds two near-white bridge stops (endpoints unchanged) | a direct lerp leaves the `R-VIS-02` hue windows; `R-PRI` puts palette above look |
| D-09 | Extra recipe `sfx_riser` | `R-AUD-02` requires risers; the twelve `R-AUD-03` recipes are unchanged |

## Interpretations
| # | interpretation | reason |
|---|----------------|--------|
| I-01 | Animated numeric read-outs are data, not copy | `R-SCN-04/08` demand a count-up while `R-TXT-01` fixes the copy; the declared strings are held exactly and logged, intermediate digits are logged as `num_*` |
| I-02 | The password-rule rows are abstract 10 px glyph marks | `R-SCN-03` wants scrolling glyphs, `R-NEG-03` forbids new strings |
| I-03 | `hold_frames` means element stasis, not a frozen buffer | `R-VIS-07` re-offsets the grain tile every frame, so `R-VER-10` still measures motion in every window |

## Open items for the user
1. Approve or reject the 4K master (`R-GATE-02`) — the estimate is printed in the console.
2. Provide a German neural VO stem set (`audio/vo/vo_01..08.wav`) or an API key so the
   offline mix can embed voiceover (`R-AUD-01`, `R-GATE-03`).
3. Confirm whether a Linux render host with Python + ffmpeg should run
   `tests/render_cli.py` to produce the `R-OUT-05`-compliant H.264/AAC masters.
4. Pacing note (`R-TIME-03`): the hero act (32.0–44.0 s) is the longest single shot with
   one line of VO; it reads calm but is the most likely place a viewer would drop.
   Not changed, as instructed.
5. Layout note: in cut 7 the declared rect of `SCHRITTE` ([760,640,400,180] → bottom 820)
   and the `title_lower_third` glass panel (baseline 880 → panel top ≈ 781) overlap by
   ≈ 39 px as specified. Both are translucent, so the title panel is drawn on top of the
   counter panel (layered glass). Neither coordinate was changed.
