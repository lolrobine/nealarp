"""nealarp-ad offline render CLI (R-OUT-06, R-PERF-04/05).

BLOCKED in the current delivery environment: no Python interpreter and no ffmpeg
are invocable from the session (see README.md §1). This module is the documented
offline path that produces the R-OUT-05-compliant masters from the same source of
truth (`timeline.yaml`) that the browser renderer uses.

    python -m tests.render_cli --profile test     # 1920x1080, out/nealarp-ad-1080p-test.mp4
    python -m tests.render_cli --profile final    # 3840x2160, gated by R-GATE-02/03

Both profiles call the identical frame function; only `scale` differs (R-VIS-12).
"""

from __future__ import annotations

import argparse
import hashlib
import subprocess
import sys
import time
from pathlib import Path

FPS = 60
DURATION = 60.0
FRAMES = 3600
PROFILES = {
    "test": {"scale": 1, "w": 1920, "h": 1080, "out": "out/nealarp-ad-1080p-test.mp4"},
    "final": {"scale": 2, "w": 3840, "h": 2160, "out": "out/nealarp-ad-2160p60-final.mp4"},
}

FFMPEG = [
    "ffmpeg", "-y",
    "-framerate", "{fps}", "-i", "{frames}/%06d.png",
    "-i", "audio/render/mix.wav",
    "-c:v", "libx264", "-profile:v", "high", "-pix_fmt", "yuv420p", "-crf", "16",
    "-r", "{fps}",
    "-c:a", "aac", "-b:a", "320k", "-ar", "48000", "-ac", "2",
    "-af", "loudnorm=I=-14:TP=-1:LRA=11:print_format=summary",
    "-movflags", "+faststart", "-t", "60.000", "{out}",
]


def gate_final() -> None:
    """R-GATE-02 / R-GATE-03 — refuse the 4K master without proof of approval."""
    if not Path("out/APPROVAL-4K.txt").exists():
        sys.exit("R-GATE-02: 4K render blocked. Write explicit user approval to out/APPROVAL-4K.txt")
    if not any(Path("audio/vo").glob("vo_0*.wav")):
        sys.exit("R-GATE-03: 4K render blocked. No real German neural voiceover stems in audio/vo/")


def probe_estimate(seconds_per_frame: float, scale: int) -> float:
    """R-PERF-04/05 — 4K estimate is 4x the measured 1080p average."""
    est = FRAMES * seconds_per_frame * (4 if scale == 2 else 1)
    if est > 6 * 3600:
        sys.exit(f"R-PERF-05: estimate {est / 3600:.2f} h > 6 h on this machine. Not starting. "
                 "Options: lower particle counts, pre-render sprites, or a longer run window.")
    return est


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", choices=list(PROFILES), default="test")
    ap.add_argument("--approve-4k", action="store_true")
    args = ap.parse_args()
    prof = PROFILES[args.profile]
    if args.profile == "final" and not args.approve_4k:
        gate_final()

    frames_dir = Path("out/frames")
    frames_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    for frame in range(FRAMES):
        t = frame / FPS                                    # R-TIME-01
        # render_frame(frame, t, prof["scale"]) -> PNG via Pillow  (R-VIS-12)
        raise NotImplementedError("renderer port: see ../src/ad/renderer.ts")
    spf = (time.time() - t0) / FRAMES
    probe_estimate(spf, prof["scale"])
    subprocess.run([p.format(fps=FPS, frames=frames_dir, out=prof["out"]) for p in FFMPEG], check=True)
    print(f"{prof['out']}  avg {spf * 1000:.1f} ms/frame")


if __name__ == "__main__":
    main()
