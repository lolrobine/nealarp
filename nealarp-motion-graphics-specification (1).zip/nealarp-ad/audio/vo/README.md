# audio/vo/ — voiceover stems (R-AUD-01)

Required files, one per line, 48 kHz mono or stereo WAV, normalised to **−18 dBFS RMS**:

| file | start | German line (exact) |
|------|-------|---------------------|
| `vo_01.wav` | 0.5 s  | Alles, was du jemals im Internet machen wolltest … an einem Ort. |
| `vo_02.wav` | 9.0 s  | Gib eine Billion Dollar aus. |
| `vo_03.wav` | 11.5 s | Brich jede Passwortregel. |
| `vo_04.wav` | 14.5 s | Tauche 11.000 Meter tief in die Tiefsee. |
| `vo_05.wav` | 20.5 s | Schleudere Asteroiden. Zeichne perfekte Kreise. |
| `vo_06.wav` | 26.0 s | Entdecke deine Lebensstatistik. |
| `vo_07.wav` | 32.5 s | Acht Spiele. Keine Downloads. Eine Adresse. |
| `vo_08.wav` | 44.8 s | Ab dem 12. Oktober erhältlich auf nealarp.vercel.app. |

Voice: professional, confident, slightly deep, clear enunciation, premium tone, `de-DE`.

**Current status — PARTIAL / BLOCKED.** In the browser console these lines are spoken in
sync by the platform's German neural voices (Microsoft *Katja Online* / *Google Deutsch*
when available), which satisfies the *creative* requirement for preview but cannot be
captured into the exported file, because `speechSynthesis` does not route through Web
Audio. No `espeak-ng` placeholder was used (`espeak-ng` is not installable here either).

`R-GATE-03`: the 4K master stays blocked until real neural stems exist in this folder.
Drop the eight WAVs here and the offline mix (`../tests/render_cli.py`) will pick them up,
duck the music bus by 6 dB under each line, and normalise the master to −14 LUFS / −1 dBTP.

`audio/render/` and `out/` are git-ignored (`R-REPO-03`).
