// ============================================================================
// nealarp-ad / art — flat geometric sprites and line icons (R-VIS-11).
// Stroke 6 reference px, white or orange. No emoji, no cartoon, no photo.
// The same painters are reused as the hero orbit sprites (R-SCN-10).
// ============================================================================

import { HEX, rgba, withAlpha } from "./constants";
import { clamp01, lerp } from "./easing";
import { gradBO, gradRadial, rrect } from "./core";

export const TAU = Math.PI * 2;
const STROKE = 6;

type Ctx = CanvasRenderingContext2D;

function stroke(ctx: Ctx, w: number, color: string, alpha = 1) {
  ctx.lineWidth = w;
  ctx.strokeStyle = alpha >= 1 ? color : withAlpha(color.startsWith("#") ? color : HEX.white, alpha);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
}

/** chrome coin: white core, blue mid tones, 2 px orange rim highlight (R-SCN-02) */
export function drawCoin(ctx: Ctx, cx: number, cy: number, d: number, spin: number, alpha = 1, rim: "blue" | "orange" = "orange") {
  const sq = 0.22 + 0.78 * Math.abs(Math.cos(spin));
  const r = d / 2;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(cx, cy);
  ctx.beginPath();
  ctx.ellipse(0, 0, r, r * sq, 0, 0, TAU);
  const g = ctx.createLinearGradient(-r, -r * sq, r, r * sq);
  g.addColorStop(0, withAlpha(HEX.white, 0.95));
  g.addColorStop(0.35, withAlpha(HEX.blue, 0.85));
  g.addColorStop(0.72, "rgba(20,32,54,1)");
  g.addColorStop(1, withAlpha(HEX.blue, 0.6));
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = rgba(rim, 0.95);
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 0.52, r * 0.52 * sq, 0, 0, TAU);
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = withAlpha(HEX.white, 0.35);
  ctx.stroke();
  ctx.restore();
}

/** padlock: rounded body + 180 deg shackle (R-SCN-03) */
export function drawLock(ctx: Ctx, cx: number, cy: number, size: number, alpha = 1, glowBlue = true) {
  const w = size;
  const h = size * 0.8;
  ctx.save();
  ctx.globalAlpha = alpha;
  // shackle
  ctx.beginPath();
  ctx.arc(cx, cy - h / 2, w * 0.34, Math.PI, TAU);
  stroke(ctx, STROKE * 1.6, HEX.white, 0.92);
  ctx.stroke();
  // body
  rrect(ctx, cx - w / 2, cy - h / 2, w, h, size * 0.1);
  const g = ctx.createLinearGradient(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
  g.addColorStop(0, "rgba(255,255,255,0.96)");
  g.addColorStop(0.5, "rgba(214,226,240,0.92)");
  g.addColorStop(1, "rgba(120,150,190,0.9)");
  ctx.fillStyle = g;
  ctx.fill();
  if (glowBlue) {
    ctx.save();
    ctx.clip();
    ctx.fillStyle = gradRadial(ctx, cx, cy + h * 0.2, w * 0.7, [
      [0, rgba("blue", 0.55)],
      [1, rgba("blue", 0)],
    ]);
    ctx.fillRect(cx - w, cy - h, w * 2, h * 2);
    ctx.restore();
  }
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = withAlpha(HEX.white, 0.5);
  rrect(ctx, cx - w / 2, cy - h / 2, w, h, size * 0.1);
  ctx.stroke();
  // keyhole
  ctx.beginPath();
  ctx.arc(cx, cy - h * 0.05, size * 0.07, 0, TAU);
  ctx.fillStyle = rgba("blue", 0.9);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(cx - size * 0.035, cy);
  ctx.lineTo(cx + size * 0.035, cy);
  ctx.lineTo(cx + size * 0.02, cy + h * 0.28);
  ctx.lineTo(cx - size * 0.02, cy + h * 0.28);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/** bioluminescent deep-sea creature (R-SCN-04) */
export function drawCreature(ctx: Ctx, cx: number, cy: number, size: number, color: string, alpha = 1, t = 0) {
  const hex = color === "orange" ? HEX.orange : HEX.blue;
  ctx.save();
  ctx.globalAlpha = alpha;
  const rx = size / 2;
  const ry = rx * (0.62 + 0.08 * Math.sin(t * 2.2));
  ctx.fillStyle = gradRadial(ctx, cx, cy, rx * 1.5, [
    [0, withAlpha(HEX.white, 0.95)],
    [0.3, withAlpha(hex, 0.8)],
    [1, withAlpha(hex, 0)],
  ]);
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx * 1.5, ry * 1.5, 0, 0, TAU);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, 0, 0, TAU);
  ctx.fillStyle = withAlpha(hex, 0.55);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = withAlpha(HEX.white, 0.55);
  ctx.stroke();
  // tentacles
  for (let i = 0; i < 5; i++) {
    const a = (i / 4 - 0.5) * 1.5;
    ctx.beginPath();
    ctx.moveTo(cx + Math.sin(a) * rx * 0.5, cy + ry * 0.8);
    ctx.quadraticCurveTo(
      cx + Math.sin(a) * rx * 1.1 + Math.sin(t * 3 + i) * 6,
      cy + ry * 1.8,
      cx + Math.sin(a) * rx * 0.7 + Math.sin(t * 2.4 + i) * 10,
      cy + ry * 2.6,
    );
    ctx.lineWidth = 2;
    ctx.strokeStyle = withAlpha(hex, 0.5);
    ctx.stroke();
  }
  ctx.restore();
}

/** speedometer arc 210 deg -> -30 deg (R-SCN-05) */
export function drawGauge(ctx: Ctx, cx: number, cy: number, r: number, value: number, alpha = 1, ticks = 24) {
  const a0 = (210 * Math.PI) / 180;
  const a1 = (-30 * Math.PI) / 180;
  void a0;
  void a1;
  ctx.save();
  ctx.globalAlpha = alpha;
  // track
  ctx.beginPath();
  const sweepStart = (210 * Math.PI) / 180;
  const sweepEnd = (330 * Math.PI) / 180; // 210 deg -> -30 deg going clockwise through 270/0
  ctx.arc(cx, cy, r, sweepStart, sweepEnd, false);
  stroke(ctx, 14, HEX.white, 0.16);
  ctx.stroke();
  // ticks
  for (let i = 0; i <= ticks; i++) {
    const a = lerp(sweepStart, sweepEnd, i / ticks);
    const long = i % 4 === 0;
    const r0 = r - (long ? 26 : 14);
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
    ctx.lineTo(cx + Math.cos(a) * (r - 4), cy + Math.sin(a) * (r - 4));
    stroke(ctx, long ? 4 : 2, HEX.white, long ? 0.55 : 0.25);
    ctx.stroke();
  }
  // value arc
  const av = lerp(sweepStart, sweepEnd, clamp01(value));
  ctx.beginPath();
  ctx.arc(cx, cy, r, sweepStart, av, false);
  ctx.strokeStyle = gradBO(ctx, cx - r, cy, cx + r, cy); // palette-safe ramp (D-08)
  ctx.lineWidth = 14;
  ctx.lineCap = "round";
  ctx.stroke();
  ctx.restore();
}

export function drawNeedle(ctx: Ctx, cx: number, cy: number, len: number, value: number, alpha = 1) {
  const sweepStart = (210 * Math.PI) / 180;
  const sweepEnd = (330 * Math.PI) / 180;
  const a = lerp(sweepStart, sweepEnd, clamp01(value));
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.moveTo(cx - Math.cos(a) * 28, cy - Math.sin(a) * 28);
  ctx.lineTo(cx + Math.cos(a) * len, cy + Math.sin(a) * len);
  stroke(ctx, 8, HEX.orange, 1);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(cx, cy, 14, 0, TAU);
  ctx.fillStyle = HEX.white;
  ctx.fill();
  ctx.restore();
}

/** heart = two circles + a triangle (R-SCN-08) */
export function drawHeart(ctx: Ctx, cx: number, cy: number, size: number, alpha = 1, color = HEX.white) {
  const s = size;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(cx - s * 0.24, cy - s * 0.16, s * 0.26, 0, TAU);
  ctx.arc(cx + s * 0.24, cy - s * 0.16, s * 0.26, 0, TAU);
  ctx.moveTo(cx - s * 0.47, cy - s * 0.06);
  ctx.lineTo(cx + s * 0.47, cy - s * 0.06);
  ctx.lineTo(cx, cy + s * 0.46);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.restore();
}

/** perfect circle glyph (R-SCN-07) */
export function drawRingGlyph(ctx: Ctx, cx: number, cy: number, r: number, alpha = 1, sweep = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + TAU * clamp01(sweep));
  stroke(ctx, 10, HEX.orange, 1);
  ctx.stroke();
  ctx.restore();
}

/** planet: blue disk + 2 px orange atmosphere rim (R-SCN-06) */
export function drawPlanet(ctx: Ctx, cx: number, cy: number, r: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, TAU);
  ctx.fillStyle = gradRadial(ctx, cx - r * 0.3, cy - r * 0.35, r * 1.5, [
    [0, withAlpha(HEX.white, 0.85)],
    [0.22, withAlpha(HEX.blue, 0.95)],
    [0.72, "rgba(16,32,58,1)"],
    [1, HEX.black],
  ]);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = rgba("orange", 0.9);
  ctx.stroke();
  ctx.restore();
}

/** meteor head + trail (R-SCN-06) */
export function drawMeteor(ctx: Ctx, x0: number, y0: number, x1: number, y1: number, p: number, alpha = 1, tail = 260) {
  const x = lerp(x0, x1, clamp01(p));
  const y = lerp(y0, y1, clamp01(p));
  const dx = x1 - x0;
  const dy = y1 - y0;
  const len = Math.hypot(dx, dy) || 1;
  const ux = dx / len;
  const uy = dy / len;
  ctx.save();
  ctx.globalAlpha = alpha;
  const g = ctx.createLinearGradient(x - ux * tail, y - uy * tail, x, y);
  g.addColorStop(0, rgba("orange", 0));
  g.addColorStop(0.6, rgba("orange", 0.45));
  g.addColorStop(1, withAlpha(HEX.white, 0.95));
  ctx.strokeStyle = g;
  ctx.lineWidth = 12;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x - ux * tail, y - uy * tail);
  ctx.lineTo(x, y);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(x, y, 16, 0, TAU);
  ctx.fillStyle = gradRadial(ctx, x, y, 40, [
    [0, withAlpha(HEX.white, 1)],
    [0.4, rgba("orange", 0.9)],
    [1, rgba("orange", 0)],
  ]);
  ctx.fill();
  ctx.restore();
  return { x, y };
}

/** telescope icon: tube (rectangle) on a tripod (two lines) — R-VIS-11 / R-SCN-09 */
export function drawTelescope(ctx: Ctx, cx: number, cy: number, h: number, p: number, alpha = 1) {
  const pr = clamp01(p);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(cx, cy);
  // tripod: two lines
  if (pr > 0.55) {
    const k = clamp01((pr - 0.55) / 0.45);
    ctx.beginPath();
    ctx.moveTo(0, h * 0.05);
    ctx.lineTo(-h * 0.34 * k, h * 0.5 * k);
    ctx.moveTo(0, h * 0.05);
    ctx.lineTo(h * 0.34 * k, h * 0.5 * k);
    stroke(ctx, STROKE, HEX.white, 0.9);
    ctx.stroke();
  }
  // tube: rectangle, tilted
  ctx.save();
  ctx.rotate(-0.36);
  const tw = h * 0.72 * clamp01(pr / 0.6);
  rrect(ctx, -tw * 0.35, -h * 0.13, tw, h * 0.26, 6);
  ctx.fillStyle = rgba("orange", 0.92);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = withAlpha(HEX.white, 0.6);
  ctx.stroke();
  ctx.restore();
  ctx.restore();
}

/** orange check circle (R-SCN-03) */
export function drawCheck(ctx: Ctx, cx: number, cy: number, r: number, p: number, alpha = 1) {
  const pr = clamp01(p);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(cx, cy, r * lerp(0.6, 1, pr), 0, TAU);
  ctx.fillStyle = rgba("orange", 0.22 * pr);
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.strokeStyle = rgba("orange", pr);
  ctx.stroke();
  if (pr > 0.35) {
    const k = clamp01((pr - 0.35) / 0.65);
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.42, cy + r * 0.02);
    ctx.lineTo(cx - r * 0.42 + r * 0.34 * Math.min(1, k * 2), cy + r * 0.02 + r * 0.32 * Math.min(1, k * 2));
    if (k > 0.5) ctx.lineTo(cx - r * 0.08 + r * 0.52 * (k - 0.5) * 2, cy + r * 0.34 - r * 0.72 * (k - 0.5) * 2);
    stroke(ctx, 5, HEX.white, k);
    ctx.stroke();
  }
  ctx.restore();
}

/** snail = spiral arc (R-SCN-05) */
export function drawSnail(ctx: Ctx, cx: number, cy: number, s: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  for (let i = 0; i <= 220; i++) {
    const a = (i / 220) * TAU * 2.4;
    const r = 6 + (i / 220) * s * 0.42;
    const x = cx + Math.cos(a) * r;
    const y = cy + Math.sin(a) * r * 0.9;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  stroke(ctx, STROKE, HEX.white, 0.95);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(cx + s * 0.42, cy + s * 0.3);
  ctx.lineTo(cx - s * 0.5, cy + s * 0.3);
  ctx.stroke();
  ctx.restore();
}

/** cheetah = three dots in a trail + a wedge (R-SCN-05) */
export function drawCheetah(ctx: Ctx, cx: number, cy: number, s: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(cx - s * 0.55 + i * s * 0.22, cy + Math.sin(i * 1.4) * s * 0.06, s * (0.05 + i * 0.025), 0, TAU);
    ctx.fillStyle = withAlpha(HEX.white, 0.35 + i * 0.25);
    ctx.fill();
  }
  ctx.beginPath();
  ctx.moveTo(cx - s * 0.28, cy - s * 0.16);
  ctx.lineTo(cx + s * 0.5, cy);
  ctx.lineTo(cx - s * 0.28, cy + s * 0.16);
  ctx.closePath();
  ctx.fillStyle = rgba("orange", 0.95);
  ctx.fill();
  ctx.restore();
}

/** rocket = triangle on a rectangle (R-SCN-05) */
export function drawRocket(ctx: Ctx, cx: number, cy: number, s: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.rotate(0);
  rrect(ctx, cx - s * 0.12, cy - s * 0.2, s * 0.24, s * 0.5, 8);
  ctx.fillStyle = HEX.white;
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(cx - s * 0.16, cy - s * 0.2);
  ctx.lineTo(cx, cy - s * 0.55);
  ctx.lineTo(cx + s * 0.16, cy - s * 0.2);
  ctx.closePath();
  ctx.fillStyle = rgba("orange", 1);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(cx - s * 0.09, cy + s * 0.3);
  ctx.lineTo(cx, cy + s * 0.62);
  ctx.lineTo(cx + s * 0.09, cy + s * 0.3);
  ctx.closePath();
  ctx.fillStyle = rgba("blue", 0.9);
  ctx.fill();
  ctx.restore();
}

/** light beam = vertical gradient line (R-SCN-05) */
export function drawBeam(ctx: Ctx, cx: number, cy: number, s: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  const g = ctx.createLinearGradient(cx, cy - s * 0.6, cx, cy + s * 0.6);
  g.addColorStop(0, withAlpha(HEX.white, 0));
  g.addColorStop(0.5, withAlpha(HEX.white, 0.95));
  g.addColorStop(1, withAlpha(HEX.white, 0));
  ctx.fillStyle = g;
  ctx.fillRect(cx - s * 0.05, cy - s * 0.6, s * 0.1, s * 1.2);
  ctx.beginPath();
  ctx.arc(cx, cy, s * 0.12, 0, TAU);
  ctx.fillStyle = rgba("orange", 0.9);
  ctx.fill();
  ctx.restore();
}

/** human silhouette: circle head + rounded rectangle body (R-SCN-09) */
export function drawHuman(ctx: Ctx, cx: number, cy: number, h: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(cx, cy - h * 0.32, h * 0.16, 0, TAU);
  ctx.fillStyle = HEX.white;
  ctx.fill();
  rrect(ctx, cx - h * 0.16, cy - h * 0.1, h * 0.32, h * 0.6, h * 0.15);
  ctx.fill();
  ctx.restore();
}

/** building: stacked rectangles (R-SCN-09) */
export function drawBuilding(ctx: Ctx, cx: number, cy: number, h: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  const rows = 5;
  for (let i = 0; i < rows; i++) {
    const w = h * (0.62 - i * 0.07);
    const y = cy + h * 0.5 - ((i + 1) * h) / rows;
    rrect(ctx, cx - w / 2, y, w, h / rows - 4, 4);
    ctx.fillStyle = i % 2 ? withAlpha(HEX.white, 0.85) : rgba("blue", 0.8);
    ctx.fill();
  }
  ctx.restore();
}

/** mountain: triangle (R-SCN-09) */
export function drawMountain(ctx: Ctx, cx: number, cy: number, h: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.moveTo(cx - h * 0.62, cy + h * 0.42);
  ctx.lineTo(cx, cy - h * 0.48);
  ctx.lineTo(cx + h * 0.62, cy + h * 0.42);
  ctx.closePath();
  ctx.fillStyle = withAlpha(HEX.white, 0.9);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(cx - h * 0.18, cy - h * 0.2);
  ctx.lineTo(cx, cy - h * 0.48);
  ctx.lineTo(cx + h * 0.18, cy - h * 0.2);
  ctx.closePath();
  ctx.fillStyle = rgba("orange", 0.85);
  ctx.fill();
  ctx.restore();
}

/** sun: orange disk with a white core (R-SCN-09) */
export function drawSun(ctx: Ctx, cx: number, cy: number, r: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, TAU);
  ctx.fillStyle = gradRadial(ctx, cx, cy, r, [
    [0, withAlpha(HEX.white, 1)],
    [0.35, rgba("orange", 0.95)],
    [1, rgba("orange", 0.35)],
  ]);
  ctx.fill();
  ctx.restore();
}

/** small flame: teardrop path (R-VIS-11) */
export function drawFlame(ctx: Ctx, cx: number, cy: number, s: number, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.moveTo(cx, cy - s * 0.55);
  ctx.bezierCurveTo(cx + s * 0.42, cy - s * 0.1, cx + s * 0.3, cy + s * 0.5, cx, cy + s * 0.5);
  ctx.bezierCurveTo(cx - s * 0.3, cy + s * 0.5, cx - s * 0.42, cy - s * 0.1, cx, cy - s * 0.55);
  ctx.closePath();
  ctx.fillStyle = gradRadial(ctx, cx, cy + s * 0.1, s * 0.6, [
    [0, withAlpha(HEX.white, 0.95)],
    [1, rgba("orange", 0.9)],
  ]);
  ctx.fill();
  ctx.restore();
}

export const ORBIT_SPRITES: Record<string, (ctx: Ctx, cx: number, cy: number, s: number, t: number) => void> = {
  coin: (c, x, y, s, t) => drawCoin(c, x, y, s, t * 2.4, 1, "orange"),
  lock: (c, x, y, s) => drawLock(c, x, y, s, 1, false),
  creature: (c, x, y, s, t) => drawCreature(c, x, y, s, "blue", 1, t),
  gauge: (c, x, y, s) => drawGauge(c, x, y, s * 0.45, 0.72, 1, 12),
  heart: (c, x, y, s) => drawHeart(c, x, y, s, 1),
  ring: (c, x, y, s) => drawRingGlyph(c, x, y, s * 0.4, 1, 1),
  planet: (c, x, y, s) => drawPlanet(c, x, y, s * 0.42, 1),
  meteor: (c, x, y, s) => drawMeteor(c, x - s * 0.6, y - s * 0.5, x + s * 0.4, y + s * 0.4, 0.6, 1, s * 0.9),
};
