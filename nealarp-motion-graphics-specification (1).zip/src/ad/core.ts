// ============================================================================
// nealarp-ad / core — paint primitives shared by all scenes.
// Everything is expressed in the 1920x1080 reference space; the canvas
// transform carries `scale` (1 = 1080p, 2 = 4K).  R-VIS-12
// ============================================================================

import {
  BLOOM_ALPHA,
  BLOOM_BLUR,
  FOCAL,
  GRAIN_OPACITY,
  GRAIN_TILE,
  HEX,
  REF_H,
  REF_W,
  VIGNETTE,
  rgba,
  resolveColor,
  titleFont,
  withAlpha,
} from "./constants";
import { clamp01, lerp } from "./easing";
import { rng } from "./rng";

export interface Caches {
  bg: HTMLCanvasElement | null;
  bgKey: string;
  vignette: HTMLCanvasElement | null;
  vigKey: string;
  grain: HTMLCanvasElement | null;
  glow: HTMLCanvasElement | null;
  glowKey: string;
  tmp: HTMLCanvasElement | null;
  tmpKey: string;
  sprites: Map<string, HTMLCanvasElement>;
  points: Map<string, Float32Array>;
  supportsFilter: boolean;
}

export interface FrameCtx {
  ctx: CanvasRenderingContext2D;
  glow: CanvasRenderingContext2D | null;
  scale: number;
  t: number;
  w: number;
  h: number;
  caches: Caches;
}

export function makeCaches(): Caches {
  const probe = document.createElement("canvas").getContext("2d");
  let supportsFilter = false;
  if (probe) {
    try {
      probe.filter = "blur(2px)";
      supportsFilter = probe.filter === "blur(2px)";
      probe.filter = "none";
    } catch {
      supportsFilter = false;
    }
  }
  return {
    bg: null,
    bgKey: "",
    vignette: null,
    vigKey: "",
    grain: null,
    glow: null,
    glowKey: "",
    tmp: null,
    tmpKey: "",
    sprites: new Map(),
    points: new Map(),
    supportsFilter,
  };
}

export function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.round(w));
  c.height = Math.max(1, Math.round(h));
  return c;
}

// ---------------------------------------------------------------- background
/** R-VIS-01 #0a0a0a + radial haze to #0f172a at 40 %. Cached (R-PERF-01). */
function buildBackground(w: number, h: number): HTMLCanvasElement {
  const c = makeCanvas(w, h);
  const g = c.getContext("2d")!;
  g.fillStyle = HEX.black;
  g.fillRect(0, 0, w, h);
  const r = Math.hypot(w, h) * 0.5;
  const grad = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, r);
  grad.addColorStop(0, withAlpha(HEX.haze, 0.4));
  grad.addColorStop(0.55, withAlpha(HEX.haze, 0.18));
  grad.addColorStop(1, withAlpha(HEX.haze, 0));
  g.fillStyle = grad;
  g.fillRect(0, 0, w, h);
  return c;
}

/** R-VIS-08 radial vignette: 0 % centre -> 25 % black corners. Cached. */
function buildVignette(w: number, h: number): HTMLCanvasElement {
  const c = makeCanvas(w, h);
  const g = c.getContext("2d")!;
  const r = Math.hypot(w, h) * 0.5;
  const grad = g.createRadialGradient(w / 2, h / 2, r * 0.28, w / 2, h / 2, r);
  grad.addColorStop(0, "rgba(0,0,0,0)");
  grad.addColorStop(0.6, `rgba(0,0,0,${(VIGNETTE * 0.35).toFixed(3)})`);
  grad.addColorStop(1, `rgba(0,0,0,${VIGNETTE})`);
  g.fillStyle = grad;
  g.fillRect(0, 0, w, h);
  return c;
}

/** R-VIS-07 one seeded 512x512 grayscale tile, generated once. */
function buildGrain(): HTMLCanvasElement {
  const c = makeCanvas(GRAIN_TILE, GRAIN_TILE);
  const g = c.getContext("2d")!;
  const img = g.createImageData(GRAIN_TILE, GRAIN_TILE);
  const r = rng(7);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = 110 + Math.floor(r() * 90);
    img.data[i] = v;
    img.data[i + 1] = v;
    img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return c;
}

export function ensureGlow(fc: FrameCtx): CanvasRenderingContext2D | null {
  if (!fc.caches.supportsFilter) return fc.glow; // still usable, just no blur pass
  const key = `${fc.w}x${fc.h}`;
  if (!fc.caches.glow || fc.caches.glowKey !== key) {
    fc.caches.glow = makeCanvas(fc.w / 2, fc.h / 2);
    fc.caches.glowKey = key;
  }
  const g = fc.caches.glow.getContext("2d")!;
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.clearRect(0, 0, fc.caches.glow.width, fc.caches.glow.height);
  g.setTransform(fc.scale / 2, 0, 0, fc.scale / 2, 0, 0);
  return g;
}

// ------------------------------------------------------------------ overlays
export function drawBackground(fc: FrameCtx) {
  const { caches, w, h, ctx } = fc;
  const key = `${w}x${h}`;
  if (!caches.bg || caches.bgKey !== key) {
    caches.bg = buildBackground(w, h);
    caches.bgKey = key;
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.drawImage(caches.bg, 0, 0);
  ctx.setTransform(fc.scale, 0, 0, fc.scale, 0, 0);
}

export function drawVignette(fc: FrameCtx) {
  const { caches, w, h, ctx } = fc;
  const key = `${w}x${h}`;
  if (!caches.vignette || caches.vigKey !== key) {
    caches.vignette = buildVignette(w, h);
    caches.vigKey = key;
  }
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.drawImage(caches.vignette, 0, 0);
  ctx.restore();
}

/** R-VIS-05 bloom: additive composite of the half-scale glow buffer. */
export function compositeBloom(fc: FrameCtx) {
  const glowCanvas = fc.caches.glow;
  if (!glowCanvas || !fc.glow) return;
  const { ctx } = fc;
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalCompositeOperation = "lighter";
  ctx.globalAlpha = BLOOM_ALPHA;
  if (fc.caches.supportsFilter) ctx.filter = `blur(${(BLOOM_BLUR * fc.scale * 0.5).toFixed(2)}px)`;
  ctx.drawImage(glowCanvas, 0, 0, fc.w, fc.h);
  ctx.filter = "none";
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";
  ctx.restore();
}

/** R-VIS-07 grain, tiled with a per-frame seeded offset at 3.5 %. */
export function drawGrain(fc: FrameCtx, frame: number) {
  if (!fc.caches.grain) fc.caches.grain = buildGrain();
  const tile = fc.caches.grain;
  const { ctx } = fc;
  const r = rng(7 + frame * 7919);
  const ox = Math.floor(r() * GRAIN_TILE) * fc.scale;
  const oy = Math.floor(r() * GRAIN_TILE) * fc.scale;
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = GRAIN_OPACITY;
  ctx.globalCompositeOperation = "overlay";
  for (let x = -ox; x < fc.w; x += GRAIN_TILE * fc.scale) {
    for (let y = -oy; y < fc.h; y += GRAIN_TILE * fc.scale) {
      ctx.drawImage(tile, x, y, GRAIN_TILE * fc.scale, GRAIN_TILE * fc.scale);
    }
  }
  ctx.globalCompositeOperation = "source-over";
  ctx.globalAlpha = 1;
  ctx.restore();
}

// --------------------------------------------------------------------- paths
export function rrect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.arcTo(x + w, y, x + w, y + rr, rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr);
  ctx.lineTo(x + rr, y + h);
  ctx.arcTo(x, y + h, x, y + h - rr, rr);
  ctx.lineTo(x, y + rr);
  ctx.arcTo(x, y, x + rr, y, rr);
  ctx.closePath();
}

/** R-VIS-03 default gradient: blue at 0 % -> orange at 100 %.
 *  D-08: the ramp is routed through two near-white bridge stops so that no
 *  intermediate pixel leaves the hue windows of R-VIS-02 / R-VER-06 (a direct
 *  blue->orange lerp passes through ~10 deg mud at 35 % saturation).
 *  Endpoints are exactly #3b82f6 and #f97316. */
export const RAMP: [number, [number, number, number]][] = [
  [0, [59, 130, 246]],
  [0.42, [137, 181, 250]],
  [0.58, [252, 182, 133]],
  [1, [249, 115, 22]],
];

export function rampColor(p: number, alpha = 1): string {
  const t = clamp01(p);
  for (let i = 0; i < RAMP.length - 1; i++) {
    const [p0, c0] = RAMP[i];
    const [p1, c1] = RAMP[i + 1];
    if (t <= p1 || i === RAMP.length - 2) {
      const k = p1 === p0 ? 0 : (t - p0) / (p1 - p0);
      const c = c0.map((v, j) => Math.round(lerp(v, c1[j], clamp01(k))));
      return alpha >= 1 ? `rgb(${c[0]},${c[1]},${c[2]})` : `rgba(${c[0]},${c[1]},${c[2]},${alpha})`;
    }
  }
  return HEX.orange;
}

export function gradBO(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  for (const [p, c] of RAMP) g.addColorStop(p, `rgb(${c[0]},${c[1]},${c[2]})`);
  return g;
}

export function gradBORadial(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, alpha = 1) {
  const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(0.001, r));
  g.addColorStop(0, withAlpha(HEX.white, alpha));
  g.addColorStop(0.28, rampColor(0.18, alpha));
  g.addColorStop(0.62, rampColor(0.62, alpha));
  g.addColorStop(1, rampColor(1, alpha * 0.9));
  return g;
}

export function gradRadial(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  stops: [number, string][],
) {
  const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(0.001, r));
  for (const [o, c] of stops) g.addColorStop(clamp01(o), c);
  return g;
}

/** R-VIS-04 glass panel: backdrop blur on a 1/4-scale copy, white 10 % fill,
 *  1 px white 25 % border, inner shadow 20 % black (0,4) blur 12. */
export function glass(fc: FrameCtx, x: number, y: number, w: number, h: number, r: number, alpha = 1, blurPx = 20) {
  const { ctx, scale } = fc;
  ctx.save();
  rrect(ctx, x, y, w, h, r);
  ctx.clip();

  const tw = Math.max(2, Math.round((w * scale) / 4));
  const th = Math.max(2, Math.round((h * scale) / 4));
  const key = `${tw}x${th}`;
  if (!fc.caches.tmp || fc.caches.tmpKey !== key) {
    fc.caches.tmp = makeCanvas(tw, th);
    fc.caches.tmpKey = key;
  }
  const tmp = fc.caches.tmp;
  const tc = tmp.getContext("2d")!;
  tc.setTransform(1, 0, 0, 1, 0, 0);
  tc.clearRect(0, 0, tw, th);
  if (fc.caches.supportsFilter) tc.filter = `blur(${((blurPx * scale) / 4).toFixed(2)}px)`;
  tc.drawImage(
    ctx.canvas,
    Math.round(x * scale),
    Math.round(y * scale),
    Math.round(w * scale),
    Math.round(h * scale),
    0,
    0,
    tw,
    th,
  );
  tc.filter = "none";
  ctx.globalAlpha = alpha;
  ctx.drawImage(tmp, x, y, w, h);
  ctx.globalAlpha = 1;

  ctx.fillStyle = rgba("white", 0.1 * alpha);
  rrect(ctx, x, y, w, h, r);
  ctx.fill();

  // inner shadow (0,4) blur 12 at 20 % black
  ctx.save();
  rrect(ctx, x, y, w, h, r);
  ctx.clip();
  ctx.shadowColor = "rgba(0,0,0,0.20)";
  ctx.shadowOffsetY = 4;
  ctx.shadowBlur = 12;
  ctx.lineWidth = 10;
  ctx.strokeStyle = "rgba(0,0,0,1)";
  rrect(ctx, x - 5, y - 5, w + 10, h + 10, r + 5);
  ctx.stroke();
  ctx.restore();
  ctx.restore();

  ctx.save();
  ctx.lineWidth = 1;
  ctx.strokeStyle = rgba("white", 0.25 * alpha);
  rrect(ctx, x + 0.5, y + 0.5, w - 1, h - 1, r);
  ctx.stroke();
  ctx.restore();
}

// ------------------------------------------------------------------ geometry
/** R-VIS-09 perspective projection: screen = c + p * f / (f + z). */
export function project(x: number, y: number, z: number, cx = REF_W / 2, cy = REF_H / 2, f = FOCAL) {
  const s = f / (f + Math.max(-f + 1, z));
  return { x: cx + x * s, y: cy + y * s, s };
}

/** deterministic camera shake inside [start,end] */
export function shakeAt(t: number, start: number, end: number, amp: number, freq: number): [number, number] {
  if (t < start || t >= end) return [0, 0];
  const p = 1 - (t - start) / (end - start);
  const a = amp * p * p;
  return [
    Math.sin(t * freq * 6.283) * a + Math.sin(t * freq * 2.7 * 6.283) * a * 0.4,
    Math.cos(t * freq * 5.1 * 6.283) * a * 0.8,
  ];
}

/** R-VIS-05 anamorphic flare: horizontal streak `len` x `height` + glow. */
export function flare(fc: FrameCtx, cx: number, cy: number, len: number, height: number, glowR: number, intensity: number) {
  if (intensity <= 0.001) return;
  const { ctx } = fc;
  const targets: (CanvasRenderingContext2D | null)[] = [ctx, fc.glow];
  for (const g of targets) {
    if (!g) continue;
    g.save();
    g.globalCompositeOperation = "lighter";
    const grad = g.createLinearGradient(cx - len / 2, cy, cx + len / 2, cy);
    grad.addColorStop(0, rgba("blue", 0));
    grad.addColorStop(0.32, rgba("blue", 0.35 * intensity));
    grad.addColorStop(0.5, `rgba(255,255,255,${0.95 * intensity})`);
    grad.addColorStop(0.68, rgba("orange", 0.35 * intensity));
    grad.addColorStop(1, rgba("orange", 0));
    g.fillStyle = grad;
    g.fillRect(cx - len / 2, cy - height / 2, len, height);
    const gg = gradRadial(g, cx, cy, glowR, [
      [0, `rgba(255,255,255,${0.85 * intensity})`],
      [0.35, rgba("blue", 0.3 * intensity)],
      [1, "rgba(0,0,0,0)"],
    ]);
    g.fillStyle = gg;
    g.beginPath();
    g.arc(cx, cy, glowR, 0, Math.PI * 2);
    g.fill();
    g.restore();
  }
}

/** additive glow blob — also feeds the bloom buffer */
export function glowDot(fc: FrameCtx, x: number, y: number, r: number, color: string, alpha: number) {
  const hex = resolveColor(color);
  for (const g of [fc.ctx, fc.glow]) {
    if (!g) continue;
    g.save();
    g.globalCompositeOperation = "lighter";
    g.fillStyle = gradRadial(g, x, y, r, [
      [0, withAlpha(hex, alpha)],
      [0.45, withAlpha(hex, alpha * 0.45)],
      [1, withAlpha(hex, 0)],
    ]);
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
    g.restore();
  }
}

export function line(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  width: number,
  color: string,
  alpha = 1,
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.lineTo(x1, y1);
  ctx.stroke();
  ctx.restore();
}

/** R-SCN-04 style counter: German thousand separators. */
export function formatDE(n: number): string {
  const v = Math.round(n);
  return String(v).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

/** deterministic point sampling of arbitrary artwork (used for the CTA reform) */
export function samplePoints(
  fc: FrameCtx,
  key: string,
  w: number,
  h: number,
  paint: (g: CanvasRenderingContext2D) => void,
  step = 7,
  max = 1500,
): Float32Array {
  const cached = fc.caches.points.get(key);
  if (cached) return cached;
  const s = 1; // sample in true reference units so the reform targets are dense
  const c = makeCanvas(w * s, h * s);
  const g = c.getContext("2d")!;
  g.setTransform(s, 0, 0, s, 0, 0);
  paint(g);
  const data = g.getImageData(0, 0, c.width, c.height).data;
  const pts: number[] = [];
  for (let y = 0; y < c.height; y += step) {
    for (let x = 0; x < c.width; x += step) {
      const a = data[(y * c.width + x) * 4 + 3];
      if (a > 110) pts.push((x / s) as number, y / s);
    }
  }
  const total = pts.length / 2;
  let out: Float32Array;
  if (total > max) {
    const r = rng(7);
    const idx = Array.from({ length: total }, (_, i) => i).sort(() => r() - 0.5).slice(0, max);
    out = new Float32Array(max * 2);
    idx.forEach((src, i) => {
      out[i * 2] = pts[src * 2];
      out[i * 2 + 1] = pts[src * 2 + 1];
    });
  } else {
    out = new Float32Array(pts);
  }
  fc.caches.points.set(key, out);
  return out;
}

/** convenience: white stroke text used for sampling */
export function sampleTextCanvas(g: CanvasRenderingContext2D, text: string, size: number, cx: number, cy: number) {
  g.font = titleFont(size);
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillStyle = "#fff";
  g.fillText(text, cx, cy);
}

export const refCenter = { x: REF_W / 2, y: REF_H / 2 };

export function fadeAlpha(v: number) {
  return clamp01(v);
}

export function softEdge(t: number, a: number, b: number) {
  return clamp01((t - a) / Math.max(1e-6, b - a));
}

export function mix(a: number, b: number, t: number) {
  return lerp(a, b, clamp01(t));
}
