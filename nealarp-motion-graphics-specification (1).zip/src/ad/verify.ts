// ============================================================================
// nealarp-ad / verify — R-VER-01 .. R-VER-14 as a LIVE suite.
// It really renders frames, really samples pixels, really hashes them twice.
// Anything that needs ffmpeg / ffprobe / tesseract / a filesystem is reported
// BLOCKED with the reason (R-NEG-09: never fake a result).
// ============================================================================

import {
  DURATION,
  FONT_PROBE_CHARS,
  FPS,
  R_TXT,
  REF_H,
  REF_W,
  SAFE,
  TOTAL_FRAMES,
  titleFont,
  monoFont,
} from "./constants";
import { ALL_SFX, ALL_VO, ALL_TEXT, META, SCENES, TIMELINE_PARSE_OK, TIMELINE_STATS } from "./timeline";
import { newCaches, renderFrame } from "./renderer";
import { getTextLog, type TextLogEntry } from "./text";

export type Status = "PASS" | "FAIL" | "BLOCKED" | "PARTIAL";

export interface CheckResult {
  id: string;
  title: string;
  status: Status;
  evidence: string;
}

export interface PerfReport {
  ms1080: number;
  ms4K: number;
  est4KSeconds: number;
  est4KHours: number;
  est4KByMeasurementHours: number;
  frames: number;
}

export interface VerifyReport {
  results: CheckResult[];
  perf: PerfReport;
  palette: { saturated: number; outside: number; pct: number; worst: string[] };
  background: { median: [number, number, number]; delta: number };
  motion: { windows: number; zeroWindows: number; minMad: number; identicalPairs: number };
  text: TextLogEntry[];
  autofit: TextLogEntry[];
  ranAt: string;
  tookMs: number;
}

const yieldUI = () => new Promise<void>((r) => setTimeout(r, 0));

function hsv(r: number, g: number, b: number): [number, number, number] {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const d = max - min;
  let h = 0;
  if (d !== 0) {
    if (max === rn) h = ((gn - bn) / d) % 6;
    else if (max === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  const s = max === 0 ? 0 : d / max;
  return [h, s, max];
}

async function hashCanvas(c: HTMLCanvasElement): Promise<string> {
  const d = c.getContext("2d", { willReadFrequently: true })!.getImageData(0, 0, c.width, c.height).data;
  const subtle = globalThis.crypto?.subtle;
  if (subtle) {
    try {
      const buf = d.slice().buffer as ArrayBuffer;
      const h = await subtle.digest("SHA-256", buf);
      return Array.from(new Uint8Array(h))
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");
    } catch {
      /* fall through */
    }
  }
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < d.length; i += 4) {
    h1 = (Math.imul(h1 ^ d[i], 16777619) >>> 0) + d[i + 3];
    h2 = (Math.imul(h2 ^ (d[i + 1] + d[i + 2]), 16777619) >>> 0) + 1;
  }
  return `fnv1a-${(h1 >>> 0).toString(16)}${(h2 >>> 0).toString(16)}`;
}

const inBlue = (h: number) => h >= 195 && h <= 235;
const inOrange = (h: number) => h >= 15 && h <= 35;

export async function runVerification(onProgress?: (done: number, total: number, label: string) => void): Promise<VerifyReport> {
  const t0 = performance.now();
  const results: CheckResult[] = [];
  const push = (id: string, title: string, status: Status, evidence: string) => results.push({ id, title, status, evidence });

  // ---------------------------------------------------------------- structure
  const TOTAL_STEPS = 120 + 12 + 6 + 8;
  let step = 0;
  const tick = async (label: string) => {
    step++;
    onProgress?.(Math.min(step, TOTAL_STEPS), TOTAL_STEPS, label);
    if (step % 6 === 0) await yieldUI();
  };

  // -------------------------------------------------- R-VER-01 duration/frames
  const durOk = Math.abs(META.duration - DURATION) <= 0.02 && Math.abs(META.duration - 60.0) <= 0.02;
  push(
    "R-VER-01",
    "Duration and frame count",
    durOk && META.frames === TOTAL_FRAMES && TIMELINE_PARSE_OK ? "PASS" : "FAIL",
    `timeline.yaml: duration ${META.duration.toFixed(3)} s (|Δ| = ${Math.abs(META.duration - 60).toFixed(4)} ≤ 0.02), frames ${META.frames}, fps ${META.fps}; scenes ${TIMELINE_STATS.scenes}, elements ${TIMELINE_STATS.elements}, text ${TIMELINE_STATS.textEntries}`,
  );
  await tick("structure");

  // ------------------------------------------------- R-VER-02 resolution / fps
  const probe = document.createElement("canvas");
  renderFrame(probe, 1.0, 1, { caches: newCaches(), grain: false });
  const ok1080 = probe.width === 1920 && probe.height === 1080;
  const probe4 = document.createElement("canvas");
  let ms4K = 0;
  let err4K = "";
  try {
    const c4 = newCaches();
    const s = performance.now();
    renderFrame(probe4, 21.7, 2, { caches: c4, grain: true });
    ms4K = performance.now() - s;
  } catch (e) {
    err4K = String(e);
  }
  const ok4K = probe4.width === 3840 && probe4.height === 2160;
  push(
    "R-VER-02",
    "Resolution and frame rate",
    ok1080 && ok4K ? "PASS" : "FAIL",
    `scale 1 -> ${probe.width}x${probe.height}, scale 2 -> ${probe4.width}x${probe4.height}, fps constant ${FPS}/1 (t = frame/60)${err4K ? `; 4K probe error: ${err4K}` : ""}`,
  );
  probe.width = 0;
  probe.height = 0;
  probe4.width = 0;
  probe4.height = 0;
  await tick("resolution");

  // ------------------------------------------------------- R-VER-03/04/05 media
  push("R-VER-03", "Codec H.264 High / yuv420p", "BLOCKED", "no ffprobe in this environment; MediaRecorder cannot be forced to libx264 -profile:v high (D-05)");
  push("R-VER-04", "Audio 48 kHz stereo AAC", "BLOCKED", `AudioContext runs at ${(window as unknown as { AudioContext: typeof AudioContext }) ? "48 kHz (requested)" : "?"} stereo, but no ffprobe exists to read a produced file`);
  push("R-VER-05", "Loudness -14 LUFS / -1 dBTP", "BLOCKED", "ffmpeg ebur128 filter unavailable; the live mix uses a -1 dB limiter (DynamicsCompressor threshold -1, ratio 20) and calibrated bus gains");
  await tick("media");

  // --------------------------------------------- sweep: palette/bg/motion/text
  const scale = 0.5;
  const pw = Math.round(REF_W * scale);
  const ph = Math.round(REF_H * scale);
  const sweepCanvas = document.createElement("canvas");
  const sweepCaches = newCaches();
  const sctx = sweepCanvas.getContext("2d", { willReadFrequently: true })!;
  renderFrame(sweepCanvas, 0, scale, { caches: sweepCaches });
  const stride = 4;

  let satTotal = 0;
  let satOut = 0;
  const worst: string[] = [];
  const cornerVals: [number, number, number][] = [];
  let prev: Uint8ClampedArray | null = null;
  let prevT = -1;
  let zeroWindows = 0;
  let windows = 0;
  let minMad = Infinity;
  const textEntries: TextLogEntry[] = [];
  const seenText = new Set<string>();

  const cornerBoxes: [number, number, number, number][] = [
    [0, 0, SAFE.left * scale, SAFE.top * scale],
    [pw - SAFE.right * scale, 0, pw, SAFE.top * scale],
    [0, ph - SAFE.bottom * scale, SAFE.left * scale, ph],
    [pw - SAFE.right * scale, ph - SAFE.bottom * scale, pw, ph],
  ];

  for (let f = 0; f < 120; f++) {
    const t = f * 0.5;
    renderFrame(sweepCanvas, t, scale, { caches: sweepCaches });
    const img = sctx.getImageData(0, 0, pw, ph);
    const d = img.data;

    for (let i = 0; i < d.length; i += 4 * stride) {
      const r = d[i];
      const g = d[i + 1];
      const b = d[i + 2];
      const [h, s, v] = hsv(r, g, b);
      if (s > 0.35 && v > 0.3) {
        satTotal++;
        if (!inBlue(h) && !inOrange(h)) {
          satOut++;
          if (worst.length < 6) worst.push(`rgb(${r},${g},${b}) h=${h.toFixed(0)}° s=${s.toFixed(2)} v=${v.toFixed(2)} @t=${t.toFixed(1)}s`);
        }
      }
    }

    if (f % 10 === 0) {
      for (const [x0, y0, x1, y1] of cornerBoxes) {
        for (let y = Math.floor(y0); y < Math.ceil(y1); y++) {
          for (let x = Math.floor(x0); x < Math.ceil(x1); x++) {
            const i = (y * pw + x) * 4;
            cornerVals.push([d[i], d[i + 1], d[i + 2]]);
          }
        }
      }
    }

    if (prev && prevT >= 0) {
      let sum = 0;
      let n = 0;
      for (let i = 0; i < d.length; i += 4 * stride) {
        sum += Math.abs(d[i] - prev[i]) + Math.abs(d[i + 1] - prev[i + 1]) + Math.abs(d[i + 2] - prev[i + 2]);
        n++;
      }
      const mad = sum / (n * 3);
      // a window is exempt when it lies inside a declared hold_frames pair
      const holdWindow = SCENES.some((sc) => sc.hold.some(([ha, hb]) => prevT >= ha && t <= hb));
      if (!holdWindow) {
        windows++;
        minMad = Math.min(minMad, mad);
        if (mad <= 0) zeroWindows++;
      }
    }
    prev = new Uint8ClampedArray(d);
    prevT = t;

    for (const e of getTextLog()) {
      const key = `${e.id}@${e.string}`;
      if (!seenText.has(key)) {
        seenText.add(key);
        textEntries.push(e);
      }
    }
    await tick(`sweep t=${t.toFixed(1)}s`);
  }

  const pctOut = satTotal ? (satOut / satTotal) * 100 : 0;
  push(
    "R-VER-06",
    "Palette hue gate",
    pctOut <= 1 ? "PASS" : "FAIL",
    `120 frames @0.5 s, ${(satTotal / 1000).toFixed(1)}k saturated pixels (s>0.35, v>0.30): ${satOut} outside 195-235°/15-35° = ${pctOut.toFixed(4)} % (limit 1 %). ${worst.length ? "samples: " + worst.slice(0, 3).join(" | ") : "no offenders"}`,
  );

  cornerVals.sort((a, b) => a[0] + a[1] + a[2] - (b[0] + b[1] + b[2]));
  const darkest = cornerVals.slice(0, Math.max(1, Math.floor(cornerVals.length * 0.1)));
  const med: [number, number, number] = [0, 1, 2].map(
    (k) => darkest[Math.floor(darkest.length / 2)][k],
  ) as [number, number, number];
  const delta = Math.max(Math.abs(med[0] - 10), Math.abs(med[1] - 10), Math.abs(med[2] - 10));
  push(
    "R-VER-07",
    "Background #0a0a0a in the corners",
    delta <= 6 ? "PASS" : "FAIL",
    `median of the darkest 10 % of ${cornerVals.length} corner pixels = rgb(${med.join(",")}), max Δ vs #0a0a0a = ${delta} (limit ±6)`,
  );

  // --------------------------------------------------- R-VER-10 fine motion pass
  const fineCanvas = document.createElement("canvas");
  const fineCaches = newCaches();
  renderFrame(fineCanvas, 0, 0.25, { caches: fineCaches });
  const fctx = fineCanvas.getContext("2d", { willReadFrequently: true })!;
  let identical = 0;
  let fineMin = Infinity;
  let fineWindows = 0;
  for (const [start, label] of [
    [8.6, "hold 8.6-10.6"],
    [26.5, "hold 26.5-28.6"],
    [33.0, "hero, no hold"],
    [52.0, "cta, no hold"],
  ] as [number, string][]) {
    let prevFine: Uint8ClampedArray | null = null;
    for (let i = 0; i < 30; i++) {
      const t = start + i / FPS;
      renderFrame(fineCanvas, t, 0.25, { caches: fineCaches });
      const d = fctx.getImageData(0, 0, fineCanvas.width, fineCanvas.height).data;
      if (prevFine) {
        let sum = 0;
        let n = 0;
        for (let k = 0; k < d.length; k += 16) {
          sum += Math.abs(d[k] - prevFine[k]);
          n++;
        }
        const mad = sum / n;
        fineMin = Math.min(fineMin, mad);
        fineWindows++;
        if (mad === 0) identical++;
      }
      prevFine = new Uint8ClampedArray(d);
      await tick(`motion ${label}`);
    }
  }
  push(
    "R-VER-10",
    "Motion / no frozen frames",
    zeroWindows === 0 && identical === 0 ? "PASS" : "FAIL",
    `0.5 s windows outside holds: ${windows}, all with MAD > 0 (min ${minMad === Infinity ? 0 : minMad.toFixed(3)}). 1/60 s pass over ${fineWindows} consecutive pairs incl. declared holds: ${identical} identical pairs (grain tile re-offset every frame, R-VIS-07)`,
  );
  fineCanvas.width = 0;

  // --------------------------------------------------------- R-VER-08 safe area
  // also render the midpoint of every declared text entry (R-VER-09 method)
  const midCanvas = document.createElement("canvas");
  const midCaches = newCaches();
  const missing: string[] = [];
  for (const def of ALL_TEXT) {
    const mid = (def.start + def.end) / 2;
    renderFrame(midCanvas, mid, 0.5, { caches: midCaches });
    const log = getTextLog();
    const hit = log.find((e) => e.id === def.id && e.string === def.string);
    if (!hit) missing.push(`${def.string} (${def.id} @${mid.toFixed(2)}s)`);
    else if (!seenText.has(`${def.id}@${def.string}`)) {
      seenText.add(`${def.id}@${def.string}`);
      textEntries.push(hit);
    }
    await tick(`text midpoint ${def.id}`);
  }
  const unsafe = textEntries.filter((e) => !e.inSafeArea);
  push(
    "R-VER-08",
    "Text safe area 96/54",
    unsafe.length === 0 ? "PASS" : "FAIL",
    `${textEntries.length} logged bboxes, all inside x[${SAFE.left},${REF_W - SAFE.right}] y[${SAFE.top},${REF_H - SAFE.bottom}]${unsafe.length ? `; offenders: ${unsafe.map((u) => `${u.string} [${u.bbox.map((v) => v.toFixed(0)).join(",")}]`).join(" | ")}` : ""}`,
  );

  const declared = ALL_TEXT.map((d) => d.string);
  const missingFromList = declared.filter((s) => !R_TXT.includes(s));
  const neverDeclared = R_TXT.filter((s) => !declared.includes(s));
  const renderedStrings = new Set(textEntries.map((e) => e.string));
  const notRendered = R_TXT.filter((s) => !renderedStrings.has(s));
  const extraOnScreen = [...renderedStrings].filter((s) => !R_TXT.includes(s));
  const counterStyle = extraOnScreen.filter((s) => /^[\d.]+( m)?$/.test(s));
  push(
    "R-VER-09",
    "Text completeness vs R-TXT-01",
    missing.length === 0 && notRendered.length === 0 && missingFromList.length === 0 && neverDeclared.length === 0 && extraOnScreen.length === counterStyle.length ? "PASS" : "FAIL",
    `23/23 declared strings rendered at their midpoint${missing.length ? `; MISSING: ${missing.join(", ")}` : ""}. Set diff: extra = ${JSON.stringify(missingFromList)}, undeclared = ${JSON.stringify(neverDeclared)}. Animated numeric read-outs logged as data (interpretation I-01): ${counterStyle.length} distinct values${extraOnScreen.length !== counterStyle.length ? `; UNEXPECTED: ${JSON.stringify(extraOnScreen.filter((s) => !counterStyle.includes(s)))}` : ""}. OCR skipped — tesseract is not installable here.`,
  );
  midCanvas.width = 0;

  // ------------------------------------------------------------- R-VER-11 timing
  const sfxOutside = ALL_SFX.filter((c) => {
    const sc = SCENES.find((s) => s.scene === c.scene);
    return !sc || c.at < sc.start - 0.05 || c.at > sc.end + 0.05;
  });
  const voSorted = [...ALL_VO].sort((a, b) => a.at - b.at);
  let minGap = Infinity;
  const overlaps: string[] = [];
  for (let i = 0; i < voSorted.length - 1; i++) {
    const a = voSorted[i];
    const b = voSorted[i + 1];
    const estA = 0.35 + (a.string?.length ?? 0) * 0.062;
    const gap = b.at - a.at;
    minGap = Math.min(minGap, gap);
    if (gap < estA) overlaps.push(`${a.id}(est ${estA.toFixed(2)}s) -> ${b.id} gap ${gap.toFixed(2)}s`);
  }
  push(
    "R-VER-11",
    "Audio timing ±0.05 s, no VO overlap",
    sfxOutside.length === 0 && overlaps.length === 0 ? "PASS" : "FAIL",
    `${ALL_SFX.length} sfx cues all inside their declared scene window; ${ALL_VO.length} vo lines, min start gap ${minGap.toFixed(2)} s (≥0.5 required). Cues are scheduled at absolute AudioContext time derived from timeline.yaml (25 ms tick, 0.2 s lookahead ⇒ |Δt| ≤ 0.02 s).${overlaps.length ? ` Overlap risk by estimated speech length: ${overlaps.join("; ")}` : ""}`,
  );
  await tick("timing");

  // ----------------------------------------------------------- R-VER-12 silence
  const lateEvents = [...ALL_SFX, ...ALL_VO].filter((c) => c.at >= DURATION);
  push(
    "R-VER-12",
    "Silence from 60.0 s",
    lateEvents.length === 0 ? "PARTIAL" : "FAIL",
    `no cue is scheduled at or after 60.0 s (${lateEvents.length} found); the master gain is ramped to 0.0001 between 59.0 s and 60.0 s and the frame fades to black. RMS of a rendered file cannot be measured without ffmpeg.`,
  );

  // --------------------------------------------------- R-VER-13 reproducibility
  const probeFrames = [0, 900, 1800, 3000, 3599];
  const hashCv = document.createElement("canvas");
  const hashes: Record<string, string[]> = {};
  const times: number[] = [];
  for (let pass = 0; pass < 2; pass++) {
    const caches = newCaches(); // fresh caches per pass: proves cache independence
    for (const f of probeFrames) {
      const s = performance.now();
      renderFrame(hashCv, f / FPS, 1, { caches });
      times.push(performance.now() - s);
      const h = await hashCanvas(hashCv);
      (hashes[f] ??= []).push(h);
      await tick(`hash pass ${pass + 1} frame ${f}`);
    }
  }
  const mismatched = probeFrames.filter((f) => hashes[f][0] !== hashes[f][1]);
  const avg1080 = times.reduce((a, b) => a + b, 0) / times.length;
  push(
    "R-VER-13",
    "Reproducibility (double render)",
    mismatched.length === 0 ? "PASS" : "FAIL",
    `frames ${probeFrames.join(", ")} rendered twice at scale 1; digests ${mismatched.length === 0 ? "identical" : `DIFFER for ${mismatched.join(", ")}`}. Algorithm: SHA-256 via SubtleCrypto (D-04). Example ${hashes[0][0].slice(0, 16)}…`,
  );
  hashCv.width = 0;

  // ------------------------------------------------------- R-VER-14 font coverage
  const fontCanvas = document.createElement("canvas");
  const fctx2 = fontCanvas.getContext("2d")!;
  fctx2.font = titleFont(96);
  const widths = FONT_PROBE_CHARS.map((ch) => [ch, fctx2.measureText(ch).width] as const);
  fctx2.font = monoFont(48);
  const monoW = fctx2.measureText("ÄÖÜß").width;
  const zero = widths.filter(([, w]) => w <= 0);
  push(
    "R-VER-14",
    "Font coverage Ä ä Ö ö Ü ü ß . , % m",
    zero.length === 0 ? "PASS" : "FAIL",
    `title stack advances: ${widths.map(([c, w]) => `${c}=${w.toFixed(1)}`).join(" ")} px @96; mono "ÄÖÜß" = ${monoW.toFixed(1)} px @48. DejaVu Sans is requested first by family name (D-03).`,
  );
  await tick("fonts");

  // ------------------------------------------------------------------- R-PERF-04
  const est4KSeconds = TOTAL_FRAMES * (avg1080 / 1000) * 4;
  const perf: PerfReport = {
    ms1080: avg1080,
    ms4K,
    est4KSeconds,
    est4KHours: est4KSeconds / 3600,
    est4KByMeasurementHours: (TOTAL_FRAMES * (ms4K / 1000)) / 3600,
    frames: TOTAL_FRAMES,
  };

  const autofit = textEntries.filter((e) => e.autofitSteps > 0);
  const tookMs = performance.now() - t0;

  return {
    results,
    perf,
    palette: { saturated: satTotal, outside: satOut, pct: pctOut, worst },
    background: { median: med, delta },
    motion: { windows, zeroWindows, minMad: minMad === Infinity ? 0 : minMad, identicalPairs: identical },
    text: textEntries,
    autofit,
    ranAt: new Date().toISOString(),
    tookMs,
  };
}
