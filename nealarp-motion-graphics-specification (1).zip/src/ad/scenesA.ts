// ============================================================================
// nealarp-ad / scenesA — ACT I (opening) and cuts 1-4 of ACT II.
// Every number comes from timeline.yaml; nothing here invents a time.
// ============================================================================

import { HEX, SEED, Z_MAX, rgba, withAlpha, resolveColor } from "./constants";
import { clamp01, ease, lerp, progress } from "./easing";
import { flare, glass, glowDot, gradRadial, project, rampColor, rrect, shakeAt, type FrameCtx } from "./core";
import { drawLayoutText } from "./text";
import { el, pNum, pStrArr, type El, type Scene } from "./timeline";
import { rng } from "./rng";
import { TAU, drawCheck, drawCoin, drawCreature, drawCheetah, drawBeam, drawGauge, drawNeedle, drawRocket, drawSnail } from "./art";

const P = (t: number, e?: El) => (e ? progress(t, e.start, e.end) : 0);
type Win = { start: number; end: number };
const ON = (t: number, e?: Win | null) => !!e && t >= e.start && t < e.end;
const ramp = (t: number, start: number, dur: number) => clamp01((t - start) / Math.max(1e-6, dur));

// ---------------------------------------------------------------------------
// shared cut decoration: the 0.0-0.2 s pop and the 2.6-3.0 s transition out
// ---------------------------------------------------------------------------
export function drawCutDecor(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  const pop = el(sc, "cut_pop");
  if (ON(t, pop) && pop) {
    const p = ease(pop.ease, P(t, pop));
    const a = pNum(pop, "alpha", 0.2) * (1 - p);
    if (a > 0.002) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = withAlpha(resolveColor(pop.props.color, "white"), a);
      ctx.fillRect(0, 0, 1920, 1080);
      ctx.restore();
    }
  }
}

export function drawCutOut(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  const out = el(sc, "out_wipe");
  if (ON(t, out) && out) {
    const a = pNum(out, "alpha", 0.85) * ease(out.ease, P(t, out));
    ctx.save();
    ctx.fillStyle = rgba("black", a);
    ctx.fillRect(0, 0, 1920, 1080);
    ctx.restore();
  }
}

/** camera shake declared by an element -> translate both buffers */
export function applyShake(fc: FrameCtx, sc: Scene, id: string): () => void {
  const e = el(sc, id);
  if (!e) return () => {};
  const [dx, dy] = shakeAt(fc.t, e.start, e.end, pNum(e, "amp", 10), pNum(e, "freq", 30));
  if (dx === 0 && dy === 0) return () => {};
  fc.ctx.save();
  fc.ctx.translate(dx, dy);
  if (fc.glow) {
    fc.glow.save();
    fc.glow.translate(dx, dy);
  }
  return () => {
    fc.ctx.restore();
    if (fc.glow) fc.glow.restore();
  };
}

/** lower-third title with a 2-3 frame letter stagger + one anamorphic flare
 *  per title reveal (R-SCN-01 pacing, R-VIS-05) */
export function drawCutTitle(fc: FrameCtx, sc: Scene, idPrefix = "title", glow = 0.35) {
  const def = sc.text.find((d) => d.id.startsWith(idPrefix));
  if (!def) return;
  const perLetter = typeof def.props?.letter_stagger === "number" ? (def.props.letter_stagger as number) : 0.034;
  const entry = drawLayoutText(fc, def, sc.scene, {
    reveal: fc.t - def.start,
    perLetter,
    letterDur: 0.26,
    glow,
  });
  if (entry) {
    const fr = 1 - ramp(fc.t, def.start, 0.55);
    if (fr > 0.01) flare(fc, entry.at[0], entry.at[1] - entry.height * 0.45, 1400 * (0.35 + 0.65 * (1 - fr)), 6, 120, 0.3 * fr);
  }
}

/** horizontal light streaks (R-VIS-05) */
export function drawStreaks(fc: FrameCtx, e: El) {
  const { ctx, t } = fc;
  const n = pNum(e, "count", 12);
  const speed = pNum(e, "speed", 300);
  const colors = pStrArr(e, "colors");
  const alpha = pNum(e, "alpha", 0.15);
  const h = pNum(e, "height", 3);
  const r = rng(SEED + 11);
  const fadeIn = clamp01((t - e.start) / 0.5) * clamp01((e.end - t) / 0.5);
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let i = 0; i < n; i++) {
    const y = 40 + r() * 1000;
    const len = 240 + r() * 900;
    const dir = r() > 0.5 ? 1 : -1;
    const v = (((r() * 2600 + dir * speed * t) % 2600) + 2600) % 2600;
    const x = dir > 0 ? v - 400 : 2320 - v;
    const c = resolveColor(colors[i % Math.max(1, colors.length)] ?? "blue", "blue");
    const g = ctx.createLinearGradient(x, y, x + len * dir, y);
    g.addColorStop(0, withAlpha(c, 0));
    g.addColorStop(0.5, withAlpha(c, alpha * fadeIn));
    g.addColorStop(1, withAlpha(c, 0));
    ctx.fillStyle = g;
    ctx.fillRect(Math.min(x, x + len * dir), y, Math.abs(len * dir), h);
  }
  ctx.restore();
}

/** one off-screen flicker per act (R-VIS-05) */
export function drawFlicker(fc: FrameCtx, e: El) {
  const { ctx, t } = fc;
  if (!ON(t, e)) return;
  const p = P(t, e);
  const blinks = pNum(e, "blinks", 3);
  const blink = Math.sin(p * blinks * Math.PI) > -0.1 ? 1 : 0.18;
  const inten = pNum(e, "intensity", 0.1) * blink * Math.sin(Math.PI * clamp01(p));
  if (inten <= 0.002) return;
  const left = pStrArrSide(e);
  const c = resolveColor(e.props.color, "blue");
  const g = ctx.createLinearGradient(left ? 0 : 1920, 0, left ? 760 : 1160, 0);
  g.addColorStop(0, withAlpha(c, inten));
  g.addColorStop(1, withAlpha(c, 0));
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 1920, 1080);
  ctx.restore();
}
const pStrArrSide = (e: El) => String(e.props.side ?? "left") === "left";

// ===========================================================================
// ACT I — OPENING 0.0-8.0  (R-SCN-01)
// ===========================================================================
const TUNNEL_N = 1200;
let tunnelCache: { a: Float32Array; rad: Float32Array; z: Float32Array; s: Float32Array } | null = null;
function tunnelData() {
  if (tunnelCache) return tunnelCache;
  const r = rng(SEED);
  const a = new Float32Array(TUNNEL_N);
  const rad = new Float32Array(TUNNEL_N);
  const z = new Float32Array(TUNNEL_N);
  const s = new Float32Array(TUNNEL_N);
  for (let i = 0; i < TUNNEL_N; i++) {
    a[i] = r() * TAU;
    rad[i] = 220 + Math.pow(r(), 0.6) * 1500;
    z[i] = r() * Z_MAX;
    s[i] = r();
  }
  tunnelCache = { a, rad, z, s };
  return tunnelCache;
}

export function drawOpening(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  const tun = el(sc, "tunnel_particles");

  if (ON(t, tun) && tun?.center) {
    const d = tunnelData();
    const n = Math.min(TUNNEL_N, Math.round(pNum(tun, "count", 1200)));
    const speed = pNum(tun, "speed", 620);
    const c = ease(tun.ease, ramp(t, pNum(tun, "converge_start", 1.4), pNum(tun, "converge_end", 2.4) - pNum(tun, "converge_start", 1.4)));
    const [ccx, ccy] = tun.center;
    const inFade = clamp01(t / 0.35);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < n; i++) {
      const ang = d.a[i];
      let z = d.z[i] - speed * t * (0.55 + 0.9 * d.s[i]);
      z = ((z % Z_MAX) + Z_MAX) % Z_MAX;
      const rad = d.rad[i] * (1 - c * 0.95);
      const p = project(Math.cos(ang) * rad, Math.sin(ang) * rad * 0.62, z, ccx, ccy);
      const size = Math.max(0.7, (1.6 + 5.4 * d.s[i]) * p.s);
      const near = 1 - z / Z_MAX;
      const alpha = clamp01(0.1 + 0.8 * near) * clamp01(0.3 + p.s) * inFade * (1 - c * 0.2);
      if (alpha <= 0.012) continue;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = Math.cos(ang) < 0 ? HEX.blue : HEX.orange;
      ctx.fillRect(p.x - size / 2, p.y - size / 2, size, size * (1 + near * 1.2));
    }
    ctx.restore();
  }

  const core = el(sc, "focal_core");
  if (ON(t, core) && core?.center) {
    const e = ease(core.ease, P(t, core));
    const r = lerp(pNum(core, "r_from", 6), pNum(core, "r_to", 150), e);
    glowDot(fc, core.center[0], core.center[1], r, "white", (1 - e * 0.85) * clamp01(t / 0.2));
  }

  const streaks = el(sc, "act1_streaks");
  if (streaks && ON(t, streaks)) drawStreaks(fc, streaks);

  const fl = el(sc, "lens_flare");
  if (fl?.center && t >= fl.start && t < fl.end) {
    const p = P(t, fl);
    const grow = ease("EXPO_OUT", ramp(t, fl.start, 0.28));
    const inten = (p < 0.12 ? p / 0.12 : 1 - (p - 0.12) / 0.88) * 0.95;
    flare(fc, fl.center[0], fl.center[1], pNum(fl, "length", 1400) * (0.25 + 0.75 * grow), pNum(fl, "height", 6), pNum(fl, "glow", 120) * grow, clamp01(inten));
  }

  const flick = el(sc, "act1_flicker");
  if (flick) drawFlicker(fc, flick);

  const def = sc.text.find((d) => d.id === "title_opening");
  if (def) {
    const perLetter = typeof def.props?.letter_stagger === "number" ? (def.props.letter_stagger as number) : 0.042;
    const tail = typeof def.props?.tail_letters === "number" ? (def.props.tail_letters as number) : 2;
    drawLayoutText(fc, def, sc.scene, {
      reveal: t - def.start,
      perLetter,
      letterDur: 0.34,
      tail,
      tailAlpha: typeof def.props?.tail_alpha === "number" ? (def.props.tail_alpha as number) : 0.3,
      glow: 0.55,
      alpha: clamp01((def.end - t) / 0.001) > 0 ? 1 : 0,
    });
  }
}

// ===========================================================================
// CUT 1 — GELD AUSGEBEN 8.0-11.0  (R-SCN-02)
// ===========================================================================
let coinCache: Float32Array | null = null;
function coinData(n: number) {
  if (coinCache && coinCache.length >= n * 4) return coinCache;
  const r = rng(SEED + 21);
  const out = new Float32Array(n * 4);
  for (let i = 0; i < n * 4; i++) out[i] = r();
  coinCache = out;
  return out;
}

export function drawWallet(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  drawCutDecor(fc, sc);

  const panel = el(sc, "glass_wallet");
  if (panel?.rect) {
    const a = ease(panel.ease, ramp(t, panel.start, pNum(panel, "fade_in", 0.5))) * clamp01((panel.end - t) / 0.2);
    if (a > 0.004) {
      const [x, y, w, h] = panel.rect;
      glass(fc, x, y, w, h, pNum(panel, "radius", 28), a);
      const slots = el(sc, "wallet_slots");
      if (slots && ON(t, slots)) {
        const sa = pNum(slots, "alpha", 0.25) * ease(slots.ease, P(t, slots));
        ctx.save();
        ctx.globalAlpha = sa;
        for (let i = 0; i < 4; i++) {
          const yy = y + 90 + i * 62;
          rrect(ctx, x + 56, yy, w - 112 - (i % 2) * 90, 14, 7);
          ctx.fillStyle = i === 1 ? HEX.orange : HEX.white;
          ctx.globalAlpha = sa * (i === 1 ? 0.85 : 0.35);
          ctx.fill();
        }
        ctx.restore();
      }
      // card chip
      ctx.save();
      ctx.globalAlpha = a * 0.9;
      rrect(ctx, x + 56, y + h - 96, 92, 62, 10);
      ctx.fillStyle = gradRadial(ctx, x + 102, y + h - 65, 70, [
        [0, withAlpha(HEX.white, 0.9)],
        [1, rgba("orange", 0.75)],
      ]);
      ctx.fill();
      ctx.restore();
    }
  }

  const coins = el(sc, "coin_cascade");
  if (coins?.center && ON(t, coins)) {
    const n = Math.round(pNum(coins, "count", 24));
    const d = coinData(n);
    const staggerMax = pNum(coins, "stagger_max", 0.6);
    const dMin = pNum(coins, "d_min", 80);
    const dMax = pNum(coins, "d_max", 110);
    const yFrom = pNum(coins, "y_from", -100);
    const yTo = pNum(coins, "y_to", 420);
    const spread = pNum(coins, "spread", 300);
    const [cx] = coins.center;
    for (let i = 0; i < n; i++) {
      const st = d[i * 4] * staggerMax;
      const local = t - coins.start - st;
      if (local < 0) continue;
      const p = ease(coins.ease, clamp01(local / 0.95));
      const bounce = p >= 1 ? Math.abs(Math.sin((local - 0.95) * 9)) * 16 * Math.exp(-(local - 0.95) * 3.4) : 0;
      const x = cx + (d[i * 4 + 1] - 0.5) * 2 * spread;
      const y = lerp(yFrom, yTo, p) - bounce + (d[i * 4 + 2] - 0.5) * 40;
      const dia = lerp(dMin, dMax, d[i * 4 + 3]);
      const spin = t * (2.2 + d[i * 4 + 2] * 2.4) + i;
      drawCoin(ctx, x, y, dia * (0.5 + 0.5 * p + 0.12), spin, clamp01(p * 2.2), d[i * 4 + 1] > 0.5 ? "orange" : "blue");
    }
    glowDot(fc, cx, 380, 260, "blue", 0.12 * clamp01((t - coins.start) / 0.6));
  }

  drawCutTitle(fc, sc);
  drawCutOut(fc, sc);
}

// ===========================================================================
// CUT 2 — DAS PASSWORT-SPIEL 11.0-14.0  (R-SCN-03)
// ===========================================================================
let ruleCache: Float32Array | null = null;
function ruleData() {
  if (ruleCache) return ruleCache;
  const r = rng(SEED + 33);
  const out = new Float32Array(12 * 14);
  for (let i = 0; i < out.length; i++) out[i] = r();
  ruleCache = out;
  return out;
}

export function drawPassword(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  drawCutDecor(fc, sc);
  const restore = applyShake(fc, sc, "shake_click");

  const body = el(sc, "lock_body");
  const shackle = el(sc, "lock_shackle");
  const click = el(sc, "lock_click");
  const s = click ? lerp(pNum(click, "scale_from", 1.04), pNum(click, "scale_to", 1), ease(click.ease, P(t, click))) : 1.04;
  const scaleNow = t >= 11.4 ? s : lerp(1.04, 1.04, 1);

  if (shackle?.center) {
    const a = ease(shackle.ease, ramp(t, shackle.start, 0.4));
    const [cx, cy] = shackle.center;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scaleNow, scaleNow);
    ctx.beginPath();
    ctx.arc(0, 0, pNum(shackle, "radius", 110), Math.PI, Math.PI + Math.PI * a, false);
    ctx.lineWidth = pNum(shackle, "stroke", 28);
    ctx.strokeStyle = rgba("white", pNum(shackle, "alpha", 0.9));
    ctx.lineCap = "round";
    ctx.stroke();
    ctx.restore();
  }

  if (body?.rect) {
    const [x, y, w, h] = body.rect;
    const a = ease(body.ease, ramp(t, body.start, 0.4));
    ctx.save();
    ctx.globalAlpha = a;
    ctx.translate(x + w / 2, y + h / 2);
    ctx.scale(scaleNow, scaleNow);
    ctx.translate(-(x + w / 2), -(y + h / 2));
    rrect(ctx, x, y, w, h, pNum(body, "radius", 32));
    const g = ctx.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, "rgba(255,255,255,0.97)");
    g.addColorStop(0.45, "rgba(206,220,238,0.95)");
    g.addColorStop(1, "rgba(112,142,182,0.92)");
    ctx.fillStyle = g;
    ctx.fill();
    // blue inner glow, blur 16 approximated by a soft radial (R-SCN-03)
    ctx.save();
    ctx.clip();
    ctx.fillStyle = gradRadial(ctx, x + w / 2, y + h * 0.85, w * 0.95, [
      [0, rgba("blue", 0.75)],
      [0.55, rgba("blue", 0.22)],
      [1, rgba("blue", 0)],
    ]);
    ctx.fillRect(x, y, w, h);
    // rule glyph rows: 12 rows of 10 px mono marks scrolling up at 120 px/s
    const rule = el(sc, "rule_text");
    if (rule && ON(t, rule)) {
      const d = ruleData();
      const rows = Math.round(pNum(rule, "rows", 12));
      const speed = pNum(rule, "speed", 120);
      const rowH = 22;
      const off = ((t - rule.start) * speed) % (rows * rowH);
      ctx.globalAlpha = pNum(rule, "alpha", 0.4);
      ctx.fillStyle = HEX.white;
      for (let r0 = 0; r0 < rows + 2; r0++) {
        const yy = y + h - 18 - r0 * rowH + off;
        if (yy < y + 8 || yy > y + h - 8) continue;
        let xx = x + 26;
        for (let k = 0; k < 12; k++) {
          const wdt = 6 + d[(r0 * 12 + k) % d.length] * 20;
          ctx.globalAlpha = pNum(rule, "alpha", 0.4) * (0.35 + d[(r0 * 7 + k) % d.length] * 0.65);
          ctx.fillRect(xx, yy - 10, wdt, 10);
          xx += wdt + 7;
          if (xx > x + w - 30) break;
        }
      }
    }
    ctx.restore();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = withAlpha(HEX.white, 0.6);
    rrect(ctx, x, y, w, h, pNum(body, "radius", 32));
    ctx.stroke();
    // keyhole
    ctx.beginPath();
    ctx.arc(x + w / 2, y + h * 0.44, 22, 0, TAU);
    ctx.fillStyle = rgba("blue", 0.95);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x + w / 2 - 11, y + h * 0.5);
    ctx.lineTo(x + w / 2 + 11, y + h * 0.5);
    ctx.lineTo(x + w / 2 + 6, y + h * 0.76);
    ctx.lineTo(x + w / 2 - 6, y + h * 0.76);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    glowDot(fc, x + w / 2, y + h * 0.5, 200, "blue", 0.22 * a);
  }

  const checks = el(sc, "check_circles");
  if (checks?.center) {
    const times = (checks.props.at as number[]) ?? [];
    const n = Math.round(pNum(checks, "count", 5));
    const gap = pNum(checks, "gap", 116);
    const rad = pNum(checks, "radius", 36);
    for (let i = 0; i < n; i++) {
      const at = times[i] ?? checks.start + i * 0.2;
      const p = ease("EXPO_OUT", ramp(t, at, 0.32));
      if (p <= 0) continue;
      const cx = checks.center[0] + (i - (n - 1) / 2) * gap;
      drawCheck(ctx, cx, checks.center[1], rad, p, 1);
      if (fc.glow) glowDot(fc, cx, checks.center[1], rad * 2.1, "orange", 0.3 * p);
    }
  }

  restore();
  drawCutTitle(fc, sc);
  drawCutOut(fc, sc);
}

// ===========================================================================
// CUT 3 — DIE TIEFSEE 14.0-17.0  (R-SCN-04)
// ===========================================================================
let seaCache: { cr: Float32Array; bu: Float32Array; dv: Float32Array } | null = null;
function seaData() {
  if (seaCache) return seaCache;
  const r = rng(SEED + 41);
  const cr = new Float32Array(12 * 5);
  for (let i = 0; i < 12; i++) {
    cr[i * 5] = (r() - 0.5) * 1900;
    cr[i * 5 + 1] = (r() - 0.5) * 900;
    cr[i * 5 + 2] = r() * Z_MAX;
    cr[i * 5 + 3] = 60 + r() * 80;
    cr[i * 5 + 4] = r() > 0.62 ? 1 : 0;
  }
  const bu = new Float32Array(60 * 4);
  for (let i = 0; i < 60; i++) {
    bu[i * 4] = r() * 1920;
    bu[i * 4 + 1] = r() * 1080;
    bu[i * 4 + 2] = 4 + r() * 10;
    bu[i * 4 + 3] = 80 + r() * 80;
  }
  const dv = new Float32Array(600 * 3);
  for (let i = 0; i < 600; i++) {
    dv[i * 3] = r() * 1920;
    dv[i * 3 + 1] = r() * 1080;
    dv[i * 3 + 2] = r();
  }
  seaCache = { cr, bu, dv };
  return seaCache;
}

function parseValue(s: string): number {
  const m = s.replace(/[^\d]/g, "");
  return m ? parseInt(m, 10) : 0;
}

export function drawDeepSea(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  drawCutDecor(fc, sc);

  const grad = el(sc, "sea_gradient");
  if (grad && ON(t, grad)) {
    const g = ctx.createLinearGradient(0, 0, 0, 1080);
    g.addColorStop(0, rgba("black", 0));
    g.addColorStop(1, rgba("blue", pNum(grad, "bottom_alpha", 0.12)));
    ctx.save();
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 1920, 1080);
    ctx.restore();
  }

  const dive = el(sc, "dive_particles");
  if (dive && ON(t, dive)) {
    const d = seaData().dv;
    const speed = pNum(dive, "speed", 1200);
    const e = ease(dive.ease, P(t, dive));
    const n = Math.round(pNum(dive, "count", 600));
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < n; i++) {
      const y = ((d[i * 3 + 1] + (t - dive.start) * speed * (0.4 + d[i * 3 + 2]) * (0.4 + 0.6 * e)) % 1300) - 110;
      const len = 10 + 90 * d[i * 3 + 2] * (0.3 + e);
      ctx.globalAlpha = pNum(dive, "alpha", 0.45) * (0.25 + d[i * 3 + 2] * 0.75);
      ctx.fillStyle = HEX.white;
      ctx.fillRect(d[i * 3], 1080 - y, 2, len);
    }
    ctx.restore();
  }

  const cr = el(sc, "creatures");
  if (cr?.center && ON(t, cr)) {
    const d = seaData().cr;
    const n = Math.round(pNum(cr, "count", 12));
    for (let i = 0; i < n; i++) {
      const z = ((d[i * 5 + 2] + (t - cr.start) * 130) % Z_MAX + Z_MAX) % Z_MAX;
      const p = project(d[i * 5] + Math.sin(t * 0.7 + i) * 40, d[i * 5 + 1] + Math.cos(t * 0.5 + i) * 26, z, cr.center[0], cr.center[1]);
      const size = d[i * 5 + 3] * p.s * 2.4;
      const a = clamp01((1 - z / Z_MAX) * 1.2) * ease(cr.ease, ramp(t, cr.start, 0.5));
      if (a < 0.02 || size < 4) continue;
      drawCreature(ctx, p.x, p.y, size, d[i * 5 + 4] > 0.5 ? "orange" : "blue", a, t + i);
      if (fc.glow && size > 40) glowDot(fc, p.x, p.y, size * 0.9, d[i * 5 + 4] > 0.5 ? "orange" : "blue", 0.28 * a);
    }
  }

  const bu = el(sc, "bubbles");
  if (bu?.rect) {
    const d = seaData().bu;
    const n = Math.round(pNum(bu, "count", 60));
    const [bx, by, bw, bh] = bu.rect;
    ctx.save();
    for (let i = 0; i < n; i++) {
      const v = pNum(bu, "v_min", 80) + d[i * 4 + 3];
      const y = by + bh - (((t - bu.start) * v + d[i * 4 + 1]) % (bh + 60));
      const x = bx + d[i * 4] % bw + Math.sin(t * 1.6 + i) * 8;
      const r0 = d[i * 4 + 2];
      ctx.globalAlpha = pNum(bu, "alpha", 0.35) * clamp01((y - by) / 120);
      ctx.beginPath();
      ctx.arc(x, y, r0, 0, TAU);
      ctx.strokeStyle = HEX.white;
      ctx.lineWidth = 1.6;
      ctx.stroke();
    }
    ctx.restore();
  }

  // depth counter: declared strings + 0.3 s EASE_IO count-up ramps (R-SCN-04)
  for (const def of sc.text) {
    if (def.layout !== "counter_center") continue;
    if (t < def.start || t >= def.end) continue;
    const target = parseValue(def.string);
    const from = typeof def.props?.ramp_from === "number" ? (def.props.ramp_from as number) : target;
    const rp = typeof def.props?.ramp === "number" ? (def.props.ramp as number) : 0;
    const p = rp > 0 ? ease("EASE_IO", ramp(t, def.start, rp)) : 1;
    const value = lerp(from, target, p);
    drawLayoutText(fc, def, sc.scene, {
      display: `${value.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ".")} m`,
      alpha: clamp01((def.end - t) / 0.12),
      glow: 0.25,
    });
  }

  drawCutTitle(fc, sc, "title");
  drawCutOut(fc, sc);
}

// ===========================================================================
// CUT 4 — TEMPO 17.0-20.0  (R-SCN-05, no voiceover)
// ===========================================================================
let streakCache: Float32Array | null = null;
function streakData(n: number) {
  if (streakCache && streakCache.length >= n * 4) return streakCache;
  const r = rng(SEED + 57);
  const out = new Float32Array(n * 4);
  for (let i = 0; i < out.length; i++) out[i] = r();
  streakCache = out;
  return out;
}

const GLYPHS: Record<string, (ctx: CanvasRenderingContext2D, x: number, y: number, s: number) => void> = {
  snail: (c, x, y, s) => drawSnail(c, x, y, s, 1),
  cheetah: (c, x, y, s) => drawCheetah(c, x, y, s, 1),
  rocket: (c, x, y, s) => drawRocket(c, x, y, s, 1),
  beam: (c, x, y, s) => drawBeam(c, x, y, s, 1),
};

export function drawTempo(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  drawCutDecor(fc, sc);

  const st = el(sc, "speed_streaks");
  if (st?.rect && ON(t, st)) {
    const d = streakData(40);
    const n = Math.round(pNum(st, "count", 40));
    const [sx, sy, sw, sh] = st.rect;
    const speed = pNum(st, "speed", 2400);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < n; i++) {
      const len = lerp(pNum(st, "len_min", 200), pNum(st, "len_max", 600), d[i * 4]);
      const y = sy + d[i * 4 + 1] * sh;
      const x = sx + sw + 200 - (((t - st.start) * speed * (0.6 + d[i * 4 + 2] * 0.8) + d[i * 4 + 3] * 2600) % (sw + len + 400));
      const g = ctx.createLinearGradient(x, y, x + len, y);
      g.addColorStop(0, rgba("white", 0));
      g.addColorStop(0.5, rgba("white", pNum(st, "alpha", 0.3)));
      g.addColorStop(1, rgba("white", 0));
      ctx.fillStyle = g;
      ctx.fillRect(x, y, len, 3);
    }
    ctx.restore();
  }

  const gauge = el(sc, "speedometer");
  if (gauge?.center && ON(t, gauge)) {
    const a = ease(gauge.ease, ramp(t, gauge.start, 0.4));
    drawGauge(ctx, gauge.center[0], gauge.center[1], pNum(gauge, "radius", 300), 0, a * 0.9, Math.round(pNum(gauge, "ticks", 24)));
    const needle = el(sc, "needle");
    if (needle) {
      const v = ease(needle.ease, P(t, needle));
      drawGauge(ctx, gauge.center[0], gauge.center[1], pNum(gauge, "radius", 300), v, a, Math.round(pNum(gauge, "ticks", 24)));
      drawNeedle(ctx, gauge.center[0], gauge.center[1], pNum(needle, "length", 268), v, a * clamp01((needle.end - t) / 0.2 + 0.4));
      if (fc.glow) glowDot(fc, gauge.center[0], gauge.center[1], 120, "orange", 0.22 * a * v);
    }
  }

  const morph = el(sc, "morph_glyphs");
  if (morph?.center && ON(t, morph)) {
    const seq = pStrArr(morph, "sequence");
    const each = pNum(morph, "each", 0.6);
    const cf = pNum(morph, "crossfade", 0.15);
    const local = t - morph.start;
    const idx = Math.floor(local / each);
    const pIn = (local % each) / each;
    const [mx, my] = morph.center;
    const size = 190;
    for (let k = -1; k <= 1; k++) {
      const i = idx + k;
      if (i < 0 || i >= seq.length) continue;
      let a = 1;
      if (k === 0) a = pIn < cf / each ? pIn / (cf / each) : 1;
      else if (k === -1) a = 1 - clamp01(pIn / (cf / each));
      else a = 0;
      if (a <= 0.01) continue;
      const fn = GLYPHS[seq[i]];
      if (!fn) continue;
      ctx.save();
      ctx.globalAlpha = a;
      fn(ctx, mx, my, size * (1 + (1 - a) * 0.06));
      ctx.restore();
    }
  }

  // TEMPO pulses at each morph (R-SCN-05)
  const tp = el(sc, "title_pulse");
  const def = sc.text.find((d) => d.id === "title_04");
  if (def) {
    let scale = 1;
    if (tp) {
      const times = (tp.props.at as number[]) ?? [];
      const dur = pNum(tp, "dur", 0.2);
      for (const at of times) {
        const p = ramp(t, at, dur);
        if (p > 0 && p < 1) scale = Math.max(scale, 1 + (pNum(tp, "scale_to", 1.08) - 1) * Math.sin(Math.PI * p));
      }
    }
    drawLayoutText(fc, def, sc.scene, {
      reveal: t - def.start,
      perLetter: 0.034,
      letterDur: 0.24,
      scale,
      glow: 0.4,
    });
  }

  drawCutOut(fc, sc);
}

export { rampColor, ramp };
