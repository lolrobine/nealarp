// ============================================================================
// nealarp-ad / checklist — the requirement board (R-REPORT §1).
// Mirrors nealarp-ad/checklist.md. R-VER-* rows are overlaid with the live
// measurement as soon as the VERIFY suite has been run.
// ============================================================================

export type CStatus = "PASS" | "PARTIAL" | "BLOCKED" | "FAIL";

export interface CItem {
  id: string;
  group: string;
  title: string;
  status: CStatus;
  evidence: string;
}

type Row = [string, string, string, CStatus, string];

export const GROUPS = [
  "R-OUT",
  "R-PRI",
  "R-STACK",
  "R-REF",
  "R-REPO",
  "R-TIME",
  "R-VIS",
  "R-SCN",
  "R-AUD",
  "R-TXT",
  "R-VER",
  "R-PERF",
  "R-GATE",
  "R-REPORT",
  "R-NEG",
] as const;

const ROWS: Row[] = [
  ["R-OUT-01", "R-OUT", "60.000 s German ad for nealarp, 12 Oct 2026", "PASS", "11 scenes, 3600 frames, German copy + German VO, release date on screen as AB 12. OKTOBER"],
  ["R-OUT-02", "R-OUT", "Built as code, pure function of time", "PASS", "renderFrame(canvas, t, scale); timeline.yaml parsed at runtime, seed 7, no accumulated state"],
  ["R-OUT-03", "R-OUT", "Test render 1920x1080@60", "PARTIAL", "EXPORT writes nealarp-ad-1080p-test.mp4 where the browser offers avc1, else .webm (D-05); no ffmpeg here"],
  ["R-OUT-04", "R-OUT", "Final render 3840x2160@60 after approval", "BLOCKED", "gate closed (R-GATE-01/02); the button is locked and states why"],
  ["R-OUT-05", "R-OUT", "H.264 High, yuv420p, AAC 48k, -14 LUFS, -1 dBTP", "PARTIAL", "16:9 / 60.000 s / 60 fps by construction; container, loudnorm and true-peak need ffmpeg (blocked)"],
  ["R-OUT-06", "R-OUT", "One documented render command for both files", "PASS", "README.md §3: build once, profile differs only by scale (1 / 2)"],
  ["R-PRI", "R-PRI", "Priority order respected", "PASS", "1 copy -> 2 palette -> 3 timing -> 4 quality; the palette gate is enforced by measurement, not by eye"],
  ["R-STACK-01", "R-STACK", "Host reachability probe recorded", "PASS", "README.md §1: npm YES (indirect), pypi/pythonhosted UNKNOWN (no shell), ffmpeg NO, headless browser NO"],
  ["R-STACK-02", "R-STACK", "Python 3.11 default stack in a venv", "BLOCKED", "no Python interpreter is invocable in this delivery environment"],
  ["R-STACK-03", "R-STACK", "Remotion only if npm + headless browser", "PASS", "Remotion rejected (no headless Chromium + ffmpeg); host default TS/Canvas stack used; no switch after first frame"],
  ["R-STACK-04", "R-STACK", "No GPU-only libs, 2 cores / 3 GB RAM", "PASS", "Canvas 2D + Float32Array only, <=3000 particles/frame, static layers cached"],
  ["R-STACK-05", "R-STACK", "DejaVu TTFs loaded by explicit path", "PARTIAL", "browser sandbox cannot read /usr/share/fonts; DejaVu Sans is requested first by family name (D-03)"],
  ["R-STACK-06", "R-STACK", "Font covers Ä ä Ö ö Ü ü ß . , % m", "PASS", "R-VER-14 live probe reports the advance of every glyph"],
  ["R-REF-01", "R-REF", "inspiration-01.jpg kept or described", "PASS", "file absent -> reference/README.md written; no TikTok fetch attempted"],
  ["R-REF-02", "R-REF", "Techniques only, no creator assets", "PASS", "hot-white core, per-letter gradient, motion-blur tails, grain + bloom; no handle/watermark/layout copied"],
  ["R-REPO-01", "R-REPO", "nealarp-ad/ separate from website code", "PASS", "own folder, website repo untouched"],
  ["R-REPO-02", "R-REPO", "Declared folder layout", "PASS", "README/timeline/checklist/reference/tests/audio present; renderer modules bundled at ../src/ad (D-02)"],
  ["R-REPO-03", "R-REPO", "audio/render + out git-ignored", "PASS", "nealarp-ad/.gitignore covers out/, audio/render/, *.mp4, *.wav, *.png"],
  ["R-TIME-01", "R-TIME", "t = frame / 60", "PASS", "FPS=60 in constants; frameToTime()/timeToFrame(); no 24 fps constants anywhere"],
  ["R-TIME-02", "R-TIME", "Fixed act timeline", "PASS", "0-8 opening, 8-32 showcase (8x3.0), 32-44 hero, 44-60 cta, exactly as declared"],
  ["R-TIME-03", "R-TIME", "Keep approved pacing", "PASS", "no scene or copy added/removed; the pacing note is filed in the report instead"],
  ["R-TIME-04", "R-TIME", "Every element has start and end", "PASS", `${"timeline.yaml declares all element/text/audio windows; the renderer draws nothing outside them"}`],
  ["R-VIS-01", "R-VIS", "Background #0a0a0a + depth haze", "PASS", "cached layer: #0a0a0a base, radial #0f172a centre at 40 %"],
  ["R-VIS-02", "R-VIS", "Only blue / orange / white / near-black", "PASS", "R-VER-06 hue gate measures it on 120 sampled frames"],
  ["R-VIS-03", "R-VIS", "Linear blue 0 % -> orange 100 % gradient", "PASS", "gradBO() with the two exact endpoints; D-08 adds near-white bridge stops so no pixel leaves the hue windows"],
  ["R-VIS-04", "R-VIS", "Glass panel recipe", "PASS", "white 10 % fill, 1 px white 25 % border, r24, inner shadow 20 % (0,4)/12, backdrop blur on a 1/4-scale copy upsampled"],
  ["R-VIS-05", "R-VIS", "Bloom, streaks, flare, flicker", "PASS", "half-scale glow buffer composited additive at 35 % with 24 px blur; streaks per act; 1400x6 flare + 120 px glow per title reveal; one off-screen flicker per act"],
  ["R-VIS-06", "R-VIS", "Seeded particles, cap 3000, shrink to 0", "PASS", "seed 7 mulberry32; CTA burst is exactly 3000; size *= life over the particle lifetime"],
  ["R-VIS-07", "R-VIS", "One seeded 512x512 grain tile at 3.5 %", "PASS", "generated once, tiled with a per-frame seeded offset, composite overlay"],
  ["R-VIS-08", "R-VIS", "Vignette 0 % -> 25 % black", "PASS", "cached radial layer, 0 at centre, 0.25 at corners"],
  ["R-VIS-09", "R-VIS", "Perspective projection, f = 900", "PASS", "project() = c + p*f/(f+z), z in [0,2000]"],
  ["R-VIS-10", "R-VIS", "Named easings, exact", "PASS", "Newton-Raphson bezier solver for 0.65/0/0.35/1 and 0.25/0.8/0.25/1, EXPO_OUT = 1-2^(-10t), STEP"],
  ["R-VIS-11", "R-VIS", "Flat geometric line icons, 6 px, no emoji", "PASS", "telescope = tube + 2 tripod lines, flame = teardrop, all icons stroke-based; zero emoji in the codebase"],
  ["R-VIS-12", "R-VIS", "1920x1080 reference space, 2x for 4K", "PASS", "canvas transform carries scale; every literal is a reference unit; safe area 96/54"],
  ["R-SCN-01", "R-SCN", "Opening tunnel + title", "PASS", "1200 particles, blue left / orange right, converge on (960,540); title 2.0-4.0 s; 0.042 s letter stagger; blur tails on the last two letters; flare at 2.0 s; hold to 8.0 s"],
  ["R-SCN-02", "R-SCN", "Cut 1 GELD AUSGEBEN", "PASS", "24 chrome coins 80-110 px, y -100->420 EASE_IO, stagger <=0.6 s; glass wallet [660,260,600,380] r28 in 8.3-8.8; clinks 8.2/8.5/8.9/9.3"],
  ["R-SCN-03", "R-SCN", "Cut 2 DAS PASSWORT-SPIEL", "PASS", "body [800,300,320,260] r32 + blue inner glow, 180 deg shackle r110 stroke 28, 12 rows of 10 px mono marks at 120 px/s, click 1.04->1.00 EXPO_OUT + 0.3 s shake at 11.4, 5 orange checks at 12.0/.2/.4/.6/.8"],
  ["R-SCN-04", "R-SCN", "Cut 3 DIE TIEFSEE", "PASS", "vertical gradient to blue 12 %, dive layer 1200 px/s EASE_OUT_EARLY, 12 glowing creatures on z, 60 seeded bubbles 4-14 px at 80-160 px/s, depth counter 0 / 1.000 / 5.000 / 11.034 m with 0.3 s ramps, 8 bubble cues"],
  ["R-SCN-05", "R-SCN", "Cut 4 TEMPO (no VO)", "PASS", "gauge 210 deg -> -30 deg r300, needle EXPO_OUT over 1.2 s, 40 white 30 % streaks 200-600 px at 2400 px/s, snail/cheetah/rocket/beam morphs 0.6 s with 0.15 s crossfade, TEMPO pulses 1.0->1.08, whirr across the cut, vo: [] declared"],
  ["R-SCN-06", "R-SCN", "Cut 5 ASTEROIDEN-WERFER", "PASS", "Earth r210 at (960,560) blue radial + 2 px orange rim, meteor (1500,60)->(1000,470) alpha 1->0 trail, impact 21.6 with 5 rings 0->700 EXPO_OUT, crater, 0.3 s shake, 100 MEGATONNEN at y=220 from 21.8, boom"],
  ["R-SCN-07", "R-SCN", "Cut 6 PERFEKTER KREIS", "PASS", "orange arc r220 stroke 14 drawn 0->360 deg over 1.2 s EASE_IO, 4 px white core at 40 %, dashed guide (12/10) at 24.2, 98 % orange 160 px at (1480,470) from 24.5, pen-draw 23.0-24.2"],
  ["R-SCN-08", "R-SCN", "Cut 7 LEBENSSTATISTIK", "PASS", "heart 200 px white + blue glow, 72 bpm pulse 1.0->1.12, one blue ring per beat 0->600, three glass panels at the declared rects fading in 26.2-26.6, 96 px counters EASE_IO, heartbeat cue per beat"],
  ["R-SCN-09", "R-SCN", "Cut 8 GRÖSSE DES WELTALLS", "PASS", "six 10x stages (human, building, mountain, Earth, Sun, 2000-particle galaxy) with 0.25 s EXPO_OUT transitions, telescope icon 120 px at (960,180) drawn 29.5-30.0, whoosh zoom"],
  ["R-SCN-10", "R-SCN", "Hero 32.0-44.0", "PASS", "star sphere r200 at (960,500) blue->orange + white core, +-3 % at 0.5 Hz, push-in 1.0->1.15 EASE_IO, 8 sprites on r420/r560 at 0.3 rad/s alternating direction, nealarp 144 px in 36.5-37.5"],
  ["R-SCN-11", "R-SCN", "Call to action 44.0-60.0", "PASS", "3000-particle burst + bass hit with echo, reform BALD VERFÜGBAR -> AB 12. OKTOBER -> nealarp.vercel.app, underline sweep 51.5-52.5, orange pill 1000x120 r60 with pulse at 55.0, push-out 55-59, fade to black 59-60"],
  ["R-AUD-01", "R-AUD", "German neural voiceover, 8 lines", "PARTIAL", "de-DE neural browser voices speak all 8 lines at the declared times, >=0.5 s apart, never sped up; speechSynthesis cannot be routed into Web Audio so the stems stay offline (D-06). No espeak placeholder used"],
  ["R-AUD-02", "R-AUD", "Original 120 BPM score, 60.000 s", "PASS", "bass drop 0.0, 8 detuned sines through a 2 kHz lowpass that opens and gains harmonic weight to 32 s, swell + risers 32->44, bass hit 44.0 with 0.25 s delay / 0.3 feedback, silent by 60.0, music ducked -6 dB under VO"],
  ["R-AUD-03", "R-AUD", "12 SFX recipes at 48 kHz", "PASS", "all recipes implemented with the declared peaks; one clear sound per cut, never more than two stacked"],
  ["R-AUD-04", "R-AUD", "Two-pass loudnorm to -14 LUFS / -1 dBTP", "BLOCKED", "ffmpeg loudnorm and true-peak measurement unavailable; a -1 dB limiter and calibrated bus gains are used live"],
  ["R-TXT-01", "R-TXT", "Render the 23 strings exactly", "PASS", "R-VER-09 diffs the layout log against the list, character exact, including umlauts, ß, % and the thousands dots"],
  ["R-TXT-02", "R-TXT", "All text through the layout system", "PASS", "no scene calls fillText directly; drawLayoutText() is the only path and it logs every string"],
  ["R-TXT-03", "R-TXT", "Auto-fit >1440 px, -4 px steps, min 64", "PASS", "fitSize() shrinks and logs every change; the layout log carries sizeRequested vs size"],
  ["R-VER-01", "R-VER", "3600 frames / 60.000 s +-0.02", "PASS", "live suite"],
  ["R-VER-02", "R-VER", "1920x1080 and 3840x2160 at 60/1", "PASS", "live suite"],
  ["R-VER-03", "R-VER", "H.264 High, yuv420p", "BLOCKED", "no ffprobe"],
  ["R-VER-04", "R-VER", "AAC 48 kHz stereo", "BLOCKED", "no ffprobe"],
  ["R-VER-05", "R-VER", "-14 LUFS +-1, <= -1 dBTP", "BLOCKED", "no ebur128 filter"],
  ["R-VER-06", "R-VER", "Palette hue gate", "PASS", "live suite: 120 frames, <=1 % outside 195-235 / 15-35 degrees"],
  ["R-VER-07", "R-VER", "Background #0a0a0a +-6 in the corners", "PASS", "live suite"],
  ["R-VER-08", "R-VER", "Text bboxes inside the safe area", "PASS", "live suite"],
  ["R-VER-09", "R-VER", "Text completeness (+OCR if available)", "PARTIAL", "string set diff PASS live; OCR skipped, tesseract not installable"],
  ["R-VER-10", "R-VER", "No frozen frames outside holds", "PASS", "live suite: 0.5 s windows + a 1/60 s consecutive pass"],
  ["R-VER-11", "R-VER", "Audio timing +-0.05 s, no VO overlap", "PASS", "live suite"],
  ["R-VER-12", "R-VER", "Silence after 60.0 s", "PARTIAL", "no cue at/after 60.0 s and the master ramps to zero; file RMS not measurable without ffmpeg"],
  ["R-VER-13", "R-VER", "Byte-identical double render", "PASS", "live suite: SHA-256 over frames 0/900/1800/3000/3599 (D-04)"],
  ["R-VER-14", "R-VER", "Font coverage probe", "PASS", "live suite"],
  ["R-PERF-01", "R-PERF", "Static layers pre-computed", "PASS", "background, vignette, grain tile, glass backdrop buffer and text sample points are cached per resolution"],
  ["R-PERF-02", "R-PERF", "Vectorised particle math", "PASS", "Float32Array fields, batched fillRect, no per-pixel loops"],
  ["R-PERF-03", "R-PERF", "Cached sprites", "PASS", "coins, creatures, icons and galaxy field generated once and reused at the used scale"],
  ["R-PERF-04", "R-PERF", "Report ms/frame + 4K estimate", "PASS", "the suite measures 1080p over 10 renders, renders one real 4K frame and prints both estimates"],
  ["R-PERF-05", "R-PERF", "Do not start 4K above 6 h", "PASS", "the estimate gates the 4K button independently of the approval gate"],
  ["R-GATE-01", "R-GATE", "Stop after the 1080p test + report", "PASS", "no code path starts the 4K profile autonomously"],
  ["R-GATE-02", "R-GATE", "4K only on explicit approval", "PASS", "the user must type the approval string; the console shows the gate state"],
  ["R-GATE-03", "R-GATE", "Real German neural VO before 4K", "BLOCKED", "voiceover cannot be embedded in a browser export (D-06), so 4K stays blocked even with approval"],
  ["R-GATE-04", "R-GATE", "No 1080p upscale as 4K master", "PASS", "no upscale path exists; scale 2 renders a true 3840x2160 frame or nothing"],
  ["R-REPORT", "R-REPORT", "Final report in 6 sections", "PASS", "REPORT tab: checklist, commands, timings, verification, deviations, open items"],
  ["R-NEG-01", "R-NEG", "No hue outside the four colours", "PASS", "enforced by the R-VER-06 measurement and the D-08 ramp"],
  ["R-NEG-02", "R-NEG", "No emoji, cartoon, stock photo, people", "PASS", "geometric primitives only"],
  ["R-NEG-03", "R-NEG", "No English, no text beyond R-TXT-01", "PASS", "all copy is German; the layout log diff proves nothing else is drawn"],
  ["R-NEG-04", "R-NEG", "No watermarks, logos, handles, UI chrome", "PASS", "no such draw call exists in the scene code"],
  ["R-NEG-05", "R-NEG", "No jitter, flicker, banding, dropped frames", "PASS", "deterministic easing, seeded fields, grain dithers the gradients, declared flicker is an intentional act transition only"],
  ["R-NEG-06", "R-NEG", "No letterboxing", "PASS", "full 16:9 at every scale; no letterbox branch exists"],
  ["R-NEG-07", "R-NEG", "No licensed music or samples", "PASS", "every sample is synthesised at runtime"],
  ["R-NEG-08", "R-NEG", "No generated media in git", "PASS", ".gitignore covers out/, audio/render/ and every media extension"],
  ["R-NEG-09", "R-NEG", "Never fake a result", "PASS", "unrunnable checks report BLOCKED with the reason; live checks print their measured numbers"],
];

export const CHECKLIST: CItem[] = ROWS.map(([id, group, title, status, evidence]) => ({ id, group, title, status, evidence }));

export interface Deviation {
  id: string;
  text: string;
  reason: string;
}

export const DEVIATIONS: Deviation[] = [
  { id: "D-01", text: "Renderer written in TypeScript + Canvas 2D + Web Audio instead of Python/Pillow/OpenCV or Remotion", reason: "neither a Python interpreter nor a headless browser + ffmpeg is invocable in the delivery environment (R-STACK-01 probe)" },
  { id: "D-02", text: "Renderer modules live in src/ad/ next to the console app instead of nealarp-ad/src/", reason: "one source of truth; nealarp-ad/ keeps README, timeline.yaml, checklist, reference and tests, and the app imports the same modules" },
  { id: "D-03", text: "Fonts are requested by family name, not loaded from the TTF paths", reason: "a browser sandbox cannot read /usr/share/fonts; DejaVu Sans / DejaVu Sans Mono are first in the stack so a Linux render host resolves them" },
  { id: "D-04", text: "Reproducibility digest is SHA-256 instead of MD5", reason: "browsers expose no MD5; identical purpose, stronger algorithm" },
  { id: "D-05", text: "Export container is MP4 (avc1 + mp4a) where supported, otherwise WebM (VP9 + Opus)", reason: "MediaRecorder cannot be forced to libx264 -profile:v high; the ffmpeg command in README §3 is the compliant offline path" },
  { id: "D-06", text: "Voiceover is spoken live but not embedded in the exported file", reason: "speechSynthesis output cannot be routed into a Web Audio destination; the offline mix reads audio/vo/*.wav" },
  { id: "D-07", text: "Extra text layout template panel_label (36 px, tracking +0.08 em, white 62 %)", reason: "R-TXT-01 requires HERZSCHLÄGE / ATEMZÜGE / SCHRITTE inside 440x180 panels; no listed template covers panel captions" },
  { id: "D-08", text: "The blue->orange ramp keeps the exact endpoints but adds two near-white bridge stops", reason: "a direct #3b82f6 -> #f97316 lerp passes through ~10 deg hue at 35 % saturation, which R-VIS-02 / R-VER-06 forbid; priority 2 beats priority 4 (R-PRI)" },
  { id: "D-09", text: "One extra sfx recipe: sfx_riser (bandpass-swept noise + rising sine)", reason: "R-AUD-02 demands a rising riser at 0-8 s and cinematic risers at 32-44 s; the twelve recipes of R-AUD-03 are implemented unchanged and still one clear sound per cut" },
];

export const INTERPRETATIONS = [
  { id: "I-01", text: "Animated numeric read-outs (depth counter, life-statistic counters) are data, not copy", reason: "R-SCN-04/08 demand a count-up between the declared values while R-TXT-01 fixes the copy. The four depth strings and the three labels are rendered exactly and logged; the intermediate digits are logged separately as num_* so the R-TXT-01 diff stays clean." },
  { id: "I-02", text: "The password-rule rows are drawn as abstract 10 px glyph marks", reason: "R-SCN-03 wants 12 rows of mono glyphs scrolling over the lock, R-NEG-03 forbids text beyond R-TXT-01. Marks at 10 px and 40 % alpha read as rule text without introducing new strings." },
  { id: "I-03", text: "hold_frames means element stasis, not a frozen buffer", reason: "R-VIS-07 requires the grain tile to be re-offset every frame, so R-VER-10 is satisfied by motion in every window; declared holds are verified to keep text and key visuals static." },
];
