// ============================================================================
// nealarp-ad / constants  (R-TIME, R-VIS, R-TXT)
// All drawing happens in the 1920x1080 reference space; `scale` multiplies the
// canvas transform (1 = 1080p test, 2 = 2160p final).  R-VIS-12
// ============================================================================

export const FPS = 60; // R-TIME-01: t = frame / 60
export const DURATION = 60.0; // R-OUT-05
export const TOTAL_FRAMES = 3600; // R-VER-01
export const REF_W = 1920;
export const REF_H = 1080;
export const SEED = 7; // R-VIS-06
export const FOCAL = 900; // R-VIS-09
export const Z_MAX = 2000;
export const PARTICLE_CAP = 3000; // R-VIS-06
export const GRAIN_OPACITY = 0.035; // R-VIS-07
export const GRAIN_TILE = 512;
export const VIGNETTE = 0.25; // R-VIS-08
export const BLOOM_BLUR = 24; // R-VIS-05
export const BLOOM_ALPHA = 0.35;

export const SAFE = { left: 96, right: 96, top: 54, bottom: 54 }; // R-VIS-12
export const AUTOFIT = { maxWidth: 1440, step: 4, minSize: 64 }; // R-VIS-12 / R-TXT-03

export type ColorName = "blue" | "orange" | "white" | "black" | "haze";

/** R-VIS-02 — the only four colours that may appear on screen (+ the haze of R-VIS-01). */
export const HEX: Record<ColorName, string> = {
  blue: "#3b82f6",
  orange: "#f97316",
  white: "#ffffff",
  black: "#0a0a0a",
  haze: "#0f172a",
};

export const RGB: Record<ColorName, [number, number, number]> = {
  blue: [59, 130, 246],
  orange: [249, 115, 22],
  white: [255, 255, 255],
  black: [10, 10, 10],
  haze: [15, 23, 42],
};

const NAMED = new Set<string>(Object.keys(HEX));

/** Accepts a palette name ('blue') or a bare hex from timeline.yaml ('3b82f6'). */
export function resolveColor(c: unknown, fallback: ColorName = "white"): string {
  if (typeof c !== "string" || !c) return HEX[fallback];
  if (NAMED.has(c)) return HEX[c as ColorName];
  const hex = c.replace(/^#/, "");
  if (/^[0-9a-fA-F]{6}$/.test(hex)) return "#" + hex.toLowerCase();
  return HEX[fallback];
}

export function withAlpha(hex: string, a: number): string {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${Math.max(0, Math.min(1, a))})`;
}

export function rgba(name: ColorName, a: number): string {
  const [r, g, b] = RGB[name];
  return `rgba(${r},${g},${b},${Math.max(0, Math.min(1, a))})`;
}

// R-STACK-05 / D-03 — DejaVu requested first by family name, metric fallbacks after.
export const FONT_TITLE_STACK = `"DejaVu Sans","Liberation Sans","Helvetica Neue",Arial,sans-serif`;
export const FONT_MONO_STACK = `"DejaVu Sans Mono","Liberation Mono",ui-monospace,"Courier New",monospace`;
export const titleFont = (size: number) => `700 ${size.toFixed(1)}px ${FONT_TITLE_STACK}`;
export const monoFont = (size: number) => `400 ${size.toFixed(1)}px ${FONT_MONO_STACK}`;

/** R-TXT-01 — the complete on-screen copy. Not one character more, not one less. */
export const R_TXT = [
  "SPIELE UND ZEUG",
  "GELD AUSGEBEN",
  "DAS PASSWORT-SPIEL",
  "DIE TIEFSEE",
  "0 m",
  "1.000 m",
  "5.000 m",
  "11.034 m",
  "TEMPO",
  "ASTEROIDEN-WERFER",
  "100 MEGATONNEN",
  "PERFEKTER KREIS",
  "98 %",
  "LEBENSSTATISTIK",
  "HERZSCHLÄGE",
  "ATEMZÜGE",
  "SCHRITTE",
  "GRÖSSE DES WELTALLS",
  "nealarp",
  "BALD VERFÜGBAR",
  "AB 12. OKTOBER",
  "nealarp.vercel.app",
  "ERHÄLTLICH AB 12. OKTOBER",
];

/** R-STACK-06 — glyphs that must be covered by the title font. */
export const FONT_PROBE_CHARS = ["Ä", "ä", "Ö", "ö", "Ü", "ü", "ß", ".", ",", "%", "m"];

export const ACTS = [
  { id: "I", name: "OPENING", start: 0, end: 8 },
  { id: "II", name: "SHOWCASE", start: 8, end: 32 },
  { id: "III", name: "HERO", start: 32, end: 44 },
  { id: "IV", name: "CALL TO ACTION", start: 44, end: 60 },
] as const;

export const SCENE_LABELS: Record<string, string> = {
  opening: "OPENING · TUNNEL",
  game_01_wallet: "CUT 1 · GELD AUSGEBEN",
  game_02_password: "CUT 2 · DAS PASSWORT-SPIEL",
  game_03_deepsea: "CUT 3 · DIE TIEFSEE",
  game_04_tempo: "CUT 4 · TEMPO",
  game_05_asteroid: "CUT 5 · ASTEROIDEN-WERFER",
  game_06_circle: "CUT 6 · PERFEKTER KREIS",
  game_07_lifestats: "CUT 7 · LEBENSSTATISTIK",
  game_08_universe: "CUT 8 · GRÖSSE DES WELTALLS",
  hero: "HERO · STAR SPHERE",
  cta: "CTA · 12. OKTOBER 2026",
};
