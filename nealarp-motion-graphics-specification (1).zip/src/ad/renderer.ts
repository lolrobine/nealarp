// ============================================================================
// nealarp-ad / renderer — renderFrame(canvas, t, scale) is a PURE FUNCTION of
// time (R-OUT-02). No accumulation between frames: every particle, every
// envelope, every letter is recomputed from timeline.yaml + seed 7.
// ============================================================================

import { DURATION, FPS, REF_H, REF_W, rgba } from "./constants";
import {
  compositeBloom,
  drawBackground,
  drawGrain,
  drawVignette,
  ensureGlow,
  makeCaches,
  type Caches,
  type FrameCtx,
} from "./core";
import { resetTextLog } from "./text";
import { el, sceneAt, sceneById, type Scene } from "./timeline";
import { ease, progress } from "./easing";
import { drawDeepSea, drawOpening, drawPassword, drawTempo, drawWallet } from "./scenesA";
import { drawAsteroid, drawCircle, drawCta, drawHero, drawLifeStats, drawUniverse } from "./scenesB";

export const SCENE_RENDERERS: Record<string, (fc: FrameCtx, sc: Scene) => void> = {
  opening: drawOpening,
  game_01_wallet: drawWallet,
  game_02_password: drawPassword,
  game_03_deepsea: drawDeepSea,
  game_04_tempo: drawTempo,
  game_05_asteroid: drawAsteroid,
  game_06_circle: drawCircle,
  game_07_lifestats: drawLifeStats,
  game_08_universe: drawUniverse,
  hero: drawHero,
  cta: drawCta,
};

const shared = makeCaches();

export interface RenderOptions {
  caches?: Caches;
  frame?: number;
  /** skip the grain pass (used by the palette/background probes for a clean read) */
  grain?: boolean;
}

export const frameToTime = (frame: number) => frame / FPS;
export const timeToFrame = (t: number) => Math.round(t * FPS);

/** THE frame function. scale 1 = 1920x1080, scale 2 = 3840x2160 (R-VIS-12). */
export function renderFrame(canvas: HTMLCanvasElement, t: number, scale = 1, opts: RenderOptions = {}) {
  const w = Math.round(REF_W * scale);
  const h = Math.round(REF_H * scale);
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w;
    canvas.height = h;
  }
  const ctx = canvas.getContext("2d", { alpha: false }) as CanvasRenderingContext2D | null;
  if (!ctx) return;

  const caches = opts.caches ?? shared;
  const time = Math.max(0, Math.min(DURATION - 1 / (FPS * 2), t));
  const frame = opts.frame ?? timeToFrame(time);

  const fc: FrameCtx = { ctx, glow: null, scale, t: time, w, h, caches };

  resetTextLog();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";
  ctx.filter = "none";
  ctx.setTransform(scale, 0, 0, scale, 0, 0);

  drawBackground(fc); // R-VIS-01
  fc.glow = ensureGlow(fc);

  const sc = sceneAt(time);
  if (sc) {
    const fn = SCENE_RENDERERS[sc.scene];
    if (fn) fn(fc, sc);
  }

  compositeBloom(fc); // R-VIS-05
  if (opts.grain !== false) drawGrain(fc, frame); // R-VIS-07
  drawVignette(fc); // R-VIS-08

  // R-SCN-11: fade to black 59.0-60.0, driven by the declared element
  const fadeEl = el(sceneById("cta"), "fade_black");
  if (fadeEl) {
    const p = ease(fadeEl.ease, progress(time, fadeEl.start, fadeEl.end));
    if (p > 0) {
      ctx.save();
      ctx.setTransform(scale, 0, 0, scale, 0, 0);
      ctx.fillStyle = rgba("black", p);
      ctx.fillRect(0, 0, REF_W, REF_H);
      ctx.restore();
    }
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
}

/** render into a fresh offscreen canvas and return it (stills, probes, export) */
export function renderStill(t: number, scale = 1, caches?: Caches): HTMLCanvasElement {
  const c = document.createElement("canvas");
  renderFrame(c, t, scale, { caches });
  return c;
}

export function newCaches(): Caches {
  return makeCaches();
}

export const REFERENCE = { w: REF_W, h: REF_H, fps: FPS, duration: DURATION };
