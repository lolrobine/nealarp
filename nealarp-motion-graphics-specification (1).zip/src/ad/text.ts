// ============================================================================
// nealarp-ad / text — the ONLY place where characters reach the screen
// (R-TXT-02). Layout templates from R-VIS-12, auto-fit from R-TXT-03, and a
// layout log consumed by R-VER-08 / R-VER-09.
// ============================================================================

import { AUTOFIT, HEX, SAFE, rgba, titleFont, withAlpha } from "./constants";
import { clamp01, ease, lerp } from "./easing";
import { glass, rampColor, type FrameCtx } from "./core";
import type { TextDef } from "./timeline";

export type LayoutId =
  | "title_lower_third"
  | "title_opening"
  | "counter_center"
  | "claim_white"
  | "claim_gradient"
  | "url"
  | "cta_button_label"
  | "panel_label";

export interface Template {
  size: number;
  color: "gradient" | "white" | "orange";
  tracking: number; // em
  at: [number, number];
  baseline: "alphabetic" | "middle";
  uppercase: boolean;
  panel: "glass" | null;
  alpha: number;
}

/** R-VIS-12 text layout templates, in 1920x1080 reference px. */
export const TEMPLATES: Record<LayoutId, Template> = {
  title_lower_third: {
    size: 96,
    color: "gradient",
    tracking: 0.04,
    at: [960, 880],
    baseline: "alphabetic",
    uppercase: true,
    panel: "glass",
    alpha: 1,
  },
  title_opening: {
    size: 180,
    color: "gradient",
    tracking: 0.04,
    at: [960, 540],
    baseline: "middle",
    uppercase: true,
    panel: null,
    alpha: 1,
  },
  counter_center: {
    size: 160,
    color: "white",
    tracking: 0.01,
    at: [960, 520],
    baseline: "middle",
    uppercase: false,
    panel: null,
    alpha: 1,
  },
  claim_white: {
    size: 112,
    color: "white",
    tracking: 0.02,
    at: [960, 540],
    baseline: "middle",
    uppercase: true,
    panel: null,
    alpha: 1,
  },
  claim_gradient: {
    size: 96,
    color: "gradient",
    tracking: 0.04,
    at: [960, 540],
    baseline: "middle",
    uppercase: true,
    panel: null,
    alpha: 1,
  },
  url: {
    size: 72,
    color: "white",
    tracking: 0.02,
    at: [960, 600],
    baseline: "middle",
    uppercase: false,
    panel: null,
    alpha: 1,
  },
  cta_button_label: {
    size: 44,
    color: "white",
    tracking: 0.06,
    at: [960, 780],
    baseline: "middle",
    uppercase: true,
    panel: null,
    alpha: 1,
  },
  // D-07: panel captions required by R-TXT-01 (HERZSCHLÄGE / ATEMZÜGE / SCHRITTE)
  panel_label: {
    size: 36,
    color: "white",
    tracking: 0.08,
    at: [960, 424],
    baseline: "middle",
    uppercase: true,
    panel: null,
    alpha: 0.62,
  },
};

export const TEMPLATE_IDS = Object.keys(TEMPLATES) as LayoutId[];

export interface TextLogEntry {
  id: string;
  string: string;
  layout: string;
  scene: string;
  t: number;
  sizeRequested: number;
  size: number;
  autofitSteps: number;
  width: number;
  height: number;
  bbox: [number, number, number, number];
  at: [number, number];
  color: string;
  alpha: number;
  inSafeArea: boolean;
  display?: string;
}

let frameLog: TextLogEntry[] = [];
export function resetTextLog() {
  frameLog = [];
}
export function getTextLog(): TextLogEntry[] {
  return frameLog;
}

export interface TextFx {
  alpha?: number;
  reveal?: number; // seconds since the text started
  perLetter?: number; // stagger in seconds per letter (R-SCN-01: 0.033-0.050)
  letterDur?: number;
  tail?: number; // number of trailing letters with a motion-blur tail
  tailAlpha?: number;
  /** animated counter value: drawn on screen, while `def.string` (approved copy,
   *  R-TXT-01) is what gets logged. Interpretation I-01 in the report. */
  display?: string;
  scale?: number;
  dx?: number;
  dy?: number;
  glow?: number;
  perLetterGradient?: boolean;
}

// per-letter colour comes from the palette-safe ramp (D-08)
const mixHex = (_a: string, _b: string, t: number): string => rampColor(t);

interface Letter {
  ch: string;
  w: number;
  x: number;
}

function measureLetters(ctx: CanvasRenderingContext2D, s: string, size: number, tracking: number) {
  ctx.font = titleFont(size);
  const adv = tracking * size;
  const letters: Letter[] = [];
  let total = 0;
  for (const ch of s) {
    const w = ctx.measureText(ch).width;
    letters.push({ ch, w, x: total });
    total += w + adv;
  }
  if (letters.length) total -= adv;
  return { letters, total };
}

/** R-TXT-03 auto-fit: >1440 px wide -> shrink in 4 px steps down to 64 px. */
function fitSize(ctx: CanvasRenderingContext2D, s: string, size: number, tracking: number) {
  let cur = size;
  let steps = 0;
  let { total } = measureLetters(ctx, s, cur, tracking);
  while (total > AUTOFIT.maxWidth && cur - AUTOFIT.step >= AUTOFIT.minSize) {
    cur -= AUTOFIT.step;
    steps++;
    total = measureLetters(ctx, s, cur, tracking).total;
  }
  return { size: cur, steps, width: total };
}

export interface ResolvedText {
  def: TextDef;
  scene: string;
  tpl: Template;
  size: number;
  at: [number, number];
  color: "gradient" | "white" | "orange";
  alpha: number;
  tracking: number;
}

export function resolveText(def: TextDef, scene: string, ctx: CanvasRenderingContext2D, override?: string): ResolvedText {
  const tpl = { ...(TEMPLATES[(def.layout as LayoutId) ?? "claim_white"] ?? TEMPLATES.claim_white) };
  const p = def.props ?? {};
  const requested = typeof p.size === "number" ? p.size : tpl.size;
  const tracking = typeof p.tracking === "number" ? p.tracking : tpl.tracking;
  const src = override ?? def.string;
  const s = tpl.uppercase ? src.toUpperCase() : src;
  const fit = fitSize(ctx, s, requested, tracking);
  const at = (Array.isArray(p.at) ? (p.at as number[]) : tpl.at) as [number, number];
  const color = (typeof p.color === "string" ? (p.color as ResolvedText["color"]) : tpl.color) as ResolvedText["color"];
  return { def, scene, tpl, size: fit.size, at, color, alpha: tpl.alpha, tracking };
}

/** Draw one timeline text entry. The single entry point for all on-screen copy. */
export function drawLayoutText(fc: FrameCtx, def: TextDef, scene: string, fx: TextFx = {}): TextLogEntry | null {
  const { ctx } = fc;
  const t = fc.t;
  if (t < def.start || t >= def.end) return null;

  const shown = fx.display ?? def.string;
  const r = resolveText(def, scene, ctx, shown);
  const tpl = r.tpl;
  const p = def.props ?? {};
  const raw = tpl.uppercase ? shown.toUpperCase() : shown;

  ctx.save();
  ctx.textBaseline = tpl.baseline;
  ctx.textAlign = "left";

  const { letters, total } = measureLetters(ctx, raw, r.size, r.tracking);
  const cx = r.at[0] + (fx.dx ?? 0);
  const cy = r.at[1] + (fx.dy ?? 0);
  const scale = fx.scale ?? 1;
  const x0 = cx - (total * scale) / 2;

  const m = ctx.measureText(raw);
  const asc = m.actualBoundingBoxAscent || r.size * 0.74;
  const desc = m.actualBoundingBoxDescent || r.size * 0.24;
  const topY = tpl.baseline === "alphabetic" ? cy - asc : cy - r.size * 0.5 - r.size * 0.12;
  const botY = tpl.baseline === "alphabetic" ? cy + desc : cy + r.size * 0.5 + r.size * 0.12;

  const bbox: [number, number, number, number] = [
    x0,
    Math.min(topY, botY),
    x0 + total * scale,
    Math.max(topY, botY),
  ];
  const inSafe =
    bbox[0] >= SAFE.left - 0.5 && bbox[2] <= 1920 - SAFE.right + 0.5 && bbox[1] >= SAFE.top - 0.5 && bbox[3] <= 1080 - SAFE.bottom + 0.5;

  const baseAlpha = (fx.alpha ?? 1) * (typeof p.alpha === "number" ? p.alpha : 1) * r.alpha;

  // --- glass panel behind lower thirds (R-VIS-04 + template) --------------
  if (tpl.panel === "glass" && baseAlpha > 0.02) {
    const padX = 48;
    const padY = 28;
    glass(
      fc,
      bbox[0] - padX,
      bbox[1] - padY,
      bbox[2] - bbox[0] + padX * 2,
      bbox[3] - bbox[1] + padY * 2,
      24,
      baseAlpha,
    );
  }

  // --- letters ------------------------------------------------------------
  const perLetter = fx.perLetter ?? 0;
  const letterDur = fx.letterDur ?? 0.3;
  const reveal = fx.reveal;
  const tailCount = fx.tail ?? 0;
  const tailAlpha = fx.tailAlpha ?? 0.3;
  const n = letters.length;

  const paintLetter = (L: Letter, i: number, ghost: number, ghostAlpha: number) => {
    let a = baseAlpha;
    let dy = 0;
    let sx = 1;
    if (reveal !== undefined && perLetter > 0) {
      const lp = clamp01((reveal - i * perLetter) / letterDur);
      const e = ease("EXPO_OUT", lp);
      a *= e;
      dy = (1 - e) * 26;
      sx = lerp(1.14, 1, e);
    } else if (reveal !== undefined) {
      a *= clamp01(reveal / Math.max(1e-6, letterDur));
    }
    if (a <= 0.004) return;

    const lx = x0 + L.x * scale;
    const isTail = tailCount > 0 && i >= n - tailCount;
    const paint = (offX: number, alphaMul: number) => {
      ctx.save();
      ctx.globalAlpha = clamp01(a * alphaMul * ghostAlpha);
      const w = L.w * scale * sx;
      if (r.color === "gradient") {
        const pLeft = total > 0 ? (L.x + offX / scale) / total : 0;
        const pRight = total > 0 ? (L.x + L.w) / total : 1;
        const g = ctx.createLinearGradient(lx + offX, cy, lx + offX + w, cy);
        if (fx.perLetterGradient === false) {
          g.addColorStop(0, HEX.blue);
          g.addColorStop(1, HEX.orange);
        } else {
          g.addColorStop(0, mixHex(HEX.blue, HEX.orange, pLeft));
          g.addColorStop(1, mixHex(HEX.blue, HEX.orange, pRight));
        }
        ctx.fillStyle = g;
      } else if (r.color === "orange") {
        ctx.fillStyle = HEX.orange;
      } else {
        ctx.fillStyle = HEX.white;
      }
      ctx.font = titleFont(r.size * scale * sx);
      ctx.textBaseline = tpl.baseline;
      ctx.fillText(L.ch, lx + offX, cy + dy);
      ctx.restore();
    };

    if (isTail && ghost > 0) {
      // motion-blur tail on the final letters (R-SCN-01, R-REF-02)
      for (let k = ghost; k >= 1; k--) paint(-k * 13 * scale, tailAlpha * (1 - k / (ghost + 1)) + 0.05);
    }
    paint(0, 1);

    if (fx.glow && fc.glow) {
      fc.glow.save();
      fc.glow.globalAlpha = clamp01(a * fx.glow);
      fc.glow.fillStyle = r.color === "gradient" ? HEX.orange : HEX.white;
      fc.glow.font = titleFont(r.size * scale);
      fc.glow.textBaseline = tpl.baseline;
      fc.glow.fillText(L.ch, lx, cy + dy);
      fc.glow.restore();
    }
  };

  const ghosts = tailCount > 0 ? 5 : 0;
  for (let i = 0; i < n; i++) paintLetter(letters[i], i, ghosts, 1);

  ctx.restore();

  const entry: TextLogEntry = {
    id: def.id,
    string: def.string,
    layout: def.layout,
    scene,
    t,
    sizeRequested: typeof (def.props ?? {}).size === "number" ? ((def.props as Record<string, number>).size as number) : tpl.size,
    size: r.size,
    autofitSteps: Math.round(((typeof p.size === "number" ? (p.size as number) : tpl.size) - r.size) / AUTOFIT.step),
    width: total * scale,
    height: bbox[3] - bbox[1],
    bbox,
    at: [cx, cy],
    color: r.color,
    alpha: baseAlpha,
    inSafeArea: inSafe,
    display: shown === def.string ? undefined : shown,
  };
  frameLog.push(entry);
  return entry;
}

/** draw all text of a scene that is inside its window (called by the renderer) */
export function drawSceneText(
  fc: FrameCtx,
  scene: { scene: string; text: TextDef[] },
  fxFor: (def: TextDef) => TextFx,
) {
  for (const def of scene.text) drawLayoutText(fc, def, scene.scene, fxFor(def));
}

/** alpha of a text entry's fade-in window, used for particle-reform targets */
export function textAlpha(def: TextDef, t: number, fadeIn = 0.25, fadeOut = 0.25) {
  if (t < def.start || t >= def.end) return 0;
  return clamp01(Math.min((t - def.start) / fadeIn, (def.end - t) / fadeOut, 1));
}

export { rgba, withAlpha };
