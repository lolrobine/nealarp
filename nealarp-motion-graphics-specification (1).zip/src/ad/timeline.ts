// ============================================================================
// nealarp-ad / timeline — timeline.yaml is parsed at runtime and is the single
// source of truth for every start/end/prop on screen (R-OUT-02, R-TIME-04).
// ============================================================================

import rawYaml from "../../nealarp-ad/timeline.yaml?raw";
import { parseYaml } from "./yaml";
import { TOTAL_FRAMES, DURATION, FPS } from "./constants";

export type Props = Record<string, unknown>;

export interface El {
  id: string;
  type: string;
  rect: [number, number, number, number] | null;
  center: [number, number] | null;
  start: number;
  end: number;
  ease: string;
  props: Props;
}

export interface TextDef {
  id: string;
  string: string;
  layout: string;
  start: number;
  end: number;
  props: Props;
}

export interface Cue {
  id: string;
  at: number;
  dur?: number;
  string?: string;
}

export interface Scene {
  scene: string;
  act: string;
  start: number;
  end: number;
  layout: string;
  elements: El[];
  text: TextDef[];
  sfx: Cue[];
  vo: Cue[];
  hold: [number, number][];
}

export interface Meta {
  fps: number;
  duration: number;
  frames: number;
  seed: number;
  focal: number;
  release: string;
  raw: Record<string, unknown>;
}

const num = (v: unknown, d = 0): number => (typeof v === "number" && isFinite(v) ? v : parseFloat(String(v ?? "")) || d);
const str = (v: unknown, d = ""): string => (v === null || v === undefined ? d : String(v));
const arrNum = (v: unknown): number[] => (Array.isArray(v) ? v.map((x) => num(x)) : []);
const obj = (v: unknown): Props => (v && typeof v === "object" && !Array.isArray(v) ? (v as Props) : {});
const list = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);

export const YAML_RAW = rawYaml;

function buildScenes(parsed: Record<string, unknown>): Scene[] {
  const out: Scene[] = [];
  for (const s of list(parsed.scenes)) {
    const so = obj(s);
    const audio = obj(so.audio);
    const elements: El[] = list(so.elements).map((e) => {
      const eo = obj(e);
      const rect = Array.isArray(eo.rect) ? (arrNum(eo.rect) as [number, number, number, number]) : null;
      const center = Array.isArray(eo.center) ? (arrNum(eo.center) as [number, number]) : null;
      return {
        id: str(eo.id),
        type: str(eo.type),
        rect,
        center,
        start: num(eo.start),
        end: num(eo.end),
        ease: str(eo.ease, "EASE_IO"),
        props: obj(eo.props),
      };
    });
    const text: TextDef[] = list(so.text).map((e) => {
      const eo = obj(e);
      return {
        id: str(eo.id),
        string: str(eo.string),
        layout: str(eo.layout),
        start: num(eo.start),
        end: num(eo.end),
        props: obj(eo.props),
      };
    });
    const cues = (v: unknown): Cue[] =>
      list(v).map((c) => {
        const co = obj(c);
        return { id: str(co.id), at: num(co.at), dur: co.dur === undefined ? undefined : num(co.dur), string: co.string === undefined ? undefined : str(co.string) };
      });
    out.push({
      scene: str(so.scene),
      act: str(so.act),
      start: num(so.start),
      end: num(so.end),
      layout: str(so.layout),
      elements,
      text,
      sfx: cues(audio.sfx),
      vo: cues(audio.vo),
      hold: list(so.hold_frames).map((h) => arrNum(h) as [number, number]),
    });
  }
  return out;
}

const parsedRoot = (parseYaml(rawYaml) ?? {}) as Record<string, unknown>;
const metaRaw = obj(parsedRoot.meta);

export const META: Meta = {
  fps: num(metaRaw.fps, FPS),
  duration: num(metaRaw.duration, DURATION),
  frames: num(metaRaw.frames, TOTAL_FRAMES),
  seed: num(metaRaw.seed, 7),
  focal: num(metaRaw.focal, 900),
  release: str(metaRaw.release, "2026-10-12"),
  raw: metaRaw,
};

export const SCENES: Scene[] = buildScenes(parsedRoot);

/** sanity: a broken parse must be loud, never silent */
export const TIMELINE_PARSE_OK =
  SCENES.length === 11 &&
  Math.abs(SCENES[0].start) < 1e-9 &&
  Math.abs(SCENES[SCENES.length - 1].end - 60) < 1e-9 &&
  SCENES.every((s) => s.elements.length > 0);

export const TIMELINE_STATS = {
  scenes: SCENES.length,
  elements: SCENES.reduce((a, s) => a + s.elements.length, 0),
  textEntries: SCENES.reduce((a, s) => a + s.text.length, 0),
  sfx: SCENES.reduce((a, s) => a + s.sfx.length, 0),
  vo: SCENES.reduce((a, s) => a + s.vo.length, 0),
  holds: SCENES.reduce((a, s) => a + s.hold.length, 0),
};

export const ALL_SFX: (Cue & { scene: string })[] = SCENES.flatMap((s) => s.sfx.map((c) => ({ ...c, scene: s.scene })));
export const ALL_VO: (Cue & { scene: string })[] = SCENES.flatMap((s) => s.vo.map((c) => ({ ...c, scene: s.scene }))).sort(
  (a, b) => a.at - b.at,
);
export const ALL_TEXT: (TextDef & { scene: string })[] = SCENES.flatMap((s) => s.text.map((d) => ({ ...d, scene: s.scene })));
export const ALL_HOLDS: [number, number][] = SCENES.flatMap((s) => s.hold);

export function sceneAt(t: number): Scene | undefined {
  return SCENES.find((s) => t >= s.start && t < s.end) ?? (t >= 60 ? SCENES[SCENES.length - 1] : undefined);
}

export function sceneById(id: string): Scene | undefined {
  return SCENES.find((s) => s.scene === id);
}

export function el(scene: Scene | undefined, id: string): El | undefined {
  return scene?.elements.find((e) => e.id === id);
}

export function elsOfType(scene: Scene | undefined, type: string): El[] {
  return scene?.elements.filter((e) => e.type === type) ?? [];
}

/** active elements of a scene at time t (R-TIME-04) */
export function activeElements(scene: Scene, t: number): El[] {
  return scene.elements.filter((e) => t >= e.start && t < e.end);
}

export function isHold(t: number): boolean {
  return ALL_HOLDS.some(([a, b]) => t >= a && t < b);
}

// --- prop accessors -------------------------------------------------------
export const pNum = (e: El | undefined, k: string, d = 0): number => num(e?.props?.[k], d);
export const pStr = (e: El | undefined, k: string, d = ""): string => str(e?.props?.[k], d);
export const pArr = (e: El | undefined, k: string): number[] => arrNum(e?.props?.[k]);
export const pStrArr = (e: El | undefined, k: string): string[] => list(e?.props?.[k]).map((x) => str(x));
export const pBool = (e: El | undefined, k: string, d = false): boolean => {
  const v = e?.props?.[k];
  return typeof v === "boolean" ? v : v === undefined ? d : String(v) === "true";
};
