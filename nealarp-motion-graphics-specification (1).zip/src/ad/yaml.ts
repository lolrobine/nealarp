// ============================================================================
// nealarp-ad / yaml — a small, strict parser for the subset of YAML used by
// timeline.yaml (block maps, block sequences, flow maps, flow sequences,
// scalars, quoted strings, comments).
//
// It exists so the browser renderer is provably driven by the *same file* the
// spec names as the source of truth (R-OUT-02, R-TIME-04) instead of a hand
// copied JS object.
// ============================================================================

export type Y = string | number | boolean | null | Y[] | { [k: string]: Y };

interface Line {
  indent: number;
  text: string;
}

/** strip a trailing # comment, respecting quotes */
function stripComment(s: string): string {
  let q: string | null = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) {
      if (c === q) q = null;
      continue;
    }
    if (c === '"' || c === "'") {
      q = c;
      continue;
    }
    if (c === "#") {
      if (i === 0 || /\s/.test(s[i - 1])) return s.slice(0, i);
    }
  }
  return s;
}

/** index of the top-level ':' that separates a key from its value, or -1 */
function keyColon(s: string): number {
  let depth = 0;
  let q: string | null = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) {
      if (c === q) q = null;
      continue;
    }
    if (c === '"' || c === "'") {
      q = c;
      continue;
    }
    if (c === "[" || c === "{") depth++;
    else if (c === "]" || c === "}") depth--;
    else if (c === ":" && depth === 0) {
      const next = s[i + 1];
      if (next === undefined || next === " " || next === "\t") return i;
    }
  }
  return -1;
}

/** split on top-level commas, respecting nesting and quotes */
function splitTop(s: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let q: string | null = null;
  let cur = "";
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) {
      cur += c;
      if (c === q) q = null;
      continue;
    }
    if (c === '"' || c === "'") {
      q = c;
      cur += c;
      continue;
    }
    if (c === "[" || c === "{") depth++;
    if (c === "]" || c === "}") depth--;
    if (c === "," && depth === 0) {
      out.push(cur.trim());
      cur = "";
      continue;
    }
    cur += c;
  }
  if (cur.trim()) out.push(cur.trim());
  return out.filter((p) => p.length > 0);
}

function parseScalar(raw: string): Y {
  const s = raw.trim();
  if (!s) return null;
  if (s[0] === "[" && s[s.length - 1] === "]") return parseSeq(s.slice(1, -1));
  if (s[0] === "{" && s[s.length - 1] === "}") return parseMap(s.slice(1, -1));
  if ((s[0] === '"' && s[s.length - 1] === '"') || (s[0] === "'" && s[s.length - 1] === "'"))
    return s.slice(1, -1);
  if (s === "true") return true;
  if (s === "false") return false;
  if (s === "null" || s === "~") return null;
  if (/^-?\d+$/.test(s)) return parseInt(s, 10);
  if (/^-?\d*\.\d+$/.test(s) || /^-?\d+\.\d*$/.test(s)) return parseFloat(s);
  return s;
}

function parseSeq(body: string): Y[] {
  return splitTop(body).map(parseScalar);
}

function parseMap(body: string): { [k: string]: Y } {
  const out: { [k: string]: Y } = {};
  for (const part of splitTop(body)) {
    const ci = keyColon(part);
    if (ci < 0) continue;
    out[part.slice(0, ci).trim()] = parseScalar(part.slice(ci + 1));
  }
  return out;
}

function parseBlock(lines: Line[], i: number, indent: number): [Y, number] {
  if (i >= lines.length) return [null, i];
  if (lines[i].text === "-" || lines[i].text.startsWith("- ")) return parseBlockSeq(lines, i, indent);
  return parseBlockMap(lines, i, indent);
}

function parseBlockSeq(lines: Line[], start: number, indent: number): [Y[], number] {
  const arr: Y[] = [];
  let i = start;
  while (i < lines.length && lines[i].indent === indent && (lines[i].text === "-" || lines[i].text.startsWith("- "))) {
    const raw = lines[i].text;
    const content = raw === "-" ? "" : raw.slice(2).trim();
    if (content === "") {
      if (i + 1 < lines.length && lines[i + 1].indent > indent) {
        const [v, ni] = parseBlock(lines, i + 1, lines[i + 1].indent);
        arr.push(v);
        i = ni;
      } else {
        arr.push(null);
        i++;
      }
      continue;
    }
    // "- key: value" -> the item is a map whose keys start at the content column
    const contentIndent = indent + (raw.length - raw.slice(2).trimStart().length);
    if (content[0] !== "[" && content[0] !== "{" && keyColon(content) >= 0) {
      lines[i] = { indent: contentIndent, text: content };
      const [v, ni] = parseBlockMap(lines, i, contentIndent);
      arr.push(v);
      i = ni;
      continue;
    }
    arr.push(parseScalar(content));
    i++;
  }
  return [arr, i];
}

function parseBlockMap(lines: Line[], start: number, indent: number): [{ [k: string]: Y }, number] {
  const obj: { [k: string]: Y } = {};
  let i = start;
  while (i < lines.length) {
    const ln = lines[i];
    if (ln.indent < indent) break;
    if (ln.indent > indent) {
      i++; // tolerate stray deeper line
      continue;
    }
    if (ln.text === "-" || ln.text.startsWith("- ")) break;
    const ci = keyColon(ln.text);
    if (ci < 0) {
      i++;
      continue;
    }
    const key = ln.text.slice(0, ci).trim().replace(/^["']|["']$/g, "");
    const rest = ln.text.slice(ci + 1).trim();
    if (rest === "") {
      if (i + 1 < lines.length && lines[i + 1].indent > indent) {
        const [v, ni] = parseBlock(lines, i + 1, lines[i + 1].indent);
        obj[key] = v;
        i = ni;
      } else {
        obj[key] = null;
        i++;
      }
      continue;
    }
    obj[key] = parseScalar(rest);
    i++;
  }
  return [obj, i];
}

export function parseYaml(src: string): Y {
  const lines: Line[] = [];
  for (const raw of src.split("\n")) {
    const noTabs = raw.replace(/\t/g, "  ");
    const clean = stripComment(noTabs);
    if (!clean.trim()) continue;
    const indent = clean.length - clean.trimStart().length;
    lines.push({ indent, text: clean.trim() });
  }
  if (!lines.length) return null;
  const [val] = parseBlock(lines, 0, lines[0].indent);
  return val;
}
