// ============================================================================
// nealarp-ad / rng  (R-VIS-06 — seeded random generator, fixed seed 7)
// Deterministic: the same seed always yields the same particle field, which is
// what makes renderFrame() a pure function of time and R-VER-13 reproducible.
// ============================================================================

import { SEED } from "./constants";

export type Rng = () => number;

/** mulberry32 — small, fast, well distributed, deterministic. */
export function rng(seed: number = SEED): Rng {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function range(r: Rng, min: number, max: number): number {
  return min + (max - min) * r();
}

/** Pre-compute `n` deterministic values (R-PERF-01: computed once, not per frame). */
export function table(n: number, seed: number = SEED): Float32Array {
  const r = rng(seed);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = r();
  return out;
}

/** n values in [min,max] */
export function tableRange(n: number, min: number, max: number, seed: number = SEED): Float32Array {
  const r = rng(seed);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = min + (max - min) * r();
  return out;
}

/** Stable per-index pseudo random in [0,1) without allocating (hash based). */
export function hash01(i: number, salt = 0): number {
  let h = (i * 374761393 + salt * 668265263) >>> 0;
  h = (h ^ (h >>> 13)) >>> 0;
  h = Math.imul(h, 1274126177) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
