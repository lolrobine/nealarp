// ============================================================================
// nealarp-ad / scenesB — cuts 5-8 of ACT II, ACT III hero, ACT IV call to action
// ============================================================================

import { HEX, SEED, rgba, withAlpha } from "./constants";
import { clamp01, ease, lerp, progress } from "./easing";
import {
  flare,
  formatDE,
  glass,
  glowDot,
  gradBO,
  gradBORadial,
  gradRadial,
  rampColor,
  rrect,
  samplePoints,
  type FrameCtx,
} from "./core";
import { TEMPLATES, drawLayoutText, type LayoutId } from "./text";
import { el, pNum, pStrArr, type El, type Scene, type TextDef } from "./timeline";
import { rng } from "./rng";
import {
  ORBIT_SPRITES,
  TAU,
  drawBuilding,
  drawHuman,
  drawMeteor,
  drawMountain,
  drawPlanet,
  drawSun,
  drawTelescope,
} from "./art";
import { applyShake, drawCutDecor, drawCutOut, drawCutTitle, drawFlicker, drawStreaks } from "./scenesA";

const P = (t: number, e?: El) => (e ? progress(t, e.start, e.end) : 0);
type Win = { start: number; end: number };
const ON = (t: number, e?: Win | null) => !!e && t >= e.start && t < e.end;
const ramp = (t: number, start: number, dur: number) => clamp01((t - start) / Math.max(1e-6, dur));

/** animated numeric read-outs (data, not copy — interpretation I-01): they still
 *  go through the text layout system so they are measured, fitted and logged. */
function drawNumber(fc: FrameCtx, scene: string, id: string, value: string, at: [number, number], size: number, color: "white" | "orange" = "white", alpha = 1) {
  const def: TextDef = {
    id,
    string: value,
    layout: "counter_center",
    start: fc.t,
    end: fc.t + 1 / 60,
    props: { at, size, color },
  };
  drawLayoutText(fc, def, scene, { alpha });
}

// ===========================================================================
// CUT 5 — ASTEROIDEN-WERFER 20.0-23.0  (R-SCN-06)
// ===========================================================================
export function drawAsteroid(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  drawCutDecor(fc, sc);
  const restore = applyShake(fc, sc, "shake_impact");

  const earth = el(sc, "earth");
  if (earth?.center && ON(t, earth)) {
    const a = ease(earth.ease, ramp(t, earth.start, 0.45));
    const r = pNum(earth, "radius", 210) * lerp(0.94, 1, a);
    drawPlanet(ctx, earth.center[0], earth.center[1], r, a);
    if (fc.glow) glowDot(fc, earth.center[0], earth.center[1], r * 1.5, "blue", 0.2 * a);
  }

  const crater = el(sc, "crater");
  if (crater?.center && ON(t, crater)) {
    const p = ease(crater.ease, P(t, crater));
    const rx = pNum(crater, "rx", 74) * p;
    const ry = pNum(crater, "ry", 28) * p;
    ctx.save();
    ctx.beginPath();
    ctx.ellipse(crater.center[0], crater.center[1], rx, ry, 0, 0, TAU);
    ctx.fillStyle = rgba("black", 0.95);
    ctx.fill();
    ctx.lineWidth = pNum(crater, "rim_width", 3);
    ctx.strokeStyle = rgba("blue", 0.9);
    ctx.stroke();
    ctx.restore();
  }

  const meteor = el(sc, "meteor");
  if (meteor && ON(t, meteor)) {
    const from = (meteor.props.from as number[]) ?? [1500, 60];
    const to = (meteor.props.to as number[]) ?? [1000, 470];
    const p = ease(meteor.ease, P(t, meteor));
    drawMeteor(ctx, from[0], from[1], to[0], to[1], p, clamp01((meteor.end - t) / 0.1), pNum(meteor, "tail", 260));
  }

  const shock = el(sc, "shockwave");
  if (shock?.center && ON(t, shock)) {
    const rings = Math.round(pNum(shock, "rings", 5));
    const maxR = pNum(shock, "radius", 700);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < rings; i++) {
      const local = t - shock.start - i * 0.07;
      if (local < 0) continue;
      const p = ease("EXPO_OUT", clamp01(local / 1.5));
      const a = (1 - clamp01(local / 1.5)) * 0.85;
      if (a <= 0.01) continue;
      ctx.beginPath();
      ctx.arc(shock.center[0], shock.center[1], maxR * p, 0, TAU);
      ctx.lineWidth = pNum(shock, "stroke", 3);
      ctx.strokeStyle = rgba("orange", a);
      ctx.stroke();
    }
    ctx.restore();
  }

  const flash = el(sc, "impact_flash");
  if (flash?.center && ON(t, flash)) {
    const p = ease(flash.ease, P(t, flash));
    glowDot(fc, flash.center[0], flash.center[1], pNum(flash, "radius", 320) * (0.3 + p), "white", pNum(flash, "alpha", 0.55) * (1 - p));
    flare(fc, flash.center[0], flash.center[1], 900 * (1 - p * 0.5), 5, 90, 0.5 * (1 - p));
  }

  restore();

  for (const def of sc.text) {
    if (def.id === "megatons") {
      drawLayoutText(fc, def, sc.scene, {
        reveal: t - def.start,
        perLetter: 0.03,
        letterDur: 0.22,
        glow: 0.3,
        alpha: clamp01((def.end - t) / 0.15),
      });
    }
  }
  drawCutTitle(fc, sc);
  drawCutOut(fc, sc);
}

// ===========================================================================
// CUT 6 — PERFEKTER KREIS 23.0-26.0  (R-SCN-07)
// ===========================================================================
export function drawCircle(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  drawCutDecor(fc, sc);

  const guide = el(sc, "guide_ring");
  if (guide?.center && ON(t, guide)) {
    const a = ease(guide.ease, ramp(t, guide.start, 0.3));
    ctx.save();
    ctx.setLineDash((guide.props.dash as number[]) ?? [12, 10]);
    ctx.globalAlpha = pNum(guide, "alpha", 0.5) * a;
    ctx.beginPath();
    ctx.arc(guide.center[0], guide.center[1], pNum(guide, "radius", 220), 0, TAU);
    ctx.lineWidth = pNum(guide, "stroke", 2);
    ctx.strokeStyle = HEX.white;
    ctx.stroke();
    ctx.restore();
  }

  const arc = el(sc, "pen_arc");
  if (arc?.center && ON(t, arc)) {
    const sweep = ease(arc.ease, P(t, arc)) * TAU;
    const startDeg = (pNum(arc, "start_deg", -90) * Math.PI) / 180;
    ctx.save();
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.arc(arc.center[0], arc.center[1], pNum(arc, "radius", 220), startDeg, startDeg + sweep);
    ctx.lineWidth = pNum(arc, "stroke", 14);
    ctx.strokeStyle = HEX.orange;
    ctx.stroke();
    if (fc.glow) {
      fc.glow.beginPath();
      fc.glow.arc(arc.center[0], arc.center[1], pNum(arc, "radius", 220), startDeg, startDeg + sweep);
      fc.glow.lineWidth = pNum(arc, "stroke", 14);
      fc.glow.strokeStyle = HEX.orange;
      fc.glow.stroke();
    }
    ctx.restore();
  }

  const core = el(sc, "pen_core");
  if (core?.center && ON(t, core)) {
    const sweep = ease(core.ease, P(t, core)) * TAU;
    const startDeg = (pNum(core, "start_deg", -90) * Math.PI) / 180;
    ctx.save();
    ctx.globalAlpha = pNum(core, "alpha", 0.4);
    ctx.beginPath();
    ctx.arc(core.center[0], core.center[1], pNum(core, "radius", 216), startDeg, startDeg + sweep);
    ctx.lineWidth = pNum(core, "stroke", 4);
    ctx.strokeStyle = HEX.white;
    ctx.stroke();
    ctx.restore();
  }

  const head = el(sc, "pen_head");
  if (head?.center && ON(t, head)) {
    const arcEl = el(sc, "pen_arc");
    const sweep = arcEl ? ease(arcEl.ease, P(t, arcEl)) * TAU : 0;
    const startDeg = (pNum(arcEl, "start_deg", -90) * Math.PI) / 180;
    const r = pNum(head, "radius", 220);
    const a = startDeg + sweep;
    const x = head.center[0] + Math.cos(a) * r;
    const y = head.center[1] + Math.sin(a) * r;
    const fade = clamp01((head.end - t) / 0.15);
    glowDot(fc, x, y, 46, "white", 0.75 * fade);
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, pNum(head, "size", 12) * 0.5, 0, TAU);
    ctx.fillStyle = withAlpha(HEX.white, fade);
    ctx.fill();
    ctx.restore();
  }

  const sg = el(sc, "score_glow");
  if (sg?.center && ON(t, sg)) {
    const p = ease(sg.ease, P(t, sg));
    glowDot(fc, sg.center[0], sg.center[1], lerp(pNum(sg, "r_from", 10), pNum(sg, "r_to", 190), p), "orange", 0.5 * (1 - p));
  }

  for (const def of sc.text) {
    if (def.id === "score_98") {
      const p = ease("EXPO_OUT", ramp(t, def.start, 0.35));
      drawLayoutText(fc, def, sc.scene, {
        scale: lerp(1.35, 1, p),
        alpha: p * clamp01((def.end - t) / 0.15),
        glow: 0.45,
      });
    }
  }
  drawCutTitle(fc, sc);
  drawCutOut(fc, sc);
}

// ===========================================================================
// CUT 7 — LEBENSSTATISTIK 26.0-29.0  (R-SCN-08)
// ===========================================================================
function heartBeat(phase: number) {
  const b1 = Math.exp(-9 * phase);
  const b2 = phase > 0.24 ? Math.exp(-9 * (phase - 0.24)) * 0.65 : 0;
  return clamp01(b1 + b2);
}

export function drawLifeStats(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  drawCutDecor(fc, sc);

  const heart = el(sc, "heart");
  const bpm = pNum(heart, "bpm", 72);
  const beatDur = 60 / bpm;
  const phase = heart ? (((t - heart.start) / beatDur) % 1 + 1) % 1 : 0;
  const beat = heartBeat(phase);

  const rings = el(sc, "pulse_rings");
  if (rings?.center && ON(t, rings)) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let k = 0; k < 6; k++) {
      const bt = rings.start + k * beatDur;
      const age = t - bt;
      if (age < 0 || age > 1.4) continue;
      const p = ease("EXPO_OUT", age / 1.2);
      const a = (1 - age / 1.4) * 0.55;
      ctx.beginPath();
      ctx.arc(rings.center[0], rings.center[1], pNum(rings, "radius", 600) * p, 0, TAU);
      ctx.lineWidth = pNum(rings, "stroke", 3);
      ctx.strokeStyle = rgba("blue", a);
      ctx.stroke();
    }
    ctx.restore();
  }

  for (const id of ["panel_herz", "panel_atem", "panel_schritte"]) {
    const p = el(sc, id);
    if (!p?.rect) continue;
    const a = ease(p.ease, ramp(t, p.start, pNum(p, "fade_in", 0.4))) * clamp01((p.end - t) / 0.2);
    if (a > 0.004) glass(fc, p.rect[0], p.rect[1], p.rect[2], p.rect[3], pNum(p, "radius", 24), a);
  }

  if (heart?.center && ON(t, heart)) {
    const size = pNum(heart, "size", 200) * lerp(1, pNum(heart, "scale_to", 1.12), beat);
    const a = ease(heart.ease, ramp(t, heart.start, 0.35)) * clamp01((heart.end - t) / 0.2);
    glowDot(fc, heart.center[0], heart.center[1], size * (0.9 + beat * 0.5), "blue", (0.3 + beat * 0.4) * a);
    ctx.save();
    ctx.globalAlpha = a;
    ctx.beginPath();
    ctx.arc(heart.center[0] - size * 0.24, heart.center[1] - size * 0.16, size * 0.26, 0, TAU);
    ctx.arc(heart.center[0] + size * 0.24, heart.center[1] - size * 0.16, size * 0.26, 0, TAU);
    ctx.moveTo(heart.center[0] - size * 0.47, heart.center[1] - size * 0.06);
    ctx.lineTo(heart.center[0] + size * 0.47, heart.center[1] - size * 0.06);
    ctx.lineTo(heart.center[0], heart.center[1] + size * 0.46);
    ctx.closePath();
    ctx.fillStyle = gradRadial(ctx, heart.center[0], heart.center[1] - size * 0.1, size * 0.75, [
      [0, withAlpha(HEX.white, 1)],
      [0.6, withAlpha(HEX.white, 0.92)],
      [1, rgba("blue", 0.85)],
    ]);
    ctx.fill();
    ctx.restore();
  }

  for (const id of ["counter_herz", "counter_atem", "counter_schritte"]) {
    const c = el(sc, id);
    if (!c?.center || !ON(t, c)) continue;
    const p = ease(c.ease, P(t, c));
    const v = lerp(pNum(c, "from", 0), pNum(c, "to", 0), p);
    drawNumber(fc, sc.scene, `num_${id}`, formatDE(v), c.center as [number, number], pNum(c, "size", 96), "white", clamp01((c.end - t) / 0.2));
  }

  for (const def of sc.text) {
    if (def.layout === "panel_label") {
      drawLayoutText(fc, def, sc.scene, { alpha: clamp01((t - def.start) / 0.3) * clamp01((def.end - t) / 0.2) });
    }
  }
  drawCutTitle(fc, sc);
  drawCutOut(fc, sc);
}

// ===========================================================================
// CUT 8 — GRÖSSE DES WELTALLS 29.0-32.0  (R-SCN-09)
// ===========================================================================
let galaxyCache: Float32Array | null = null;
function galaxyData(n: number) {
  if (galaxyCache && galaxyCache.length >= n * 3) return galaxyCache;
  const r = rng(SEED + 71);
  const out = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const arm = Math.floor(r() * 4);
    const rad = Math.pow(r(), 0.55);
    const spin = rad * 3.1 + (arm * TAU) / 4 + (r() - 0.5) * 0.42;
    out[i * 3] = rad;
    out[i * 3 + 1] = spin;
    out[i * 3 + 2] = r();
  }
  galaxyCache = out;
  return out;
}

function drawGalaxy(ctx: CanvasRenderingContext2D, cx: number, cy: number, radius: number, alpha: number, t: number) {
  const n = 2000;
  const d = galaxyData(n);
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let i = 0; i < n; i++) {
    const rad = d[i * 3] * radius;
    const a = d[i * 3 + 1] + t * 0.16;
    const x = cx + Math.cos(a) * rad;
    const y = cy + Math.sin(a) * rad * 0.42;
    const k = d[i * 3 + 2];
    const s = 1 + k * 2.6;
    ctx.globalAlpha = alpha * (0.25 + k * 0.75) * (1 - d[i * 3] * 0.55);
    ctx.fillStyle = k > 0.9 ? HEX.white : k > 0.5 ? HEX.orange : HEX.blue;
    ctx.fillRect(x, y, s, s);
  }
  ctx.restore();
}

export function drawUniverse(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  drawCutDecor(fc, sc);

  const stages = el(sc, "zoom_stages");
  if (stages?.center && ON(t, stages)) {
    const seq = pStrArr(stages, "sequence");
    const n = seq.length || 6;
    const dur = (stages.end - stages.start) / n;
    const trans = pNum(stages, "transition", 0.25);
    const [cx, cy] = stages.center;
    const local = t - stages.start;
    const idx = Math.min(n - 1, Math.floor(local / dur));
    const pIn = (local - idx * dur) / dur;

    const drawStage = (i: number, scale: number, alpha: number) => {
      if (alpha <= 0.01 || i < 0 || i >= n) return;
      const kind = seq[i];
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);
      ctx.translate(-cx, -cy);
      switch (kind) {
        case "human":
          drawHuman(ctx, cx, cy + 40, 150, 1);
          break;
        case "building":
          drawBuilding(ctx, cx, cy + 20, 240, 1);
          break;
        case "mountain":
          drawMountain(ctx, cx, cy + 30, 320, 1);
          break;
        case "earth":
          drawPlanet(ctx, cx, cy, 200, 1);
          break;
        case "sun":
          drawSun(ctx, cx, cy, 210, 1);
          glowDot(fc, cx, cy, 420 * scale, "orange", 0.35 * alpha);
          break;
        case "galaxy":
          drawGalaxy(ctx, cx, cy, 520, alpha, t);
          break;
      }
      ctx.restore();
    };

    const transP = ease(stages.ease, clamp01((pIn * dur) / trans));
    if (idx > 0 && transP < 1) drawStage(idx - 1, lerp(1, 10, transP), 1 - transP);
    drawStage(idx, lerp(1 / 10, 1, transP), idx > 0 ? transP : clamp01(pIn * 6 + 0.2));
  }

  const tel = el(sc, "telescope_icon");
  if (tel?.center && t >= tel.start) {
    const p = ease(tel.ease, ramp(t, tel.start, pNum(tel, "draw", 0.5)));
    const a = clamp01((Math.min(tel.end, sc.end) - t) / 0.2);
    drawTelescope(ctx, tel.center[0], tel.center[1], pNum(tel, "height", 120), p, a);
  }

  const flick = el(sc, "act2_flicker");
  if (flick) drawFlicker(fc, flick);

  drawCutTitle(fc, sc);
  drawCutOut(fc, sc);
}

// ===========================================================================
// ACT III — HERO 32.0-44.0  (R-SCN-10)
// ===========================================================================
export function drawHero(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  const sphere = el(sc, "hero_sphere");
  if (!sphere?.center) return;
  const [cx, cy] = sphere.center;
  const push = lerp(pNum(sphere, "push_from", 1), pNum(sphere, "push_to", 1.15), ease(sphere.ease, P(t, sphere)));
  const pulse = 1 + pNum(sphere, "pulse_amp", 0.03) * Math.sin(TAU * pNum(sphere, "pulse_hz", 0.5) * t);
  const r = pNum(sphere, "radius", 200) * push * pulse;

  const streaks = el(sc, "hero_streaks");
  if (streaks && ON(t, streaks)) drawStreaks(fc, streaks);

  const paths = el(sc, "hero_rings");
  if (paths?.center) {
    const radii = (paths.props.radii as number[]) ?? [420, 560];
    const tilts = (paths.props.tilt as number[]) ?? [0.26, -0.2];
    ctx.save();
    ctx.globalAlpha = pNum(paths, "alpha", 0.12);
    ctx.strokeStyle = HEX.white;
    ctx.lineWidth = 1.5;
    radii.forEach((R, i) => {
      ctx.beginPath();
      ctx.ellipse(paths.center![0], paths.center![1], R * push, R * Math.abs(tilts[i] ?? 0.25) * push, 0, 0, TAU);
      ctx.stroke();
    });
    ctx.restore();
  }

  const orbitOf = (id: string) => {
    const o = el(sc, id);
    if (!o?.center || !ON(t, o)) return [];
    const sprites = pStrArr(o, "sprites");
    const R = pNum(o, "radius", 420) * push;
    const tilt = pNum(o, "tilt", 0.26);
    const speed = pNum(o, "speed", 0.3) * pNum(o, "dir", 1);
    const phase = pNum(o, "phase", 0);
    return sprites.map((name, i) => {
      const a = phase + (i / sprites.length) * TAU + speed * (t - o.start);
      return { name, a, x: o.center![0] + Math.cos(a) * R, y: o.center![1] + Math.sin(a) * R * tilt, depth: Math.sin(a) };
    });
  };

  const all = [...orbitOf("orbit_ring_b"), ...orbitOf("orbit_ring_a")];
  const drawSprite = (s: { name: string; x: number; y: number; depth: number }) => {
    const fn = ORBIT_SPRITES[s.name];
    if (!fn) return;
    const size = 78 * push * (1 + s.depth * 0.2);
    ctx.save();
    ctx.globalAlpha = 0.72 + 0.28 * ((s.depth + 1) / 2);
    fn(ctx, s.x, s.y, size, t);
    ctx.restore();
    if (fc.glow) glowDot(fc, s.x, s.y, size * 0.9, s.name === "planet" || s.name === "heart" ? "orange" : "blue", 0.18);
  };

  all.filter((s) => s.depth < 0).forEach(drawSprite);

  // star sphere
  const intro = ease("EASE_OUT_EARLY", ramp(t, sphere.start, 0.8));
  ctx.save();
  ctx.globalAlpha = intro;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, TAU);
  ctx.fillStyle = gradRadial(ctx, cx - r * 0.22, cy - r * 0.28, r * 1.15, [
    [0, withAlpha(HEX.white, 1)],
    [0.22, rampColor(0.12)],
    [0.58, rampColor(0.6)],
    [0.88, rampColor(0.98)],
    [1, rgba("orange", 0.55)],
  ]);
  ctx.fill();
  ctx.restore();
  glowDot(fc, cx, cy, r * 2.1, "orange", 0.3 * intro * (0.92 + 0.08 * Math.sin(TAU * 0.5 * t)));
  if (fc.glow) {
    fc.glow.save();
    fc.glow.globalAlpha = 0.9 * intro;
    fc.glow.beginPath();
    fc.glow.arc(cx, cy, r, 0, TAU);
    fc.glow.fillStyle = gradBORadial(fc.glow, cx, cy, r, 0.85);
    fc.glow.fill();
    fc.glow.restore();
  }
  // corona filaments
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const rr = rng(SEED + 91);
  for (let i = 0; i < 26; i++) {
    const a = rr() * TAU + t * 0.05;
    const len = r * (1.06 + rr() * 0.28);
    ctx.globalAlpha = 0.06 + 0.09 * rr();
    ctx.strokeStyle = i % 3 === 0 ? HEX.orange : HEX.blue;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * r * 0.98, cy + Math.sin(a) * r * 0.98);
    ctx.lineTo(cx + Math.cos(a) * len, cy + Math.sin(a) * len);
    ctx.stroke();
  }
  ctx.restore();

  all.filter((s) => s.depth >= 0).forEach(drawSprite);

  const scrim = el(sc, "wordmark_scrim");
  const wm = sc.text.find((d) => d.id === "wordmark");
  if (scrim?.center && wm && t >= scrim.start) {
    const a = pNum(scrim, "alpha", 0.55) * ease(scrim.ease, ramp(t, scrim.start, pNum(scrim, "fade_in", 1)));
    ctx.save();
    ctx.fillStyle = gradRadial(ctx, scrim.center[0], scrim.center[1], pNum(scrim, "radius", 340), [
      [0, rgba("black", a)],
      [0.6, rgba("black", a * 0.55)],
      [1, rgba("black", 0)],
    ]);
    ctx.beginPath();
    ctx.arc(scrim.center[0], scrim.center[1], pNum(scrim, "radius", 340), 0, TAU);
    ctx.fill();
    ctx.restore();
    drawLayoutText(fc, wm, sc.scene, {
      alpha: ease("EASE_OUT_EARLY", ramp(t, wm.start, typeof wm.props?.fade_in === "number" ? (wm.props.fade_in as number) : 1)),
      reveal: t - wm.start,
      perLetter: 0.05,
      letterDur: 0.5,
      glow: 0.5,
      scale: lerp(1.04, 1, ease("EXPO_OUT", ramp(t, wm.start, 1))),
    });
  }

  const flick = el(sc, "act3_flicker");
  if (flick) drawFlicker(fc, flick);

  const swell = el(sc, "hero_swell");
  if (swell && ON(t, swell)) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = rgba("white", pNum(swell, "alpha", 0.3) * ease(swell.ease, P(t, swell)));
    ctx.fillRect(0, 0, 1920, 1080);
    ctx.restore();
  }
}

// ===========================================================================
// ACT IV — CALL TO ACTION 44.0-60.0  (R-SCN-11)
// ===========================================================================
const CTA_N = 3000; // R-VIS-06 cap
const CTA_TARGETS = 1500;
let ctaCache: { dir: Float32Array; spd: Float32Array; sz: Float32Array; col: Uint8Array; jit: Float32Array } | null = null;
function ctaData() {
  if (ctaCache) return ctaCache;
  const r = rng(SEED + 101);
  const dir = new Float32Array(CTA_N * 2);
  const spd = new Float32Array(CTA_N);
  const sz = new Float32Array(CTA_N);
  const col = new Uint8Array(CTA_N);
  const jit = new Float32Array(CTA_N);
  for (let i = 0; i < CTA_N; i++) {
    const a = r() * TAU;
    const bias = Math.pow(r(), 0.7);
    dir[i * 2] = Math.cos(a);
    dir[i * 2 + 1] = Math.sin(a) * 0.72;
    spd[i] = 120 + bias * 1250;
    sz[i] = 1.5 + r() * 5.5;
    const k = r();
    col[i] = k > 0.86 ? 2 : k > 0.44 ? 1 : 0;
    jit[i] = r();
  }
  ctaCache = { dir, spd, sz, col, jit };
  return ctaCache;
}

function paintSample(g: CanvasRenderingContext2D, str: string, layout: LayoutId) {
  const tpl = TEMPLATES[layout];
  const s = tpl.uppercase ? str.toUpperCase() : str;
  g.font = `700 ${tpl.size}px "DejaVu Sans","Liberation Sans",Arial,sans-serif`;
  g.textAlign = "center";
  g.textBaseline = tpl.baseline;
  try {
    (g as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = `${(tpl.tracking * tpl.size).toFixed(2)}px`;
  } catch {
    /* older engines: tracking is cosmetic for sampling */
  }
  g.fillStyle = "#fff";
  g.fillText(s, tpl.at[0], tpl.at[1]);
  try {
    (g as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = "0px";
  } catch {
    /* noop */
  }
}

export function drawCta(fc: FrameCtx, sc: Scene) {
  const { ctx, t } = fc;
  const burst = el(sc, "sphere_burst");
  const pushOut = el(sc, "push_out");
  const pushScale = pushOut && ON(t, pushOut) ? lerp(pNum(pushOut, "scale_from", 1), pNum(pushOut, "scale_to", 0.955), ease(pushOut.ease, P(t, pushOut))) : 1;

  ctx.save();
  if (fc.glow) fc.glow.save();
  if (pushScale !== 1) {
    ctx.translate(960, 540);
    ctx.scale(pushScale, pushScale);
    ctx.translate(-960, -540);
    if (fc.glow) {
      fc.glow.translate(960, 540);
      fc.glow.scale(pushScale, pushScale);
      fc.glow.translate(-960, -540);
    }
  }

  // ---- drifting background field, keeps moving through the push-out -------
  const drift = el(sc, "drift_field");
  if (drift?.rect && ON(t, drift)) {
    const n = Math.round(pNum(drift, "count", 400));
    const r = rng(SEED + 113);
    const speed = pNum(drift, "speed", 40);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < n; i++) {
      const x = (r() * 1920 + Math.sin(i) * 40 + t * speed * (0.3 + r() * 0.9)) % 1960;
      const y = (r() * 1080 + t * speed * 0.25 * (0.2 + r())) % 1120;
      const s = 1 + r() * pNum(drift, "size", 4);
      ctx.globalAlpha = 0.1 + r() * 0.35;
      ctx.fillStyle = r() > 0.55 ? HEX.orange : HEX.blue;
      ctx.fillRect(x - 20, y - 20, s, s);
    }
    ctx.restore();
  }

  // ---- burst + reform ----------------------------------------------------
  const d = ctaData();
  const [bcx, bcy] = burst?.center ?? [960, 500];
  const reformA = el(sc, "reform_bald");
  const reformB = el(sc, "reform_ab12");
  const reformC = el(sc, "reform_url");
  const defA = sc.text.find((x) => x.id === "title_bald");
  const defB = sc.text.find((x) => x.id === "title_ab12");
  const defC = sc.text.find((x) => x.id === "title_url");

  const ptsA = defA ? samplePoints(fc, "pta", 1920, 1080, (g) => paintSample(g, defA.string, "claim_white"), 6, CTA_TARGETS) : new Float32Array(0);
  const ptsB = defB ? samplePoints(fc, "ptb", 1920, 1080, (g) => paintSample(g, defB.string, "claim_gradient"), 6, CTA_TARGETS) : new Float32Array(0);
  const ptsC = defC ? samplePoints(fc, "ptc", 1920, 1080, (g) => paintSample(g, defC.string, "url"), 5, CTA_TARGETS) : new Float32Array(0);

  const burstEnd = reformA ? reformA.start : 46.0;
  const settleA = reformA ? pNum(reformA, "settle", 1.1) : 1.1;
  const settleB = reformB ? pNum(reformB, "settle", 0.8) : 0.8;
  const settleC = reformC ? pNum(reformC, "settle", 0.9) : 0.9;

  const posOf = (i: number): [number, number, number, number] => {
    const dx = d.dir[i * 2];
    const dy = d.dir[i * 2 + 1];
    const dist = d.spd[i];
    const ex = bcx + dx * dist;
    const ey = bcy + dy * dist * 0.85;
    if (t < burstEnd) {
      const p = burst ? ease(burst.ease, ramp(t, burst.start, burstEnd - burst.start)) : 1;
      return [lerp(bcx, ex, p), lerp(bcy, ey, p), 1 - p * 0.15, p];
    }
    const k = i % Math.max(1, ptsA.length / 2);
    const hasTarget = i < CTA_TARGETS && ptsA.length > 0;
    if (!hasTarget) {
      const driftP = clamp01((t - burstEnd) / 2.4);
      return [ex + dx * driftP * 120, ey + dy * driftP * 120, 1 - driftP, 1];
    }
    const ax = ptsA[k * 2];
    const ay = ptsA[k * 2 + 1];
    if (reformB && t >= reformB.start) {
      const bx = ptsB.length ? ptsB[(i % Math.max(1, ptsB.length / 2)) * 2] : ax;
      const by = ptsB.length ? ptsB[(i % Math.max(1, ptsB.length / 2)) * 2 + 1] : ay;
      if (reformC && t >= reformC.start) {
        const cxp = ptsC.length ? ptsC[(i % Math.max(1, ptsC.length / 2)) * 2] : bx;
        const cyp = ptsC.length ? ptsC[(i % Math.max(1, ptsC.length / 2)) * 2 + 1] : by;
        const p = ease("EASE_IO", ramp(t, reformC.start, settleC));
        const fade = 1 - clamp01((t - (reformC.start + settleC)) / 0.7);
        return [lerp(bx, cxp, p), lerp(by, cyp, p), fade, 1];
      }
      const p = ease("EASE_IO", ramp(t, reformB.start, settleB));
      return [lerp(ax, bx, p), lerp(ay, by, p), 1, 1];
    }
    const p = ease("EASE_IO", ramp(t, burstEnd, settleA));
    return [lerp(ex, ax, p), lerp(ey, ay, p), 1, 1];
  };

  if (burst && t >= burst.start && t < 53.4) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const cols = [HEX.blue, HEX.orange, HEX.white];
    for (let i = 0; i < CTA_N; i++) {
      const [x, y, life] = posOf(i);
      if (life <= 0.01) continue;
      // R-VIS-06: particles start large and shrink to 0 as they fade
      const s = d.sz[i] * life * (0.6 + 0.4 * d.jit[i]);
      if (s < 0.3) continue;
      ctx.globalAlpha = clamp01(life * (0.35 + 0.65 * d.jit[i]));
      ctx.fillStyle = cols[d.col[i]];
      ctx.fillRect(x - s / 2, y - s / 2, s, s);
    }
    ctx.restore();
    if (fc.glow && t < burstEnd + 0.6) glowDot(fc, bcx, bcy, 420 * (1 - clamp01((t - burst.start) / 1.6)), "orange", 0.5);
  }

  // ---- declared copy ------------------------------------------------------
  if (defA && ON(t, defA)) {
    drawLayoutText(fc, defA, sc.scene, {
      alpha: ease("EASE_OUT_EARLY", ramp(t, defA.start + 0.5, 0.9)) * clamp01((defA.end - t) / 0.12),
      glow: 0.35,
    });
  }
  if (defB && ON(t, defB)) {
    drawLayoutText(fc, defB, sc.scene, {
      alpha: ease("EASE_OUT_EARLY", ramp(t, defB.start + 0.35, 0.6)) * clamp01((defB.end - t) / 0.12),
      reveal: t - defB.start,
      perLetter: 0.02,
      letterDur: 0.3,
      glow: 0.4,
    });
  }
  if (defC && ON(t, defC)) {
    drawLayoutText(fc, defC, sc.scene, {
      alpha: ease("EASE_OUT_EARLY", ramp(t, defC.start + 0.55, 0.7)) * clamp01((defC.end - t) / 0.3),
      glow: 0.3,
    });
  }

  const underline = el(sc, "url_underline");
  if (underline?.rect && ON(t, underline)) {
    const p = ease(underline.ease, P(t, underline));
    const [ux, uy, uw, uh] = underline.rect;
    ctx.save();
    ctx.beginPath();
    rrect(ctx, ux, uy, uw * p, uh, pNum(underline, "radius", 3));
    ctx.fillStyle = gradBO(ctx, ux, uy, ux + uw, uy); // palette-safe ramp (D-08)
    ctx.fill();
    ctx.restore();
    if (fc.glow) {
      fc.glow.save();
      fc.glow.globalAlpha = 0.6;
      fc.glow.fillStyle = rampColor(p);
      fc.glow.fillRect(ux + uw * p - 40, uy - 4, 40, uh + 8);
      fc.glow.restore();
    }
  }

  const pill = el(sc, "cta_button");
  const ctaText = sc.text.find((x) => x.id === "title_cta");
  if (pill?.rect && ON(t, pill)) {
    const a = ease(pill.ease, ramp(t, pill.start, pNum(pill, "fade_in", 0.6)));
    const pulseAt = pNum(pill, "pulse_at", 55);
    const ps = 1 + (pNum(pill, "pulse_scale", 1.06) - 1) * Math.sin(Math.PI * clamp01((t - pulseAt) / 0.28)) * (t >= pulseAt ? 1 : 0);
    const [bx, by, bw, bh] = pill.rect;
    ctx.save();
    ctx.globalAlpha = a;
    ctx.translate(bx + bw / 2, by + bh / 2);
    ctx.scale(ps, ps);
    ctx.translate(-(bx + bw / 2), -(by + bh / 2));
    rrect(ctx, bx, by, bw, bh, pNum(pill, "radius", 60));
    const g = ctx.createLinearGradient(bx, by, bx + bw, by + bh);
    g.addColorStop(0, HEX.orange);
    g.addColorStop(1, "#fb923c");
    ctx.fillStyle = g;
    ctx.fill();
    ctx.save();
    ctx.clip();
    ctx.fillStyle = withAlpha(HEX.white, 0.16);
    rrect(ctx, bx + 8, by + 6, bw - 16, bh * 0.42, pNum(pill, "radius", 60) * 0.8);
    ctx.fill();
    ctx.restore();
    ctx.lineWidth = 1;
    ctx.strokeStyle = withAlpha(HEX.white, 0.45);
    rrect(ctx, bx + 0.5, by + 0.5, bw - 1, bh - 1, pNum(pill, "radius", 60));
    ctx.stroke();
    ctx.restore();
    if (fc.glow) glowDot(fc, bx + bw / 2, by + bh / 2, bw * 0.62, "orange", 0.22 * a * ps);
  }
  if (ctaText && ON(t, ctaText)) {
    const pulseAt = pill ? pNum(pill, "pulse_at", 55) : 55;
    const ps = 1 + (pNum(pill, "pulse_scale", 1.06) - 1) * Math.sin(Math.PI * clamp01((t - pulseAt) / 0.28)) * (t >= pulseAt ? 1 : 0);
    drawLayoutText(fc, ctaText, sc.scene, {
      alpha: ease("EASE_OUT_EARLY", ramp(t, ctaText.start + 0.15, 0.5)) * clamp01((ctaText.end - t) / 0.3),
      scale: ps,
      reveal: t - ctaText.start,
      perLetter: 0.018,
      letterDur: 0.28,
    });
  }

  const flick = el(sc, "act4_flicker");
  if (flick) drawFlicker(fc, flick);

  ctx.restore();
  if (fc.glow) fc.glow.restore();
}
