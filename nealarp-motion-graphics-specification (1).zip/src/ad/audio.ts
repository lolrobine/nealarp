// ============================================================================
// nealarp-ad / audio — everything is synthesised (R-AUD-02, R-AUD-03, R-NEG-07).
// 48 kHz Web Audio graph:
//   music bus ─┐
//   sfx   bus ─┼─> duck -> limiter -> master -> (speakers + capture dest)
//   vo    bus ─┘
// Music bus is ducked by 6 dB while a voiceover line plays (R-AUD-02).
// ============================================================================

import { DURATION, SEED } from "./constants";
import { ALL_SFX, ALL_VO, SCENES } from "./timeline";
import { rng } from "./rng";
import { clamp01 } from "./easing";

const db = (v: number) => Math.pow(10, v / 20);
const A = {
  pop: db(-6),
  click: db(-8),
  coin: db(-10),
  clunk: db(-6),
  bubble: db(-14),
  whirr: db(-12),
  boom: db(-4),
  pen: db(-18),
  heart: db(-8),
  whoosh: db(-10),
  bassDrop: db(-4),
  bassHit: db(-3),
  riser: db(-10),
};

export interface Levels {
  music: number;
  sfx: number;
  master: number;
}

export interface AdAudioOptions {
  onCue?: (kind: "sfx" | "vo", id: string, at: number) => void;
}

export class AdAudio {
  ac: AudioContext | null = null;
  private master!: GainNode;
  private duck!: GainNode;
  private musicBus!: GainNode;
  private sfxBus!: GainNode;
  private voBus!: GainNode;
  private analyserM!: AnalyserNode;
  private analyserS!: AnalyserNode;
  private analyserMaster!: AnalyserNode;
  private dest: MediaStreamAudioDestinationNode | null = null;
  private white: AudioBuffer | null = null;
  private brown: AudioBuffer | null = null;
  private delay: DelayNode | null = null;

  // arp voices (persistent, re-tuned per note -> cheap)
  private arpOsc: OscillatorNode[] = [];
  private arpGain!: GainNode;
  private arpFilter!: BiquadFilterNode;
  private harmOsc: OscillatorNode[] = [];
  private harmGain!: GainNode;
  private bassOsc!: OscillatorNode;
  private bassGain!: GainNode;
  private padOsc: OscillatorNode[] = [];
  private padGain!: GainNode;
  private musicStarted = false;

  private timer: number | null = null;
  private startedAt = 0; // AudioContext time of timeline t=offset
  private offset = 0; // timeline position at play()
  private firedSfx = new Set<string>();
  private firedVo = new Set<string>();
  private scheduledBeat = -1;
  private voTimeouts: number[] = [];
  private voice: SpeechSynthesisVoice | null = null;
  private voicesReady = false;

  muted = { music: false, sfx: false, vo: false };
  playing = false;
  opts: AdAudioOptions;

  constructor(opts: AdAudioOptions = {}) {
    this.opts = opts;
  }

  get sampleRate() {
    return this.ac?.sampleRate ?? 48000;
  }

  async init(): Promise<void> {
    if (this.ac) return;
    const Ctor: typeof AudioContext =
      window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    let ac: AudioContext;
    try {
      ac = new Ctor({ sampleRate: 48000, latencyHint: "interactive" }); // R-AUD-03: 48 kHz
    } catch {
      ac = new Ctor(); // engines that reject an explicit rate
    }
    this.ac = ac;

    this.master = ac.createGain();
    this.master.gain.value = 0.9;
    const limiter = ac.createDynamicsCompressor();
    limiter.threshold.value = -1; // -1 dBTP intent (R-OUT-05)
    limiter.knee.value = 0;
    limiter.ratio.value = 20;
    limiter.attack.value = 0.002;
    limiter.release.value = 0.12;
    this.duck = ac.createGain();
    this.duck.gain.value = 1;
    this.musicBus = ac.createGain();
    this.sfxBus = ac.createGain();
    this.voBus = ac.createGain();
    this.voBus.gain.value = 1.35; // approx. -18 dBFS RMS normalisation (R-AUD-01)

    this.analyserM = ac.createAnalyser();
    this.analyserS = ac.createAnalyser();
    this.analyserMaster = ac.createAnalyser();
    for (const a of [this.analyserM, this.analyserS, this.analyserMaster]) a.fftSize = 1024;

    this.musicBus.connect(this.analyserM);
    this.sfxBus.connect(this.analyserS);
    this.musicBus.connect(this.duck);
    this.sfxBus.connect(this.duck);
    this.voBus.connect(this.duck);
    this.duck.connect(limiter);
    limiter.connect(this.master);
    this.master.connect(this.analyserMaster);
    this.master.connect(ac.destination);

    // echo for the 44.0 s bass hit: delay 0.25 s, feedback 0.3 (R-AUD-02)
    this.delay = ac.createDelay(1.0);
    this.delay.delayTime.value = 0.25;
    const fb = ac.createGain();
    fb.gain.value = 0.3;
    const wet = ac.createGain();
    wet.gain.value = 0.45;
    this.delay.connect(fb);
    fb.connect(this.delay);
    this.delay.connect(wet);
    wet.connect(this.duck);

    // noise buffers, generated once (R-PERF-01)
    this.white = this.noiseBuffer(2, "white");
    this.brown = this.noiseBuffer(2, "brown");

    this.loadVoices();
  }

  private noiseBuffer(seconds: number, kind: "white" | "brown"): AudioBuffer {
    const ac = this.ac!;
    const buf = ac.createBuffer(1, Math.floor(ac.sampleRate * seconds), ac.sampleRate);
    const d = buf.getChannelData(0);
    const r = rng(SEED + 5);
    let last = 0;
    for (let i = 0; i < d.length; i++) {
      if (kind === "white") d[i] = r() * 2 - 1;
      else {
        const w = r() * 2 - 1;
        last = (last + 0.02 * w) / 1.02;
        d[i] = last * 3.2;
      }
    }
    return buf;
  }

  private loadVoices() {
    if (typeof speechSynthesis === "undefined") return;
    const pick = () => {
      const vs = speechSynthesis.getVoices();
      if (!vs.length) return;
      const de = vs.filter((v) => v.lang.toLowerCase().startsWith("de"));
      const neural =
        de.find((v) => /online|neural|natural/i.test(v.name)) ??
        de.find((v) => /katja|anna|google deutsch|stefan/i.test(v.name)) ??
        de[0];
      this.voice = neural ?? null;
      this.voicesReady = true;
    };
    pick();
    speechSynthesis.addEventListener?.("voiceschanged", pick);
  }

  get voiceInfo() {
    return {
      ready: this.voicesReady,
      name: this.voice?.name ?? null,
      lang: this.voice?.lang ?? null,
      available: typeof speechSynthesis !== "undefined" ? speechSynthesis.getVoices().filter((v) => v.lang.toLowerCase().startsWith("de")).length : 0,
    };
  }

  /** capture stream for MediaRecorder export */
  captureStream(): MediaStream | null {
    if (!this.ac) return null;
    if (!this.dest) {
      this.dest = this.ac.createMediaStreamDestination();
      this.master.connect(this.dest);
    }
    return this.dest.stream;
  }

  // ---------------------------------------------------------------- transport
  async play(t: number) {
    await this.init();
    const ac = this.ac!;
    if (ac.state === "suspended") await ac.resume();
    this.offset = t;
    this.startedAt = ac.currentTime + 0.06;
    this.firedSfx.clear();
    this.firedVo.clear();
    this.scheduledBeat = Math.floor(t / 0.125) - 1;
    // mark everything before the playhead as already fired
    for (const c of ALL_SFX) if (c.at < t) this.firedSfx.add(`${c.id}@${c.at}`);
    for (const c of ALL_VO) if (c.at < t) this.firedVo.add(`${c.id}@${c.at}`);
    this.startMusicVoices();
    this.master.gain.cancelScheduledValues(ac.currentTime);
    this.master.gain.setValueAtTime(0.9, ac.currentTime);
    this.playing = true;
    this.scheduleVo(t);
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = window.setInterval(() => this.tick(), 25);
  }

  pause() {
    this.playing = false;
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = null;
    this.voTimeouts.forEach((id) => window.clearTimeout(id));
    this.voTimeouts = [];
    if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
    if (this.ac) {
      const now = this.ac.currentTime;
      this.master.gain.cancelScheduledValues(now);
      this.master.gain.setValueAtTime(this.master.gain.value, now);
      this.master.gain.linearRampToValueAtTime(0.0001, now + 0.08);
    }
  }

  stop() {
    this.pause();
    this.stopMusicVoices();
    if (this.ac) {
      this.master.gain.cancelScheduledValues(this.ac.currentTime);
      this.master.gain.setValueAtTime(0.9, this.ac.currentTime);
    }
  }

  currentPosition(): number {
    if (!this.ac || !this.playing) return this.offset;
    return this.offset + (this.ac.currentTime - this.startedAt);
  }

  setMute(bus: "music" | "sfx" | "vo", v: boolean) {
    this.muted[bus] = v;
    if (!this.ac) return;
    const node = bus === "music" ? this.musicBus : bus === "sfx" ? this.sfxBus : this.voBus;
    const target = v ? 0 : bus === "vo" ? 1.35 : 1;
    node.gain.cancelScheduledValues(this.ac.currentTime);
    node.gain.setTargetAtTime(target, this.ac.currentTime, 0.02);
  }

  getLevels(): Levels {
    if (!this.ac) return { music: -90, sfx: -90, master: -90 };
    const rms = (a: AnalyserNode) => {
      const buf = new Uint8Array(a.fftSize);
      a.getByteTimeDomainData(buf);
      let s = 0;
      for (let i = 0; i < buf.length; i++) {
        const v = (buf[i] - 128) / 128;
        s += v * v;
      }
      const r = Math.sqrt(s / buf.length);
      return r > 0 ? 20 * Math.log10(r) : -90;
    };
    return { music: rms(this.analyserM), sfx: rms(this.analyserS), master: rms(this.analyserMaster) };
  }

  // ------------------------------------------------------------------ score
  /** R-AUD-02 — 120 BPM, 60.000 s, original, generated in code. */
  private startMusicVoices() {
    const ac = this.ac;
    if (!ac || this.musicStarted) return;
    this.musicStarted = true;
    const now = ac.currentTime;

    this.arpFilter = ac.createBiquadFilter();
    this.arpFilter.type = "lowpass";
    this.arpFilter.frequency.setValueAtTime(2000, now); // cold blue: 2 kHz
    this.arpFilter.frequency.linearRampToValueAtTime(3400, this.startedAt + 32); // warms toward orange
    this.arpFilter.frequency.linearRampToValueAtTime(2400, this.startedAt + 44);
    this.arpFilter.Q.value = 6;
    this.arpGain = ac.createGain();
    this.arpGain.gain.value = 0;
    this.arpFilter.connect(this.arpGain);
    this.arpGain.connect(this.musicBus);

    this.arpOsc = [];
    const detunes = [-16, -9, -4, 0, 0, 4, 9, 16]; // 8 detuned sines
    for (let i = 0; i < 8; i++) {
      const o = ac.createOscillator();
      o.type = "sine";
      o.detune.value = detunes[i];
      const g = ac.createGain();
      g.gain.value = 1 / 8;
      o.connect(g);
      g.connect(this.arpFilter);
      o.start(now);
      this.arpOsc.push(o);
    }

    // higher-harmonic bank: emphasis grows 8 s -> 32 s ("orange" timbre)
    this.harmGain = ac.createGain();
    this.harmGain.gain.setValueAtTime(0.0001, now);
    this.harmGain.connect(this.arpFilter);
    this.harmOsc = [];
    for (const mult of [2, 3, 4, 5]) {
      const o = ac.createOscillator();
      o.type = "sine";
      o.frequency.value = 220 * mult;
      const g = ac.createGain();
      g.gain.value = 0.22 / mult;
      o.connect(g);
      g.connect(this.harmGain);
      o.start(now);
      this.harmOsc.push(o);
      (o as OscillatorNode & { __mult?: number }).__mult = mult;
    }

    // bass voice
    this.bassOsc = ac.createOscillator();
    this.bassOsc.type = "sine";
    this.bassOsc.frequency.value = 55;
    this.bassGain = ac.createGain();
    this.bassGain.gain.value = 0.0001;
    const bassLp = ac.createBiquadFilter();
    bassLp.type = "lowpass";
    bassLp.frequency.value = 320;
    this.bassOsc.connect(this.bassGain);
    this.bassGain.connect(bassLp);
    bassLp.connect(this.musicBus);
    this.bassOsc.start(now);

    // cinematic pad for the 32-44 s swell
    this.padGain = ac.createGain();
    this.padGain.gain.value = 0.0001;
    const padFilter = ac.createBiquadFilter();
    padFilter.type = "lowpass";
    padFilter.frequency.value = 1400;
    this.padGain.connect(padFilter);
    padFilter.connect(this.musicBus);
    this.padOsc = [];
    for (const f of [110, 164.81, 220, 329.63]) {
      const o = ac.createOscillator();
      o.type = "sawtooth";
      o.frequency.value = f;
      o.detune.value = (Math.random() - 0.5) * 8;
      const g = ac.createGain();
      g.gain.value = 0.18;
      o.connect(g);
      g.connect(this.padGain);
      o.start(now);
      this.padOsc.push(o);
    }
  }

  private stopMusicVoices() {
    this.musicStarted = false;
    this.scheduledBeat = -1;
    for (const o of [...this.arpOsc, ...this.harmOsc, ...this.padOsc]) {
      try {
        o.stop();
      } catch {
        /* already stopped */
      }
      o.disconnect();
    }
    this.arpOsc = [];
    this.harmOsc = [];
    this.padOsc = [];
    try {
      this.bassOsc?.stop();
      this.bassOsc?.disconnect();
    } catch {
      /* noop */
    }
  }

  private noteFreq(root: number, semi: number) {
    return root * Math.pow(2, semi / 12);
  }

  /** schedule beats inside the lookahead window */
  private scheduleMusic(tNow: number, tEnd: number) {
    const ac = this.ac!;
    const beatDur = 0.5; // 120 BPM
    const sixteenth = beatDur / 4;
    const roots = [55, 43.65, 65.41, 49]; // A1 F1 C2 G1
    const scale = [0, 3, 7, 10, 12, 15];
    const firstBeat = Math.floor(tNow / sixteenth);
    for (let i = Math.max(0, this.scheduledBeat + 1); i <= Math.floor(tEnd / sixteenth); i++) {
      if (i < firstBeat - 8) continue;
      const tl = i * sixteenth; // timeline seconds
      if (tl >= DURATION) break;
      const when = this.startedAt + (tl - this.offset);
      if (when < ac.currentTime - 0.05) continue;
      const bar = Math.floor(tl / 4) % 4;
      const root = roots[bar];

      // --- arpeggio 16ths
      const stepIdx = i % 8;
      const semi = scale[(stepIdx * 3 + bar) % scale.length] + (tl > 32 ? 12 : 0);
      const f = this.noteFreq(root * 4, semi);
      const open = clamp01((tl - 8) / 24); // timbre warms toward orange
      const amp = (tl < 8 ? 0.1 + 0.1 * (tl / 8) : 0.2) * (1 + open * 0.35) * (tl > 44 ? Math.max(0, 1 - (tl - 44) / 14) : 1);
      for (const o of this.arpOsc) o.frequency.setValueAtTime(f, when);
      for (const o of this.harmOsc) {
        const m = (o as OscillatorNode & { __mult?: number }).__mult ?? 2;
        o.frequency.setValueAtTime(f * m, when);
      }
      this.harmGain.gain.setValueAtTime(Math.max(0.0001, 0.02 + open * 0.5), when);
      this.arpGain.gain.cancelScheduledValues(when);
      this.arpGain.gain.setValueAtTime(0.0001, when);
      this.arpGain.gain.linearRampToValueAtTime(tl > 44 ? amp * 0.5 : amp, when + 0.008);
      this.arpGain.gain.exponentialRampToValueAtTime(0.0001, when + sixteenth * 0.92);

      // --- bass on every beat
      if (i % 4 === 0) {
        const bf = root;
        this.bassOsc.frequency.cancelScheduledValues(when);
        this.bassOsc.frequency.setValueAtTime(bf * 1.5, when);
        this.bassOsc.frequency.exponentialRampToValueAtTime(bf, when + 0.12);
        const bamp = (tl < 8 ? 0.5 : 0.34) * (tl > 44 ? Math.max(0, 1 - (tl - 45) / 12) : 1);
        this.bassGain.gain.cancelScheduledValues(when);
        this.bassGain.gain.setValueAtTime(0.0001, when);
        this.bassGain.gain.linearRampToValueAtTime(bamp, when + 0.012);
        this.bassGain.gain.exponentialRampToValueAtTime(0.0001, when + 0.44);
      }

      // --- 32-44 s swell toward the 44.0 s crescendo
      if (tl >= 32 && tl < 44) {
        const p = (tl - 32) / 12;
        this.padGain.gain.setTargetAtTime(0.0001 + p * p * 0.5, when, 0.25);
      } else if (tl >= 44 && tl < 45) {
        this.padGain.gain.setTargetAtTime(0.0001, when, 0.4);
      }
      this.scheduledBeat = i;
    }
    // --- global silence by 60.0 s (R-SCN-11 / R-VER-12)
    const endWhen = this.startedAt + (59.0 - this.offset);
    if (tEnd > 58.8 && endWhen > ac.currentTime) {
      this.master.gain.cancelScheduledValues(endWhen);
      this.master.gain.setValueAtTime(this.master.gain.value, endWhen);
      this.master.gain.linearRampToValueAtTime(0.0001, this.startedAt + (60.0 - this.offset));
    }
  }

  // -------------------------------------------------------------------- SFX
  private env(g: GainNode, when: number, peak: number, attack: number, decay: number) {
    g.gain.cancelScheduledValues(when);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(peak, when + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, when + attack + decay);
  }

  private noiseSource(kind: "white" | "brown", when: number, dur: number) {
    const ac = this.ac!;
    const src = ac.createBufferSource();
    src.buffer = kind === "white" ? this.white : this.brown;
    src.loop = true;
    const r = rng(SEED + Math.round(when * 1000));
    src.playbackRate.value = 0.9 + r() * 0.2;
    const offset = r() * 1.5;
    src.start(when, offset, dur + 0.05);
    src.stop(when + dur + 0.06);
    return src;
  }

  private bandpass(f0: number, f1: number, when: number, dur: number, q = 1.2) {
    const ac = this.ac!;
    const bp = ac.createBiquadFilter();
    bp.type = "bandpass";
    bp.Q.value = q;
    bp.frequency.setValueAtTime(f0, when);
    bp.frequency.exponentialRampToValueAtTime(Math.max(20, f1), when + dur);
    return bp;
  }

  /** R-AUD-03 recipes, sample-accurate, deterministic (seeded pitch jitter). */
  playSfx(name: string, tl: number, dur?: number) {
    const ac = this.ac;
    if (!ac) return;
    const when = this.startedAt + (tl - this.offset);
    if (when < ac.currentTime - 0.02) return;
    const r = rng(SEED + Math.round(tl * 1000) + name.length);
    const out = this.sfxBus;

    const sine = (f0: number, f1: number, d: number, peak: number, attack = 0.004, type: OscillatorType = "sine") => {
      const o = ac.createOscillator();
      o.type = type;
      o.frequency.setValueAtTime(f0, when);
      if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), when + d);
      const g = ac.createGain();
      this.env(g, when, peak, attack, d);
      o.connect(g);
      g.connect(out);
      o.start(when);
      o.stop(when + d + attack + 0.05);
      return g;
    };
    const noise = (d: number, peak: number, f0: number, f1: number, q = 1.0, kind: "white" | "brown" = "white") => {
      const src = this.noiseSource(kind, when, d);
      const bp = this.bandpass(f0, f1, when, d, q);
      const g = ac.createGain();
      this.env(g, when, peak, 0.003, d);
      src.connect(bp);
      bp.connect(g);
      g.connect(out);
      return g;
    };

    switch (name) {
      case "sfx_pop":
        sine(1200, 600, 0.08, A.pop);
        noise(0.005, A.pop * 0.6, 3000, 5000, 0.8);
        break;
      case "sfx_click":
        noise(0.025, A.click, 2000, 4000, 1.6);
        break;
      case "sfx_coin_clink": {
        const j = 1 + (r() - 0.5) * 0.06; // ±3 %
        sine(3000 * j, 3000 * j, 0.3, A.coin * 0.9);
        sine(4500 * j, 4500 * j, 0.3, A.coin * 0.7);
        break;
      }
      case "sfx_lock_clunk":
        sine(90, 55, 0.18, A.clunk);
        noise(0.025, A.click * 0.8, 2000, 4000, 1.6);
        break;
      case "sfx_bubble": {
        const d = 0.06 + r() * 0.06;
        sine(300, 900, d, A.bubble, 0.01);
        break;
      }
      case "sfx_whirr": {
        const d = dur ?? 3.0;
        const g = ac.createGain();
        this.env(g, when, A.whirr, d * 0.35, d * 0.65);
        g.connect(out);
        for (let i = 0; i < 8; i++) {
          const o = ac.createOscillator();
          o.type = "sine";
          o.detune.value = (i - 4) * 11;
          o.frequency.setValueAtTime(200, when);
          o.frequency.exponentialRampToValueAtTime(1200, when + d);
          const og = ac.createGain();
          og.gain.value = 1 / 8;
          o.connect(og);
          og.connect(g);
          o.start(when);
          o.stop(when + d + 0.1);
        }
        break;
      }
      case "sfx_boom": {
        sine(60, 60, 1.2, A.boom, 0.006);
        const src = this.noiseSource("brown", when, 1.5);
        const lp = ac.createBiquadFilter();
        lp.type = "lowpass";
        lp.frequency.value = 600;
        const g = ac.createGain();
        this.env(g, when, A.boom * 0.7, 0.008, 1.5);
        src.connect(lp);
        lp.connect(g);
        g.connect(out);
        break;
      }
      case "sfx_pen_draw": {
        const d = dur ?? 1.2;
        const src = this.noiseSource("white", when, d);
        const bp = this.bandpass(2000, 5000, when, d, 1.4);
        const am = ac.createGain();
        const lfo = ac.createOscillator();
        lfo.frequency.value = 18;
        const lfoGain = ac.createGain();
        lfoGain.gain.value = 0.5;
        lfo.connect(lfoGain);
        lfoGain.connect(am.gain);
        am.gain.value = 0.5;
        const g = ac.createGain();
        this.env(g, when, A.pen, 0.05, d);
        src.connect(bp);
        bp.connect(am);
        am.connect(g);
        g.connect(out);
        lfo.start(when);
        lfo.stop(when + d + 0.1);
        break;
      }
      case "sfx_heartbeat": {
        const thump = (at: number) => {
          const o = ac.createOscillator();
          o.type = "sine";
          o.frequency.setValueAtTime(55, at);
          const g = ac.createGain();
          g.gain.setValueAtTime(0.0001, at);
          g.gain.linearRampToValueAtTime(A.heart, at + 0.012);
          g.gain.exponentialRampToValueAtTime(0.0001, at + 0.12);
          o.connect(g);
          g.connect(out);
          o.start(at);
          o.stop(at + 0.16);
        };
        thump(when);
        thump(when + 0.3); // two thumps, 300 ms apart
        break;
      }
      case "sfx_whoosh_zoom": {
        const d = 1.2;
        const src = this.noiseSource("white", when, d);
        const bp = this.bandpass(300, 3000, when, d, 0.9);
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, when);
        g.gain.linearRampToValueAtTime(A.whoosh, when + d * 0.45);
        g.gain.exponentialRampToValueAtTime(0.0001, when + d);
        src.connect(bp);
        bp.connect(g);
        g.connect(out);
        break;
      }
      case "sfx_bass_drop":
        sine(120, 35, 1.5, A.bassDrop, 0.02);
        break;
      case "sfx_bass_hit": {
        sine(45, 45, 0.8, A.bassHit, 0.005);
        noise(0.02, A.bassHit * 0.35, 1800, 4200, 1.1);
        if (this.delay) {
          const send = ac.createGain();
          send.gain.value = 0.5;
          sine(45, 45, 0.8, A.bassHit * 0.5, 0.005).connect(send);
          send.connect(this.delay);
        }
        break;
      }
      case "sfx_riser": {
        const d = dur ?? 2.4;
        const src = this.noiseSource("white", when, d);
        const bp = this.bandpass(400, 6000, when, d, 1.1);
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, when);
        g.gain.linearRampToValueAtTime(A.riser, when + d * 0.9);
        g.gain.exponentialRampToValueAtTime(0.0001, when + d);
        src.connect(bp);
        bp.connect(g);
        g.connect(out);
        const o = ac.createOscillator();
        o.type = "sine";
        o.frequency.setValueAtTime(180, when);
        o.frequency.exponentialRampToValueAtTime(1600, when + d);
        const og = ac.createGain();
        this.env(og, when, A.riser * 0.35, d * 0.7, d * 0.3);
        o.connect(og);
        og.connect(out);
        o.start(when);
        o.stop(when + d + 0.1);
        break;
      }
      default:
        break;
    }
    this.opts.onCue?.("sfx", name, tl);
  }

  // -------------------------------------------------------------------- VO
  private estDuration(text: string) {
    // never speed up delivery (R-AUD-01): ~0.062 s per character + 0.35 s tail
    return Math.min(6.5, 0.35 + text.length * 0.062);
  }

  /** voiceover is fired from tick(), locked to the AudioContext clock, so the
   *  declared start times of timeline.yaml are honoured within the lookahead. */
  private scheduleVo(_fromT: number) {
    this.voTimeouts.forEach((id) => window.clearTimeout(id));
    this.voTimeouts = [];
  }

  private speak(text: string, tl: number, id: string) {
    const ac = this.ac;
    if (!ac) return;
    const dur = this.estDuration(text);
    const when = ac.currentTime;
    // duck the music bus by 6 dB while the line plays (R-AUD-02)
    this.duckMusic(when, dur + 0.25);
    this.opts.onCue?.("vo", id, tl);
    if (typeof speechSynthesis === "undefined" || this.muted.vo) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "de-DE";
    if (this.voice) u.voice = this.voice;
    u.rate = 0.98; // never sped up
    u.pitch = 0.86; // slightly deep, premium tone
    u.volume = 1;
    try {
      speechSynthesis.speak(u);
    } catch {
      /* speech engine unavailable */
    }
  }

  private duckMusic(when: number, dur: number) {
    if (!this.ac) return;
    const g = this.musicBus.gain;
    g.cancelScheduledValues(when);
    g.setValueAtTime(this.muted.music ? 0 : 1, when);
    g.linearRampToValueAtTime(this.muted.music ? 0 : db(-6), when + 0.06);
    g.setValueAtTime(this.muted.music ? 0 : db(-6), when + Math.max(0.1, dur - 0.25));
    g.linearRampToValueAtTime(this.muted.music ? 0 : 1, when + dur);
  }

  // ------------------------------------------------------------------- tick
  private tick() {
    const ac = this.ac;
    if (!ac || !this.playing) return;
    const t = this.currentPosition();
    const lookahead = 0.2;
    if (t > DURATION + 0.25) {
      this.playing = false;
      if (this.timer !== null) window.clearInterval(this.timer);
      this.timer = null;
      return;
    }
    this.scheduleMusic(t, t + lookahead);
    for (const c of ALL_SFX) {
      const key = `${c.id}@${c.at}`;
      if (this.firedSfx.has(key)) continue;
      if (c.at >= t - 0.02 && c.at <= t + lookahead) {
        this.firedSfx.add(key);
        if (!this.muted.sfx) this.playSfx(c.id, c.at, c.dur);
      }
    }
    for (const c of ALL_VO) {
      const key = `${c.id}@${c.at}`;
      if (this.firedVo.has(key)) continue;
      if (c.at >= t - 0.02 && c.at <= t + lookahead) {
        this.firedVo.add(key);
        this.speak(c.string ?? "", c.at, c.id);
      }
    }
  }

  /** static description of the score for the UI + R-VER-11/12 */
  static scoreSummary() {
    return {
      bpm: 120,
      beats: Math.round((DURATION / 60) * 120),
      sfx: ALL_SFX.map((c) => ({ ...c })),
      vo: ALL_VO.map((c) => ({ ...c, est: 0.35 + (c.string?.length ?? 0) * 0.062 })),
      scenes: SCENES.map((s) => ({ id: s.scene, start: s.start, end: s.end })),
    };
  }
}

export const VO_LINES = ALL_VO;
export const SFX_CUES = ALL_SFX;
