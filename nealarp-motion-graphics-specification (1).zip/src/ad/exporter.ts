// ============================================================================
// nealarp-ad / exporter — real-time MediaRecorder export (R-OUT-03).
// One source, two profiles: only `scale` differs (R-VIS-12).
//   scale 1 -> nealarp-ad-1080p-test.<ext>
//   scale 2 -> nealarp-ad-2160p60-final.<ext>   (gated, R-GATE-01/02/03)
// ============================================================================

import { DURATION, FPS } from "./constants";
import { newCaches, renderFrame } from "./renderer";
import type { AdAudio } from "./audio";

export interface ExportProfile {
  id: "test" | "final";
  scale: number;
  width: number;
  height: number;
  baseName: string;
  gated: boolean;
  bitsPerSecond: number;
}

export const PROFILES: ExportProfile[] = [
  { id: "test", scale: 1, width: 1920, height: 1080, baseName: "nealarp-ad-1080p-test", gated: false, bitsPerSecond: 24_000_000 },
  { id: "final", scale: 2, width: 3840, height: 2160, baseName: "nealarp-ad-2160p60-final", gated: true, bitsPerSecond: 60_000_000 },
];

/** H.264 High + AAC first (R-OUT-05), WebM/VP9 as the fallback container (D-05). */
export function pickMime(): { mime: string; ext: string; h264: boolean } | null {
  if (typeof MediaRecorder === "undefined") return null;
  const candidates = [
    "video/mp4;codecs=avc1.640028,mp4a.40.2",
    "video/mp4;codecs=avc1.64002A,mp4a.40.2",
    "video/mp4;codecs=avc1.420028,mp4a.40.2",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
  ];
  for (const mime of candidates) {
    try {
      if (MediaRecorder.isTypeSupported(mime)) return { mime, ext: mime.includes("mp4") ? "mp4" : "webm", h264: mime.includes("avc1") };
    } catch {
      /* keep probing */
    }
  }
  return null;
}

export interface ExportProgress {
  t: number;
  pct: number;
  fps: number;
  avgMs: number;
  dropped: number;
}

export interface ExportDone {
  blob: Blob;
  name: string;
  mime: string;
  ext: string;
  seconds: number;
  avgMs: number;
  frames: number;
}

export interface ExportHandle {
  cancel: () => void;
}

export function startExport(opts: {
  canvas: HTMLCanvasElement;
  audio: AdAudio | null;
  profile: ExportProfile;
  withAudio: boolean;
  onProgress: (p: ExportProgress) => void;
  onDone: (d: ExportDone) => void;
  onError: (msg: string) => void;
}): ExportHandle {
  const { canvas, audio, profile, withAudio, onProgress, onDone, onError } = opts;
  const picked = pickMime();
  if (!picked) {
    onError("MediaRecorder is not available in this browser — no container can be written.");
    return { cancel: () => {} };
  }

  let cancelled = false;
  const caches = newCaches();
  // pre-warm: the CTA text-point sampling (46.5 s) must not cost a frame at 44 s
  renderFrame(canvas, 46.5, profile.scale, { caches });
  renderFrame(canvas, 0, profile.scale, { caches });

  const stream = canvas.captureStream(FPS);
  let audioStream: MediaStream | null = null;
  if (withAudio && audio) {
    audioStream = audio.captureStream();
    audioStream?.getAudioTracks().forEach((tr) => stream.addTrack(tr));
  }

  let rec: MediaRecorder;
  try {
    rec = new MediaRecorder(stream, { mimeType: picked.mime, videoBitsPerSecond: profile.bitsPerSecond, audioBitsPerSecond: 192_000 });
  } catch (e) {
    onError(`MediaRecorder rejected ${picked.mime}: ${String(e)}`);
    return { cancel: () => {} };
  }

  const chunks: BlobPart[] = [];
  rec.ondataavailable = (e) => {
    if (e.data && e.data.size) chunks.push(e.data);
  };

  const t0 = performance.now();
  let frames = 0;
  let msSum = 0;
  let last = t0;
  let dropped = 0;
  let raf = 0;

  const finish = (stopped: boolean) => {
    cancelAnimationFrame(raf);
    audio?.stop();
    if (rec.state !== "inactive") {
      rec.onstop = () => emit(stopped);
      rec.stop();
    } else emit(stopped);
  };

  const emit = (stopped: boolean) => {
    stream.getTracks().forEach((tr) => tr.stop());
    if (stopped && !chunks.length) {
      onError("Recording was cancelled before any data was written.");
      return;
    }
    const blob = new Blob(chunks, { type: picked.mime });
    const seconds = (performance.now() - t0) / 1000;
    onDone({
      blob,
      name: `${profile.baseName}.${picked.ext}`,
      mime: picked.mime,
      ext: picked.ext,
      seconds,
      avgMs: frames ? msSum / frames : 0,
      frames,
    });
  };

  rec.start(1000);

  const loop = () => {
    if (cancelled) {
      finish(true);
      return;
    }
    const now = performance.now();
    const t = (now - t0) / 1000;
    if (t >= DURATION) {
      renderFrame(canvas, DURATION - 1 / FPS, profile.scale, { caches, frame: 3599 });
      frames++;
      finish(false);
      return;
    }
    const s = performance.now();
    renderFrame(canvas, t, profile.scale, { caches, frame: Math.round(t * FPS) });
    msSum += performance.now() - s;
    frames++;
    const dt = now - last;
    if (dt > 1000 / FPS + 6) dropped++;
    last = now;
    onProgress({ t, pct: (t / DURATION) * 100, fps: frames / Math.max(0.001, t), avgMs: msSum / frames, dropped });
    raf = requestAnimationFrame(loop);
  };

  if (audio && withAudio) {
    void audio.play(0).then(() => {
      raf = requestAnimationFrame(loop);
    });
  } else {
    raf = requestAnimationFrame(loop);
  }

  return {
    cancel: () => {
      cancelled = true;
    },
  };
}

export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function downloadCanvas(canvas: HTMLCanvasElement, name: string) {
  canvas.toBlob((b) => {
    if (b) downloadBlob(b, name);
  }, "image/png");
}
