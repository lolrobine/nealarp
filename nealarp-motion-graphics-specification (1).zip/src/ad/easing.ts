// ============================================================================
// nealarp-ad / easing  (R-VIS-10 — named, exact)
//   EASE_IO        cubic-bezier(0.65, 0.00, 0.35, 1.00)
//   EASE_OUT_EARLY cubic-bezier(0.25, 0.80, 0.25, 1.00)
//   EXPO_OUT       1 - 2^(-10 t)
//   STEP           hold the start value, then snap
// ============================================================================

export type EaseName = "EASE_IO" | "EASE_OUT_EARLY" | "EXPO_OUT" | "STEP";
export const EASE_NAMES: EaseName[] = ["EASE_IO", "EASE_OUT_EARLY", "EXPO_OUT", "STEP"];
export const EASE_CURVES: Record<string, [number, number, number, number]> = {
  EASE_IO: [0.65, 0.0, 0.35, 1.0],
  EASE_OUT_EARLY: [0.25, 0.8, 0.25, 1.0],
};

export const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const invLerp = (a: number, b: number, v: number) => (b === a ? 0 : clamp01((v - a) / (b - a)));

/** cubic-bezier(x1,y1,x2,y2) -> f(x) with Newton-Raphson + bisection fallback. */
export function cubicBezier(x1: number, y1: number, x2: number, y2: number) {
  const A = (a: number, b: number) => 1 - 3 * b + 3 * a;
  const B = (a: number, b: number) => 3 * b - 6 * a;
  const C = (a: number) => 3 * a;
  const calc = (t: number, a: number, b: number) => ((A(a, b) * t + B(a, b)) * t + C(a)) * t;
  const slope = (t: number, a: number, b: number) => 3 * A(a, b) * t * t + 2 * B(a, b) * t + C(a);

  return function bezier(x: number): number {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const s = slope(t, x1, x2);
      if (Math.abs(s) < 1e-6) break;
      const err = calc(t, x1, x2) - x;
      if (Math.abs(err) < 1e-6) return calc(t, y1, y2);
      t -= err / s;
    }
    let lo = 0;
    let hi = 1;
    t = x;
    for (let i = 0; i < 24; i++) {
      const v = calc(t, x1, x2);
      if (Math.abs(v - x) < 1e-6) break;
      if (v > x) hi = t;
      else lo = t;
      t = (lo + hi) / 2;
    }
    return calc(t, y1, y2);
  };
}

const easeIO = cubicBezier(0.65, 0.0, 0.35, 1.0);
const easeOutEarly = cubicBezier(0.25, 0.8, 0.25, 1.0);
const expoOut = (t: number) => (t >= 1 ? 1 : t <= 0 ? 0 : 1 - Math.pow(2, -10 * t));
const step = (t: number) => (t >= 1 ? 1 : 0);

export const EASERS: Record<EaseName, (t: number) => number> = {
  EASE_IO: easeIO,
  EASE_OUT_EARLY: easeOutEarly,
  EXPO_OUT: expoOut,
  STEP: step,
};

export function ease(name: string | undefined, p: number): number {
  const fn = EASERS[(name as EaseName) ?? "EASE_IO"] ?? easeIO;
  return fn(clamp01(p));
}

/** raw linear progress of `t` inside [start,end] */
export const progress = (t: number, start: number, end: number) => clamp01((t - start) / Math.max(1e-6, end - start));

/** eased progress of `t` inside [start,end] */
export function seg(t: number, start: number, end: number, name: string | undefined = "EASE_IO"): number {
  return ease(name, progress(t, start, end));
}

/** 1 inside the window, 0 outside (edges inclusive at start, exclusive at end) */
export const inWindow = (t: number, start: number, end: number) => t >= start && t < end;

/** symmetric pulse: 0 -> 1 -> 0 over [start, start+dur] */
export function pulse(t: number, start: number, dur: number, name: string = "EASE_IO"): number {
  const p = progress(t, start, start + dur);
  if (p <= 0 || p >= 1) return 0;
  return p < 0.5 ? ease(name, p * 2) : ease(name, (1 - p) * 2);
}

/** Evaluate a bezier curve for the UI mini-plots. */
export function sampleCurve(name: EaseName, n = 64): { x: number; y: number }[] {
  const pts: { x: number; y: number }[] = [];
  for (let i = 0; i <= n; i++) {
    const x = i / n;
    pts.push({ x, y: ease(name, x) });
  }
  return pts;
}
