import { memo } from "react";
import { ACTS, HEX, R_TXT, SCENE_LABELS } from "@/ad/constants";
import { DEVIATIONS, INTERPRETATIONS } from "@/ad/checklist";
import { ALL_SFX, ALL_VO, SCENES } from "@/ad/timeline";
import { TEMPLATES, TEMPLATE_IDS } from "@/ad/text";
import { EASE_NAMES, sampleCurve, type EaseName } from "@/ad/easing";
import { Chip, Reveal, SectionHead, cx } from "./primitives";

const CSS_EASE: Record<string, string> = {
  EASE_IO: "cubic-bezier(0.65,0,0.35,1)",
  EASE_OUT_EARLY: "cubic-bezier(0.25,0.8,0.25,1)",
  EXPO_OUT: "cubic-bezier(0.16,1,0.3,1)",
  STEP: "steps(1,end)",
};
const EASE_FORMULA: Record<string, string> = {
  EASE_IO: "bezier .65 0 .35 1",
  EASE_OUT_EARLY: "bezier .25 .8 .25 1",
  EXPO_OUT: "1 − 2^(−10t)",
  STEP: "hold, then snap",
};

export function Dossier({ t, onSeek }: { t: number; onSeek: (t: number) => void }) {
  return (
    <div className="mt-16 flex flex-col gap-16">
      {/* ------------------------------------------------------------ shots */}
      <section>
        <Reveal>
          <SectionHead
            n="01"
            title="Elf Einstellungen, keine Sekunde Zufall"
            sub="Jede Szene, jedes Element und jeder Cue stammt aus timeline.yaml. Ein Klick springt an den Anfang der Einstellung — der Renderer berechnet das Bild neu als reine Funktion der Zeit."
            right={
              <div className="flex gap-1.5">
                {ACTS.map((a) => (
                  <button key={a.id} className="btn !px-2 !py-1" onClick={() => onSeek(a.start + 0.001)}>
                    {a.id} · {a.start}s
                  </button>
                ))}
              </div>
            }
          />
        </Reveal>
        <div className="mt-5 flex flex-col">
          {SCENES.map((s, i) => {
            const active = t >= s.start && t < s.end;
            const title = s.text[0]?.string ?? SCENE_LABELS[s.scene];
            return (
              <Reveal key={s.scene} delay={i * 28}>
                <button
                  onClick={() => onSeek(s.start + 0.02)}
                  className={cx(
                    "group grid w-full grid-cols-[42px_minmax(0,1fr)_auto] items-center gap-4 border-b border-white/[0.07] px-2 py-3 text-left transition-all duration-300",
                    active ? "border-l-2 border-l-orange-500 bg-orange-500/[0.07]" : "border-l-2 border-l-transparent hover:border-l-blue-500 hover:bg-white/[0.03]",
                  )}
                >
                  <span className={cx("mono text-[11px] tabular transition-colors", active ? "text-orange-300" : "text-white/30")}>
                    {String(i).padStart(2, "0")}
                  </span>
                  <span className="min-w-0">
                    <span className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                      <span className={cx("font-display text-[clamp(17px,2vw,26px)] font-bold leading-none tracking-[-0.02em] transition-colors", active ? "text-white" : "text-white/80 group-hover:text-white")}>
                        {title}
                      </span>
                      <span className="mono text-[10px] uppercase tracking-[0.16em] text-white/35">{SCENE_LABELS[s.scene]}</span>
                    </span>
                    <span className="mono mt-1.5 block text-[10px] uppercase tracking-[0.12em] text-white/30">
                      act {s.act} · {s.elements.length} elements · {s.text.length} text · {s.sfx.length} sfx · {s.vo.length} vo
                      {s.hold.length ? ` · hold ${s.hold.map((h) => `${h[0]}–${h[1]}`).join(", ")}` : ""}
                    </span>
                  </span>
                  <span className="mono shrink-0 text-right text-[11px] tabular text-white/50">
                    {s.start.toFixed(1)} – {s.end.toFixed(1)} s
                  </span>
                </button>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ---------------------------------------------------------- palette */}
      <section>
        <Reveal>
          <SectionHead
            n="02"
            title="Vier Farben, gemessen nicht geglaubt"
            sub="R-VIS-02 erlaubt ausschließlich Electric Blue, Vibrant Orange, Weiß und Near-Black. Der Verlauf von Blau nach Orange läuft über zwei fast weiße Stützstellen (D-08), damit kein Zwischenpixel den Farbtonbereich 195–235° oder 15–35° verlässt."
          />
        </Reveal>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { n: "electric blue", hex: HEX.blue, h: "217°", s: "76 %" },
            { n: "vibrant orange", hex: HEX.orange, h: "25°", s: "91 %" },
            { n: "white", hex: HEX.white, h: "—", s: "0 %" },
            { n: "near black", hex: HEX.black, h: "—", s: "0 %" },
          ].map((c, i) => (
            <Reveal key={c.n} delay={i * 60}>
              <div className="panel group overflow-hidden transition-transform duration-300 hover:-translate-y-1">
                <div className="h-24 transition-all duration-500 group-hover:h-28" style={{ background: c.hex }} />
                <div className="p-3">
                  <div className="font-display text-[15px] font-bold text-white">{c.n}</div>
                  <div className="mono mt-1 flex justify-between text-[10px] uppercase tracking-[0.14em] text-white/45">
                    <span>{c.hex}</span>
                    <span>h {c.h} · s {c.s}</span>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={120}>
          <div className="panel mt-3 p-3">
            <div className="label mb-2">r-vvis-03 ramp · #3b82f6 → #f97316 with near-white bridge stops</div>
            <div
              className="h-10 w-full"
              style={{ background: "linear-gradient(90deg,#3b82f6 0%,#89b5fa 42%,#fcb685 58%,#f97316 100%)" }}
            />
            <div className="mono mt-1 flex justify-between text-[9px] uppercase tracking-[0.16em] text-white/35">
              <span>0 %</span>
              <span>42 %</span>
              <span>58 %</span>
              <span>100 %</span>
            </div>
          </div>
        </Reveal>
      </section>

      {/* ----------------------------------------------------------- easing */}
      <section>
        <Reveal>
          <SectionHead n="03" title="Vier Kurven, exakt benannt" sub="R-VIS-10: jede Bewegung nutzt eine dieser vier Funktionen. Der Punkt läuft mit derselben Kurve wie die Animation im Film." />
        </Reveal>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {EASE_NAMES.map((n, i) => (
            <Reveal key={n} delay={i * 60}>
              <EaseCard name={n} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------------- cues */}
      <Reveal>
        <section>
          <SectionHead
            n="04"
            title="Partitur aus Code"
            sub="120 BPM, 60.000 Sekunden, keine lizenzierten Samples. Musik, Effekte und die acht deutschen Voiceover-Zeilen sind auf derselben Zeitleiste geplant; die Musik wird unter Sprache um 6 dB geduckt."
            right={<Chip tone="orange">{ALL_SFX.length} sfx · {ALL_VO.length} vo</Chip>}
          />
          <div className="panel mt-5 p-3">
            <CueSheet />
          </div>
        </section>
      </Reveal>

      {/* -------------------------------------------------------- templates */}
      <Reveal>
        <section>
          <SectionHead n="05" title="Text-Layout-System" sub="Kein String wird von Szenenlogik gezeichnet (R-TXT-02). Auto-fit: über 1440 px Breite wird die Größe in 4-px-Schritten bis minimal 64 px reduziert — jede Änderung wird protokolliert." />
          <div className="mt-5 overflow-x-auto">
            <table className="w-full min-w-[720px] border-collapse">
              <thead>
                <tr className="mono border-b border-white/15 text-[10px] uppercase tracking-[0.16em] text-white/40">
                  <th className="py-2 text-left">template</th>
                  <th className="py-2 text-left">size</th>
                  <th className="py-2 text-left">anchor</th>
                  <th className="py-2 text-left">tracking</th>
                  <th className="py-2 text-left">fill</th>
                  <th className="py-2 text-left">panel</th>
                </tr>
              </thead>
              <tbody>
                {TEMPLATE_IDS.map((id) => {
                  const tp = TEMPLATES[id];
                  return (
                    <tr key={id} className="border-b border-white/[0.06] transition-colors hover:bg-white/[0.04]">
                      <td className="mono py-2 text-[11px] text-white/85">{id}</td>
                      <td className="mono py-2 text-[11px] tabular text-white/60">{tp.size} px</td>
                      <td className="mono py-2 text-[11px] tabular text-white/60">
                        {tp.at[0]}, {tp.at[1]} · {tp.baseline}
                      </td>
                      <td className="mono py-2 text-[11px] tabular text-white/60">+{tp.tracking.toFixed(2)} em</td>
                      <td className="py-2">
                        <span className="flex items-center gap-2">
                          <span
                            className="inline-block h-3 w-8"
                            style={{
                              background: tp.color === "gradient" ? "linear-gradient(90deg,#3b82f6,#fcb685,#f97316)" : tp.color === "orange" ? HEX.orange : HEX.white,
                            }}
                          />
                          <span className="mono text-[10px] uppercase tracking-[0.14em] text-white/45">{tp.color}</span>
                        </span>
                      </td>
                      <td className="mono py-2 text-[10px] uppercase tracking-[0.14em] text-white/40">{tp.panel ?? "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="mt-3 flex flex-wrap gap-1">
            {R_TXT.map((s) => (
              <span key={s} className="mono border border-white/10 bg-white/[0.03] px-1.5 py-1 text-[10px] text-white/55 transition-colors hover:border-orange-400/50 hover:text-white">
                {s}
              </span>
            ))}
          </div>
        </section>
      </Reveal>

      {/* ------------------------------------------------------- deviations */}
      <Reveal>
        <section>
          <SectionHead n="06" title="Abweichungen und Lesarten" sub="Alles, was von der Spezifikation abweicht, steht hier mit Begründung — nichts wurde stillschweigend geändert." />
          <div className="mt-5 grid gap-3 lg:grid-cols-2">
            <div className="panel-flat p-3">
              <div className="label mb-2">deviations</div>
              <div className="flex flex-col gap-2">
                {DEVIATIONS.map((d) => (
                  <div key={d.id} className="border-l-2 border-orange-500/60 pl-2.5">
                    <div className="mono text-[10px] uppercase tracking-[0.14em] text-orange-300">{d.id}</div>
                    <div className="text-[12.5px] text-white/85">{d.text}</div>
                    <div className="text-[11.5px] text-white/40">{d.reason}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <div className="panel-flat p-3">
                <div className="label mb-2">interpretations</div>
                <div className="flex flex-col gap-2">
                  {INTERPRETATIONS.map((d) => (
                    <div key={d.id} className="border-l-2 border-blue-500/60 pl-2.5">
                      <div className="mono text-[10px] uppercase tracking-[0.14em] text-blue-300">{d.id}</div>
                      <div className="text-[12.5px] text-white/85">{d.text}</div>
                      <div className="text-[11.5px] text-white/40">{d.reason}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="panel-flat p-3">
                <div className="label mb-2">r-neg · negative constraints</div>
                <ul className="mono grid gap-1 text-[10.5px] uppercase tracking-[0.1em] text-white/50 sm:grid-cols-2">
                  <li>01 no hue outside the four colours</li>
                  <li>02 no emoji, cartoon, stock photo</li>
                  <li>03 no english, no extra text</li>
                  <li>04 no watermark, logo, ui chrome</li>
                  <li>05 no jitter, banding, dropped frames</li>
                  <li>06 no letterboxing</li>
                  <li>07 no licensed music or samples</li>
                  <li>08 no generated media in git</li>
                  <li>09 never fake a result</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </Reveal>
    </div>
  );
}

const EaseCard = memo(function EaseCard({ name }: { name: EaseName }) {
  const pts = sampleCurve(name, 40);
  const d = pts.map((p, i) => `${i ? "L" : "M"}${(p.x * 100).toFixed(2)},${(100 - p.y * 100).toFixed(2)}`).join(" ");
  return (
    <div className="panel p-3 transition-transform duration-300 hover:-translate-y-1">
      <div className="flex items-center justify-between gap-2">
        <span className="mono text-[10px] uppercase tracking-[0.14em] text-white/80">{name}</span>
        <span className="mono text-[9px] uppercase tracking-[0.12em] text-orange-300/80">{EASE_FORMULA[name]}</span>
      </div>
      <div className="relative mt-2 h-24 w-full border border-white/10 bg-black/40">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
          <line x1="0" y1="100" x2="100" y2="0" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />
          <path d={d} fill="none" stroke="#3b82f6" strokeWidth="1.6" vectorEffect="non-scaling-stroke" />
        </svg>
        <div className="dot-x absolute top-0 h-full w-0">
          <div className="dot-y absolute h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-orange-400" style={{ ["--ease" as string]: CSS_EASE[name], boxShadow: "0 0 12px rgba(249,115,22,.9)" }} />
        </div>
      </div>
      <div className="mono mt-1.5 text-[9px] uppercase tracking-[0.12em] text-white/30">{CSS_EASE[name]}</div>
    </div>
  );
});

const CueSheet = memo(function CueSheet() {
  const W = 1200;
  const x = (t: number) => (t / 60) * W;
  return (
    <svg viewBox={`0 0 ${W} 210`} className="h-auto w-full">
      {ACTS.map((a, i) => (
        <g key={a.id}>
          <rect x={x(a.start)} y={8} width={x(a.end) - x(a.start)} height={160} fill={i % 2 ? "rgba(255,255,255,0.022)" : "rgba(255,255,255,0.045)"} />
          <line x1={x(a.start)} y1={8} x2={x(a.start)} y2={168} stroke="rgba(255,255,255,0.18)" strokeWidth="1" />
          <text x={x(a.start) + 6} y={22} className="mono" fontSize="10" letterSpacing="1.6" fill="rgba(255,255,255,0.45)">
            {`ACT ${a.id} · ${a.name}`}
          </text>
        </g>
      ))}
      {/* music blocks */}
      {[
        [0, 8, "bass drop · cold arps · riser"],
        [8, 32, "arps warm toward orange harmonics"],
        [32, 44, "swell + risers → crescendo"],
        [44, 60, "bass hit, echo .25/.3, fade out"],
      ].map(([a, b, label]) => (
        <g key={String(a)}>
          <rect x={x(a as number) + 2} y={34} width={x(b as number) - x(a as number) - 4} height={20} fill="rgba(59,130,246,0.22)" stroke="rgba(59,130,246,0.6)" />
          <text x={x(a as number) + 8} y={48} className="mono" fontSize="9.5" letterSpacing="1.2" fill="rgba(191,219,254,0.9)">
            {label as string}
          </text>
        </g>
      ))}
      {/* sfx lane */}
      <text x={2} y={78} className="mono" fontSize="9.5" letterSpacing="1.4" fill="rgba(255,255,255,0.4)">
        SFX
      </text>
      {ALL_SFX.map((c, i) => (
        <g key={`${c.id}${c.at}${i}`}>
          <line x1={x(c.at)} y1={84} x2={x(c.at)} y2={98} stroke="#f97316" strokeWidth="1.6" />
          <circle cx={x(c.at)} cy={84} r="2" fill="#f97316" />
        </g>
      ))}
      {/* vo lane */}
      <text x={2} y={122} className="mono" fontSize="9.5" letterSpacing="1.4" fill="rgba(255,255,255,0.4)">
        VO
      </text>
      {ALL_VO.map((v) => {
        const est = 0.35 + (v.string?.length ?? 0) * 0.062;
        return (
          <g key={v.id}>
            <rect x={x(v.at)} y={128} width={x(Math.min(60, v.at + est)) - x(v.at)} height={16} fill="rgba(255,255,255,0.14)" stroke="rgba(255,255,255,0.45)" />
            <text x={x(v.at) + 4} y={140} className="mono" fontSize="8.6" fill="rgba(255,255,255,0.75)">
              {v.at.toFixed(1)}s
            </text>
          </g>
        );
      })}
      {/* axis */}
      <line x1={0} y1={168} x2={W} y2={168} stroke="rgba(255,255,255,0.2)" />
      {Array.from({ length: 13 }, (_, i) => i * 5).map((s) => (
        <g key={s}>
          <line x1={x(s)} y1={168} x2={x(s)} y2={174} stroke="rgba(255,255,255,0.3)" />
          <text x={x(s) + 3} y={186} className="mono" fontSize="9.5" fill="rgba(255,255,255,0.4)">
            {s}s
          </text>
        </g>
      ))}
      <text x={W - 118} y={204} className="mono" fontSize="9.5" letterSpacing="1.4" fill="rgba(249,115,22,0.85)">
        3600 FRAMES · 60/1
      </text>
    </svg>
  );
});
