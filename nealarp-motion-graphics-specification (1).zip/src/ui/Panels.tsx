import { memo, useCallback, useMemo, useState } from "react";
import { R_TXT, SAFE, SCENE_LABELS } from "@/ad/constants";
import { CHECKLIST, DEVIATIONS, INTERPRETATIONS, type CItem, type CStatus } from "@/ad/checklist";
import { ALL_SFX, ALL_VO, META, SCENES, TIMELINE_PARSE_OK, TIMELINE_STATS, YAML_RAW } from "@/ad/timeline";
import { TEMPLATES, TEMPLATE_IDS } from "@/ad/text";
import { runVerification, type VerifyReport } from "@/ad/verify";
import type { PlayerApi } from "./usePlayer";
import { Chip, KV, StatusPill, cx } from "./primitives";

type TabId = "verify" | "audio" | "timeline" | "log" | "board" | "report";
const TABS: [TabId, string][] = [
  ["verify", "verify"],
  ["audio", "audio"],
  ["timeline", "timeline.yaml"],
  ["log", "layout log"],
  ["board", "board"],
  ["report", "report"],
];

export function Panels({ p }: { p: PlayerApi }) {
  const [tab, setTab] = useState<TabId>("verify");
  const [report, setReport] = useState<VerifyReport | null>(null);
  const [running, setRunning] = useState<{ done: number; total: number; label: string } | null>(null);
  const [filter, setFilter] = useState<CStatus | "ALL">("ALL");

  const run = useCallback(async () => {
    p.pause();
    setRunning({ done: 0, total: 1, label: "boot" });
    try {
      const r = await runVerification((done, total, label) => setRunning({ done, total, label }));
      setReport(r);
      setTab("report");
    } finally {
      setRunning(null);
      p.seek(p.t);
    }
  }, [p]);

  const merged = useMemo<CItem[]>(() => {
    if (!report) return CHECKLIST;
    return CHECKLIST.map((row) => {
      const live = report.results.find((r) => r.id === row.id);
      return live ? { ...row, status: live.status as CStatus, evidence: live.evidence } : row;
    });
  }, [report]);

  const counts = useMemo(() => {
    const c: Record<CStatus, number> = { PASS: 0, PARTIAL: 0, BLOCKED: 0, FAIL: 0 };
    for (const r of merged) c[r.status]++;
    return c;
  }, [merged]);

  return (
    <div className="panel-flat flex min-h-[560px] flex-col">
      <div className="flex flex-wrap items-center gap-1 border-b border-white/10 px-2 py-2">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={cx(
              "mono border px-2.5 py-[6px] text-[10px] uppercase tracking-[0.16em] transition-all duration-200",
              tab === id ? "border-orange-400/70 bg-orange-500/15 text-orange-200" : "border-transparent text-white/40 hover:bg-white/[0.05] hover:text-white/80",
            )}
          >
            {label}
          </button>
        ))}
        <span className="ml-auto flex items-center gap-1.5 pr-1">
          <Chip tone={counts.FAIL ? "fail" : "pass"}>{counts.PASS} pass</Chip>
          <Chip tone="partial">{counts.PARTIAL}</Chip>
          <Chip>{counts.BLOCKED} blocked</Chip>
        </span>
      </div>

      <div className="scroll-thin max-h-[62vh] min-h-0 flex-1 overflow-y-auto p-3">
        {tab === "verify" && <VerifyTab report={report} running={running} onRun={run} />}
        {tab === "audio" && <AudioTab p={p} />}
        {tab === "timeline" && <TimelineTab />}
        {tab === "log" && <LogTab p={p} />}
        {tab === "board" && <BoardTab rows={merged} filter={filter} setFilter={setFilter} />}
        {tab === "report" && <ReportTab report={report} counts={counts} rows={merged} />}
      </div>
    </div>
  );
}

// --------------------------------------------------------------------- verify
function VerifyTab({ report, running, onRun }: { report: VerifyReport | null; running: { done: number; total: number; label: string } | null; onRun: () => void }) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="font-display text-[20px] font-bold leading-none text-white">R-VER-01 … R-VER-14</div>
          <p className="mono mt-1 text-[10px] uppercase tracking-[0.14em] text-white/40">
            live suite · renders frames, samples pixels, hashes twice
          </p>
        </div>
        <button className="btn btn-solid" onClick={onRun} disabled={!!running}>
          {running ? "running…" : "run verification"}
        </button>
      </div>

      {running && (
        <div className="border border-blue-500/30 bg-blue-500/[0.07] p-3">
          <div className="mono flex justify-between text-[10px] uppercase tracking-[0.14em] text-blue-200">
            <span>{running.label}</span>
            <span className="tabular">
              {running.done}/{running.total}
            </span>
          </div>
          <div className="mt-2 h-[3px] bg-white/10">
            <div className="h-full bg-blue-400 transition-[width] duration-150" style={{ width: `${(running.done / running.total) * 100}%` }} />
          </div>
        </div>
      )}

      {!report && !running && (
        <p className="text-[12px] leading-relaxed text-white/50">
          Nothing is asserted from memory here. The suite renders 120 frames at 0.5 s spacing plus ten 1080p frames and one real
          3840×2160 frame, converts pixels to HSV, measures the corner background, diffs the layout log against the 23 approved
          strings and hashes the probe frames twice. Checks that need ffmpeg, ffprobe or tesseract report BLOCKED with the reason
          (R-NEG-09).
        </p>
      )}

      {report && (
        <>
          <div className="grid grid-cols-2 gap-2">
            <Stat k="ms / frame 1080p" v={`${report.perf.ms1080.toFixed(1)} ms`} />
            <Stat k="4k estimate (4×)" v={`${report.perf.est4KHours.toFixed(2)} h`} />
            <Stat k="4k measured frame" v={`${report.perf.ms4K.toFixed(0)} ms → ${report.perf.est4KByMeasurementHours.toFixed(2)} h`} />
            <Stat k="suite runtime" v={`${(report.tookMs / 1000).toFixed(1)} s`} />
          </div>
          <div className="flex flex-col gap-1.5">
            {report.results.map((r) => (
              <div key={r.id} className="border border-white/[0.07] bg-white/[0.02] p-2.5 transition-colors hover:border-white/20">
                <div className="flex items-center justify-between gap-2">
                  <span className="mono text-[11px] tracking-[0.1em] text-white/85">{r.id}</span>
                  <StatusPill status={r.status as CStatus} />
                </div>
                <div className="mt-0.5 text-[12px] font-medium text-white/80">{r.title}</div>
                <p className="mono mt-1 text-[10px] leading-relaxed tracking-[0.04em] text-white/45">{r.evidence}</p>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

const Stat = ({ k, v }: { k: string; v: string }) => (
  <div className="border border-white/[0.07] bg-white/[0.02] p-2.5">
    <div className="label">{k}</div>
    <div className="mono mt-1 text-[13px] text-white tabular">{v}</div>
  </div>
);

// ---------------------------------------------------------------------- audio
const AudioTab = memo(function AudioTab({ p }: { p: PlayerApi }) {
  const now = p.t;
  return (
    <div className="flex flex-col gap-4">
      <div>
        <div className="label mb-2">voice · r-aud-01</div>
        <div className="border border-white/[0.07] bg-white/[0.02] p-3">
          <KV k="engine" v="Web Speech API (browser neural voices)" />
          <KV k="selected voice" v={p.voiceInfo.name ?? "not resolved yet"} />
          <KV k="lang" v={p.voiceInfo.lang ?? "de-DE requested"} />
          <KV k="german voices found" v={String(p.voiceInfo.available)} />
          <KV k="status" v="PARTIAL — spoken live, not embeddable (D-06)" />
        </div>
      </div>

      <div>
        <div className="label mb-2">voiceover lines · german, exact</div>
        <div className="flex flex-col gap-1">
          {ALL_VO.map((v) => {
            const est = 0.35 + (v.string?.length ?? 0) * 0.062;
            const active = now >= v.at && now <= v.at + est;
            return (
              <button
                key={v.id + v.at}
                onClick={() => p.seek(v.at)}
                className={cx(
                  "group flex items-start gap-3 border px-2.5 py-2 text-left transition-all duration-200",
                  active ? "border-orange-400/70 bg-orange-500/12" : "border-white/[0.07] bg-white/[0.02] hover:border-white/25 hover:bg-white/[0.05]",
                )}
              >
                <span className="mono w-12 shrink-0 pt-[2px] text-[10px] tabular text-orange-300/90">{v.at.toFixed(2)}s</span>
                <span className="text-[12px] leading-snug text-white/85">{v.string}</span>
                <span className="mono ml-auto shrink-0 text-[9px] uppercase tracking-[0.14em] text-white/30">{est.toFixed(1)}s</span>
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <div className="label mb-2">score · r-aud-02 · 120 bpm, 60.000 s, generated</div>
        <div className="border border-white/[0.07] bg-white/[0.02] p-3">
          <KV k="0.0 – 8.0 s" v="bass drop · cold blue arps (8 detuned sines, 2 kHz lowpass) · riser" />
          <KV k="8.0 – 32.0 s" v="arps continue, harmonic bank grows → warmer" />
          <KV k="32.0 – 44.0 s" v="pad swell + riser into the 44.0 s crescendo" />
          <KV k="44.0 – 60.0 s" v="bass hit, delay 0.25 s / feedback 0.3, fade to silence" />
          <KV k="ducking" v="music bus −6 dB while a VO line plays" />
        </div>
      </div>

      <div>
        <div className="label mb-2">sfx cues · r-aud-03 · {ALL_SFX.length} scheduled</div>
        <div className="scroll-thin max-h-56 overflow-y-auto border border-white/[0.07]">
          {ALL_SFX.map((c, i) => {
            const active = Math.abs(now - c.at) < 0.25;
            return (
              <button
                key={`${c.id}${c.at}${i}`}
                onClick={() => p.seek(Math.max(0, c.at - 0.05))}
                className={cx(
                  "mono flex w-full items-center gap-2 border-b border-white/[0.05] px-2.5 py-1 text-[10px] uppercase tracking-[0.12em] transition-colors",
                  active ? "bg-blue-500/15 text-blue-200" : "text-white/45 hover:bg-white/[0.05] hover:text-white/80",
                )}
              >
                <span className="w-12 tabular text-white/70">{c.at.toFixed(2)}s</span>
                <span className="flex-1 text-left">{c.id}</span>
                <span className="text-white/25">{c.scene}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
});

// ------------------------------------------------------------------- timeline
const TimelineTab = memo(function TimelineTab() {
  const [q, setQ] = useState("");
  const lines = useMemo(() => YAML_RAW.split("\n"), []);
  const filtered = useMemo(() => {
    if (!q.trim()) return lines.map((l, i) => ({ l, i }));
    const needle = q.toLowerCase();
    return lines.map((l, i) => ({ l, i })).filter(({ l, i }) => {
      if (l.toLowerCase().includes(needle)) return true;
      for (let k = i; k >= 0; k--) {
        if (/^\s*-?\s*(scene|meta):/.test(lines[k])) return lines[k].toLowerCase().includes(needle);
        if (/^\S/.test(lines[k]) && k !== i) break;
      }
      return false;
    });
  }, [lines, q]);

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-2">
        <Stat k="parse" v={TIMELINE_PARSE_OK ? "ok · 11 scenes" : "FAILED"} />
        <Stat k="declared objects" v={`${TIMELINE_STATS.elements} el · ${TIMELINE_STATS.textEntries} txt · ${TIMELINE_STATS.sfx} sfx · ${TIMELINE_STATS.vo} vo`} />
      </div>
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="filter scenes / ids / strings"
        className="mono w-full border border-white/15 bg-black/50 px-2.5 py-2 text-[11px] text-white/85 outline-none placeholder:text-white/25 focus:border-blue-400/70"
      />
      <div className="mono scroll-thin max-h-[46vh] overflow-auto border border-white/[0.07] bg-black/45 p-2 text-[10.5px] leading-[1.55]">
        {filtered.map(({ l, i }) => (
          <div key={i} className="flex gap-2 whitespace-pre">
            <span className="w-8 shrink-0 select-none text-right text-white/20 tabular">{i + 1}</span>
            <span className={cx(l.trim().startsWith("#") ? "text-white/30" : /^\s*-?\s*(scene|id|string|start|end|ease|type|layout):/.test(l) ? "text-blue-200/85" : "text-white/70")}>
              {l || " "}
            </span>
          </div>
        ))}
      </div>
      <p className="mono text-[10px] leading-relaxed tracking-[0.05em] text-white/35">
        This file is imported verbatim and parsed in the browser (src/ad/yaml.ts). Nothing is drawn that is not declared here —
        R-TIME-04. meta.fps {META.fps} · meta.frames {META.frames} · seed {META.seed} · focal {META.focal}.
      </p>
    </div>
  );
});

// ------------------------------------------------------------------------ log
function LogTab({ p }: { p: PlayerApi }) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <Chip tone="blue">t = {p.t.toFixed(3)} s</Chip>
        <Chip>frame {p.frame}</Chip>
        <Chip tone={p.scene === "—" ? "neutral" : "orange"}>{SCENE_LABELS[p.scene] ?? p.scene}</Chip>
      </div>
      <div>
        <div className="label mb-2">layout log · this frame · {p.textLog.length} entries</div>
        {p.textLog.length === 0 && <p className="text-[12px] text-white/40">no text inside its window at this time.</p>}
        <div className="flex flex-col gap-1">
          {p.textLog.map((e) => (
            <div key={e.id} className="border border-white/[0.07] bg-white/[0.02] p-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[13px] font-semibold text-white">{e.display ?? e.string}</span>
                <Chip tone={e.inSafeArea ? "pass" : "fail"}>{e.inSafeArea ? "in safe area" : "OUTSIDE"}</Chip>
              </div>
              <div className="mono mt-1 grid grid-cols-2 gap-x-3 text-[10px] uppercase tracking-[0.1em] text-white/40">
                <span>{e.layout}</span>
                <span className="text-right">{e.size.toFixed(0)} px {e.autofitSteps ? `(−${e.autofitSteps * 4} autofit)` : ""}</span>
                <span>bbox {e.bbox.map((v) => v.toFixed(0)).join(", ")}</span>
                <span className="text-right">w {e.width.toFixed(0)} · α {e.alpha.toFixed(2)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div>
        <div className="label mb-2">active elements · {SCENES.find((s) => s.scene === p.scene)?.elements.filter((e) => p.t >= e.start && p.t < e.end).length ?? 0}</div>
        <div className="flex flex-col gap-1">
          {(SCENES.find((s) => s.scene === p.scene)?.elements ?? []).map((e) => {
            const on = p.t >= e.start && p.t < e.end;
            const prog = on ? (p.t - e.start) / (e.end - e.start) : 0;
            return (
              <div key={e.id} className={cx("border px-2.5 py-1.5 transition-colors", on ? "border-blue-400/40 bg-blue-500/[0.07]" : "border-white/[0.05] bg-transparent opacity-45")}>
                <div className="mono flex items-center gap-2 text-[10px] uppercase tracking-[0.12em] text-white/75">
                  <span className="w-12 tabular text-white/40">{e.start.toFixed(2)}</span>
                  <span className="flex-1 text-left">{e.id}</span>
                  <span className="text-orange-300/80">{e.ease}</span>
                  <span className="w-10 text-right tabular text-white/40">{e.end.toFixed(2)}</span>
                </div>
                <div className="mt-1 h-[2px] bg-white/10">
                  <div className="h-full bg-blue-400" style={{ width: `${prog * 100}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------- board
const BoardTab = memo(function BoardTab({ rows, filter, setFilter }: { rows: CItem[]; filter: CStatus | "ALL"; setFilter: (f: CStatus | "ALL") => void }) {
  const shown = rows.filter((r) => filter === "ALL" || r.status === filter);
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap gap-1">
        {(["ALL", "PASS", "PARTIAL", "BLOCKED", "FAIL"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cx("mono border px-2 py-1 text-[10px] uppercase tracking-[0.14em] transition-colors", filter === f ? "border-orange-400/70 bg-orange-500/15 text-orange-200" : "border-white/12 text-white/45 hover:text-white/80")}
          >
            {f} · {f === "ALL" ? rows.length : rows.filter((r) => r.status === f).length}
          </button>
        ))}
      </div>
      <div className="flex flex-col gap-1">
        {shown.map((r) => (
          <details key={r.id} className="group border border-white/[0.07] bg-white/[0.02] open:border-white/20">
            <summary className="flex cursor-pointer list-none items-center gap-2 px-2.5 py-1.5">
              <span className="mono w-[86px] shrink-0 text-[10px] tracking-[0.08em] text-white/70">{r.id}</span>
              <span className="min-w-0 flex-1 truncate text-[12px] text-white/85">{r.title}</span>
              <StatusPill status={r.status} />
            </summary>
            <p className="mono border-t border-white/[0.07] px-2.5 py-2 text-[10px] leading-relaxed tracking-[0.04em] text-white/45">{r.evidence}</p>
          </details>
        ))}
      </div>
    </div>
  );
});

// --------------------------------------------------------------------- report
const ReportTab = memo(function ReportTab({ report, counts, rows }: { report: VerifyReport | null; counts: Record<CStatus, number>; rows: CItem[] }) {
  return (
    <div className="flex flex-col gap-4 text-[12px] leading-relaxed text-white/70">
      <section>
        <div className="label mb-1">1 · checklist status</div>
        <p>
          {rows.length} requirement IDs: <b className="text-blue-300">{counts.PASS} PASS</b>,{" "}
          <b className="text-orange-300">{counts.PARTIAL} PARTIAL</b>, <b className="text-white/60">{counts.BLOCKED} BLOCKED</b>,{" "}
          <b className="text-orange-400">{counts.FAIL} FAIL</b>. Full rows in the BOARD tab and in nealarp-ad/checklist.md.
        </p>
      </section>
      <section>
        <div className="label mb-1">2 · render commands</div>
        <pre className="mono overflow-x-auto border border-white/[0.07] bg-black/45 p-2.5 text-[10.5px] leading-relaxed text-white/70">
{`npm install && npm run build && npm run preview
# console → EXPORT → "render 1080p test"   ⇒ out/nealarp-ad-1080p-test.mp4 (scale 1)
# console → EXPORT → "render 2160p final"  ⇒ gated by R-GATE-02/03 (scale 2)

# offline master (same source, ffmpeg, R-OUT-05):
ffmpeg -y -framerate 60 -i out/frames/%06d.png -i audio/render/mix.wav \\
  -c:v libx264 -profile:v high -pix_fmt yuv420p -crf 16 -r 60 \\
  -c:a aac -b:a 320k -ar 48000 -ac 2 -af loudnorm=I=-14:TP=-1:LRA=11 \\
  -movflags +faststart -t 60.000 out/nealarp-ad-1080p-test.mp4`}
        </pre>
      </section>
      <section>
        <div className="label mb-1">3 · timings</div>
        {report ? (
          <>
            <KV k="avg 1080p frame" v={`${report.perf.ms1080.toFixed(2)} ms (this machine, this browser)`} />
            <KV k="4k estimate (4× rule)" v={`${report.perf.est4KHours.toFixed(2)} h for ${report.perf.frames} frames`} />
            <KV k="4k measured frame" v={`${report.perf.ms4K.toFixed(0)} ms → ${report.perf.est4KByMeasurementHours.toFixed(2)} h`} />
            <KV k="r-perf-05" v={report.perf.est4KHours > 6 ? "estimate > 6 h — 4K must not start" : "estimate ≤ 6 h on a render host; browser export stays real time (60 s)"} />
          </>
        ) : (
          <p className="text-white/45">Run the verification suite to fill this section with measured numbers.</p>
        )}
      </section>
      <section>
        <div className="label mb-1">4 · verification</div>
        {report ? (
          <div className="flex flex-col gap-1">
            {report.results.map((r) => (
              <div key={r.id} className="flex items-start gap-2 border-b border-white/[0.06] py-1">
                <span className="mono w-[70px] shrink-0 text-[10px] text-white/60">{r.id}</span>
                <StatusPill status={r.status as CStatus} />
                <span className="mono min-w-0 flex-1 text-[10px] leading-relaxed text-white/45">{r.evidence}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-white/45">Not run yet.</p>
        )}
      </section>
      <section>
        <div className="label mb-1">5 · deviations &amp; interpretations</div>
        <div className="flex flex-col gap-1">
          {DEVIATIONS.map((d) => (
            <div key={d.id} className="border-l-2 border-orange-500/60 pl-2">
              <span className="mono text-[10px] uppercase tracking-[0.12em] text-orange-300">{d.id}</span>
              <span className="ml-2 text-white/80">{d.text}</span>
              <span className="block text-white/40">— {d.reason}</span>
            </div>
          ))}
          {INTERPRETATIONS.map((d) => (
            <div key={d.id} className="border-l-2 border-blue-500/60 pl-2">
              <span className="mono text-[10px] uppercase tracking-[0.12em] text-blue-300">{d.id}</span>
              <span className="ml-2 text-white/80">{d.text}</span>
              <span className="block text-white/40">— {d.reason}</span>
            </div>
          ))}
        </div>
      </section>
      <section>
        <div className="label mb-1">6 · open items</div>
        <ol className="list-decimal space-y-1 pl-4 text-white/60">
          <li>Approve or reject the 4K master (R-GATE-02) — the estimate is measured, not guessed.</li>
          <li>Supply eight German neural VO stems in nealarp-ad/audio/vo/ (or a TTS API key) so the mix can embed voiceover; R-GATE-03 stays blocked until then.</li>
          <li>Confirm whether a Linux host with Python + ffmpeg should run tests/render_cli.py for the H.264/AAC masters with two-pass loudnorm.</li>
          <li>
            Pacing note (R-TIME-03, unchanged as instructed): the hero act 32.0–44.0 s is one long shot carrying a single VO line —
            calm, but the most likely drop-off point.
          </li>
        </ol>
      </section>
      <section>
        <div className="label mb-1">approved copy · r-txt-01</div>
        <div className="flex flex-wrap gap-1">
          {R_TXT.map((s) => (
            <span key={s} className="mono border border-white/12 bg-white/[0.03] px-1.5 py-1 text-[10px] text-white/70">
              {s}
            </span>
          ))}
        </div>
        <p className="mono mt-2 text-[10px] uppercase tracking-[0.12em] text-white/35">
          safe area {SAFE.left}/{SAFE.top} · templates {TEMPLATE_IDS.length} · auto-fit &gt;1440 px in 4 px steps down to 64 px
        </p>
      </section>
    </div>
  );
});

export { TEMPLATES };
