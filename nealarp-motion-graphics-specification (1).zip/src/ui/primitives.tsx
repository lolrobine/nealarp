import { useEffect, useRef, useState, type ReactNode } from "react";

export const cx = (...parts: (string | false | null | undefined)[]) => parts.filter(Boolean).join(" ");

export function Reveal({ children, delay = 0, className }: { children: ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setSeen(true);
            io.disconnect();
          }
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" },
    );
    io.observe(node);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={cx("reveal", seen && "is-in", className)} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

type Tone = "neutral" | "blue" | "orange" | "pass" | "partial" | "blocked" | "fail";

const TONES: Record<Tone, string> = {
  neutral: "border-white/15 text-white/70 bg-white/[0.03]",
  blue: "border-blue-500/50 text-blue-300 bg-blue-500/10",
  orange: "border-orange-500/50 text-orange-300 bg-orange-500/10",
  pass: "border-blue-400/60 text-blue-200 bg-blue-500/15",
  partial: "border-orange-400/50 text-orange-200 bg-orange-500/12",
  blocked: "border-white/20 text-white/45 bg-white/[0.04]",
  fail: "border-orange-600 text-orange-300 bg-orange-600/20",
};

export function Chip({ children, tone = "neutral", className }: { children: ReactNode; tone?: Tone; className?: string }) {
  return (
    <span className={cx("mono inline-flex items-center gap-1.5 border px-2 py-[3px] text-[10px] uppercase tracking-[0.16em] leading-none", TONES[tone], className)}>
      {children}
    </span>
  );
}

export function StatusPill({ status }: { status: "PASS" | "PARTIAL" | "BLOCKED" | "FAIL" }) {
  const tone: Tone = status === "PASS" ? "pass" : status === "PARTIAL" ? "partial" : status === "BLOCKED" ? "blocked" : "fail";
  return <Chip tone={tone}>{status}</Chip>;
}

export function Led({ on, color = "blue" }: { on: boolean; color?: "blue" | "orange" }) {
  return (
    <span
      className="inline-block h-[6px] w-[6px] rounded-full transition-all duration-200"
      style={{
        background: on ? (color === "blue" ? "#3b82f6" : "#f97316") : "rgba(255,255,255,0.18)",
        boxShadow: on ? `0 0 10px ${color === "blue" ? "#3b82f6" : "#f97316"}` : "none",
      }}
    />
  );
}

/** dB meter, -60..0 */
export function Meter({ db, label, color = "blue" }: { db: number; label: string; color?: "blue" | "orange" }) {
  const v = Math.max(0, Math.min(1, (db + 60) / 60));
  return (
    <div className="flex items-center gap-2">
      <span className="label w-12 shrink-0">{label}</span>
      <span className="relative h-[6px] flex-1 overflow-hidden rounded-[1px] bg-white/[0.07]">
        <span
          className="absolute inset-y-0 left-0 transition-[width] duration-100 ease-out"
          style={{
            width: `${v * 100}%`,
            background: color === "blue" ? "linear-gradient(90deg,#1d4ed8,#3b82f6)" : "linear-gradient(90deg,#c2410c,#f97316)",
            boxShadow: color === "blue" ? "0 0 12px rgba(59,130,246,.7)" : "0 0 12px rgba(249,115,22,.7)",
          }}
        />
      </span>
      <span className="mono w-14 shrink-0 text-right text-[10px] text-white/45 tabular">
        {db <= -59 ? "-inf" : db.toFixed(1)} dB
      </span>
    </div>
  );
}

export function SectionHead({ n, title, sub, right }: { n: string; title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/10 pb-4">
      <div className="flex items-start gap-4">
        <span className="mono mt-1 text-[11px] tracking-[0.2em] text-orange-400/80">{n}</span>
        <div>
          <h2 className="font-display text-[clamp(24px,3.4vw,40px)] font-bold leading-[0.95] tracking-[-0.02em] text-white">{title}</h2>
          {sub && <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-white/50">{sub}</p>}
        </div>
      </div>
      {right}
    </div>
  );
}

export function KV({ k, v, mono = true }: { k: string; v: ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-white/[0.06] py-1.5 last:border-0">
      <span className="label shrink-0">{k}</span>
      <span className={cx("text-right text-[12px] text-white/85", mono && "mono tabular")}>{v}</span>
    </div>
  );
}

export function Toggle({ on, onChange, label, color = "blue" }: { on: boolean; onChange: (v: boolean) => void; label: string; color?: "blue" | "orange" }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className={cx(
        "mono group flex items-center gap-2 border px-2.5 py-[7px] text-[10px] uppercase tracking-[0.16em] transition-all duration-200",
        on
          ? color === "blue"
            ? "border-blue-400/60 bg-blue-500/15 text-blue-200"
            : "border-orange-400/60 bg-orange-500/15 text-orange-200"
          : "border-white/12 bg-white/[0.02] text-white/40 hover:border-white/25 hover:text-white/70",
      )}
    >
      <Led on={on} color={color} />
      {label}
    </button>
  );
}
