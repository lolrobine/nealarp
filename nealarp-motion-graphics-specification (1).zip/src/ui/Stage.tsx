import { useState } from "react";
import { REF_H, REF_W } from "@/ad/constants";
import { SCENE_LABELS } from "@/ad/constants";
import type { PlayerApi } from "./usePlayer";
import { Chip, Led, cx } from "./primitives";

export function Stage({ p, showSafe, showBoxes }: { p: PlayerApi; showSafe: boolean; showBoxes: boolean }) {
  const [hover, setHover] = useState<string | null>(null);
  const exporting = !!p.exporting;

  return (
    <div className="relative">
      <div
        className="group relative w-full cursor-pointer overflow-hidden border border-white/12 bg-[#0a0a0a]"
        style={{ aspectRatio: "16 / 9" }}
        onClick={() => !exporting && p.toggle()}
        title={p.playing ? "pause" : "play"}
      >
        <canvas ref={p.canvasRef} className="absolute inset-0 block h-full w-full" />

        {/* idle affordance */}
        {!p.playing && !exporting && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="relative flex h-20 w-20 items-center justify-center border border-white/25 bg-black/45 backdrop-blur-[2px] transition-all duration-300 group-hover:border-orange-400/80 group-hover:bg-black/60">
              <svg width="20" height="20" viewBox="0 0 16 16" fill="currentColor" className="ml-1 text-white/85 transition-colors group-hover:text-orange-300">
                <path d="M3 1.5 14 8 3 14.5z" />
              </svg>
              <span className="mono absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] uppercase tracking-[0.2em] text-white/45 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                60.000 s · click
              </span>
            </div>
          </div>
        )}

        {/* corner registration marks */}
        {[
          "left-2 top-2 border-l border-t",
          "right-2 top-2 border-r border-t",
          "left-2 bottom-2 border-b border-l",
          "right-2 bottom-2 border-b border-r",
        ].map((c) => (
          <span key={c} className={cx("pointer-events-none absolute h-4 w-4 border-white/35", c)} />
        ))}

        {/* safe area guides */}
        {showSafe && (
          <div
            className="pointer-events-none absolute border border-dashed border-orange-400/45"
            style={{
              left: `${(96 / REF_W) * 100}%`,
              top: `${(54 / REF_H) * 100}%`,
              right: `${(96 / REF_W) * 100}%`,
              bottom: `${(54 / REF_H) * 100}%`,
            }}
          >
            <span className="mono absolute -top-4 left-0 text-[9px] uppercase tracking-[0.2em] text-orange-300/80">safe 96 / 54</span>
          </div>
        )}

        {/* live layout-log bboxes (R-VER-08 made visible) */}
        {showBoxes &&
          p.textLog.map((e) => (
            <div
              key={e.id}
              className={cx(
                "pointer-events-auto absolute border transition-colors",
                e.inSafeArea ? "border-blue-400/60" : "border-orange-500",
              )}
              style={{
                left: `${(e.bbox[0] / REF_W) * 100}%`,
                top: `${(e.bbox[1] / REF_H) * 100}%`,
                width: `${((e.bbox[2] - e.bbox[0]) / REF_W) * 100}%`,
                height: `${((e.bbox[3] - e.bbox[1]) / REF_H) * 100}%`,
              }}
              onMouseEnter={() => setHover(e.id)}
              onMouseLeave={() => setHover(null)}
            >
              {hover === e.id && (
                <span className="mono absolute -top-5 left-0 whitespace-nowrap border border-white/20 bg-black/85 px-1.5 py-0.5 text-[9px] uppercase tracking-[0.14em] text-white/85">
                  {e.layout} · {e.size.toFixed(0)}px · w{e.width.toFixed(0)}
                  {e.autofitSteps > 0 ? ` · autofit −${e.autofitSteps * 4}` : ""}
                </span>
              )}
            </div>
          ))}

        {/* HUD */}
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3">
          <div className="flex items-center gap-2">
            <Chip tone={exporting ? "orange" : "blue"}>
              <span className={cx("inline-block h-[6px] w-[6px] rounded-full", exporting ? "bg-orange-400" : "bg-blue-400", exporting && "beat")} />
              {exporting ? "RENDERING" : p.playing ? "PLAYBACK" : "STANDBY"}
            </Chip>
            <Chip>{`ACT ${p.act}`}</Chip>
          </div>
          <div className="mono text-right text-[10px] uppercase tracking-[0.18em] text-white/45">
            <div>{SCENE_LABELS[p.scene] ?? p.scene}</div>
            <div className="tabular">
              scale {p.renderScale.toFixed(2)} · {Math.round(REF_W * p.renderScale)}×{Math.round(REF_H * p.renderScale)} · {p.fps.toFixed(0)} fps ·{" "}
              {p.msFrame.toFixed(1)} ms/frame
            </div>
          </div>
        </div>

        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-3">
          <div className="mono text-[10px] uppercase tracking-[0.18em] text-white/40">
            <span className="flex items-center gap-2">
              <Led on={p.levels.master > -50} color="orange" /> master {p.levels.master <= -59 ? "-inf" : p.levels.master.toFixed(1)} dB
            </span>
            {p.lastCue && (
              <span className="mt-1 block text-white/55">
                cue {p.lastCue.kind}:{p.lastCue.id} @{p.lastCue.at.toFixed(2)}s
              </span>
            )}
          </div>
          <div className="font-display text-right leading-none">
            <span className="tabular text-[clamp(26px,3.6vw,46px)] font-bold tracking-[-0.03em] text-white">
              {tc(p.t)}
            </span>
            <span className="mono ml-2 text-[10px] uppercase tracking-[0.18em] text-white/40">
              f {String(p.frame).padStart(4, "0")}/3600
            </span>
          </div>
        </div>

        {exporting && (
          <div className="absolute inset-x-0 bottom-0 h-[3px] bg-white/10">
            <div
              className="h-full transition-[width] duration-100"
              style={{
                width: `${p.exporting!.progress.pct}%`,
                background: "linear-gradient(90deg,#3b82f6,#f97316)",
                boxShadow: "0 0 14px rgba(249,115,22,.8)",
              }}
            />
          </div>
        )}
      </div>

      {p.exporting && (
        <div className="mono mt-2 flex flex-wrap items-center justify-between gap-2 border border-orange-500/30 bg-orange-500/[0.07] px-3 py-2 text-[10px] uppercase tracking-[0.16em] text-orange-200">
          <span>
            real-time render → {p.exporting.profile} · {p.exporting.progress.t.toFixed(2)} / 60.00 s · {p.exporting.progress.fps.toFixed(1)} fps ·{" "}
            {p.exporting.progress.avgMs.toFixed(1)} ms/frame · dropped {p.exporting.progress.dropped}
          </span>
          <button className="btn !px-2 !py-1" onClick={p.cancelExport}>
            cancel
          </button>
        </div>
      )}
      {p.exportDone && !exporting && (
        <div className="mono mt-2 flex flex-wrap items-center justify-between gap-2 border border-blue-500/30 bg-blue-500/[0.07] px-3 py-2 text-[10px] uppercase tracking-[0.16em] text-blue-200">
          <span>
            wrote {p.exportDone.name} · {(p.exportDone.blob.size / 1e6).toFixed(1)} MB · {p.exportDone.mime} · {p.exportDone.frames} frames ·{" "}
            {p.exportDone.avgMs.toFixed(1)} ms/frame · {p.exportDone.seconds.toFixed(1)} s real time
          </span>
          <button className="btn !px-2 !py-1" onClick={() => window.location.reload()}>
            reset
          </button>
        </div>
      )}
      {p.exportError && !exporting && (
        <div className="mono mt-2 border border-orange-600/40 bg-orange-600/10 px-3 py-2 text-[10px] uppercase tracking-[0.16em] text-orange-200">
          export blocked — {p.exportError}
        </div>
      )}
    </div>
  );
}

export function tc(t: number) {
  const total = Math.max(0, Math.min(59.9999, t));
  const s = Math.floor(total);
  const f = Math.floor((total - s) * 60);
  return `00:${String(s).padStart(2, "0")}:${String(f).padStart(2, "0")}`;
}
