import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AdAudio } from "@/ad/audio";
import { DURATION, FPS, TOTAL_FRAMES } from "@/ad/constants";
import { downloadBlob, downloadCanvas, PROFILES, startExport, type ExportDone, type ExportProfile, type ExportProgress } from "@/ad/exporter";
import { newCaches, renderFrame } from "@/ad/renderer";
import { getTextLog, type TextLogEntry } from "@/ad/text";
import { SCENES, sceneAt } from "@/ad/timeline";

export interface PlayerApi {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  t: number;
  frame: number;
  playing: boolean;
  rate: number;
  scene: string;
  sceneLabel: string;
  act: string;
  textLog: TextLogEntry[];
  levels: { music: number; sfx: number; master: number };
  mutes: { music: boolean; sfx: boolean; vo: boolean };
  voiceInfo: { ready: boolean; name: string | null; lang: string | null; available: number };
  fps: number;
  msFrame: number;
  renderScale: number;
  lastCue: { kind: string; id: string; at: number } | null;
  exporting: { profile: string; progress: ExportProgress } | null;
  exportDone: ExportDone | null;
  exportError: string | null;
  approved4k: boolean;
  setApproved4k: (v: boolean) => void;
  play: () => void;
  pause: () => void;
  toggle: () => void;
  seek: (t: number) => void;
  nudge: (d: number) => void;
  setRate: (r: number) => void;
  setMute: (bus: "music" | "sfx" | "vo", v: boolean) => void;
  runExport: (id: "test" | "final", withAudio: boolean) => void;
  cancelExport: () => void;
  saveStill: (scale: number) => void;
  audioReady: boolean;
}

export function usePlayer(): PlayerApi {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const cachesRef = useRef(newCaches());
  const audioRef = useRef<AdAudio | null>(null);
  const exportRef = useRef<{ cancel: () => void } | null>(null);

  const tRef = useRef(0);
  const playingRef = useRef(false);
  const rateRef = useRef(1);
  const wallRef = useRef(0);
  const dirtyRef = useRef(true);
  const scaleRef = useRef(0.6);
  const exportingRef = useRef(false);

  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [rate, setRateState] = useState(1);
  const [textLog, setTextLog] = useState<TextLogEntry[]>([]);
  const [levels, setLevels] = useState({ music: -90, sfx: -90, master: -90 });
  const [mutes, setMutes] = useState({ music: false, sfx: false, vo: false });
  const [voiceInfo, setVoiceInfo] = useState({ ready: false, name: null as string | null, lang: null as string | null, available: 0 });
  const [fps, setFps] = useState(60);
  const [msFrame, setMsFrame] = useState(0);
  const [renderScale, setRenderScale] = useState(0.6);
  const [lastCue, setLastCue] = useState<{ kind: string; id: string; at: number } | null>(null);
  const [exporting, setExporting] = useState<{ profile: string; progress: ExportProgress } | null>(null);
  const [exportDone, setExportDone] = useState<ExportDone | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [approved4k, setApproved4k] = useState(false);
  const [audioReady, setAudioReady] = useState(false);

  const getAudio = useCallback(() => {
    if (!audioRef.current) {
      audioRef.current = new AdAudio({ onCue: (kind, id, at) => setLastCue({ kind, id, at }) });
    }
    return audioRef.current;
  }, []);

  // ---- responsive render scale (never upscale beyond the reference space) --
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const measure = () => {
      const cssW = cv.clientWidth || 960;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.25);
      const s = Math.max(0.34, Math.min(0.9, (cssW * dpr) / 1920));
      scaleRef.current = s;
      setRenderScale(s);
      dirtyRef.current = true;
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(cv);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, []);

  // ---- pre-warm the caches that would otherwise cost a frame mid-film -----
  useEffect(() => {
    const id = window.setTimeout(() => {
      const off = document.createElement("canvas");
      for (const tt of [0.05, 8.5, 14.5, 20.6, 26.5, 33, 46.5, 49, 51.2, 55.2]) {
        renderFrame(off, tt, 0.4, { caches: cachesRef.current });
      }
      off.width = 0;
      off.height = 0;
      dirtyRef.current = true;
    }, 350);
    return () => window.clearTimeout(id);
  }, []);

  // ---- voices -------------------------------------------------------------
  useEffect(() => {
    const id = window.setInterval(() => {
      const a = audioRef.current;
      if (a) setVoiceInfo(a.voiceInfo);
      else if (typeof speechSynthesis !== "undefined") {
        const de = speechSynthesis.getVoices().filter((v) => v.lang.toLowerCase().startsWith("de"));
        setVoiceInfo({ ready: de.length > 0, name: de[0]?.name ?? null, lang: de[0]?.lang ?? null, available: de.length });
      }
    }, 1200);
    return () => window.clearInterval(id);
  }, []);

  // ---- the frame loop -----------------------------------------------------
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let frames = 0;
    let msAcc = 0;
    let fpsClock = performance.now();
    let uiClock = 0;
    let logClock = 0;

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = now - last;
      last = now;

      if (exportingRef.current) return; // the exporter owns the canvas

      const cv = canvasRef.current;
      if (!cv) return;

      if (playingRef.current) {
        const audio = audioRef.current;
        let next: number;
        if (audio?.playing) {
          next = audio.currentPosition();
          wallRef.current = now - (next / rateRef.current) * 1000;
        } else {
          next = ((now - wallRef.current) / 1000) * rateRef.current;
        }
        if (next >= DURATION) {
          next = DURATION;
          playingRef.current = false;
          setPlaying(false);
          audio?.stop();
        }
        tRef.current = next;
        dirtyRef.current = true;
      }

      if (dirtyRef.current || playingRef.current) {
        const s = performance.now();
        renderFrame(cv, tRef.current, scaleRef.current, { caches: cachesRef.current });
        msAcc += performance.now() - s;
        frames++;
        dirtyRef.current = false;
      }

      if (now - fpsClock > 500) {
        setFps((frames / (now - fpsClock)) * 1000);
        setMsFrame(frames ? msAcc / frames : 0);
        frames = 0;
        msAcc = 0;
        fpsClock = now;
      }
      if (now - uiClock > 33) {
        uiClock = now;
        setT(tRef.current);
      }
      if (now - logClock > 110) {
        logClock = now;
        setTextLog([...getTextLog()]);
        const a = audioRef.current;
        if (a?.playing) setLevels(a.getLevels());
        else setLevels({ music: -90, sfx: -90, master: -90 });
      }
      void dt;
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const draw = useCallback(() => {
    dirtyRef.current = true;
  }, []);

  const seek = useCallback(
    (v: number) => {
      const nv = Math.max(0, Math.min(DURATION - 1e-4, v));
      tRef.current = nv;
      setT(nv);
      draw();
      if (playingRef.current) {
        wallRef.current = performance.now() - (nv / rateRef.current) * 1000;
        void getAudio().play(nv);
      }
    },
    [draw, getAudio],
  );

  const play = useCallback(() => {
    const cv = canvasRef.current;
    if (!cv || exportingRef.current) return;
    if (tRef.current >= DURATION - 0.02) {
      tRef.current = 0;
      setT(0);
    }
    playingRef.current = true;
    setPlaying(true);
    wallRef.current = performance.now() - (tRef.current / rateRef.current) * 1000;
    const audio = getAudio();
    void audio.play(tRef.current).then(() => {
      setAudioReady(true);
      setVoiceInfo(audio.voiceInfo);
      audio.setMute("music", mutes.music);
      audio.setMute("sfx", mutes.sfx);
      audio.setMute("vo", mutes.vo);
    });
  }, [getAudio, mutes.music, mutes.sfx, mutes.vo]);

  const pause = useCallback(() => {
    playingRef.current = false;
    setPlaying(false);
    audioRef.current?.pause();
  }, []);

  const toggle = useCallback(() => (playingRef.current ? pause() : play()), [pause, play]);

  const nudge = useCallback((d: number) => seek(tRef.current + d), [seek]);

  const setRate = useCallback((r: number) => {
    rateRef.current = r;
    setRateState(r);
    wallRef.current = performance.now() - (tRef.current / r) * 1000;
  }, []);

  const setMute = useCallback(
    (bus: "music" | "sfx" | "vo", v: boolean) => {
      setMutes((m) => ({ ...m, [bus]: v }));
      audioRef.current?.setMute(bus, v);
      if (bus === "vo" && v && typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
    },
    [],
  );

  const runExport = useCallback(
    async (id: "test" | "final", withAudio: boolean) => {
      const cv = canvasRef.current;
      if (!cv || exportingRef.current) return;
      const profile: ExportProfile = PROFILES.find((p) => p.id === id)!;
      pause();
      exportingRef.current = true;
      setExportError(null);
      setExportDone(null);
      setExporting({ profile: profile.baseName, progress: { t: 0, pct: 0, fps: 0, avgMs: 0, dropped: 0 } });
      const audio = withAudio ? getAudio() : null;
      if (audio) {
        try {
          await audio.init(); // the capture stream only exists once the context does
        } catch (e) {
          setExportError(`audio init failed: ${String(e)}`);
        }
      }
      exportRef.current = startExport({
        canvas: cv,
        audio,
        profile,
        withAudio,
        onProgress: (p) => setExporting({ profile: profile.baseName, progress: p }),
        onDone: (d) => {
          exportingRef.current = false;
          setExporting(null);
          setExportDone(d);
          downloadBlob(d.blob, d.name);
          scaleRef.current = Math.max(0.34, Math.min(1, (cv.clientWidth || 960) / 1920));
          tRef.current = 0;
          setT(0);
          draw();
        },
        onError: (msg) => {
          exportingRef.current = false;
          setExporting(null);
          setExportError(msg);
          draw();
        },
      });
    },
    [draw, getAudio, pause],
  );

  const cancelExport = useCallback(() => {
    exportRef.current?.cancel();
  }, []);

  const saveStill = useCallback(
    (scale: number) => {
      const off = document.createElement("canvas");
      renderFrame(off, tRef.current, scale, { caches: newCaches() });
      downloadCanvas(off, `nealarp-ad-frame-${String(Math.round(tRef.current * FPS)).padStart(4, "0")}-${scale === 2 ? "2160p" : "1080p"}.png`);
      off.width = 0;
    },
    [],
  );

  // keyboard transport
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space") {
        e.preventDefault();
        toggle();
      } else if (e.code === "ArrowLeft") seek(tRef.current - (e.shiftKey ? 1 : 1 / FPS));
      else if (e.code === "ArrowRight") seek(tRef.current + (e.shiftKey ? 1 : 1 / FPS));
      else if (e.code === "Home") seek(0);
      else if (e.code === "End") seek(DURATION - 0.05);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [seek, toggle]);

  useEffect(() => () => audioRef.current?.stop(), []);

  const scene = sceneAt(t);
  const api = useMemo<PlayerApi>(
    () => ({
      canvasRef,
      t,
      frame: Math.min(TOTAL_FRAMES - 1, Math.round(t * FPS)),
      playing,
      rate,
      scene: scene?.scene ?? "—",
      sceneLabel: scene?.scene ?? "—",
      act: scene?.act ?? "—",
      textLog,
      levels,
      mutes,
      voiceInfo,
      fps,
      msFrame,
      renderScale,
      lastCue,
      exporting,
      exportDone,
      exportError,
      approved4k,
      setApproved4k,
      play,
      pause,
      toggle,
      seek,
      nudge,
      setRate,
      setMute,
      runExport,
      cancelExport,
      saveStill,
      audioReady,
    }),
    [
      t,
      playing,
      rate,
      scene,
      textLog,
      levels,
      mutes,
      voiceInfo,
      fps,
      msFrame,
      renderScale,
      lastCue,
      exporting,
      exportDone,
      exportError,
      approved4k,
      play,
      pause,
      toggle,
      seek,
      nudge,
      setRate,
      setMute,
      runExport,
      cancelExport,
      saveStill,
      audioReady,
    ],
  );
  return api;
}

export const SCENE_LIST = SCENES.map((s) => ({ id: s.scene, act: s.act, start: s.start, end: s.end }));
