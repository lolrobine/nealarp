import { useRef, useState } from "react";
import { DURATION } from "@/ad/constants";
import { SCENES } from "@/ad/timeline";
import { SCENE_LABELS } from "@/ad/constants";
import type { PlayerApi } from "./usePlayer";
import { Chip, Led, Meter, Toggle, cx } from "./primitives";
import { tc } from "./Stage";

function Scrubber({ p }: { p: PlayerApi }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const dragging = useRef(false);
  const [hoverScene, setHoverScene] = useState<string | null>(null);

  const pos = (clientX: number) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return 0;
    return Math.max(0, Math.min(1, (clientX - r.left) / r.width)) * DURATION;
  };

  return (
    <div className="select-none">
      <div
        ref={ref}
        className="relative h-[46px] cursor-ew-resize border border-white/12 bg-black/50"
        onPointerDown={(e) => {
          dragging.current = true;
          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
          p.seek(pos(e.clientX));
        }}
        onPointerMove={(e) => dragging.current && p.seek(pos(e.clientX))}
        onPointerUp={() => (dragging.current = false)}
        onPointerCancel={() => (dragging.current = false)}
        onPointerLeave={() => (dragging.current = false)}
      >
        {SCENES.map((s) => {
          const left = (s.start / DURATION) * 100;
          const width = ((s.end - s.start) / DURATION) * 100;
          const active = p.t >= s.start && p.t < s.end;
          return (
            <div
              key={s.scene}
              className={cx(
                "absolute inset-y-0 border-r border-white/10 transition-colors duration-200",
                active ? "bg-blue-500/16" : hoverScene === s.scene ? "bg-white/[0.07]" : "bg-white/[0.02]",
              )}
              style={{ left: `${left}%`, width: `${width}%` }}
              onMouseEnter={() => setHoverScene(s.scene)}
              onMouseLeave={() => setHoverScene(null)}
            >
              <span
                className={cx(
                  "mono absolute bottom-1 left-1 truncate text-[9px] uppercase tracking-[0.14em] transition-colors",
                  active ? "text-orange-300" : "text-white/30",
                )}
              >
                {s.act}
                {s.scene.startsWith("game_") ? s.scene.slice(5, 7) : ""}
              </span>
              {s.hold.map(([a, b], i) => (
                <span
                  key={i}
                  className="absolute top-0 h-[3px] bg-white/25"
                  style={{ left: `${((a - s.start) / (s.end - s.start)) * 100}%`, width: `${((b - a) / (s.end - s.start)) * 100}%` }}
                />
              ))}
            </div>
          );
        })}
        <div className="pointer-events-none absolute inset-y-0 w-[2px] bg-orange-500" style={{ left: `${(p.t / DURATION) * 100}%`, boxShadow: "0 0 12px rgba(249,115,22,.9)" }} />
      </div>
      <div className="mono mt-1 flex items-center justify-between text-[9px] uppercase tracking-[0.16em] text-white/35">
        <span>{hoverScene ? SCENE_LABELS[hoverScene] ?? hoverScene : "timeline.yaml · 11 scenes · 8 cuts · hold marks on top"}</span>
        <span className="tabular">0.0 — 60.0 s</span>
      </div>
    </div>
  );
}

export function Transport({ p }: { p: PlayerApi }) {
  const [withAudio, setWithAudio] = useState(true);
  const [approval, setApproval] = useState("");
  const gate3Blocked = true; // D-06: no neural VO can be embedded in a browser export

  return (
    <div className="panel-flat p-3 sm:p-4">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
        <div className="flex items-center gap-3">
          <button
            className={cx("btn btn-solid flex h-[52px] w-[52px] items-center justify-center !p-0")}
            onClick={p.toggle}
            aria-label={p.playing ? "pause" : "play"}
          >
            {p.playing ? (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <rect x="2" y="1" width="4" height="14" />
                <rect x="10" y="1" width="4" height="14" />
              </svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <path d="M3 1.5 14 8 3 14.5z" />
              </svg>
            )}
          </button>
          <div className="flex flex-col gap-1">
            <div className="flex gap-1">
              {[
                { l: "−1f", d: -1 / 60 },
                { l: "+1f", d: 1 / 60 },
                { l: "−1s", d: -1 },
                { l: "+1s", d: 1 },
              ].map((b) => (
                <button key={b.l} className="btn !px-2 !py-1" onClick={() => p.nudge(b.d)}>
                  {b.l}
                </button>
              ))}
            </div>
            <div className="flex gap-1">
              {[1, 0.5, 0.25].map((r) => (
                <button
                  key={r}
                  className={cx("btn !px-2 !py-1", p.rate === r && "!border-orange-400/70 !bg-orange-500/15 !text-orange-200")}
                  onClick={() => p.setRate(r)}
                >
                  {r}×
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="min-w-0 flex-1">
          <Scrubber p={p} />
        </div>

        <div className="flex shrink-0 flex-col gap-2">
          <div className="flex items-center gap-2">
            <Toggle on={!p.mutes.music} onChange={(v) => p.setMute("music", !v)} label="music" />
            <Toggle on={!p.mutes.sfx} onChange={(v) => p.setMute("sfx", !v)} label="sfx" color="orange" />
            <Toggle on={!p.mutes.vo} onChange={(v) => p.setMute("vo", !v)} label="vo de-DE" />
          </div>
          <div className="flex flex-col gap-1">
            <Meter db={p.levels.music} label="music" />
            <Meter db={p.levels.sfx} label="sfx" color="orange" />
          </div>
        </div>
      </div>

      <div className="hair my-4" />

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,360px)]">
        <div>
          <div className="label mb-2">export · one source, two profiles</div>
          <div className="flex flex-wrap items-center gap-2">
            <button className="btn btn-orange" disabled={!!p.exporting} onClick={() => p.runExport("test", withAudio)}>
              render 1080p test
            </button>
            <Toggle on={withAudio} onChange={setWithAudio} label="audio mix" color="orange" />
            <button className="btn" disabled={!!p.exporting} onClick={() => p.saveStill(1)}>
              still 1080p png
            </button>
            <button className="btn" disabled={!!p.exporting} onClick={() => p.saveStill(2)}>
              still 2160p png
            </button>
            <Chip tone="neutral">
              <Led on={p.audioReady} color="orange" /> 48 kHz
            </Chip>
          </div>
          <p className="mono mt-2 max-w-2xl text-[10px] leading-relaxed tracking-[0.06em] text-white/35">
            MediaRecorder writes in real time (60.00 s per pass). H.264 High + AAC is used when the browser offers
            video/mp4;codecs=avc1 — otherwise WebM/VP9 (deviation D-05). Voiceover is spoken live by the de-DE neural voice but
            cannot be captured into the file (D-06).
          </p>
        </div>

        <div className={cx("border p-3", p.approved4k ? "border-orange-500/40 bg-orange-500/[0.06]" : "border-white/10 bg-white/[0.02]")}>
          <div className="label mb-2">r-gate · 4k master</div>
          <div className="flex flex-wrap items-center gap-2">
            <input
              value={approval}
              onChange={(e) => {
                setApproval(e.target.value);
                p.setApproved4k(e.target.value.trim().toUpperCase() === "APPROVE 4K");
              }}
              placeholder='type "APPROVE 4K"'
              className="mono w-full border border-white/15 bg-black/50 px-2 py-[7px] text-[11px] uppercase tracking-[0.14em] text-white/85 outline-none placeholder:text-white/25 focus:border-orange-400/70"
            />
            <button
              className={cx("btn w-full", p.approved4k && "btn-orange")}
              disabled={!p.approved4k || !!p.exporting}
              onClick={() => p.runExport("final", withAudio)}
            >
              render 2160p final
            </button>
          </div>
          <p className="mono mt-2 text-[10px] leading-relaxed tracking-[0.06em] text-white/45">
            R-GATE-02 {p.approved4k ? "satisfied" : "open"} — explicit approval required.{" "}
            <span className="text-orange-300">
              R-GATE-03 {gate3Blocked ? "BLOCKED" : "ok"}: a real German neural voice cannot be embedded in a browser export
              (D-06), so the 4K master stays blocked and no 1080p upscale is substituted (R-GATE-04).
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}

export function TimecodeBig({ t }: { t: number }) {
  return <span className="font-display tabular text-[clamp(30px,4.6vw,58px)] font-bold leading-none tracking-[-0.04em] text-white">{tc(t)}</span>;
}
