import { useState } from "react";
import { DURATION, FPS, R_TXT, TOTAL_FRAMES } from "@/ad/constants";
import { rampColor } from "@/ad/core";
import { META, TIMELINE_PARSE_OK, TIMELINE_STATS } from "@/ad/timeline";
import { Dossier } from "@/ui/Dossier";
import { Panels } from "@/ui/Panels";
import { Stage } from "@/ui/Stage";
import { Transport } from "@/ui/Transport";
import { usePlayer } from "@/ui/usePlayer";
import { Chip, Led, Reveal, Toggle, cx } from "@/ui/primitives";

function Wordmark({ text, className }: { text: string; className?: string }) {
  const n = Math.max(1, text.length - 1);
  return (
    <span className={cx("font-display font-bold tracking-[-0.03em]", className)}>
      {[...text].map((ch, i) => (
        <span key={i} style={{ color: rampColor(i / n) }}>
          {ch}
        </span>
      ))}
    </span>
  );
}

const FACTS: [string, string][] = [
  ["veröffentlicht", "12. Oktober 2026"],
  ["adresse", "nealarp.vercel.app"],
  ["dauer", `${DURATION.toFixed(3)} s · ${TOTAL_FRAMES} frames`],
  ["master", "3840×2160 @ 60/1 (gated)"],
  ["test", "1920×1080 @ 60/1"],
  ["quelle", "timeline.yaml · seed 7"],
];

export default function App() {
  const p = usePlayer();
  const [showSafe, setShowSafe] = useState(false);
  const [showBoxes, setShowBoxes] = useState(true);

  return (
    <div className="relative min-h-screen">
      <div className="ambient" />
      <div className="sweep" />
      <div className="grain-overlay" />

      {/* ------------------------------------------------------------ header */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#07080a]/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1680px] flex-wrap items-center gap-3 px-4 py-2.5">
          <div className="flex items-baseline gap-2.5">
            <Wordmark text="nealarp" className="text-[19px] leading-none" />
            <span className="mono text-[10px] uppercase tracking-[0.22em] text-white/35">motion master</span>
          </div>
          <span className="hidden h-4 w-px bg-white/12 sm:block" />
          <div className="flex flex-wrap items-center gap-1.5">
            <Chip tone={TIMELINE_PARSE_OK ? "pass" : "fail"}>
              <Led on={TIMELINE_PARSE_OK} /> timeline {TIMELINE_STATS.scenes} scenes · {TIMELINE_STATS.elements} el
            </Chip>
            <Chip>stack · canvas2d + webaudio</Chip>
            <Chip tone="blocked">gate 4k · closed</Chip>
            <Chip tone="orange">
              <span className="beat inline-block h-[6px] w-[6px] rounded-full bg-orange-400" /> 120 bpm
            </Chip>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="mono hidden text-[10px] uppercase tracking-[0.16em] text-white/35 md:block">space = play · ←/→ = frame</span>
            <button className="btn !px-3 !py-1.5" onClick={p.toggle}>
              {p.playing ? "pause" : "play 60 s"}
            </button>
          </div>
        </div>
      </header>

      <main className="relative z-10 mx-auto max-w-[1680px] px-4 pb-24">
        {/* ---------------------------------------------------------- masthead */}
        <section className="grid gap-8 border-b border-white/10 py-10 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)] lg:py-14">
          <div>
            <div className="mono flex items-center gap-2 text-[10px] uppercase tracking-[0.24em] text-orange-300/85">
              <span className="flicker inline-block h-px w-8 bg-orange-400/70" />
              cinematic motion graphics · deutsch · r-out-01
              <span className="ml-1 inline-block h-px w-3 bg-blue-400/70" />
            </div>
            <h1 className="mt-4 font-display leading-[0.82] tracking-[-0.045em]">
              <span className="block text-[clamp(58px,11vw,148px)] font-bold text-white tabular">60.000</span>
              <span className="block text-[clamp(20px,3.2vw,42px)] font-medium text-white/55">Sekunden, berechnet aus einer YAML-Datei.</span>
            </h1>
            <p className="mt-5 max-w-2xl text-[14.5px] leading-relaxed text-white/60">
              Acht interaktive Webgames, eine Adresse, ein Veröffentlichungsdatum. Jeder Frame ist eine reine Funktion der Zeit —
              Partikeltunnel, Chrom-Münzen, Tiefsee-Zähler, Asteroideneinschlag, Herzschlag-Statistik, Sternensphäre und ein
              Finale aus 3.000 Partikeln, das sich zu <span className="text-white">BALD VERFÜGBAR</span> formt.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-2">
              <button className="btn btn-solid !px-5 !py-3" onClick={p.toggle}>
                {p.playing ? "◼ stoppe playback" : "▶ spiele den film"}
              </button>
              <button className="btn !px-4 !py-3" onClick={() => p.seek(44.0)}>
                zum finale · 44.0 s
              </button>
              <Toggle on={showBoxes} onChange={setShowBoxes} label="text bboxes" />
              <Toggle on={showSafe} onChange={setShowSafe} label="safe area" color="orange" />
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <div className="panel-flat p-4">
              <div className="label mb-3">slate</div>
              <div className="flex flex-col">
                {FACTS.map(([k, v]) => (
                  <div key={k} className="flex items-baseline justify-between gap-3 border-b border-white/[0.06] py-2 last:border-0">
                    <span className="mono text-[10px] uppercase tracking-[0.18em] text-white/40">{k}</span>
                    <span className="mono text-right text-[12px] text-white/90 tabular">{v}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="panel-flat flex items-center gap-3 p-4">
              <div className="relative h-14 w-14 shrink-0">
                <div className="spin-slow absolute inset-0 rounded-full border border-dashed border-blue-400/40" />
                <div className="absolute inset-[14px] rounded-full" style={{ background: "radial-gradient(circle at 35% 32%,#fff,#3b82f6 42%,#f97316 100%)", boxShadow: "0 0 26px rgba(249,115,22,.55)" }} />
              </div>
              <div>
                <div className="font-display text-[17px] font-bold leading-tight text-white">Hero-Sphäre, 32.0–44.0 s</div>
                <p className="mono mt-1 text-[10px] uppercase leading-relaxed tracking-[0.12em] text-white/40">
                  r=200 · puls ±3 % @0.5 Hz · 8 sprites auf 420/560 px · push-in 1.00→1.15
                </p>
              </div>
            </div>
            <div className="panel-flat p-4">
              <div className="label mb-2">parser</div>
              <p className="mono text-[10.5px] leading-relaxed tracking-[0.04em] text-white/45">
                timeline.yaml wird im Browser importiert und geparst (src/ad/yaml.ts): meta.fps {META.fps} · frames {META.frames} ·{" "}
                {TIMELINE_STATS.elements} Elemente · {TIMELINE_STATS.textEntries} Text-Einträge · {TIMELINE_STATS.sfx} SFX ·{" "}
                {TIMELINE_STATS.vo} VO · {TIMELINE_STATS.holds} hold-Fenster. Status:{" "}
                <span className={TIMELINE_PARSE_OK ? "text-blue-300" : "text-orange-300"}>{TIMELINE_PARSE_OK ? "OK" : "PARSE FAILED"}</span>
              </p>
            </div>
          </div>
        </section>

        {/* ----------------------------------------------------------- console */}
        <section className="mt-6 grid gap-4 xl:grid-cols-[minmax(0,1fr)_430px]">
          <div className="flex min-w-0 flex-col gap-3">
            <Reveal>
              <Stage p={p} showSafe={showSafe} showBoxes={showBoxes} />
            </Reveal>
            <Reveal delay={80}>
              <Transport p={p} />
            </Reveal>
            <div className="mono flex flex-wrap items-center gap-x-4 gap-y-1 px-1 text-[10px] uppercase tracking-[0.14em] text-white/30">
              <span>r-txt-01 · {R_TXT.length} strings, zeichenexakt</span>
              <span>r-vis-06 · cap 3000 partikel</span>
              <span>r-vis-07 · grain 3.5 %</span>
              <span>r-vis-08 · vignette 25 %</span>
              <span className="text-white/45">t = frame / {FPS}</span>
            </div>
          </div>
          <Reveal delay={120}>
            <Panels p={p} />
          </Reveal>
        </section>

        {/* ---------------------------------------------------------- dossier */}
        <Dossier t={p.t} onSeek={p.seek} />
      </main>

      <footer className="relative z-10 border-t border-white/10 bg-black/40">
        <div className="mx-auto flex max-w-[1680px] flex-wrap items-center justify-between gap-4 px-4 py-8">
          <div>
            <Wordmark text="nealarp.vercel.app" className="text-[clamp(20px,3vw,34px)] leading-none" />
            <p className="mono mt-2 text-[10px] uppercase tracking-[0.2em] text-white/40">erhältlich ab 12. oktober 2026</p>
          </div>
          <div className="mono max-w-md text-[10px] uppercase leading-relaxed tracking-[0.12em] text-white/30">
            60.000 s · 3600 frames · H.264 High / yuv420p · AAC 48 kHz stereo · −14 LUFS · −1 dBTP. Gebaut als Code: TypeScript,
            Canvas 2D, Web Audio. Kein KI-Video, keine lizenzierten Samples, kein Stock.
          </div>
        </div>
      </footer>
    </div>
  );
}
