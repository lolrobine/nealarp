# nealarp-ad

A 60.000-second cinematic motion-graphics advertisement in German for **nealarp** — a site with
eight interactive web games, available from **12 October 2026**.

Everything is rendered from code. `timeline.yaml` is the single source of truth and
`src/compose.py::Composer.frame(t)` is a **pure function of time**: no frame depends on the
previous one, so frames can be rendered in any order, in parallel, or twice with byte-identical
results.

```
nealarp-ad/
  README.md          this file
  timeline.yaml      every scene, element, text line, sfx/vo event and hold window
  checklist.md       status of every requirement ID
  Makefile           the documented commands
  requirements.txt   default stack (R-STACK-02)
  src/
    config.py        palette, fonts, seeds, presets, exact string list (R-TXT-01)
    easing.py        EASE_IO / EASE_OUT_EARLY / EXPO_OUT / STEP (R-VIS-10)
    text.py          font loading, layout templates, auto-fit, layout log (R-TXT, R-STACK-05/06)
    layers.py        haze, grain, bloom, vignette, glass, streaks, flare, projection (R-VIS)
    sprites.py       cached coins, lock, creatures, heart, icons, scale stages (R-PERF-03)
    particles.py     closed-form tunnel, explosion, reform, bubbles, dive, drift (R-VIS-06/09)
    timeline.py      loader, model and validation
    scenes.py        one painter per element type (R-SCN-01..11)
    compose.py       frame(t) -> uint8 RGB
    render.py        CLI: encode, mux, perf report, 4K gate
    audio.py         music + all 12 sfx recipes, synthesised (R-AUD-02/03)
    vo.py            German voiceover providers + placeholder path (R-AUD-01)
    mix.py           ducking, summing, two-pass loudnorm (R-AUD-04)
    verify.py        R-VER-01..14
  audio/vo/          voiceover clips            (git-ignored media)
  audio/render/      music/sfx/premix/master    (git-ignored, R-REPO-03)
  reference/         inspiration description    (R-REF-01/02)
  tests/             pytest: timeline, easing, text, frames, media, reproducibility
  out/               MP4 outputs + reports      (git-ignored, R-REPO-03)
```

---

## Step 0 — host reachability (R-STACK-01)

**Status: BLOCKED in the authoring environment** — it provides no shell, so no probe could be run.
Run this on the render machine and paste the result into the table:

```bash
make host-check
```

| Host | Result |
|---|---|
| `https://pypi.org/simple/` | _not measured_ |
| `https://files.pythonhosted.org/` | _not measured_ |
| `https://registry.npmjs.org/` | _not measured_ |

**Stack decision (R-STACK-03): the default Python stack.** Remotion requires npm *and* a headless
browser to be confirmed reachable; neither could be confirmed here, so React/Remotion was not used.
The renderer has a single code path, therefore no stack switch is possible after the first frame.

## Step 1 — install

```bash
cd nealarp-ad
make setup          # python3.11 -m venv .venv && pip install -r requirements.txt
```

Requirements: numpy, Pillow, opencv-python-headless, imageio-ffmpeg (provides ffmpeg), PyYAML,
pytest. No GPU-only libraries (R-STACK-04); the budget is 2 CPU cores / ~3 GB RAM, so glass
backdrops are blurred at 1/4 scale, sprites are cached, and particles are capped at 3000.

## Step 2 — font coverage record (R-STACK-06 / R-VER-14)

```bash
make fonts          # python -m src.text
```

Expected output: a JSON report with `"pass": true` and, for both fonts, `true` for every character
of `Ä ä Ö ö Ü ü ß . , % m`. **Status: BLOCKED here** (no shell); paste the actual output below.

| Font | Path | Ä ä Ö ö Ü ü ß | . , % m | Result |
|---|---|---|---|---|
| titles | `/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf` | _not measured_ | _not measured_ | _not measured_ |
| code glyphs | `/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf` | _not measured_ | _not measured_ | _not measured_ |

Fonts are loaded by absolute path only (`src/config.py::FONT_BOLD` / `FONT_MONO`); no system
default is ever requested.

## Step 3 — audio

```bash
make vo             # German voiceover  (espeak-ng => PLACEHOLDER, 1080p test only)
make audio          # music bed + sfx bed + manifests
make mix            # duck, sum, two-pass loudnorm -> audio/render/mix.m4a
```

Voiceover providers (`python -m src.vo --provider …`): `azure`, `elevenlabs`, `google`, `polly`
(real German neural voices) or `espeak` (placeholder). Each line is normalised to −18 dBFS RMS,
lines keep at least 0.5 s between them, and a line that would overlap pushes the **next** line
later — delivery is never sped up. The chosen provider name is written to
`audio/render/vo_provider.txt`, which the 4K gate reads.

Music is 120 BPM, 60.000 s, synthesised in code (8 detuned sines through a 2 kHz lowpass,
bass drop, risers, harmonic warming toward 32 s, swell to the 44.0 s crescendo, bass hit with a
0.25 s / 0.3-feedback echo). The music bus is ducked −6 dB while voiceover plays. The master is
normalised with two-pass `loudnorm` to −14 LUFS / −1 dBTP.

## Render — the documented command (R-OUT-06)

One command chain, one source (`src/compose.py`), two outputs:

```bash
python -m src.render --preset test && python -m src.render --preset final --i-approve-4k
```

| Preset | Output | Size |
|---|---|---|
| `test` | `out/nealarp-ad-1080p-test.mp4` | 1920×1080, 60 fps |
| `final` | `out/nealarp-ad-2160p60-final.mp4` | 3840×2160 (2× reference scale), 60 fps |

Both are H.264 High, `yuv420p`, 16:9, 60.000 s / 3600 frames, with AAC 48 kHz stereo audio
muxed from `audio/render/mix.m4a`.

```bash
make test-render    # vo + audio + mix + 1080p encode
make verify         # R-VER-01..14 + pytest
make md5            # R-VER-13 reproducibility
make final-render   # gated 4K master
```

Useful flags: `--no-audio` (video-only scratch pass), `--frames 0,900,1800` (spot frames),
`--md5` (reproducibility only), `--force-4k` (override the R-PERF-05 time guard).

## Gates

* **R-GATE-01** — work stops after the 1080p test render and its verification report.
* **R-GATE-02** — `--preset final` exits unless `--i-approve-4k` is passed explicitly.
* **R-GATE-03** — `--preset final` also exits unless `audio/render/vo_provider.txt` names a real
  neural provider; an `espeak`/PLACEHOLDER voiceover blocks the 4K master.
* **R-GATE-04** — there is no upscale code path. `--preset final` renders natively at 3840×2160.
* **R-PERF-05** — if the 4K estimate (4 × the measured 1080p average) exceeds 6 hours, the final
  render refuses to start and prints the options: lower particle counts, pre-render sprite sheets,
  or schedule a longer window and pass `--force-4k`.

## Verification

```bash
python -m src.verify --preset test      # writes out/verification-report.json
python -m pytest -q
```

| Check | What it proves |
|---|---|
| R-VER-01 | 3600 frames, duration 60.000 ± 0.02 s |
| R-VER-02 | 1920×1080 (test) / 3840×2160 (final) at exactly 60 fps |
| R-VER-03 | H.264 High, `yuv420p` |
| R-VER-04 | AAC, 48000 Hz, stereo |
| R-VER-05 | integrated −14 LUFS ±1, true peak ≤ −1 dBTP (`ebur128`) |
| R-VER-06 | palette: ≤1 % of saturated bright pixels outside blue 195–235° / orange 15–35° |
| R-VER-07 | darkest corner decile within ±6 of `#0a0a0a` per channel |
| R-VER-08 | every text box inside the 96/54 safe area (from `out/layout_log.json`) |
| R-VER-09 | layout log vs. the R-TXT-01 string list (+ OCR when tesseract is installed) |
| R-VER-10 | motion outside declared `hold_frames`, stillness inside them |
| R-VER-11 | every sfx/vo starts within ±0.05 s of its declared time; no VO overlap |
| R-VER-12 | audio below −70 dBFS in the final second; nothing exists beyond 60.000 s |
| R-VER-13 | frames 0/900/1800/3000/3599 rendered twice are byte-identical (MD5) |
| R-VER-14 | DejaVu covers `Ä ä Ö ö Ü ü ß . , % m` |

The frame-level parts of R-VER-06/07/10/13 also run **without ffmpeg** through
`tests/test_compose.py` and `tests/test_reproducibility.py` at quarter scale.

## Design notes and deviations

1. **Palette-safe gradients.** A raw RGB lerp from `#3b82f6` to `#f97316` passes through hues
   near 10° and 340° at ~40 % saturation, which would violate R-VIS-02 / R-NEG-01 and fail
   R-VER-06. `layers.linear_gradient` and `sprites.radial_core` therefore lift the crossover
   through white (`mid_lift = 0.45`). Both endpoints stay exactly the specified colours, and
   R-PRI-2 puts the palette above the interpolation detail of R-VIS-03. Covered by
   `tests/test_text_layout.py::test_gradient_stays_inside_the_palette`.
2. **Numeric readouts.** R-SCN-04 requires the depth counter to count up between its anchors and
   R-SCN-08 requires three life-statistic counters, so interpolated numbers ("3.412 m", "1.204.880")
   exist between the declared strings. They are rendered through the same text layout system and
   logged with `dynamic: true`; R-VER-09 checks the 23 declared strings against static entries.
   No other text exists on screen (R-NEG-03).
3. **Extra text templates.** `score_orange`, `panel_label` and `panel_number` were added for
   R-SCN-06/08 (98 %, the three panel labels, the counter digits). They reuse the same
   measurement, auto-fit and logging path as the seven templates in the spec.
4. **Speedometer angle mapping.** "210° to −30°" is specified in the mathematical convention
   (y up); Pillow measures clockwise from 3 o'clock with y down, so the arc is drawn 150°→390°,
   which is the same visual sweep over the top of the dial.
5. **`globals:` block.** Ambient and post layers (haze, grain, bloom, vignette, fade-out) carry
   explicit start/end times in a top-level `globals:` list so that R-TIME-04 holds for them too.
6. **Hold windows.** `hold_frames` lists exactly the windows with no intended motion; the film
   grain keeps a per-frame random offset (R-VIS-07), so R-VER-10 compares a grain-suppressed
   structural difference as well as the raw one.

## Performance (R-PERF-04)

`src/render.py` writes `out/perf-report.json` with the measured average seconds per frame, the
total, and the 4K estimate (4 × the 1080p average). **Not measured yet — blocked on execution.**

| Metric | Value |
|---|---|
| 1080p average per frame | _not measured_ |
| 1080p total | _not measured_ |
| 4K estimate (4×) | _not measured_ |
