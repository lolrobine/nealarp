"""Frame-level checks that run without ffmpeg: purity, palette, background, motion."""

import numpy as np
import pytest

from src import config as C
from src.compose import Composer
from src.verify import _rgb_to_hsv

TIMES = [0.5, 2.5, 5.0, 7.9, 9.0, 12.5, 15.2, 18.0, 21.7, 24.0, 27.0,
         30.5, 33.0, 38.0, 43.9, 45.0, 47.5, 51.0, 54.0, 57.0, 59.5]


@pytest.fixture(scope="module")
def frames(composer):
    return {t: composer.frame(t, int(round(t * C.FPS))) for t in TIMES}


def _corner_decile_delta(rgb: np.ndarray) -> float:
    ch, cw = rgb.shape[0] // 8, rgb.shape[1] // 8
    corners = np.concatenate([rgb[:ch, :cw].reshape(-1, 3), rgb[:ch, -cw:].reshape(-1, 3),
                              rgb[-ch:, :cw].reshape(-1, 3), rgb[-ch:, -cw:].reshape(-1, 3)])
    luma = corners.astype(np.float32).sum(axis=1)
    dark = corners[luma <= np.percentile(luma, 10)]
    return float(np.abs(dark.astype(np.float32).mean(axis=0) - np.array(C.BLACK, np.float32)).max())


def test_frame_shape_is_exact_and_unpadded(frames, composer):
    """R-NEG-06: the frame is exactly the preset size — no letterbox, no bars."""
    want = (int(round(C.REF_H * composer.scale)), int(round(C.REF_W * composer.scale)), 3)
    for t, arr in frames.items():
        assert arr.shape == want, t
        assert arr.dtype == np.uint8


def test_every_frame_has_content(frames):
    for t, arr in frames.items():
        assert arr.max() > 40, f"frame at t={t} is empty"


def test_palette_r_ver_06_offline(frames):
    """R-VER-06 / R-NEG-01: <=1% of saturated bright pixels outside blue/orange."""
    worst = 0.0
    offenders = {}
    for t, arr in frames.items():
        hsv = _rgb_to_hsv(arr)
        sel = (hsv[..., 1] > C.SAT_FLOOR) & (hsv[..., 2] > C.VAL_FLOOR)
        h = hsv[..., 0][sel]
        if h.size == 0:
            continue
        ok = (((h >= C.HUE_BLUE[0]) & (h <= C.HUE_BLUE[1])) |
              ((h >= C.HUE_ORANGE[0]) & (h <= C.HUE_ORANGE[1])) | (h >= 355.0))
        ratio = float((~ok).mean())
        if ratio > worst:
            worst = ratio
        if ratio > C.PALETTE_TOLERANCE:
            offenders[t] = (round(ratio * 100, 4), np.unique(np.round(h[~ok])).tolist()[:8])
    assert not offenders, f"palette violations: {offenders} (worst {worst*100:.4f}%)"


def test_background_r_ver_07_offline(frames):
    """R-VER-07: darkest decile of the four corners within 6/255 of #0a0a0a."""
    bad = {t: round(_corner_decile_delta(arr), 2) for t, arr in frames.items()
           if _corner_decile_delta(arr) > 6.0}
    assert not bad, f"corners drifted from #0a0a0a: {bad}"


def test_haze_is_present(frames):
    """R-VIS-01: the centre must be lifted above the corners by the 40% haze."""
    arr = frames[2.5].astype(np.float32)
    h, w = arr.shape[:2]
    centre = arr[h // 2 - 8:h // 2 + 8, w // 2 - 8:w // 2 + 8].mean()
    corner = arr[:8, :8].mean()
    assert centre > corner


def test_render_is_a_pure_function_of_time(tl, fonts_available):
    """R-OUT-02 / R-VER-13: two independent composers produce identical bytes."""
    if not fonts_available:
        pytest.skip("DejaVu fonts not installed")
    a = Composer(tl, scale=0.25)
    b = Composer(tl, scale=0.25)
    for t in (0.0, 2.5, 9.75, 15.2, 21.7, 27.0, 33.0, 45.0, 51.0, 59.9):
        idx = int(round(t * C.FPS))
        assert np.array_equal(a.frame(t, idx), b.frame(t, idx)), f"t={t}"


def test_same_composer_is_repeatable(composer):
    """Sprite/font caches must not leak state between calls."""
    t = 15.2
    idx = int(round(t * C.FPS))
    first = composer.frame(t, idx)
    composer.frame(40.0, 2400)
    assert np.array_equal(first, composer.frame(t, idx))


def test_motion_outside_holds(composer, tl):
    """R-VER-10: consecutive frames differ wherever motion is not declared off."""
    holds = tl.holds()
    still = []
    for idx in range(0, C.TOTAL_FRAMES, 211):
        t0 = idx / C.FPS
        if any(a <= t0 < b for a, b in holds):
            continue
        f0 = composer.frame(t0, idx).astype(np.int16)
        f1 = composer.frame((idx + 1) / C.FPS, idx + 1).astype(np.int16)
        if float(np.abs(f1 - f0).mean()) <= 0.0:
            still.append(round(t0, 4))
    assert not still, f"no motion at {still}"


def test_frames_inside_holds_are_still(composer, tl):
    """Structural stillness inside a declared hold (grain aside)."""
    holds = [h for h in tl.holds() if h[1] - h[0] > 0.6]
    if not holds:
        pytest.skip("no hold window long enough to sample")
    a, b = holds[0]
    mid = (a + b) / 2
    # box-downsample first: film grain (R-VIS-07) keeps every frame unique by design, so the
    # hold is checked on structure, exactly like R-VER-10 does on the rendered file.
    f0 = _thumb_of(composer.frame(mid, int(mid * C.FPS)))
    f1 = _thumb_of(composer.frame(mid + 0.1, int((mid + 0.1) * C.FPS)))
    assert float(np.abs(f1 - f0).mean()) < 1.0


def _thumb_of(arr):
    from PIL import Image

    h, w = arr.shape[:2]
    return np.asarray(Image.fromarray(arr).resize((max(1, w // 8), max(1, h // 8)), Image.BOX),
                      dtype=np.float32)


def test_last_frame_fades_to_black(composer):
    """R-SCN-11: 59.0-60.0 fades out."""
    arr = composer.frame(3599 / C.FPS, 3599).astype(np.float32)
    assert arr.mean() < 20.0


def test_grain_is_frame_dependent_but_seeded(composer):
    """R-VIS-07: same frame index -> same grain; different index -> different grain."""
    a = composer.frame(30.0, 1800)
    b = composer.frame(30.0, 1800)
    c = composer.frame(30.0 + 1 / C.FPS, 1801)
    assert np.array_equal(a, b)
    assert not np.array_equal(a, c)


def test_particle_cap(composer):
    """R-VIS-06: no frame may exceed the particle budget."""
    from src import particles

    assert particles.cap(99999, composer.scale) <= C.MAX_PARTICLES_1080P
