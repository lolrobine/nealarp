"""R-TXT-01/02/03, R-STACK-05/06, R-VER-08 — all offline, no render needed."""

from pathlib import Path

import pytest

from src import config as C
from src.text import LAYOUTS, TextSystem, check_font_coverage
from src.timeline import load


pytestmark = pytest.mark.usefixtures()


def fonts_or_skip():
    if not (Path(C.FONT_BOLD).exists() and Path(C.FONT_MONO).exists()):
        pytest.skip(f"DejaVu fonts not installed at {C.FONT_BOLD}")


def test_font_paths_are_explicit_and_absolute():
    """R-STACK-05: never a system default."""
    assert C.FONT_BOLD.startswith("/") and C.FONT_BOLD.endswith("DejaVuSans-Bold.ttf")
    assert C.FONT_MONO.startswith("/") and C.FONT_MONO.endswith("DejaVuSansMono.ttf")
    for name, tpl in LAYOUTS.items():
        assert tpl["font"] in {C.FONT_BOLD, C.FONT_MONO}, name


def test_font_coverage_r_stack_06():
    """R-STACK-06 / R-VER-14: Ä ä Ö ö Ü ü ß and . , % m must exist."""
    fonts_or_skip()
    rep = check_font_coverage()
    missing = {k: [c for c, ok in v["chars"].items() if not ok] for k, v in rep["fonts"].items()}
    assert rep["pass"], f"missing glyphs: {missing}"
    for ch in "ÄäÖöÜüß.,%m":
        assert rep["fonts"]["bold"]["chars"][ch], f"bold font lacks {ch!r}"


def test_layout_templates_match_spec():
    assert LAYOUTS["title_opening"]["size"] == 180
    assert LAYOUTS["title_opening"]["at"] == (960, 540)
    assert LAYOUTS["title_lower_third"]["size"] == 96
    assert LAYOUTS["title_lower_third"]["y_mode"] == "baseline"
    assert LAYOUTS["title_lower_third"]["at"] == (960, 880)
    assert LAYOUTS["title_lower_third"]["panel"] == {"pad_x": 48, "pad_y": 28, "radius": 24}
    assert LAYOUTS["counter_center"]["size"] == 160 and LAYOUTS["counter_center"]["at"] == (960, 520)
    assert LAYOUTS["claim_white"]["size"] == 112
    assert LAYOUTS["claim_gradient"]["size"] == 96
    assert LAYOUTS["url"]["size"] == 72 and LAYOUTS["url"]["at"] == (960, 600)
    assert LAYOUTS["cta_button_label"]["size"] == 44 and LAYOUTS["cta_button_label"]["at"] == (960, 780)
    for name in ("title_opening", "title_lower_third"):
        assert LAYOUTS[name]["tracking"] == pytest.approx(0.04)
        assert LAYOUTS[name]["case"] == "upper"


def test_autofit_shrinks_and_logs():
    """R-TXT-03: >1440 px -> steps of 4 px down to a 64 px floor, every change logged."""
    fonts_or_skip()
    ts = TextSystem(scale=1.0)
    long_entry = {"id": "fit", "string": "SPIELE UND ZEUG", "layout": "title_opening",
                  "start": 2.0, "end": 8.0, "ease": "EASE_IO", "props": {}}
    m = ts.metrics(long_entry)
    assert m.size_ref < 180, "expected auto-fit to kick in at 180 px"
    assert m.size_ref >= C.AUTOFIT_MIN_SIZE
    assert (180 - m.size_ref) % C.AUTOFIT_STEP == 0
    assert m.width_ref <= C.AUTOFIT_MAX_WIDTH + 1e-6
    assert any(e["id"] == "fit" for e in ts.autofit_log)

    short_entry = {"id": "nofit", "string": "TEMPO", "layout": "title_lower_third",
                   "start": 0.0, "end": 1.0, "ease": "EASE_IO", "props": {}}
    assert ts.metrics(short_entry).size_ref == 96


def test_autofit_floor_is_64():
    fonts_or_skip()
    ts = TextSystem(scale=1.0)
    entry = {"id": "huge", "string": "X" * 120, "layout": "title_opening",
             "start": 0.0, "end": 1.0, "ease": "EASE_IO", "props": {}}
    assert ts.metrics(entry).size_ref == C.AUTOFIT_MIN_SIZE


def test_every_declared_string_fits_the_safe_area():
    """R-VER-08 offline: every text box inside 96 px left/right, 54 px top/bottom."""
    fonts_or_skip()
    ts = TextSystem(scale=1.0)
    tl = load()
    offenders = []
    for scene in tl.scenes:
        for entry in scene.text:
            m = ts.metrics(entry)
            x, y, w, h = m.ink_ref
            if not (x >= C.SAFE_X and y >= C.SAFE_Y
                    and x + w <= C.REF_W - C.SAFE_X and y + h <= C.REF_H - C.SAFE_Y):
                offenders.append((entry.id, entry.string, [round(v, 1) for v in (x, y, x + w, y + h)]))
    assert not offenders, f"outside safe area: {offenders}"


def test_strings_are_rendered_verbatim():
    """R-TXT-01: no re-casing beyond the template rule, no character changes."""
    fonts_or_skip()
    ts = TextSystem(scale=1.0)
    tl = load()
    for scene in tl.scenes:
        for entry in scene.text:
            m = ts.metrics(entry)
            expected = entry.string.upper() if LAYOUTS[entry.layout]["case"] == "upper" else entry.string
            assert m.string == expected, f"{entry.id}: {m.string!r} != {expected!r}"


def test_layout_log_records_every_entry(tmp_path):
    fonts_or_skip()
    ts = TextSystem(scale=1.0)
    tl = load()
    for scene in tl.scenes:
        for entry in scene.text:
            ts.metrics(entry)
            ts._record(entry, ts.metrics(entry), entry.start)
    out = ts.save_log(tmp_path / "layout_log.json")
    import json

    log = json.loads(out.read_text(encoding="utf-8"))
    assert log["reference"] == [1920, 1080]
    assert log["safe_area"] == {"x": 96, "y": 54}
    assert all(e["safe_area_ok"] for e in log["entries"])


def test_gradient_endpoints_are_exact():
    """R-VIS-03 with the R-NEG-01 hue guard: ramp starts blue and ends orange."""
    from src import layers

    g = layers.linear_gradient((256, 2), C.BLUE, C.ORANGE, axis="x")
    assert tuple(g[0, 0]) == C.BLUE
    assert tuple(g[0, -1]) == C.ORANGE


def test_gradient_stays_inside_the_palette():
    """No pixel of the title gradient may carry a forbidden hue (R-VER-06 offline)."""
    from src import layers
    from src.verify import _rgb_to_hsv

    g = layers.linear_gradient((1024, 1), C.BLUE, C.ORANGE, axis="x")
    hsv = _rgb_to_hsv(g.astype("uint8"))
    sel = (hsv[..., 1] > C.SAT_FLOOR) & (hsv[..., 2] > C.VAL_FLOOR)
    h = hsv[..., 0][sel]
    ok = (((h >= C.HUE_BLUE[0]) & (h <= C.HUE_BLUE[1])) |
          ((h >= C.HUE_ORANGE[0]) & (h <= C.HUE_ORANGE[1])))
    assert ok.all(), f"{(~ok).sum()} gradient pixels outside blue/orange"
