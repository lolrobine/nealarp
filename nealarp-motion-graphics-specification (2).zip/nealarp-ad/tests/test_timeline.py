"""timeline.yaml is the contract: these tests run without any render or media tooling."""

from pathlib import Path

import pytest

from src import config as C
from src.compose import POST_TYPES
from src.scenes import PAINTERS
from src.timeline import MIN_VO_GAP, vo_duration


def test_validation_passes(tl):
    assert tl.validate() == []


def test_meta_matches_spec(tl):
    assert tl.meta["fps"] == C.FPS
    assert abs(tl.meta["duration"] - C.DURATION) < 1e-9
    assert tl.meta["total_frames"] == C.TOTAL_FRAMES
    assert tl.meta["seed"] == C.SEED
    assert tl.meta["available_from"] == "2026-10-12"


def test_acts_tile_the_60_seconds(tl):
    """R-TIME-02: opening 0-8, showcase 8-32 (8 x 3.0 s), hero 32-44, CTA 44-60."""
    ordered = sorted(tl.scenes, key=lambda s: s.start)
    assert ordered[0].scene == "opening" and ordered[0].start == 0.0
    assert ordered[-1].scene == "cta" and ordered[-1].end == 60.0
    cursor = 0.0
    for s in ordered:
        assert s.start == pytest.approx(cursor), f"gap before {s.scene}"
        cursor = s.end
    cuts = [s for s in ordered if s.scene.startswith("game_")]
    assert len(cuts) == 8
    assert all(abs((s.end - s.start) - 3.0) < 1e-9 for s in cuts)
    assert cuts[0].start == 8.0 and cuts[-1].end == 32.0
    hero = next(s for s in ordered if s.scene == "hero")
    assert (hero.start, hero.end) == (32.0, 44.0)
    cta = next(s for s in ordered if s.scene == "cta")
    assert (cta.start, cta.end) == (44.0, 60.0)


def test_every_element_has_a_painter(tl):
    """R-TIME-04: nothing may appear without a declared, implemented painter."""
    unknown = set()
    for s in tl.scenes:
        for e in s.elements:
            if e.type not in PAINTERS and e.type not in POST_TYPES:
                unknown.add(e.type)
    for g in tl.globals:
        if g.type not in PAINTERS and g.type not in POST_TYPES:
            unknown.add(g.type)
    assert not unknown, f"element types without painters: {sorted(unknown)}"


def test_every_element_has_time_and_geometry(tl):
    for s in tl.scenes:
        for e in s.elements:
            assert e.start < e.end, f"{s.scene}/{e.id}"
            assert s.start - 1e-9 <= e.start and e.end <= s.end + 1e-9
            assert e.rect is not None or e.center is not None, f"{s.scene}/{e.id}"
            assert e.ease in {"EASE_IO", "EASE_OUT_EARLY", "EXPO_OUT", "STEP"}


def test_on_screen_strings_are_exactly_r_txt_01(tl):
    declared = [t.string for s in tl.scenes for t in s.text]
    assert set(declared) == set(C.TEXT_STRINGS)
    assert len(C.TEXT_STRINGS) == 23
    for s in C.TEXT_STRINGS:
        assert s in declared, f"missing {s!r}"


def test_no_undeclared_static_text(tl):
    """Only counter/number readouts may be dynamic; every static string is declared."""
    for s in tl.scenes:
        for t in s.text:
            assert t.string in C.TEXT_STRINGS


def test_hold_frames_inside_their_scene(tl):
    for s in tl.scenes:
        for a, b in s.hold_frames:
            assert s.start <= a < b <= s.end


def test_voiceover_script_and_gaps(tl):
    """R-AUD-01: exact lines, >= 0.5 s apart, never overlapping, never sped up."""
    expected = [
        (0.5, "Alles, was du jemals im Internet machen wolltest … an einem Ort."),
        (9.0, "Gib eine Billion Dollar aus."),
        (11.5, "Brich jede Passwortregel."),
        (14.5, "Tauche 11.000 Meter tief in die Tiefsee."),
        (20.5, "Schleudere Asteroiden. Zeichne perfekte Kreise."),
        (26.0, "Entdecke deine Lebensstatistik."),
        (32.5, "Acht Spiele. Keine Downloads. Eine Adresse."),
        (44.8, "Ab dem 12. Oktober erhältlich auf nealarp.vercel.app."),
    ]
    lines = sorted(tl.vo_lines, key=lambda v: float(v["at"]))
    assert [(float(a), s) for a, s in lines] == expected

    vo = tl.vo_events()
    for a, b in zip(vo, vo[1:]):
        assert b["at"] - a["at"] >= MIN_VO_GAP - 1e-9
        assert a["at"] + a["est_duration"] <= b["at"] + 1e-9, f"{a['id']} would overlap {b['id']}"
    assert vo[-1]["at"] + vo[-1]["est_duration"] <= C.DURATION
    assert vo_duration("x" * 135) == pytest.approx(10.0, abs=0.01)


def test_cut_4_has_no_voiceover(tl):
    """R-SCN-05: TEMPO has no VO line."""
    tempo = next(s for s in tl.scenes if s.scene == "game_04_tempo")
    assert tempo.vo == []


def test_sfx_density_limit(tl):
    """R-AUD-03: never more than two effects at once."""
    events = tl.sfx_events()
    for a in events:
        dur = a.get("duration") or 0.4
        stack = [b for b in events if b["at"] < a["at"] + dur and b["at"] + (b.get("duration") or 0.4) > a["at"]]
        assert len(stack) <= 2, f"{len(stack)} effects overlap at {a['at']}"


def test_every_sfx_recipe_exists(tl):
    from src.audio import SFX

    for ev in tl.sfx_events():
        assert ev["id"] in SFX, f"unknown sfx recipe {ev['id']}"


def test_one_offscreen_flicker_per_act(tl):
    """R-VIS-05: four acts, four flickers."""
    flickers = [e for s in tl.scenes for e in s.elements if e.type == "offscreen_flicker"]
    assert len(flickers) == 4
    acts = {"opening": 0, "showcase": 0, "hero": 0, "cta": 0}
    for s in tl.scenes:
        for e in s.elements:
            if e.type == "offscreen_flicker":
                act = ("opening" if s.scene == "opening" else "hero" if s.scene == "hero"
                       else "cta" if s.scene == "cta" else "showcase")
                acts[act] += 1
    assert acts == {"opening": 1, "showcase": 1, "hero": 1, "cta": 1}


def test_globals_declare_post_layers(tl):
    kinds = {g.type for g in tl.globals}
    assert {"background_haze", "film_grain", "bloom", "vignette", "fade_out"} <= kinds
    for g in tl.globals:
        assert g.start >= 0.0 and g.end <= C.DURATION


def test_fade_out_is_the_last_second(tl):
    fades = [g for g in tl.globals if g.type == "fade_out"]
    assert len(fades) == 1
    assert (fades[0].start, fades[0].end) == (59.0, 60.0)


def test_reference_assets():
    """R-REF-01: either the image is kept, or the description file exists."""
    ref = Path(__file__).resolve().parents[1] / "reference"
    assert (ref / "inspiration-01.jpg").exists() or (ref / "README.md").exists()
