"""R-VIS-10: the four named easings, exactly."""

import math

import pytest

from src.easing import (BEZIER_CONTROL_POINTS, EASINGS, apply, expo_out, progress,
                        ease_io, ease_out_early, step)


def test_control_points_match_spec():
    assert BEZIER_CONTROL_POINTS["EASE_IO"] == (0.65, 0.00, 0.35, 1.00)
    assert BEZIER_CONTROL_POINTS["EASE_OUT_EARLY"] == (0.25, 0.80, 0.25, 1.00)


@pytest.mark.parametrize("name", sorted(EASINGS))
def test_endpoints(name):
    f = EASINGS[name]
    assert f(0.0) == pytest.approx(0.0, abs=1e-9)
    assert f(1.0) == pytest.approx(1.0, abs=1e-9)


@pytest.mark.parametrize("name", ["EASE_IO", "EASE_OUT_EARLY", "EXPO_OUT"])
def test_monotonic_and_bounded(name):
    f = EASINGS[name]
    prev = -1.0
    for i in range(101):
        p = i / 100.0
        v = f(p)
        assert -1e-9 <= v <= 1.0 + 1e-9
        assert v >= prev - 1e-9, f"{name} not monotonic at {p}"
        prev = v


def test_ease_io_is_symmetric():
    for p in (0.1, 0.25, 0.4, 0.5):
        assert ease_io(p) + ease_io(1 - p) == pytest.approx(1.0, abs=1e-6)
    assert ease_io(0.5) == pytest.approx(0.5, abs=1e-6)


def test_ease_out_early_peaks_early():
    """cubic-bezier(0.25, 0.80, 0.25, 1.00) is far ahead of linear at 25%."""
    assert ease_out_early(0.25) > 0.55
    assert ease_out_early(0.25) > ease_io(0.25)


def test_expo_out_formula():
    for p in (0.05, 0.2, 0.5, 0.9):
        assert expo_out(p) == pytest.approx(1.0 - 2.0 ** (-10.0 * p), abs=1e-12)
    assert expo_out(0.0) == 0.0
    assert expo_out(1.0) == 1.0
    assert expo_out(0.5) > 0.96


def test_step_holds_then_snaps():
    assert step(0.0) == 0.0
    assert step(0.999) == 0.0
    assert step(1.0) == 1.0
    assert step(2.0) == 1.0


def test_unknown_easing_raises():
    with pytest.raises(KeyError):
        apply("EASE_IN_OUT_BACK", 0.5)


def test_progress_clamps():
    assert progress(0.5, 1.0, 2.0) == 0.0
    assert progress(1.5, 1.0, 2.0) == pytest.approx(0.5)
    assert progress(9.0, 1.0, 2.0) == 1.0


def test_time_base_is_seconds_at_60fps():
    """R-TIME-01: t = frame / 60, so frame 3599 lands at 59.9833 s."""
    assert 3599 / 60 == pytest.approx(59.983333, abs=1e-5)
    assert progress(3599 / 60, 0.0, 60.0) < 1.0
    assert math.isclose(60.0 * 60, 3600)
