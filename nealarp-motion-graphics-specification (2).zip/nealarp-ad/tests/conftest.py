import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src import config as C          # noqa: E402
from src.timeline import load        # noqa: E402


@pytest.fixture(scope="session")
def tl():
    return load()


@pytest.fixture(scope="session")
def fonts_available() -> bool:
    return Path(C.FONT_BOLD).exists() and Path(C.FONT_MONO).exists()


@pytest.fixture(scope="session")
def composer(tl, fonts_available):
    """Quarter-scale composer: same code path as the masters, fast enough for tests."""
    if not fonts_available:
        pytest.skip(f"DejaVu fonts not installed ({C.FONT_BOLD})")
    from src.compose import Composer

    return Composer(tl, scale=0.25)


@pytest.fixture(scope="session")
def test_render() -> Path:
    return ROOT / C.PRESETS["test"]["out"]


@pytest.fixture(scope="session")
def final_render() -> Path:
    return ROOT / C.PRESETS["final"]["out"]
