"""R-VER-13: render the same frames twice, compare MD5 of the raw RGB bytes."""

import hashlib

import numpy as np
import pytest

from src import config as C
from src.compose import Composer
from src.timeline import load

INDICES = (0, 1800, 3599)          # full-run check uses 0, 900, 1800, 3000, 3599
SCALE = 0.25                       # quarter scale keeps the test under a few seconds


def md5_of(arr: np.ndarray) -> str:
    return hashlib.md5(np.ascontiguousarray(arr).tobytes()).hexdigest()


@pytest.mark.parametrize("idx", INDICES)
def test_frame_is_byte_identical_across_runs(idx, fonts_available):
    if not fonts_available:
        pytest.skip("DejaVu fonts not installed")
    t = idx / C.FPS
    a = md5_of(Composer(load(), scale=SCALE).frame(t, idx))
    b = md5_of(Composer(load(), scale=SCALE).frame(t, idx))
    assert a == b, f"frame {idx} differs between runs"


def test_render_md5_helper_reports_identical(fonts_available):
    if not fonts_available:
        pytest.skip("DejaVu fonts not installed")
    from src.render import md5_frames

    res = md5_frames(scale=SCALE, indices=INDICES)
    assert res["identical"], res


def test_seed_is_fixed():
    """R-VIS-06: the particle seed is the specified constant."""
    assert C.SEED == 7
    from src import config

    a = config.rng("particles").random(64)
    b = config.rng("particles").random(64)
    assert np.array_equal(a, b)
    assert not np.array_equal(a, config.rng("other-stream").random(64))
