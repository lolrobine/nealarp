"""R-VER-01..14 against the rendered masters. Skipped (BLOCKED) until a render exists."""

import json
import shutil
from pathlib import Path

import pytest

from src import config as C
from src.verify import (check_audio, check_codec, check_duration, check_loudness,
                        check_palette, check_resolution, check_silence, probe, scan_frames)


def need(path: Path):
    if not path.exists():
        pytest.skip(f"BLOCKED: {path} has not been rendered yet")


def test_probe_test_render(test_render):
    need(test_render)
    info = probe(test_render)
    assert info.get("vcodec") == "h264"


def test_r_ver_01_duration_and_frames(test_render, tl):
    need(test_render)
    scan = scan_frames(test_render, tl)
    res = check_duration(probe(test_render), scan.get("frames"))
    assert res["status"] == "PASS", res["detail"]


def test_r_ver_02_resolution(test_render):
    need(test_render)
    res = check_resolution(probe(test_render), "test")
    assert res["status"] == "PASS", res["detail"]


def test_r_ver_03_codec(test_render):
    need(test_render)
    res = check_codec(probe(test_render))
    assert res["status"] == "PASS", res["detail"]


def test_r_ver_04_audio(test_render):
    need(test_render)
    res = check_audio(probe(test_render))
    assert res["status"] == "PASS", res["detail"]


def test_r_ver_05_loudness(test_render):
    need(test_render)
    res = check_loudness(test_render)
    assert res["status"] == "PASS", res["detail"]


def test_r_ver_06_07_10_pixel_checks(test_render, tl):
    need(test_render)
    scan = scan_frames(test_render, tl)
    for res in (check_palette(scan),):
        assert res["status"] == "PASS", res["detail"]
    from src.verify import check_background, check_motion

    assert check_background(scan)["status"] == "PASS"
    assert check_motion(scan)["status"] == "PASS"


def test_r_ver_12_silence(test_render):
    need(test_render)
    res = check_silence(test_render)
    assert res["status"] == "PASS", res["detail"]


def test_r_ver_09_ocr_midpoints(test_render, tl):
    """Optional OCR pass: only runs when tesseract is installed (R-VER-09)."""
    need(test_render)
    if shutil.which("tesseract") is None:
        pytest.skip("OCR skipped: tesseract not installed (recorded per R-VER-09)")
    import subprocess

    import cv2

    log_path = Path(__file__).resolve().parents[1] / "out" / "layout_log.json"
    if not log_path.exists():
        pytest.skip("layout log missing")
    log = json.loads(log_path.read_text(encoding="utf-8"))
    cap = cv2.VideoCapture(str(test_render))
    mismatches = []
    for entry in log["entries"]:
        if entry.get("dynamic"):
            continue
        mid = (entry["start"] + entry["end"]) / 2
        cap.set(cv2.CAP_PROP_POS_MSEC, mid * 1000)
        ok, frame = cap.read()
        if not ok:
            continue
        tmp = Path("/tmp") / f"ocr_{entry['id']}.png"
        cv2.imwrite(str(tmp), frame)
        out = subprocess.run(["tesseract", str(tmp), "-", "-l", "deu"],
                             capture_output=True, text=True).stdout
        got = " ".join(out.split())
        want = " ".join(entry["string"].split())
        if got.upper() != want.upper():
            mismatches.append((entry["id"], want, got))
        tmp.unlink(missing_ok=True)
    cap.release()
    assert not mismatches, f"OCR mismatches: {mismatches}"


def test_r_ver_02_final_render(final_render):
    """R-OUT-04: only meaningful once the gated 4K master exists."""
    need(final_render)
    info = probe(final_render)
    res = check_resolution(info, "final")
    assert res["status"] == "PASS", res["detail"]
    assert (info["width"], info["height"]) == (3840, 2160)


def test_no_generated_media_is_tracked():
    """R-NEG-08 / R-REPO-03: .gitignore covers out/, audio/render/ and media types."""
    gi = (Path(__file__).resolve().parents[1] / ".gitignore").read_text(encoding="utf-8")
    for token in ("out/", "audio/render/", "*.mp4", "*.wav", "*.png"):
        assert token in gi
