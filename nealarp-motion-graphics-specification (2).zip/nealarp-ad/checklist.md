# nealarp-ad — Requirement Checklist

Status legend (per R-REPORT-1 / R-NEG-09):

- **PASS-IMPL** — requirement is satisfied by code/artefact that exists in this repo and can be
  verified by reading it. Evidence = file:line.
- **BLOCKED-EXEC** — requirement needs a shell (python/ffmpeg/espeak/pytest) to satisfy or to
  measure. **This authoring environment has no command execution**, so nothing was run, rendered,
  measured or faked. Evidence = the exact command to run + what it proves.
- **FAIL** — requirement not met. (None at time of writing.)

No MP4, WAV or PNG artefact exists in this repo, therefore every media-measuring requirement is
BLOCKED-EXEC by definition, not by choice.

## R-OUT — Deliverables

| ID | Status | Evidence |
|---|---|---|
| R-OUT-01 | PASS-IMPL | 60.000 s German ad fully specified in `timeline.yaml` (11 scenes, 8 game cuts, 12.10.2026 CTA). |
| R-OUT-02 | PASS-IMPL | `src/compose.py::render_frame(t, scale)` is a pure function of `t`; all motion derived from `timeline.yaml` via `src/timeline.py`. No frame-to-frame integration anywhere (`src/particles.py` is closed-form). |
| R-OUT-03 | BLOCKED-EXEC | `make test-render` → `python -m src.render --preset test`. Output path `out/nealarp-ad-1080p-test.mp4` is wired in `src/render.py::PRESETS`. |
| R-OUT-04 | BLOCKED-EXEC (and gated) | `make final-render` exists but `src/render.py` refuses `--preset final` unless `--i-approve-4k` is passed (R-GATE-02) **and** `audio/render/vo_provider.txt` says a neural provider (R-GATE-03). |
| R-OUT-05 | PASS-IMPL | `src/render.py::PRESETS` (H.264 High, yuv420p, 60 fps, 16:9) + `src/mix.py` (AAC 48 kHz stereo, two-pass loudnorm −14 LUFS, −1 dBTP). |
| R-OUT-06 | PASS-IMPL | One documented command pair in `README.md` → "Render" section; both presets come from the same `src/compose.py`. |

## R-PRI — Priority order

| ID | Status | Evidence |
|---|---|---|
| R-PRI | PASS-IMPL | Enforced structurally: German strings live only in `timeline.yaml` + `src/config.py::TEXT_STRINGS` (1); palette is a closed 4-entry dict with a verifier (2); every element carries start/end (3); post FX last (4). |

## R-STACK — Environment and stack

| ID | Status | Evidence |
|---|---|---|
| R-STACK-01 | BLOCKED-EXEC | Cannot probe hosts without a shell. `README.md` → "Step 0: host reachability" gives the exact `curl` commands and the empty result table to fill in. Default stack chosen (see R-STACK-03). |
| R-STACK-02 | PASS-IMPL | `requirements.txt` pins numpy/Pillow/opencv-python-headless/imageio-ffmpeg/PyYAML/pytest; venv inside `nealarp-ad/.venv` per `README.md` and `.gitignore`. |
| R-STACK-03 | PASS-IMPL | Remotion **not** used: npm reachability unverified and no headless browser can be confirmed here. Default Python stack selected; `src/render.py` is the single renderer, so no post-first-frame stack switch is possible. |
| R-STACK-04 | PASS-IMPL | No GPU libs in `requirements.txt`. Budgeted for 2 cores / 3 GB: 1/4-scale glass blur (R-VIS-04), cached sprites, `MAX_PARTICLES=3000`, single-frame float32 working buffer (`src/compose.py`). |
| R-STACK-05 | PASS-IMPL | `src/config.py::FONT_BOLD` / `FONT_MONO` are absolute DejaVu paths, loaded explicitly in `src/text.py::load_font`. No system default is ever requested. |
| R-STACK-06 | BLOCKED-EXEC | Checker written: `python -m src.text --check-coverage` → asserts `Ä ä Ö ö Ü ü ß . , % m`. Result must be pasted into `README.md` → "Font coverage". Cannot run here. |

## R-REF — Reference assets

| ID | Status | Evidence |
|---|---|---|
| R-REF-01 | PASS-IMPL | `reference/inspiration-01.jpg` does not exist in the project → `reference/README.md` written instead. No TikTok fetch attempted. |
| R-REF-02 | PASS-IMPL | Techniques only, implemented as: hot-white core → colour edges (`src/sprites.py::radial_core`), per-letter gradient title (`src/text.py::gradient_fill`), motion-blur tails on final letters (`src/text.py::draw_with_tail`), grain + bloom (`src/layers.py`). No handle/watermark/layout copied. |

## R-REPO — Project layout

| ID | Status | Evidence |
|---|---|---|
| R-REPO-01 | PASS-IMPL | Everything new lives in `nealarp-ad/`. The website repo (`src/App.tsx`, `index.html`, …) is untouched. |
| R-REPO-02 | PASS-IMPL | Layout matches the spec tree exactly (`src/`, `audio/vo/`, `audio/render/`, `reference/`, `tests/`, `out/`). |
| R-REPO-03 | PASS-IMPL | `.gitignore` covers `audio/render/`, `out/`, `*.mp4`, `*.wav`, `*.png`, `.venv/`, `__pycache__/`. |

## R-TIME — Timing model

| ID | Status | Evidence |
|---|---|---|
| R-TIME-01 | PASS-IMPL | `src/render.py` iterates frames and calls `render_frame(frame / FPS)`; no 24 fps constants exist. |
| R-TIME-02 | PASS-IMPL | `timeline.yaml`: opening 0–8, eight 3.0 s cuts 8–32, hero 32–44, CTA 44–60. |
| R-TIME-03 | PASS-IMPL | No scene added/removed. Pacing observations are in the final report only. |
| R-TIME-04 | PASS-IMPL | Every element and text entry carries `start`/`end`; ambient/post layers are declared in the `globals:` block so nothing is undeclared. |

## R-VIS — Visual system

| ID | Status | Evidence |
|---|---|---|
| R-VIS-01 | PASS-IMPL | `src/layers.py::make_background` (#0a0a0a edges → #0f172a centre, 40 % opacity). |
| R-VIS-02 | PASS-IMPL | `src/config.py::PALETTE` is closed (4 colours + haze); `src/verify.py::check_palette` is R-VER-06. |
| R-VIS-03 | PASS-IMPL | `src/text.py::gradient_fill` / `src/layers.py::linear_gradient` = #3b82f6 → #f97316. |
| R-VIS-04 | PASS-IMPL | `src/layers.py::glass_panel` (white 10 %, 1 px 25 % border, r=24, inner shadow 20 % black (0,4) blur 12, backdrop blur 20 px computed at 1/4 scale then upsampled). |
| R-VIS-05 | PASS-IMPL | `src/layers.py::bloom` (24 px, additive, 35 %), `light_streaks`, `anamorphic_flare` (1400×6 + 120 px glow), `offscreen_flicker` (4 in `timeline.yaml`, one per act). |
| R-VIS-06 | PASS-IMPL | `src/config.py::SEED = 7`, `MAX_PARTICLES_1080P = 3000`; `src/particles.py` scales life-size 1.0 → 0.0. |
| R-VIS-07 | PASS-IMPL | `src/layers.py::make_grain_tile` (seeded 512×512, tiled, per-frame offset, 3.5 %). |
| R-VIS-08 | PASS-IMPL | `src/layers.py::make_vignette` (0 % centre → 25 % black corners). |
| R-VIS-09 | PASS-IMPL | `src/layers.py::project` with `FOCAL = 900`, z ∈ [0, 2000]. |
| R-VIS-10 | PASS-IMPL | `src/easing.py` — exact bezier control points, EXPO_OUT `1 - 2^(-10t)`, STEP hold-then-snap. |
| R-VIS-11 | PASS-IMPL | `src/sprites.py::icon_telescope` (tube + tripod), `icon_flame` (teardrop); stroke 6 ref px, white/orange, no emoji anywhere. |
| R-VIS-12 | PASS-IMPL | All coordinates are 1920×1080 reference units; `scale` multiplies geometry and font sizes centrally (`src/compose.py`, `src/text.py`). |
| Text templates | PASS-IMPL | `src/text.py::LAYOUTS` holds all 8 templates + safe area 96/54 + auto-fit (1440 px → −4 px steps → min 64 px) with logging. |

## R-SCN — Scenes

| ID | Status | Evidence |
|---|---|---|
| R-SCN-01 | PASS-IMPL | `timeline.yaml::opening` + `src/scenes.py::paint_particle_tunnel`, `paint_title_flare`; stagger 0.042 s, tails on final two letters, flare at 2.000 s, hold 4–8 s. |
| R-SCN-02 | PASS-IMPL | `paint_coin_cascade` (24 chrome coins, 80–110 px, y −100 → 420, EASE_IO, stagger 0–0.6), `paint_glass_panel` [660,260,600,380] r28 fade 8.3–8.8, clinks at 8.2/8.5/8.9/9.3. |
| R-SCN-03 | PASS-IMPL | `paint_lock_body`/`paint_shackle`/`paint_glyph_rows` (12 rows mono 10 px, 40 % white, 120 px/s)/`paint_lock_click` (1.04→1.0 EXPO_OUT 0.15 s)/`paint_camera_shake` (0.3 s)/`paint_check_circles` (5 × r36 at 12.0–12.8). |
| R-SCN-04 | PASS-IMPL | `paint_sea_gradient`, `paint_dive_particles` (1200 px/s EASE_OUT_EARLY), `paint_creatures` (12, 60–140 px, z-placed), `paint_bubbles` (60, 4–14 px, 80–160 px/s), `depth_counter` (4 declared anchors + EASE_IO 0.3 s count-up), 8 × `sfx_bubble`. |
| R-SCN-05 | PASS-IMPL | `paint_speedometer` (arc 210°→−30°, r300 @ (960,470), needle EXPO_OUT 1.2 s), `paint_speed_streaks` (40 lines, 30 % white, 200–600 px, −2400 px/s), `paint_morph_glyph` (snail/cheetah/rocket/beam, 0.6 s each, 0.15 s crossfade), `paint_title_pulse` (1.0→1.08 over 0.2 s), no VO in this cut. |
| R-SCN-06 | PASS-IMPL | `paint_planet_disk` (r210 @ (960,560) + 2 px orange rim), `paint_meteor` ((1500,60)→(1000,470), alpha 1→0 trail), `paint_shockwave` (5 rings 0→700, EXPO_OUT 1.5 s, 3 px orange), `paint_crater`, shake 0.3 s, `100 MEGATONNEN` claim_white @ y=220 from 21.8, `sfx_boom` @21.6. |
| R-SCN-07 | PASS-IMPL | `paint_arc_draw` (r220 @ (960,470), 14 px, 0→360° EASE_IO 1.2 s) + 4 px inner white core @40 %, `paint_dashed_ring` (2/12/10, 50 % white, from 24.2), `98 %` orange 160 px @ (1480,470) from 24.5, `sfx_pen_draw` 23.0–24.2. |
| R-SCN-08 | PASS-IMPL | `paint_heart_glyph` (2 circles + triangle, 200 px @ (960,470), 72 bpm 1.0→1.12), `paint_pulse_rings` (0→600, 3 px blue, one per beat), `paint_counter_panels` (440×180 @ [200,380] / [1280,380], 400×180 @ [760,640], fade 26.2–26.6), `panel_numbers` 96 px EASE_IO count-up, `sfx_heartbeat` two thumps per beat. |
| R-SCN-09 | PASS-IMPL | `paint_zoom_stages` (6 stages ×10, 0.25 s EXPO_OUT: silhouette, building, mountain, earth, sun, 2000-particle galaxy), `paint_telescope_icon` @ (960,180) 120 px drawn 29.5–30.0, `sfx_whoosh_zoom`. |
| R-SCN-10 | PASS-IMPL | `paint_hero_sphere` (r200 @ (960,500), blue→orange radial + white core, ±3 % @0.5 Hz), `paint_orbiters` (8 sprites, rings 420/560, 0.3 rad/s alternating), `paint_push_in` (1.0→1.15 EASE_IO over 32–44), `nealarp` claim_white 144 px @ y=500 fade 36.5–37.5. |
| R-SCN-11 | PASS-IMPL | `paint_explosion` (~3000 particles 44.0–46.0), `paint_reform_text` (BALD VERFÜGBAR 46.0–48.5 → AB 12. OKTOBER 48.5–50.0 → nealarp.vercel.app 50.0–52.5), `paint_underline_sweep` (1.0 s from 51.5), `paint_cta_pill` (fade 53.0–55.0, pulse 1.0→1.06 at 55.0), drift 55–59, `paint_fade_out` 59–60, audio silent from 60.0. |

## R-AUD — Audio

| ID | Status | Evidence |
|---|---|---|
| R-AUD-01 | BLOCKED-EXEC | `src/vo.py` implements provider plug-ins (`azure`, `elevenlabs`, `google`, `polly`) + `espeak-ng de` placeholder path, −18 dBFS RMS normalisation, ≥0.5 s gap rule, "never speed up" rule (`shift later` only). Nothing synthesised here. Placeholder labelling + 4K block per R-GATE-03 implemented. |
| R-AUD-02 | PASS-IMPL | `src/audio.py::render_music` — 120 BPM, 60.000 s, original code-only synthesis: bass drop, 8 detuned sines through a 2 kHz lowpass, riser, harmonic warming 8→32 s, swell 32→44 s, bass hit + echo (0.25 s / 0.3 fb) 44→60 s. Ducking in `src/mix.py`. |
| R-AUD-03 | PASS-IMPL | `src/audio.py::SFX` — all 12 recipes with the specified frequencies, durations, envelopes and peak dBFS. Max-two-at-once enforced by `src/mix.py::assert_sfx_density`. |
| R-AUD-04 | BLOCKED-EXEC | `src/mix.py` implements sum → two-pass `loudnorm` (I=−14, TP=−1, LRA=11) → `ebur128`/`astats` true-peak confirmation. Needs ffmpeg. |

## R-TXT — On-screen text

| ID | Status | Evidence |
|---|---|---|
| R-TXT-01 | PASS-IMPL | `src/config.py::TEXT_STRINGS` is the exact 23-string list; `tests/test_timeline.py::test_text_strings_exact` diffs every `timeline.yaml` string against it (no adds/removes/edits). |
| R-TXT-02 | PASS-IMPL | Scenes never draw glyphs: `src/scenes.py` has no text calls; all strings route through `src/text.py::draw_text`, which writes `out/layout_log.json`. |
| R-TXT-03 | PASS-IMPL | `src/text.py::autofit` (1440 px threshold, −4 px steps, 64 px floor, every change logged). |

## R-VER — Automated verification

| ID | Status | Evidence |
|---|---|---|
| R-VER-01 … R-VER-14 | BLOCKED-EXEC | All 14 checks are implemented in `src/verify.py` and driven by `tests/test_media.py` / `tests/test_reproducibility.py`. They require the rendered MP4 + ffmpeg, which cannot be produced or executed here. Run `make verify`. |
| Unit-level parts of R-VER-08/09/11/13/14 | BLOCKED-EXEC | `tests/test_text_layout.py` (safe area, autofit, coverage) and `tests/test_timeline.py` (sfx/vo timing, no VO overlap) run **without** media — they still need pytest. |

## R-PERF — Performance

| ID | Status | Evidence |
|---|---|---|
| R-PERF-01 | PASS-IMPL | `src/layers.py` caches background/vignette/grain per (w,h) in module-level `_CACHE`; glass backdrops blurred at 1/4 scale. |
| R-PERF-02 | PASS-IMPL | Particle projection, grain, vignette, bloom, gradients are numpy-vectorised (`src/particles.py`, `src/layers.py`). No per-pixel Python loops. |
| R-PERF-03 | PASS-IMPL | `src/sprites.py::sprite()` memoises by `(name, size_px, scale)`. |
| R-PERF-04 | BLOCKED-EXEC | `src/render.py` writes `out/perf-report.json` (avg s/frame, total, 4K estimate = 4×) — needs a run. |
| R-PERF-05 | PASS-IMPL | `src/render.py` refuses `--preset final` when `estimate_4k > 6 h` unless `--force-4k`; prints the three documented options. |

## R-GATE — Approval gate

| ID | Status | Evidence |
|---|---|---|
| R-GATE-01 | PASS | Stopped. No render was started (none could be). |
| R-GATE-02 | PASS-IMPL | `--preset final` requires the literal flag `--i-approve-4k`. |
| R-GATE-03 | PASS-IMPL | `src/render.py::assert_neural_vo()` reads `audio/render/vo_provider.txt`; `espeak`/`placeholder` aborts with the documented message. |
| R-GATE-04 | PASS-IMPL | No upscale path exists in the codebase; `--preset final` renders at native 3840×2160 (`SCALE = 2`). |

## R-NEG — Negative constraints

| ID | Status | Evidence |
|---|---|---|
| R-NEG-01 | PASS-IMPL | Closed palette + `src/verify.py::check_palette`. |
| R-NEG-02 | PASS-IMPL | Only geometric primitives/icons; no emoji codepoints in `timeline.yaml` or `src/`. |
| R-NEG-03 | PASS-IMPL | On-screen strings are exactly the German list in R-TXT-01 (plus the numeric counter readouts mandated by R-SCN-04/08 — see Deviations in the report). |
| R-NEG-04 | PASS-IMPL | No watermark/logo/handle/URL-chrome element types exist. |
| R-NEG-05 | PASS-IMPL (design) / BLOCKED-EXEC (measurement) | Deterministic seeding, closed-form motion, `R-VER-10` motion check, dithered gradients to avoid banding. Needs a render to confirm. |
| R-NEG-06 | PASS-IMPL | Both presets are exactly 16:9 (1920×1080 / 3840×2160); no padding code path. |
| R-NEG-07 | PASS-IMPL | All audio is synthesised in `src/audio.py`; no sample loading anywhere. |
| R-NEG-08 | PASS-IMPL | `.gitignore`. |
| R-NEG-09 | PASS | This checklist marks every unrun item BLOCKED-EXEC instead of claiming a result. |
