# Reference

`reference/inspiration-01.jpg` was **not** present in the project, so per R-REF-01 this file records
the description instead (R-REF-02). No TikTok page was fetched (they return HTTP 403).

## Inspiration description (techniques only)

- Near-black background.
- A glowing hot-white core subject that fades into colour at its edges.
- Gradient display title, with a different colour landing on each letter.
- Motion-blur tails on the final letters of a word.
- Film grain and bloom.

## How each technique is implemented here

| Technique | Implementation |
|---|---|
| Near-black background | `src/layers.py::make_background` — #0a0a0a with a 40 % radial haze to #0f172a (R-VIS-01). |
| Hot-white core → colour at edges | `src/sprites.py::radial_core(core=white, mid=blue, rim=orange)` — used by coins, the hero sphere, the sun, bioluminescent creatures. |
| Per-letter gradient title | `src/text.py::gradient_fill` — one linear #3b82f6 → #f97316 ramp across the measured string box, masked by the rendered glyphs, so each letter samples a different part of the ramp (R-VIS-03, R-REF-02). |
| Motion-blur tails on final letters | `src/text.py::draw_with_tail(tail_letters=2)` — 5 ghost copies per tailed letter, offset along −x, alpha 0.35 → 0.04 (R-SCN-01). |
| Film grain | `src/layers.py::make_grain_tile` — one seeded 512×512 tile, tiled with a per-frame offset, 3.5 % (R-VIS-07). |
| Bloom | `src/layers.py::bloom` — bright-pass, 24 px blur, additive at 35 % (R-VIS-05). |

Nothing else was taken from the inspiration: no creator handle, no watermark, no layout, no
photographic subject matter (R-NEG-04, R-NEG-02).
