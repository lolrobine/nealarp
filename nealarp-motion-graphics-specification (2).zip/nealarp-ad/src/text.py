"""Text layout system (R-TXT-01/02/03, R-VIS text templates).

Every on-screen character in the ad is drawn by this module. Scene code never touches
glyphs, so the layout log (`out/layout_log.json`) is complete and checkable:
R-VER-08 (safe area) and R-VER-09 (completeness/OCR) both read it.

Fills: linear blue->orange gradient (R-VIS-03) sampled across the whole string, so each
letter lands on a different colour (R-REF-02). Motion-blur tails are ghost copies of the
final letters, composited with ImageChops.lighter so they can never darken the solid glyph.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFont

from . import config as C
from .easing import clamp, progress

# --------------------------------------------------------------------- templates
# y_mode: "center"   -> y is the vertical centre of the ink box
#         "baseline" -> y is the typographic baseline
LAYOUTS: dict[str, dict[str, Any]] = {
    "title_opening": dict(
        font=C.FONT_BOLD, size=180, case="upper", tracking=0.04, y_mode="center",
        at=(960, 540), fill="gradient", panel=None,
    ),
    "title_lower_third": dict(
        font=C.FONT_BOLD, size=96, case="upper", tracking=0.04, y_mode="baseline",
        at=(960, 880), fill="gradient",
        panel=dict(pad_x=48, pad_y=28, radius=24),
    ),
    "counter_center": dict(
        font=C.FONT_BOLD, size=160, case="none", tracking=0.0, y_mode="center",
        at=(960, 520), fill="white", panel=None,
    ),
    "claim_white": dict(
        font=C.FONT_BOLD, size=112, case="upper", tracking=0.02, y_mode="center",
        at=(960, 540), fill="white", panel=None,
    ),
    "claim_gradient": dict(
        font=C.FONT_BOLD, size=96, case="upper", tracking=0.02, y_mode="center",
        at=(960, 540), fill="gradient", panel=None,
    ),
    "url": dict(
        font=C.FONT_BOLD, size=72, case="none", tracking=0.01, y_mode="center",
        at=(960, 600), fill="white", panel=None,
    ),
    "cta_button_label": dict(
        font=C.FONT_BOLD, size=44, case="upper", tracking=0.06, y_mode="center",
        at=(960, 780), fill="white", panel=None,
    ),
    # Templates required by individual scene specs (R-SCN-06/07/08). They reuse the same
    # measurement, auto-fit and logging path as the seven spec templates.
    "score_orange": dict(
        font=C.FONT_BOLD, size=160, case="none", tracking=0.0, y_mode="center",
        at=(1480, 470), fill="orange", panel=None,
    ),
    "panel_label": dict(
        font=C.FONT_BOLD, size=28, case="upper", tracking=0.14, y_mode="center",
        at=(960, 540), fill="white60", panel=None,
    ),
    "panel_number": dict(
        font=C.FONT_BOLD, size=96, case="none", tracking=0.0, y_mode="center",
        at=(960, 540), fill="white", panel=None,
    ),
}

FILL_COLORS = {
    "white": C.WHITE,
    "orange": C.ORANGE,
    "blue": C.BLUE,
    "white60": (255, 255, 255),
}

_FONT_CACHE: dict[tuple[str, int], ImageFont.FreeTypeFont] = {}


def load_font(path: str, size_px: int) -> ImageFont.FreeTypeFont:
    """Explicit font loading by absolute path (R-STACK-05). Never a system default."""
    key = (path, size_px)
    font = _FONT_CACHE.get(key)
    if font is None:
        font = ImageFont.truetype(path, max(1, int(size_px)))
        _FONT_CACHE[key] = font
    return font


def check_font_coverage() -> dict[str, Any]:
    """R-STACK-06 / R-VER-14: does DejaVu cover Ä ä Ö ö Ü ü ß and . , % m ?"""
    report: dict[str, Any] = {"chars": C.REQUIRED_CHARS, "fonts": {}, "pass": True}
    for name, path in (("bold", C.FONT_BOLD), ("mono", C.FONT_MONO)):
        exists = Path(path).exists()
        per_char: dict[str, bool] = {}
        if exists:
            font = load_font(path, 64)
            for ch in C.REQUIRED_CHARS:
                box = font.getbbox(ch)
                per_char[ch] = bool(box and box[2] > box[0] and box[3] > box[1])
        else:
            per_char = {ch: False for ch in C.REQUIRED_CHARS}
        ok = exists and all(per_char.values())
        report["fonts"][name] = {"path": path, "exists": exists, "chars": per_char, "pass": ok}
        report["pass"] = report["pass"] and ok
    return report


# --------------------------------------------------------------------- metrics
@dataclass
class TextMetrics:
    string: str
    layout: str
    size_ref: int
    size_px: int
    tracking_px: float
    width_ref: float
    ink_ref: tuple[float, float, float, float]   # x, y, w, h in reference units
    autofit_from: int | None = None


@dataclass
class _Draw:
    """Internal: a rendered text layer ready to be pasted."""

    layer: Image.Image
    box: tuple[int, int]
    ink_ref: tuple[float, float, float, float]


class TextSystem:
    """Owns fonts, auto-fit, the layout log and glyph sampling for particle reform."""

    def __init__(self, scale: float = 1.0) -> None:
        self.scale = float(scale)
        self.log: list[dict[str, Any]] = []
        self.autofit_log: list[dict[str, Any]] = []
        self._seen: set[str] = set()
        self._metrics: dict[str, TextMetrics] = {}
        self._points: dict[str, np.ndarray] = {}

    # -- measurement ------------------------------------------------------
    def metrics(self, entry) -> TextMetrics:
        key = getattr(entry, "id", None) or entry["id"]
        cached = self._metrics.get(key)
        if cached is not None:
            return cached

        string = getattr(entry, "string", None) or entry["string"]
        layout_id = getattr(entry, "layout", None) or entry["layout"]
        tpl = LAYOUTS[layout_id]
        override = getattr(entry, "size", None) or (entry.get("size") if isinstance(entry, dict) else None)

        size_ref = int(override or tpl["size"])
        case = tpl.get("case", "none")
        shown = {"upper": str.upper, "lower": str.lower, "none": lambda s: s}[case](string)

        # auto-fit in reference units (R-TXT-03)
        original = size_ref
        while size_ref > C.AUTOFIT_MIN_SIZE:
            w = self._measure_width(shown, tpl["font"], size_ref, tpl.get("tracking", 0.0))
            if w <= C.AUTOFIT_MAX_WIDTH:
                break
            size_ref -= C.AUTOFIT_STEP
            self.autofit_log.append(
                {"id": key, "string": shown, "layout": layout_id, "from": size_ref + C.AUTOFIT_STEP,
                 "to": size_ref, "reason": f"width {w:.0f}px > {C.AUTOFIT_MAX_WIDTH}px"}
            )
        w_ref = self._measure_width(shown, tpl["font"], size_ref, tpl.get("tracking", 0.0))

        font_px = max(1, int(round(size_ref * self.scale)))
        ascent, descent = load_font(tpl["font"], font_px).getmetrics()
        h_ref = (ascent + descent) / self.scale
        at = self._anchor(entry, tpl)
        x_ref = at[0] - w_ref / 2.0
        if tpl["y_mode"] == "baseline":
            y_ref = at[1] - ascent / self.scale
        else:
            y_ref = at[1] - h_ref / 2.0

        m = TextMetrics(
            string=shown, layout=layout_id, size_ref=size_ref, size_px=font_px,
            tracking_px=tpl.get("tracking", 0.0) * size_ref * self.scale,
            width_ref=w_ref, ink_ref=(x_ref, y_ref, w_ref, h_ref),
            autofit_from=original if original != size_ref else None,
        )
        self._metrics[key] = m
        return m

    @staticmethod
    def _anchor(entry, tpl: dict[str, Any]) -> tuple[float, float]:
        at = getattr(entry, "at", None) or (entry.get("at") if isinstance(entry, dict) else None)
        if at:
            return float(at[0]), float(at[1])
        base = tpl["at"]
        return float(base[0]), float(base[1])

    def _measure_width(self, string: str, font_path: str, size_ref: int, tracking_em: float) -> float:
        font = load_font(font_path, max(1, int(round(size_ref * self.scale))))
        extra = tracking_em * size_ref * self.scale
        total = sum(font.getlength(ch) for ch in string)
        if string:
            total += extra * (len(string) - 1)
        return total / self.scale

    # -- rendering --------------------------------------------------------
    def _mask(self, m: TextMetrics, alphas: Sequence[float], tail: int, tail_shift: float) -> Image.Image:
        """Glyph alpha mask with per-letter alpha, tracking, and optional blur tails."""
        tpl = LAYOUTS[m.layout]
        font = load_font(tpl["font"], m.size_px)
        ascent, descent = font.getmetrics()
        n = len(m.string)

        advances = [font.getlength(ch) + m.tracking_px for ch in m.string]
        prefix: list[float] = []
        acc = 0.0
        for a in advances:
            prefix.append(acc)
            acc += a

        tail_px = abs(tail_shift) * 5.0 * self.scale if tail > 0 else 0.0
        pad = int(max(8.0, m.size_px * 0.35) + tail_px + 4)
        w = int(math.ceil(m.width_ref * self.scale)) + pad * 2
        h = int(math.ceil(ascent + descent)) + pad * 2

        mask = Image.new("L", (w, h), 0)
        d = ImageDraw.Draw(mask)
        for i, ch in enumerate(m.string):
            a = alphas[i] if i < len(alphas) else 1.0
            if a > 0.003 and ch != " ":
                d.text((pad + prefix[i], pad), ch, font=font, fill=int(round(255 * clamp(a))))

        if tail > 0 and tail_shift:
            ghosts = Image.new("L", (w, h), 0)
            gd = ImageDraw.Draw(ghosts)
            for i in range(max(0, n - tail), n):
                ch = m.string[i]
                if ch == " ":
                    continue
                base_a = alphas[i] if i < len(alphas) else 1.0
                for g in range(1, 6):
                    ga = (0.35 - 0.062 * g) * base_a
                    if ga <= 0.004:
                        continue
                    gd.text((pad + prefix[i] + tail_shift * g * self.scale, pad), ch, font=font,
                            fill=int(round(255 * clamp(ga))))
            # lighter() keeps the solid glyph on top of its own tails
            mask = ImageChops.lighter(mask, ghosts)
        return mask

    def _fill(self, m: TextMetrics, mask: Image.Image) -> Image.Image:
        tpl = LAYOUTS[m.layout]
        fill = tpl["fill"]
        w, h = mask.size
        if fill == "gradient":
            from . import layers

            base = Image.fromarray(
                layers.linear_gradient((w, h), C.BLUE, C.ORANGE, axis="x").astype(np.uint8), "RGB"
            )
        else:
            color = FILL_COLORS[fill]
            base = Image.new("RGB", (w, h), color)
            if fill == "white60":
                mask = mask.point(lambda v: int(v * 0.6))
        return Image.merge("RGBA", (*base.split(), mask))

    def _paste_box(self, m: TextMetrics, mask: Image.Image, dy_px: float = 0.0) -> tuple[int, int]:
        """Top-left paste position so the declared anchor lands exactly where the spec says."""
        tpl = LAYOUTS[m.layout]
        ascent, descent = load_font(tpl["font"], m.size_px).getmetrics()
        pad_x = (mask.size[0] - int(math.ceil(m.width_ref * self.scale))) // 2
        pad_y = (mask.size[1] - int(math.ceil(ascent + descent))) // 2
        ax, ay = self._anchor_from_metrics(m)

        if tpl["y_mode"] == "baseline":
            top = ay * self.scale - (pad_y + ascent)
        else:
            top = ay * self.scale - (pad_y + (ascent + descent) / 2.0)
        left = ax * self.scale - (m.width_ref * self.scale) / 2.0 - pad_x
        return int(round(left)), int(round(top + dy_px))

    def _anchor_from_metrics(self, m: TextMetrics) -> tuple[float, float]:
        """Recover the declared anchor point (reference units) from the cached ink box."""
        x, y, w, h = m.ink_ref
        tpl = LAYOUTS[m.layout]
        if tpl["y_mode"] == "baseline":
            ascent, _ = load_font(tpl["font"], m.size_px).getmetrics()
            return (x + w / 2.0, y + ascent / self.scale)
        return (x + w / 2.0, y + h / 2.0)

    def draw(self, img: Image.Image, entry, t: float, alpha: float = 1.0,
             scale_mul: float = 1.0, draw_panel: bool = True) -> TextMetrics:
        """Draw one timeline text entry onto `img` (a PIL RGB/RGBA frame)."""
        m = self.metrics(entry)
        tpl = LAYOUTS[m.layout]
        props = _props(entry)
        start = _f(entry, "start")
        end = _f(entry, "end")
        ease = _s(entry, "ease", "EASE_IO")

        fade_in = float(props.get("fade_in", 0.25))
        stagger = float(props.get("stagger", 0.0))
        tail = int(props.get("tail_letters", 0))
        fade_out = float(props.get("fade_out", 0.0))

        p_in = progress(t, start, min(end, start + max(fade_in, 1e-6)))
        from .easing import apply as _apply
        env = _apply(ease, p_in) * alpha
        if fade_out > 0:
            env *= 1.0 - _apply("EASE_IO", progress(t, end - fade_out, end))
        if env <= 0.002:
            self._record(entry, m, t)
            return m

        n = max(1, len(m.string))
        per_letter = max(0.05, fade_in - (n - 1) * stagger)
        alphas: list[float] = []
        for i in range(n):
            ls = start + i * stagger
            alphas.append(clamp((t - ls) / per_letter) * env)

        mask = self._mask(m, alphas, tail, -max(6.0, m.size_ref * 0.09))
        layer = self._fill(m, mask)

        dy = (1.0 - env) * 14.0 * self.scale if stagger or fade_in else 0.0
        box = self._paste_box(m, mask, dy)

        if abs(scale_mul - 1.0) > 1e-4:
            # scale about the layer's own centre (used by title_pulse, R-SCN-05)
            nw = max(1, int(round(layer.width * scale_mul)))
            nh = max(1, int(round(layer.height * scale_mul)))
            cx = box[0] + layer.width / 2.0
            cy = box[1] + layer.height / 2.0
            layer = layer.resize((nw, nh), Image.LANCZOS)
            box = (int(round(cx - nw / 2.0)), int(round(cy - nh / 2.0)))

        if draw_panel and tpl.get("panel") and env > 0.02:
            from . import layers
            pl = tpl["panel"]
            x, y, w, h = m.ink_ref
            rect = (x - pl["pad_x"], y - pl["pad_y"], w + 2 * pl["pad_x"], h + 2 * pl["pad_y"])
            layers.glass_panel(img, rect, pl["radius"], self.scale, alpha=env)

        img.paste(layer, box, layer)
        self._record(entry, m, t)
        return m

    # -- logging (R-VER-08 / R-VER-09) ------------------------------------
    def _record(self, entry, m: TextMetrics, t: float) -> None:
        key = _s(entry, "id", "?")
        if key in self._seen:
            return
        self._seen.add(key)
        x, y, w, h = m.ink_ref
        self.log.append({
            "id": key,
            "string": m.string,
            "layout": m.layout,
            "size_ref": m.size_ref,
            "autofit_from": m.autofit_from,
            # data readouts (depth counter, life statistics) are interpolated between the
            # declared anchors, so R-VER-09 treats them separately from static copy.
            "dynamic": bool(_props(entry).get("dynamic")),
            "bbox_ref": [round(x, 2), round(y, 2), round(w, 2), round(h, 2)],
            "first_seen_t": round(t, 4),
            "start": _f(entry, "start"),
            "end": _f(entry, "end"),
            "safe_area_ok": bool(
                x >= C.SAFE_X - 0.5 and y >= C.SAFE_Y - 0.5
                and x + w <= C.REF_W - C.SAFE_X + 0.5
                and y + h <= C.REF_H - C.SAFE_Y + 0.5
            ),
        })

    def save_log(self, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "reference": [C.REF_W, C.REF_H],
            "safe_area": {"x": C.SAFE_X, "y": C.SAFE_Y},
            "autofit": self.autofit_log,
            "entries": sorted(self.log, key=lambda e: e["first_seen_t"]),
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    # -- particle targets (R-SCN-11 reform) -------------------------------
    def sample_points(self, entry, count: int) -> np.ndarray:
        """`count` points (reference units) sampled from the glyph ink of `entry`."""
        key = _s(entry, "id", "?")
        cache_key = f"{key}:{count}"
        if cache_key in self._points:
            return self._points[cache_key]

        m = self.metrics(entry)
        mask = self._mask(m, [1.0] * len(m.string), 0, 0.0)
        arr = np.asarray(mask) > 128
        ys, xs = np.nonzero(arr)
        if xs.size == 0:
            pts = np.zeros((count, 2), dtype=np.float32)
        else:
            rng = C.rng(f"reform:{cache_key}")
            idx = rng.integers(0, xs.size, size=count)
            left, top = self._paste_box(m, mask)
            pts = np.stack(
                [(left + xs[idx]) / self.scale, (top + ys[idx]) / self.scale],
                axis=1,
            ).astype(np.float32)
        self._points[cache_key] = pts
        return pts

    def coverage(self) -> dict[str, Any]:
        return check_font_coverage()


def _props(entry) -> dict[str, Any]:
    if isinstance(entry, dict):
        return entry.get("props") or {}
    return getattr(entry, "props", None) or {}


def _f(entry, key: str, default: float = 0.0) -> float:
    v = entry[key] if isinstance(entry, dict) else getattr(entry, key, default)
    return float(default if v is None else v)


def _s(entry, key: str, default: str = "") -> str:
    v = entry[key] if isinstance(entry, dict) else getattr(entry, key, default)
    return str(default if v is None else v)


if __name__ == "__main__":  # pragma: no cover
    import sys

    rep = check_font_coverage()
    print(json.dumps(rep, ensure_ascii=False, indent=2))
    sys.exit(0 if rep["pass"] else 1)
