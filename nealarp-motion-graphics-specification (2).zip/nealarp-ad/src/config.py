"""Constants, palette, fonts and the seeded RNG (R-VIS, R-STACK, R-TXT)."""

from __future__ import annotations

from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------- time / space
FPS = 60
DURATION = 60.0
TOTAL_FRAMES = int(round(DURATION * FPS))  # 3600 (R-VER-01)
REF_W, REF_H = 1920, 1080

PRESETS = {
    "test": {
        "width": 1920,
        "height": 1080,
        "scale": 1,
        "out": "out/nealarp-ad-1080p-test.mp4",
    },
    "final": {
        "width": 3840,
        "height": 2160,
        "scale": 2,
        "out": "out/nealarp-ad-2160p60-final.mp4",
    },
}

# ---------------------------------------------------------------- palette (R-VIS-02)
BLUE = (59, 130, 246)      # #3b82f6
ORANGE = (249, 115, 22)    # #f97316
WHITE = (255, 255, 255)
BLACK = (10, 10, 10)       # #0a0a0a
HAZE = (15, 23, 42)        # #0f172a — depth haze centre only (R-VIS-01)

PALETTE = {"blue": BLUE, "orange": ORANGE, "white": WHITE, "black": BLACK, "haze": HAZE}

# hue windows used by the palette verifier (R-VER-06), degrees
HUE_BLUE = (195.0, 235.0)
HUE_ORANGE = (15.0, 35.0)
SAT_FLOOR = 0.35
VAL_FLOOR = 0.30
PALETTE_TOLERANCE = 0.01


def color(name: str | tuple) -> tuple[int, int, int]:
    """Resolve a palette name or pass through an explicit RGB triple."""
    if isinstance(name, (tuple, list)):
        return tuple(int(c) for c in name)
    return PALETTE[name]


# ---------------------------------------------------------------- fonts (R-STACK-05)
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"

# R-STACK-06 / R-VER-14
REQUIRED_CHARS = "ÄäÖöÜüß.,%m"

# ---------------------------------------------------------------- particles / camera
SEED = 7                                   # R-VIS-06
MAX_PARTICLES_1080P = 3000                 # R-VIS-06
FOCAL = 900.0                              # R-VIS-09
Z_NEAR, Z_FAR = 0.0, 2000.0                # R-VIS-09

# ---------------------------------------------------------------- grain / vignette
GRAIN_TILE = 512                           # R-VIS-07
GRAIN_OPACITY = 0.035                      # R-VIS-07
VIGNETTE_CORNER = 0.25                     # R-VIS-08
BLOOM_BLUR = 24                            # R-VIS-05
BLOOM_STRENGTH = 0.35                      # R-VIS-05
BLOOM_THRESHOLD = 178

# ---------------------------------------------------------------- text layout
SAFE_X, SAFE_Y = 96, 54                    # R-VIS-12 text templates
AUTOFIT_MAX_WIDTH = 1440                   # 75% of 1920
AUTOFIT_STEP = 4
AUTOFIT_MIN_SIZE = 64

# R-TXT-01 — the complete, exact on-screen string list. Not one character more or less.
TEXT_STRINGS = [
    "SPIELE UND ZEUG",
    "GELD AUSGEBEN",
    "DAS PASSWORT-SPIEL",
    "DIE TIEFSEE",
    "0 m",
    "1.000 m",
    "5.000 m",
    "11.034 m",
    "TEMPO",
    "ASTEROIDEN-WERFER",
    "100 MEGATONNEN",
    "PERFEKTER KREIS",
    "98 %",
    "LEBENSSTATISTIK",
    "HERZSCHLÄGE",
    "ATEMZÜGE",
    "SCHRITTE",
    "GRÖSSE DES WELTALLS",
    "nealarp",
    "BALD VERFÜGBAR",
    "AB 12. OKTOBER",
    "nealarp.vercel.app",
    "ERHÄLTLICH AB 12. OKTOBER",
]

# German thousands separator (R-TXT-01 uses "1.000 m", "11.034 m")
def de_int(value: float) -> str:
    return f"{int(round(value)):,}".replace(",", ".")


# ---------------------------------------------------------------- rng (R-VIS-06)
def rng(stream: str | int) -> np.random.Generator:
    """Deterministic generator: same stream name => same numbers, always.

    SeedSequence entropy mixes the fixed project seed with a stream id, so every
    subsystem (particles, grain, bubbles, galaxy…) gets an independent but
    reproducible sequence.
    """
    return np.random.default_rng(np.random.SeedSequence(entropy=(SEED, hash_stream(stream))))


def hash_stream(stream: str | int) -> int:
    if isinstance(stream, int):
        return abs(stream) % (2**31)
    # stable, interpreter-independent string hash (PYTHONHASHSEED-proof)
    h = 2166136261
    for ch in stream.encode("utf-8"):
        h = ((h ^ ch) * 16777619) & 0xFFFFFFFF
    return h


# ---------------------------------------------------------------- video (R-OUT-05)
VIDEO_CODEC = "libx264"
VIDEO_PROFILE = "high"
PIXEL_FORMAT = "yuv420p"
CRF = 16
AUDIO_CODEC = "aac"
AUDIO_RATE = 48000
AUDIO_CHANNELS = 2
TARGET_LUFS = -14.0
TARGET_TP = -1.0
TARGET_LRA = 11.0
VO_RMS_DBFS = -18.0
SILENCE_DBFS = -70.0
