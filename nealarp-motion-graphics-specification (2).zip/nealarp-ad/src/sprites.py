"""Cached sprite painters (R-PERF-03, R-VIS-11, R-REF-02).

Every sprite is a Pillow RGBA image rendered once per (name, size, scale) and memoised.
Only flat geometric shapes and radial gradients are used — no emoji, no photo material,
no cartoon outlines (R-NEG-02).
"""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from . import config as C

_CACHE: dict[tuple, Image.Image] = {}


def sprite(name: str, size_ref: float, scale: float, **kw) -> Image.Image:
    key = (name, round(size_ref, 3), round(scale, 4), tuple(sorted((k, str(v)) for k, v in kw.items())))
    img = _CACHE.get(key)
    if img is None:
        img = _BUILDERS[name](size_ref, scale, **kw)
        _CACHE[key] = img
    return img


def clear_cache() -> None:
    _CACHE.clear()


# ------------------------------------------------------------------- gradients
def radial_core(size_ref: float, scale: float, core=C.WHITE, mid=C.BLUE, rim=C.ORANGE,
                rim_px: float = 2.0, glow: float = 0.0) -> Image.Image:
    """Hot white core fading into colour at the edges (R-REF-02)."""
    s = max(3, int(round(size_ref * scale)))
    pad = int(round(glow * scale)) if glow else 0
    box = s + pad * 2
    yy, xx = np.mgrid[0:box, 0:box].astype(np.float32)
    c = box / 2.0
    r = np.sqrt((xx - c) ** 2 + (yy - c) ** 2) / (s / 2.0)
    core_a = np.array(core, dtype=np.float32)
    mid_a = np.array(mid, dtype=np.float32)
    rim_a = np.array(rim, dtype=np.float32)

    t1 = np.clip(r / 0.55, 0, 1)[..., None]
    t2n = np.clip((r - 0.55) / 0.45, 0, 1)
    t2 = t2n[..., None]
    rgb = core_a + (mid_a - core_a) * t1
    rgb = rgb + (rim_a - rgb) * t2
    # crossover through white: keeps mid-tone hues out of the forbidden range (R-NEG-01)
    lift = (np.sin(np.pi * t2n) ** 2 * 0.45)[..., None]
    rgb = rgb + (255.0 - rgb) * lift

    rim_band = np.clip(1.0 - np.abs(r - 1.0) / max(1e-6, (rim_px * scale) / (s / 2.0)), 0, 1)
    rgb = rgb + (rim_a - rgb) * (rim_band * 0.85)[..., None]

    alpha = np.clip((1.0 - r) * 6.0, 0, 1)
    if glow > 0:
        alpha = np.maximum(alpha, np.clip((1.35 - r) * 0.55, 0, 1) * 0.5)
    out = np.dstack([rgb.astype(np.uint8), (alpha * 255).astype(np.uint8)])
    return Image.fromarray(out, "RGBA")


# ------------------------------------------------------------------ game props
def coin(size_ref: float, scale: float, spin: float = 1.0) -> Image.Image:
    """Chrome coin: white centre, blue mid-tones, 2 px orange rim highlight (R-SCN-02)."""
    img = radial_core(size_ref, scale, core=C.WHITE, mid=(120, 170, 250), rim=C.ORANGE, rim_px=2.0)
    if spin < 0.999:
        w, h = img.size
        nw = max(1, int(round(w * max(0.06, spin))))
        img = img.resize((nw, h), Image.LANCZOS)
    return img


def lock(size_ref: float, scale: float) -> Image.Image:
    s = max(4, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    bw, bh = int(s * 0.72), int(s * 0.56)
    x0, y0 = (s - bw) // 2, int(s * 0.40)
    d.rounded_rectangle([x0, y0, x0 + bw, y0 + bh], radius=int(s * 0.12), fill=(235, 240, 250, 255))
    d.rounded_rectangle([x0, y0, x0 + bw, y0 + bh], radius=int(s * 0.12),
                        outline=(59, 130, 246, 200), width=max(1, int(round(2 * scale))))
    d.arc([s // 2 - int(s * 0.24), int(s * 0.10), s // 2 + int(s * 0.24), int(s * 0.58)],
          start=180, end=360, fill=(245, 248, 255, 255), width=max(2, int(round(s * 0.09))))
    return img


def creature(size_ref: float, scale: float, color: str = "blue") -> Image.Image:
    """Bioluminescent deep-sea blob: glowing ellipse with a hot core (R-SCN-04)."""
    col = C.color(color)
    img = radial_core(size_ref, scale, core=C.WHITE, mid=col, rim=col, glow=size_ref * 0.35)
    w, h = img.size
    return img.resize((w, max(2, int(round(h * 0.66)))), Image.LANCZOS)


def heart(size_ref: float, scale: float) -> Image.Image:
    """Two circles + a triangle (R-SCN-08), white with a blue glow."""
    s = max(8, int(round(size_ref * scale)))
    pad = int(round(s * 0.28))
    box = s + pad * 2
    img = Image.new("RGBA", (box, box), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r = s * 0.29
    cx = box / 2.0
    top = pad + s * 0.10
    d.ellipse([cx - 2 * r, top, cx, top + 2 * r], fill=C.WHITE)
    d.ellipse([cx, top, cx + 2 * r, top + 2 * r], fill=C.WHITE)
    d.polygon([(cx - 2 * r + 1, top + r * 0.95), (cx + 2 * r - 1, top + r * 0.95),
               (cx, pad + s * 0.94)], fill=C.WHITE)
    glow = Image.new("RGBA", (box, box), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([pad * 0.4, pad * 0.4, box - pad * 0.4, box - pad * 0.4], fill=(*C.BLUE, 90))
    glow = glow.filter(ImageFilter.GaussianBlur(max(1.0, 12 * scale)))
    out = Image.alpha_composite(glow, img)
    return out


def ring(size_ref: float, scale: float, color: str = "orange", stroke: float = 14.0) -> Image.Image:
    s = max(6, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(img).ellipse(
        [stroke * scale / 2, stroke * scale / 2, s - stroke * scale / 2, s - stroke * scale / 2],
        outline=C.color(color), width=max(1, int(round(stroke * scale))),
    )
    return img


def planet(size_ref: float, scale: float) -> Image.Image:
    """Earth: radial blue disk with a thin orange atmosphere rim (R-SCN-06)."""
    return radial_core(size_ref, scale, core=(190, 220, 255), mid=C.BLUE, rim=C.ORANGE, rim_px=2.0,
                       glow=size_ref * 0.12)


def sun(size_ref: float, scale: float) -> Image.Image:
    return radial_core(size_ref, scale, core=C.WHITE, mid=(255, 190, 120), rim=C.ORANGE,
                       glow=size_ref * 0.45)


def meteor(size_ref: float, scale: float) -> Image.Image:
    s = max(6, int(round(size_ref * scale)))
    img = radial_core(s, scale, core=C.WHITE, mid=(255, 170, 90), rim=C.ORANGE, glow=s * 0.5)
    return img


def speedometer(size_ref: float, scale: float) -> Image.Image:
    s = max(8, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    w = max(1, int(round(6 * scale)))
    d.arc([w, w, s - w, s - w], start=150, end=330, fill=(255, 255, 255, 200), width=w)
    d.line([(s / 2, s / 2), (s * 0.78, s * 0.30)], fill=C.ORANGE, width=w)
    d.ellipse([s / 2 - w, s / 2 - w, s / 2 + w, s / 2 + w], fill=C.WHITE)
    return img


# ---------------------------------------------------------------- icons (R-VIS-11)
def icon_telescope(size_ref: float, scale: float, color: str = "white", stroke: float = 6.0) -> Image.Image:
    """Flat geometric line icon: tube (rectangle) on a tripod (two lines)."""
    s = max(8, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    col = C.color(color)
    w = max(1, int(round(stroke * scale)))
    d.rectangle([int(s * 0.18), int(s * 0.20), int(s * 0.86), int(s * 0.42)], outline=col, width=w)
    d.line([(int(s * 0.50), int(s * 0.44)), (int(s * 0.28), int(s * 0.90))], fill=col, width=w)
    d.line([(int(s * 0.50), int(s * 0.44)), (int(s * 0.74), int(s * 0.90))], fill=col, width=w)
    return img


def icon_flame(size_ref: float, scale: float, color: str = "orange", stroke: float = 6.0) -> Image.Image:
    """Flat geometric teardrop path."""
    s = max(8, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pts = [(s * 0.5, s * 0.06)]
    for i in range(1, 25):
        a = math.pi * (i / 24.0)
        pts.append((s * 0.5 + math.sin(a) * s * 0.34, s * 0.30 + (1 - math.cos(a)) * s * 0.30))
    pts += [(s * 0.5 + s * 0.30, s * 0.66), (s * 0.5, s * 0.94), (s * 0.5 - s * 0.30, s * 0.66)]
    d.line(pts + [pts[0]], fill=C.color(color), width=max(1, int(round(stroke * scale))), joint="curve")
    return img


# ------------------------------------------------- scale stages (R-SCN-09)
def human(size_ref: float, scale: float) -> Image.Image:
    """Tiny silhouette: circle head + rounded-rectangle body."""
    s = max(8, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s, s * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    hr = s * 0.28
    d.ellipse([s / 2 - hr, 0, s / 2 + hr, hr * 2], fill=C.WHITE)
    d.rounded_rectangle([s / 2 - s * 0.22, hr * 2.3, s / 2 + s * 0.22, s * 1.9],
                        radius=s * 0.16, fill=C.WHITE)
    return img


def building(size_ref: float, scale: float) -> Image.Image:
    s = max(8, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s, s * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i, (x0, x1, top) in enumerate([(0.10, 0.42, 0.30), (0.38, 0.66, 0.05), (0.62, 0.94, 0.44)]):
        d.rectangle([s * x0, s * 2 * top, s * x1, s * 2], outline=C.WHITE,
                    width=max(1, int(round(3 * scale))))
        for f in range(4):
            y = s * 2 * top + (f + 1) * (s * 2 * (1 - top)) / 5
            d.line([(s * x0 + 3 * scale, y), (s * x1 - 3 * scale, y)], fill=(*C.BLUE, 190),
                   width=max(1, int(round(2 * scale))))
    return img


def mountain(size_ref: float, scale: float) -> Image.Image:
    s = max(8, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s * 2, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(0, s), (s * 0.62, s * 0.10), (s * 1.24, s)], outline=C.BLUE,
              width=max(1, int(round(4 * scale))))
    d.polygon([(s * 0.9, s), (s * 1.45, s * 0.34), (s * 2, s)], outline=C.WHITE,
              width=max(1, int(round(3 * scale))))
    return img


def galaxy(size_ref: float, scale: float, particles: int = 2000) -> Image.Image:
    """Seeded two-arm spiral (R-SCN-09 stage 6)."""
    s = max(16, int(round(size_ref * scale)))
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    rng = C.rng(f"galaxy:{particles}")
    n = int(particles)
    arm = rng.integers(0, 2, n)
    rad = rng.random(n) ** 0.6
    ang = arm * math.pi + rad * 3.1 + rng.standard_normal(n) * 0.16
    rr = rad * s * 0.47
    xs = s / 2 + np.cos(ang) * rr
    ys = s / 2 + np.sin(ang) * rr * 0.62
    sizes = np.clip((1.0 - rad) * 3.2 + 0.6, 0.6, 3.6) * scale
    colors = [C.WHITE, C.BLUE, C.ORANGE]
    for i in range(n):
        col = colors[0] if rad[i] < 0.18 else (colors[1] if (i % 7) else colors[2])
        a = int(255 * clamp_f(0.25 + 0.75 * (1.0 - rad[i])))
        r = float(sizes[i])
        d.ellipse([xs[i] - r, ys[i] - r, xs[i] + r, ys[i] + r], fill=(*col, a))
    return img


def clamp_f(v: float) -> float:
    return 0.0 if v < 0 else (1.0 if v > 1 else v)


_BUILDERS = {
    "coin": coin,
    "lock": lock,
    "creature": creature,
    "heart": heart,
    "ring": ring,
    "planet": planet,
    "sun": sun,
    "meteor": meteor,
    "speedometer": speedometer,
    "telescope": icon_telescope,
    "flame": icon_flame,
    "human": human,
    "building": building,
    "mountain": mountain,
    "galaxy": galaxy,
    "core": radial_core,
}
