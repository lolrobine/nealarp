"""Buses, ducking and the two-pass loudnorm master (R-AUD-04, R-OUT-05).

    premix = music (ducked -6 dB under VO) + sfx bed + vo bus
    master = ffmpeg loudnorm two-pass -> I = -14 LUFS, TP = -1 dBTP, LRA = 11
"""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

import numpy as np

from . import config as C
from .audio import SR, db_to_amp, ffmpeg_exe, read_wav, read_wav_stereo, write_wav
from .timeline import load

ROOT = C.ROOT
RENDER_DIR = ROOT / "audio" / "render"
PREMIX = RENDER_DIR / "premix.wav"
MASTER_WAV = RENDER_DIR / "mix.wav"
MASTER_M4A = RENDER_DIR / "mix.m4a"
LOUDNESS_JSON = RENDER_DIR / "loudness.json"

DUCK_DB = -6.0
DUCK_ATTACK = 0.080
DUCK_RELEASE = 0.250


def _length() -> int:
    return int(round(C.DURATION * SR))


def read_stereo(path: Path) -> np.ndarray:
    """(N,2) float64, padded/trimmed to exactly 60.000 s. Stereo width is preserved."""
    if not path.exists():
        return np.zeros((_length(), 2))
    data = read_wav_stereo(path)
    n = _length()
    out = np.zeros((n, 2))
    m = min(n, data.shape[0])
    out[:m] = data[:m]
    return out


def build_vo_bus() -> tuple[np.ndarray, list[dict]]:
    bus = np.zeros((_length(), 2))
    manifest_path = RENDER_DIR / "vo_manifest.json"
    if not manifest_path.exists():
        raise SystemExit("audio/render/vo_manifest.json missing - run: python -m src.vo")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    placed: list[dict] = []
    for line in manifest["lines"]:
        path = Path(line["path"])
        if not path.exists():
            raise SystemExit(f"voiceover clip missing: {path}")
        sig = read_wav(path)
        start = int(round(float(line["at"]) * SR))
        end = min(_length(), start + sig.shape[0])
        bus[start:end, 0] += sig[: end - start]
        bus[start:end, 1] += sig[: end - start]
        placed.append({"id": line["id"], "at": float(line["at"]),
                       "sample_start": start, "samples": int(sig.shape[0]),
                       "duration": sig.shape[0] / SR, "provider": line["provider"],
                       "placeholder": line.get("placeholder", False)})
    return bus, placed


def duck_envelope(vo_bus: np.ndarray) -> np.ndarray:
    """-6 dB gain on the music bus while voiceover plays, with 80 ms attack / 250 ms release."""
    mono = np.abs(vo_bus).max(axis=1)
    active = (mono > 1e-4).astype(np.float64)
    target = np.where(active > 0, db_to_amp(DUCK_DB), 1.0)

    up = max(1, int(DUCK_ATTACK * SR))
    down = max(1, int(DUCK_RELEASE * SR))
    env = np.ones_like(target)
    cur = 1.0
    # one-pole follower, evaluated on a coarse grid and interpolated (fast, deterministic)
    grid = max(1, SR // 1000)          # 1 ms resolution
    marks = target[::grid]
    coarse = np.ones_like(marks)
    for i, v in enumerate(marks):
        step = 1.0 / (up / grid) if v < cur else 1.0 / (down / grid)
        cur += (v - cur) * min(1.0, step)
        coarse[i] = cur
    idx = np.arange(target.shape[0])
    env = np.interp(idx / grid, np.arange(coarse.shape[0]), coarse)
    return env[:, None]


def assert_sfx_density(manifest_path: Path | None = None) -> dict:
    """R-AUD-03: never more than two effects at once."""
    tl = load()
    events = tl.sfx_events()
    worst = 0
    for a in events:
        stack = [b for b in events
                 if b["at"] < a["at"] + a.get("duration", 0.4) and b["at"] + b.get("duration", 0.4) > a["at"]]
        worst = max(worst, len(stack))
    report = {"max_simultaneous_sfx": worst, "limit": 2, "pass": worst <= 2, "events": len(events)}
    (manifest_path or RENDER_DIR / "sfx_density.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def premix() -> Path:
    music = read_stereo(RENDER_DIR / "music.wav")
    sfx = read_stereo(RENDER_DIR / "sfx.wav")
    vo, placed = build_vo_bus()

    music = music * duck_envelope(vo)
    out = music + sfx + vo * 1.06

    peak = float(np.max(np.abs(out))) or 1.0
    if peak > 0.99:                      # keep headroom for the loudnorm pass
        out = out * (0.99 / peak)
    write_wav(PREMIX, out, stereo=True)
    (RENDER_DIR / "vo_placement.json").write_text(json.dumps(placed, indent=2), encoding="utf-8")
    return PREMIX


def _run(cmd: list[str]) -> str:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    return proc.stdout + proc.stderr


def loudnorm_pass1(src: Path) -> dict:
    out = _run([ffmpeg_exe(), "-hide_banner", "-nostats", "-i", str(src), "-af",
                f"loudnorm=I={C.TARGET_LUFS}:TP={C.TARGET_TP}:LRA={C.TARGET_LRA}:print_format=json",
                "-f", "null", "-"])
    match = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", out, re.S)
    if not match:
        raise SystemExit("loudnorm pass 1 produced no measurement JSON:\n" + out[-2000:])
    return json.loads(match.group(0))


def loudnorm_pass2(src: Path, meas: dict, dst_wav: Path, dst_m4a: Path) -> None:
    af = (f"loudnorm=I={C.TARGET_LUFS}:TP={C.TARGET_TP}:LRA={C.TARGET_LRA}"
          f":measured_I={meas['input_i']}:measured_TP={meas['input_tp']}"
          f":measured_LRA={meas['input_lra']}:measured_thresh={meas['input_thresh']}"
          f":offset={meas.get('target_offset', 0.0)}:linear=true:print_format=summary")
    _run([ffmpeg_exe(), "-y", "-hide_banner", "-i", str(src), "-af", af, "-ar", str(SR),
          "-ac", "2", "-c:a", "pcm_s16le", str(dst_wav)])
    _run([ffmpeg_exe(), "-y", "-hide_banner", "-i", str(dst_wav), "-c:a", C.AUDIO_CODEC,
          "-b:a", "192k", "-ar", str(SR), "-ac", "2", "-t", f"{C.DURATION:.3f}", str(dst_m4a)])


def measure(dst: Path) -> dict:
    out = _run([ffmpeg_exe(), "-hide_banner", "-nostats", "-i", str(dst), "-af",
                "ebur128=peak=true:metadata=1,astats=metadata=1:reset=0", "-f", "null", "-"])
    m = {}
    for key, pattern in (("integrated", r"I:\s*(-?\d+(?:\.\d+)?)\s*LUFS"),
                         ("lra", r"LRA:\s*(-?\d+(?:\.\d+)?)\s*LU"),
                         ("true_peak", r"Peak:\s*(-?\d+(?:\.\d+)?)\s*dBFS")):
        found = re.findall(pattern, out)
        if found:
            m[key] = float(found[-1])
    m["pass_loudness"] = abs(m.get("integrated", -99) - C.TARGET_LUFS) <= 1.0
    m["pass_true_peak"] = m.get("true_peak", 0.0) <= C.TARGET_TP + 1e-9
    return m


def main() -> int:
    RENDER_DIR.mkdir(parents=True, exist_ok=True)
    density = assert_sfx_density()
    print(f"sfx density: max {density['max_simultaneous_sfx']} simultaneous "
          f"({'PASS' if density['pass'] else 'FAIL'})")

    src = premix()
    print(f"premix -> {src}")
    meas = loudnorm_pass1(src)
    print(f"loudnorm pass 1: I={meas['input_i']} TP={meas['input_tp']} LRA={meas['input_lra']}")
    loudnorm_pass2(src, meas, MASTER_WAV, MASTER_M4A)
    result = measure(MASTER_M4A)
    payload = {"pass1": meas, "master": result, "targets": {
        "integrated_lufs": C.TARGET_LUFS, "true_peak_dbtp": C.TARGET_TP, "lra": C.TARGET_LRA},
        "sfx_density": density}
    LOUDNESS_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    print(f"master -> {MASTER_M4A}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
