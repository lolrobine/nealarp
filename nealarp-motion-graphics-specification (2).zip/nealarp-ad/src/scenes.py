"""Scene painters — one function per element type declared in timeline.yaml (R-SCN-01..11).

A painter is a pure function of (frame image, t, element). It never stores state and never
reads the clock except through `ctx.t`, so frames can be rendered in any order, in
parallel, or twice (R-OUT-02, R-VER-13).

Text is never drawn here: painters that need a number on screen build a dynamic text entry
and hand it to the TextSystem, which keeps the layout log complete (R-TXT-02).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from . import config as C
from . import layers, particles, sprites
from .easing import apply, clamp, lerp, progress
from .timeline import Element, Scene


@dataclass
class Ctx:
    img: Image.Image
    t: float
    scale: float
    text: Any
    scene: Scene | None = None
    mods: dict[str, Any] = field(default_factory=dict)

    @property
    def w(self) -> int:
        return self.img.size[0]

    @property
    def h(self) -> int:
        return self.img.size[1]

    def __post_init__(self) -> None:
        # One shared RGBA overlay per frame: painters may use RGBA fills (arcs, rings,
        # trails) without each of them allocating and compositing a full-frame layer.
        self._ov = Image.new("RGBA", self.img.size, (0, 0, 0, 0))
        self._od = ImageDraw.Draw(self._ov)

    def draw(self) -> ImageDraw.ImageDraw:
        """Draw context with full alpha support. Composited by `flush()`."""
        return self._od

    def flush(self) -> None:
        """Composite the overlay onto the frame and start a clean one."""
        if self._ov.getbbox() is not None:
            self.img.paste(self._ov, (0, 0), self._ov)
        self._ov = Image.new("RGBA", self.img.size, (0, 0, 0, 0))
        self._od = ImageDraw.Draw(self._ov)

    def p(self, el: Element) -> float:
        return apply(el.ease, progress(self.t, el.start, el.end))

    def raw(self, el: Element) -> float:
        return progress(self.t, el.start, el.end)

    def find(self, eid: str) -> Element | None:
        return self.scene.element(eid) if self.scene else None

    def find_text(self, tid: str):
        return self.scene.text_entry(tid) if self.scene else None

    def additive(self, fn: Callable[[np.ndarray], None]) -> None:
        """Run `fn` on a float32 copy of the frame (additive light/particles)."""
        arr = np.asarray(self.img, dtype=np.float32).copy()
        fn(arr)
        self.img.paste(Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)), (0, 0))

    def paste_sprite(self, spr: Image.Image, cx: float, cy: float, alpha: float = 1.0,
                     size_ref: float | None = None) -> None:
        if alpha <= 0.004:
            return
        img = spr
        if size_ref is not None:
            target = max(2, int(round(size_ref * self.scale)))
            if img.width != target:
                ratio = target / img.width
                img = img.resize((target, max(2, int(round(img.height * ratio)))), Image.LANCZOS)
        if alpha < 0.999:
            img = img.copy()
            img.putalpha(img.getchannel("A").point(lambda v: int(round(v * clamp(alpha)))))
        box = (int(round(cx * self.scale - img.width / 2)), int(round(cy * self.scale - img.height / 2)))
        self.img.paste(img, box, img)

    def glow_ellipse(self, cx: float, cy: float, r: float, color, alpha: float, blur: float = 8.0) -> None:
        if alpha <= 0.004 or r <= 0:
            return
        s = int(max(4, r * 2 * self.scale + blur * 4 * self.scale))
        ov = Image.new("RGBA", (s, s), (0, 0, 0, 0))
        d = ImageDraw.Draw(ov)
        c = s / 2
        rr = r * self.scale
        d.ellipse([c - rr, c - rr, c + rr, c + rr], fill=(*C.color(color), int(round(255 * clamp(alpha)))))
        ov = ov.filter(ImageFilter.GaussianBlur(max(0.5, blur * self.scale)))
        self.img.paste(ov, (int(round(cx * self.scale - c)), int(round(cy * self.scale - c))), ov)


def draw_dynamic_text(ctx: Ctx, string: str, layout: str, at=None, size: int | None = None,
                      alpha: float = 1.0, tag: str = "") -> None:
    """Numeric/data readouts still go through the text layout system (R-TXT-02)."""
    entry = {
        "id": f"dyn:{layout}:{tag}:{string}",
        "string": string, "layout": layout,
        "start": ctx.t, "end": ctx.t + 1.0 / C.FPS, "ease": "STEP",
        "at": tuple(at) if at else None, "size": size,
        "props": {"fade_in": 0.0, "dynamic": True},
    }
    ctx.text.draw(ctx.img, entry, ctx.t, alpha=alpha, draw_panel=False)


# ============================================================ opening (R-SCN-01)
def paint_particle_tunnel(ctx: Ctx, el: Element) -> None:
    pts = particles.tunnel(ctx.t, el.start, el.center, el.props, ctx.scale)
    ctx.additive(lambda a: particles.draw_points(a, pts, ctx.scale))


def paint_converge_to_title(ctx: Ctx, el: Element) -> None:
    entry = ctx.find_text(el.props["text_id"])
    if entry is None:
        return
    n = 1400
    targets = ctx.text.sample_points(entry, n)
    tunnel_el = ctx.find("tunnel")
    if tunnel_el is None:
        return
    src = particles.tunnel(el.start, tunnel_el.start, tunnel_el.center, tunnel_el.props, ctx.scale)
    m = min(n, len(src), targets.shape[0])
    p = ctx.p(el)
    snap = float(el.props.get("snap", 0.85))
    e = apply("EASE_IO", clamp(p / snap))
    white = np.array(C.WHITE, dtype=np.float32)[None, :]
    src_col = src.color[:m].astype(np.float32)
    hot = src_col + (white - src_col) * clamp(e * 1.15)[:, None]
    pts = particles.Points(
        x=lerp(src.x[:m], targets[:m, 0], e),
        y=lerp(src.y[:m], targets[:m, 1], e),
        r=lerp(src.r[:m], np.full(m, 2.2), e),
        color=np.clip(hot, 0, 255).astype(np.uint8),
        alpha=src.alpha[:m] * (1.0 - 0.85 * clamp((p - snap) / max(1e-6, 1 - snap))),
    )
    ctx.additive(lambda a: particles.draw_points(a, pts, ctx.scale))


def paint_anamorphic_flare(ctx: Ctx, el: Element) -> None:
    p = el.props
    layers.anamorphic_flare(ctx.img, el.center, ctx.p(el), float(p.get("length", 1400)),
                            float(p.get("height", 6)), float(p.get("glow", 120)), ctx.scale,
                            p.get("color", "white"))


def paint_letter_trails(ctx: Ctx, el: Element) -> None:
    """Declarative: the tails themselves are drawn by TextSystem (props.tail_letters)."""
    return None


def paint_offscreen_flicker(ctx: Ctx, el: Element) -> None:
    p = el.props
    ctx.additive(lambda a: layers.offscreen_flicker_arr(
        a, el.center, ctx.raw(el), p.get("color", "blue"), float(p.get("intensity", 0.4)), ctx.scale))


# ============================================================ shared cut parts
def paint_cut_pop(ctx: Ctx, el: Element) -> None:
    p = el.props
    layers.cut_pop(ctx.img, el.center, ctx.raw(el), float(p.get("radius", 900)),
                   p.get("color", "blue"), float(p.get("alpha", 0.3)), ctx.scale)


def paint_glass_panel(ctx: Ctx, el: Element) -> None:
    p = el.props
    fade = float(p.get("fade_in", 0.5))
    a = apply("EASE_OUT_EARLY", progress(ctx.t, el.start, el.start + fade))
    if a <= 0.01:
        return
    layers.glass_panel(ctx.img, el.rect, float(p.get("radius", 24)), ctx.scale, alpha=a,
                       blur=float(p.get("blur", 20)))


def paint_light_streaks(ctx: Ctx, el: Element) -> None:
    p = el.props
    a = math.sin(math.pi * clamp(ctx.raw(el))) if el.end - el.start < 2.0 else 1.0
    layers.light_streaks(ctx.img, el.center, int(p.get("count", 8)), list(p.get("colors", ["blue", "orange"])),
                         float(p.get("length", 900)), float(p.get("alpha", 0.35)) * a,
                         ctx.scale, ctx.t, float(p.get("drift", 0.0)))


def paint_transition_out(ctx: Ctx, el: Element) -> None:
    p = el.props
    out = layers.transition_out(ctx.img, p.get("mode", "wipe_left"), ctx.p(el),
                                p.get("color", "black"), float(p.get("alpha", 1.0)))
    ctx.img.paste(out, (0, 0))


def paint_camera_shake(ctx: Ctx, el: Element) -> None:
    """Declarative: compose pre-collects shake offsets and shifts the finished frame."""
    return None


# ============================================================ cut 1 (R-SCN-02)
def paint_coin_cascade(ctx: Ctx, el: Element) -> None:
    p = el.props
    n = int(p.get("count", 24))
    rng = C.rng("coin-cascade")
    xs = el.center[0] + (rng.random(n) - 0.5) * 520.0
    dmin, dmax = float(p.get("diameter_min", 80)), float(p.get("diameter_max", 110))
    diam = np.round(dmin + rng.random(n) * (dmax - dmin)).astype(int)
    stag = rng.random(n) * float(p.get("stagger_max", 0.6))
    y_from, y_to = float(p.get("y_from", -100)), float(p.get("y_to", 420))
    fall = 0.9
    for i in range(n):
        st = el.start + float(stag[i])
        pr = clamp((ctx.t - st) / fall)
        if pr <= 0:
            continue
        e = apply(el.ease, pr)
        y = lerp(y_from, y_to, e)
        spin = abs(math.cos((ctx.t - st) * 3.4 + i)) if p.get("spin", True) else 1.0
        spin_q = round(max(0.12, spin), 1)
        spr = sprites.sprite("coin", int(diam[i]), ctx.scale, spin=spin_q)
        land = 1.0 - clamp((ctx.t - (st + fall)) / 0.18) * 0.0
        ctx.paste_sprite(spr, float(xs[i]), y, alpha=clamp(pr * 6) * land)
        if pr >= 0.98:
            ctx.glow_ellipse(float(xs[i]), y, float(diam[i]) * 0.55, C.BLUE, 0.10 * (1 - clamp((ctx.t - st - fall) / 0.6)))


# ============================================================ cut 2 (R-SCN-03)
def paint_lock_body(ctx: Ctx, el: Element) -> None:
    p = el.props
    x, y, w, h = el.rect
    r = float(p.get("radius", 32)) * ctx.scale
    scale_mul = float(ctx.mods.get("lock_scale", 1.0))
    cx, cy = (x + w / 2) * ctx.scale, (y + h / 2) * ctx.scale
    bw, bh = w * ctx.scale * scale_mul, h * ctx.scale * scale_mul
    box = [cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2]

    grad = layers.linear_gradient((max(2, int(bw)), max(2, int(bh))), (248, 250, 255), (150, 165, 190), axis="y")
    body = Image.fromarray(grad.astype(np.uint8), "RGB").convert("RGBA")
    mask = Image.new("L", body.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, body.width - 1, body.height - 1], radius=r, fill=255)
    body.putalpha(mask)

    glow = Image.new("RGBA", body.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.rounded_rectangle([6 * ctx.scale, 6 * ctx.scale, body.width - 6 * ctx.scale, body.height - 6 * ctx.scale],
                         radius=max(1, r - 6 * ctx.scale), outline=(*C.BLUE, 200),
                         width=max(1, int(round(8 * ctx.scale))))
    glow = glow.filter(ImageFilter.GaussianBlur(max(1.0, float(p.get("inner_glow_blur", 16)) * ctx.scale / 2)))
    body = Image.alpha_composite(body, glow)
    ctx.img.paste(body, (int(box[0]), int(box[1])), body)


def paint_shackle(ctx: Ctx, el: Element) -> None:
    p = el.props
    r = float(p.get("radius", 110)) * ctx.scale
    stroke = max(1, int(round(float(p.get("stroke", 28)) * ctx.scale)))
    cx, cy = el.center[0] * ctx.scale, el.center[1] * ctx.scale
    grow = apply("EASE_OUT_EARLY", progress(ctx.t, el.start, el.start + 0.4))
    d = ctx.draw()
    d.arc([cx - r, cy - r * grow, cx + r, cy + r * grow], start=180, end=360,
          fill=C.color(p.get("color", "white")), width=stroke)


def paint_glyph_rows(ctx: Ctx, el: Element) -> None:
    """12 rows of mono glyphs scrolling up across the lock body at 120 px/s."""
    p = el.props
    x, y, w, h = (v * ctx.scale for v in el.rect)
    rows = int(p.get("rows", 12))
    gpx = float(p.get("glyph_px", 10)) * ctx.scale
    speed = float(p.get("speed", 120)) * ctx.scale
    charset = str(p.get("charset", "01"))
    alpha = int(round(255 * float(p.get("alpha", 0.4))))
    font = C.FONT_MONO

    layer = Image.new("RGBA", (int(w) + 2, int(h) + 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    row_h = h / rows
    offset = (ctx.t - el.start) * speed
    rng = C.rng("glyph-rows")
    cols = max(4, int(w / (gpx * 1.35)))
    grid = rng.integers(0, len(charset), size=(rows + 2, cols))
    for r_i in range(rows + 1):
        yy = r_i * row_h - (offset % row_h)
        if yy < -row_h or yy > h:
            continue
        for c_i in range(cols):
            ch = charset[int(grid[r_i % (rows + 1), c_i])]
            d.text((c_i * (w / cols), yy), ch, font=layers_font(font, gpx), fill=(*C.WHITE, alpha))
    mask = Image.new("L", layer.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, layer.width - 1, layer.height - 1],
                                           radius=max(1, 18 * ctx.scale), fill=255)
    layer.putalpha(Image.composite(layer.getchannel("A"), Image.new("L", layer.size, 0), mask))
    ctx.img.paste(layer, (int(x), int(y)), layer)


_FONT_CACHE: dict[tuple[str, int], Any] = {}


def layers_font(path: str, size_px: float):
    from .text import load_font

    return load_font(path, max(4, int(round(size_px))))


def paint_lock_click(ctx: Ctx, el: Element) -> None:
    """Declarative: compose pre-collects the scale modifier used by paint_lock_body."""
    return None


def paint_check_circles(ctx: Ctx, el: Element) -> None:
    p = el.props
    times = [float(a) for a in p.get("at", [])]
    r = float(p.get("radius", 36))
    spacing = float(p.get("spacing", 120))
    n = len(times) or int(p.get("count", 5))
    for i, at in enumerate(times or [el.start] * n):
        pr = clamp((ctx.t - at) / 0.28)
        if pr <= 0:
            continue
        e = apply("EXPO_OUT", pr)
        cx = el.center[0] + (i - (n - 1) / 2) * spacing
        cy = el.center[1]
        rr = r * lerp(0.4, 1.0, e) * ctx.scale
        col = C.color(p.get("color", "orange"))
        ctx.glow_ellipse(cx, cy, rr * 1.5, col, 0.30 * e, blur=float(p.get("glow", 18)))
        d = ctx.draw()
        d.ellipse([cx * ctx.scale - rr, cy * ctx.scale - rr, cx * ctx.scale + rr, cy * ctx.scale + rr],
                  fill=col)
        sw = max(2, int(round(float(p.get("stroke", 6)) * ctx.scale)))
        s = rr * 0.52 * e
        d.line([(cx * ctx.scale - s, cy * ctx.scale), (cx * ctx.scale - s * 0.2, cy * ctx.scale + s * 0.7),
                (cx * ctx.scale + s, cy * ctx.scale - s * 0.75)], fill=C.WHITE, width=sw, joint="curve")


# ============================================================ cut 3 (R-SCN-04)
def paint_sea_gradient(ctx: Ctx, el: Element) -> None:
    p = el.props
    alpha = float(p.get("bottom_alpha", 0.12))

    def edit(a: np.ndarray) -> None:
        h, w = a.shape[:2]
        ramp = np.linspace(0.0, 1.0, h, dtype=np.float32)[None, :, None] ** 1.5
        blue = np.array(C.color(p.get("bottom", "blue")), dtype=np.float32)[None, None, :]
        a += blue * ramp * alpha

    ctx.additive(edit)


def paint_dive_particles(ctx: Ctx, el: Element) -> None:
    pts = particles.dive(ctx.t, el.start, el.rect, dict(el.props, ease=el.ease), ctx.scale)
    ctx.additive(lambda a: particles.draw_points(a, pts, ctx.scale))


def paint_creatures(ctx: Ctx, el: Element) -> None:
    p = el.props
    n = int(p.get("count", 12))
    rng = C.rng("creatures")
    colors = list(p.get("colors", ["blue", "orange"]))
    for i in range(n):
        z = lerp(float(p.get("z_min", 200)), float(p.get("z_max", 1600)), rng.random())
        wx = (rng.random() - 0.5) * 1900
        wy = (rng.random() - 0.5) * 900
        sx, sy, k = layers.project(wx, wy, z, el.center[0] * ctx.scale, el.center[1] * ctx.scale)
        sx /= ctx.scale
        sy /= ctx.scale
        size = lerp(float(p.get("size_max", 140)), float(p.get("size_min", 60)), (z - p.get("z_min", 200)) /
                   max(1.0, float(p.get("z_max", 1600)) - float(p.get("z_min", 200))))
        col = colors[i % len(colors)]
        appear = apply("EASE_IO", progress(ctx.t, el.start + i * 0.06, el.start + 0.5 + i * 0.06))
        bob = math.sin(ctx.t * 1.1 + i) * 10
        spr = sprites.sprite("creature", int(round(size / 10) * 10), ctx.scale, color=col)
        ctx.paste_sprite(spr, sx, sy + bob, alpha=appear * (0.55 + 0.45 * k))
        ctx.glow_ellipse(sx, sy + bob, size * 0.7, C.color(col), 0.16 * appear * k, blur=float(p.get("glow", 26)))


def paint_bubbles(ctx: Ctx, el: Element) -> None:
    pts = particles.bubbles(ctx.t, el.start, el.rect, el.props, ctx.scale)
    ctx.additive(lambda a: particles.draw_points(a, pts, ctx.scale))


def paint_depth_counter(ctx: Ctx, el: Element) -> None:
    p = el.props
    anchors = p["anchors"]
    cu = float(p.get("count_up", 0.3))
    value = float(anchors[0]["value"])
    for i, a in enumerate(anchors):
        if ctx.t >= float(a["at"]):
            value = float(a["value"])
            if i > 0:
                prev = float(anchors[i - 1]["value"])
                value = lerp(prev, float(a["value"]), apply("EASE_IO", progress(ctx.t, float(a["at"]), float(a["at"]) + cu)))
    draw_dynamic_text(ctx, f"{C.de_int(value)} {p.get('unit', 'm')}", "counter_center",
                      at=el.center, tag="depth")


# ============================================================ cut 4 (R-SCN-05)
def paint_speed_streaks(ctx: Ctx, el: Element) -> None:
    st = particles.speed_streaks(ctx.t, el.start, el.rect, el.props, ctx.scale)
    ctx.additive(lambda a: particles.draw_streaks(a, st, ctx.scale))


def paint_speedometer(ctx: Ctx, el: Element) -> None:
    p = el.props
    r = float(p.get("radius", 300)) * ctx.scale
    cx, cy = el.center[0] * ctx.scale, el.center[1] * ctx.scale
    stroke = max(1, int(round(float(p.get("stroke", 14)) * ctx.scale)))
    # spec 210deg -> -30deg (math, y-up) == Pillow 150deg -> 390deg over the top
    a0, a1 = 150.0, 390.0
    d = ctx.draw()
    d.arc([cx - r, cy - r, cx + r, cy + r], start=a0, end=a1,
          fill=(*C.WHITE, int(round(255 * float(p.get("track_alpha", 0.18))))), width=stroke)

    sweep = apply("EXPO_OUT", progress(ctx.t, el.start, el.start + float(p.get("needle_sweep", 1.2))))
    ticks = int(p.get("ticks", 24))
    for i in range(ticks + 1):
        frac = i / ticks
        ang = math.radians(lerp(a0, a1, frac))
        r0 = r * (0.86 if i % 4 else 0.92)
        lit = frac <= sweep
        col = C.color(p.get("arc_color", "blue")) if lit else C.WHITE
        d.line([cx + math.cos(ang) * r0, cy + math.sin(ang) * r0,
                cx + math.cos(ang) * r * 0.99, cy + math.sin(ang) * r * 0.99],
               fill=(*col, 235 if lit else 90), width=max(1, int(round(3 * ctx.scale))))

    # progress arc
    if sweep > 0.002:
        d.arc([cx - r, cy - r, cx + r, cy + r], start=a0, end=lerp(a0, a1, sweep),
              fill=C.color(p.get("arc_color", "blue")), width=stroke)

    ang = math.radians(lerp(a0, a1, sweep))
    nl = r * 0.80
    d.line([cx - math.cos(ang) * r * 0.14, cy - math.sin(ang) * r * 0.14,
            cx + math.cos(ang) * nl, cy + math.sin(ang) * nl],
           fill=C.color(p.get("needle_color", "orange")), width=max(2, int(round(6 * ctx.scale))))
    hub = 12 * ctx.scale
    d.ellipse([cx - hub, cy - hub, cx + hub, cy + hub], fill=C.WHITE)


def paint_morph_glyph(ctx: Ctx, el: Element) -> None:
    p = el.props
    cf = float(p.get("crossfade", 0.15))
    a_in = apply("EASE_IO", progress(ctx.t, el.start, el.start + cf))
    a_out = 1.0 - apply("EASE_IO", progress(ctx.t, el.end - cf, el.end))
    alpha = clamp(min(a_in, a_out))
    if alpha <= 0.01:
        return
    col = C.color(p.get("color", "white"))
    size = float(p.get("size", 180)) * ctx.scale
    cx, cy = el.center[0] * ctx.scale, el.center[1] * ctx.scale
    d = ctx.draw()
    g = p.get("glyph", "snail")
    lw = max(2, int(round(6 * ctx.scale)))

    if g == "snail":  # spiral arc
        for k in range(3):
            rr = size * (0.16 + 0.14 * k)
            d.arc([cx - rr, cy - rr, cx + rr, cy + rr], start=200 + k * 40, end=520 + k * 40,
                  fill=(*col, int(255 * alpha * (1 - k * 0.22))), width=lw)
    elif g == "cheetah":  # three trailing dots + a wedge
        for k in range(3):
            rr = size * (0.05 + 0.03 * k)
            xx = cx - size * (0.42 - 0.28 * k)
            d.ellipse([xx - rr, cy - rr, xx + rr, cy + rr], fill=(*col, int(255 * alpha * (0.4 + 0.3 * k))))
        d.polygon([(cx - size * 0.1, cy - size * 0.16), (cx + size * 0.46, cy),
                   (cx - size * 0.1, cy + size * 0.16)], fill=(*col, int(255 * alpha)))
    elif g == "rocket":  # triangle on a rectangle
        d.rectangle([cx - size * 0.11, cy - size * 0.18, cx + size * 0.11, cy + size * 0.34],
                    outline=(*col, int(255 * alpha)), width=lw)
        d.polygon([(cx - size * 0.11, cy - size * 0.18), (cx + size * 0.11, cy - size * 0.18),
                   (cx, cy - size * 0.5)], fill=(*col, int(255 * alpha)))
    elif g == "beam":  # vertical gradient line
        hgt = int(size * 1.1)
        grad = layers.linear_gradient((max(2, lw * 3), hgt), C.WHITE, C.color(p.get("color", "blue")), axis="y")
        beam = Image.fromarray((grad * alpha).astype(np.uint8), "RGB").convert("RGBA")
        ctx.img.paste(beam, (int(cx - beam.width / 2), int(cy - hgt / 2)), beam)


def paint_title_pulse(ctx: Ctx, el: Element) -> None:
    """Declarative: compose pre-collects the pulse scale for the referenced text entry."""
    return None


# ============================================================ cut 5 (R-SCN-06)
def paint_planet_disk(ctx: Ctx, el: Element) -> None:
    p = el.props
    r = float(p.get("radius", 210))
    appear = apply("EASE_OUT_EARLY", progress(ctx.t, el.start, el.start + 0.5))
    spr = sprites.sprite("planet", int(r * 2), ctx.scale)
    ctx.paste_sprite(spr, el.center[0], el.center[1], alpha=appear, size_ref=r * 2 * lerp(0.94, 1.0, appear))


def paint_meteor(ctx: Ctx, el: Element) -> None:
    p = el.props
    fx, fy = p["from"]
    tx, ty = p["to"]
    e = apply("EASE_IO", progress(ctx.t, el.start, el.end))
    hx, hy = lerp(fx, tx, e), lerp(fy, ty, e)
    tail = 0.34
    t0 = max(0.0, e - tail)
    d = ctx.draw()
    steps = 26
    for i in range(steps):
        f0 = lerp(t0, e, i / steps)
        f1 = lerp(t0, e, (i + 1) / steps)
        a = (i / steps) * float(p.get("trail_alpha_from", 1.0))
        w = max(1, int(round(lerp(2, float(p.get("head_px", 26)) * 0.55, i / steps) * ctx.scale)))
        d.line([lerp(fx, tx, f0) * ctx.scale, lerp(fy, ty, f0) * ctx.scale,
                lerp(fx, tx, f1) * ctx.scale, lerp(fy, ty, f1) * ctx.scale],
               fill=(*C.color(p.get("trail_color", "orange")), int(255 * a)), width=w)
    ctx.flush()  # trail must stay under the glowing head
    spr = sprites.sprite("meteor", int(float(p.get("head_px", 26)) * 2.4), ctx.scale)
    ctx.paste_sprite(spr, hx, hy, alpha=1.0)


def paint_shockwave(ctx: Ctx, el: Element) -> None:
    p = el.props
    rings = int(p.get("rings", 5))
    dur = float(p.get("duration", 1.5))
    rmax = float(p.get("radius_to", 700))
    stroke = max(1, int(round(float(p.get("stroke", 3)) * ctx.scale)))
    d = ctx.draw()
    for i in range(rings):
        st = el.start + i * 0.12
        e = apply("EXPO_OUT", progress(ctx.t, st, st + dur))
        if e <= 0:
            continue
        r = rmax * e * ctx.scale
        a = clamp(1.0 - e) * (1.0 - i * 0.14)
        cx, cy = el.center[0] * ctx.scale, el.center[1] * ctx.scale
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(*C.color(p.get("color", "orange")), int(255 * a)),
                  width=stroke)


def paint_crater(ctx: Ctx, el: Element) -> None:
    p = el.props
    e = apply("EXPO_OUT", progress(ctx.t, el.start, el.start + 0.4))
    rx = float(p.get("radius_x", 74)) * e * ctx.scale
    ry = float(p.get("radius_y", 30)) * e * ctx.scale
    cx, cy = el.center[0] * ctx.scale, el.center[1] * ctx.scale
    d = ctx.draw()
    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=C.color(p.get("fill", "black")))
    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], outline=C.color(p.get("rim_color", "blue")),
              width=max(1, int(round(float(p.get("rim_px", 3)) * ctx.scale))))


# ============================================================ cut 6 (R-SCN-07)
def paint_arc_draw(ctx: Ctx, el: Element) -> None:
    p = el.props
    r = float(p.get("radius", 220)) * ctx.scale
    cx, cy = el.center[0] * ctx.scale, el.center[1] * ctx.scale
    stroke = max(1, int(round(float(p.get("stroke", 14)) * ctx.scale)))
    dur = float(p.get("duration", 1.2))
    e = apply(el.ease, progress(ctx.t, el.start, el.start + dur))
    if e <= 0.001:
        return
    end = lerp(float(p.get("sweep_from", 0)), float(p.get("sweep_to", 360)), e)
    d = ctx.draw()
    d.arc([cx - r, cy - r, cx + r, cy + r], start=270, end=270 + end,
          fill=C.color(p.get("color", "orange")), width=stroke)
    inset = float(p.get("core_inset", 4)) * ctx.scale
    core_w = max(1, int(round(float(p.get("core_stroke", 4)) * ctx.scale)))
    d.arc([cx - r + inset, cy - r + inset, cx + r - inset, cy + r - inset], start=270, end=270 + end,
          fill=(*C.color(p.get("core_color", "white")), int(round(255 * float(p.get("core_alpha", 0.4))))),
          width=core_w)


def paint_dashed_ring(ctx: Ctx, el: Element) -> None:
    p = el.props
    r = float(p.get("radius", 220)) * ctx.scale
    cx, cy = el.center[0] * ctx.scale, el.center[1] * ctx.scale
    dash = float(p.get("dash", 12)) * ctx.scale
    gap = float(p.get("gap", 10)) * ctx.scale
    stroke = max(1, int(round(float(p.get("stroke", 2)) * ctx.scale)))
    circ = 2 * math.pi * r
    n = max(1, int(circ / (dash + gap)))
    step_deg = 360.0 / n
    dash_deg = step_deg * (dash / (dash + gap))
    a = int(round(255 * float(p.get("alpha", 0.5)))) * apply("EASE_OUT_EARLY", progress(ctx.t, el.start, el.start + 0.3))
    d = ctx.draw()
    for i in range(n):
        d.arc([cx - r, cy - r, cx + r, cy + r], start=i * step_deg, end=i * step_deg + dash_deg,
              fill=(*C.color(p.get("color", "white")), int(a)), width=stroke)


# ============================================================ cut 7 (R-SCN-08)
def _beat_phase(ctx: Ctx, el: Element) -> tuple[float, float]:
    p = el.props
    bpm = float(p.get("bpm", 72))
    period = 60.0 / bpm
    t0 = float(p.get("phase_start", el.start))
    dt = ctx.t - t0
    return dt / period, period


def paint_heart_glyph(ctx: Ctx, el: Element) -> None:
    p = el.props
    beats, period = _beat_phase(ctx, el)
    frac = beats - math.floor(beats)
    pulse = math.sin(math.pi * clamp(frac / 0.34)) if frac < 0.34 else 0.0
    scale_mul = lerp(float(p.get("scale_from", 1.0)), float(p.get("scale_to", 1.12)), clamp(pulse))
    size = float(p.get("size", 200))
    spr = sprites.sprite("heart", int(size), ctx.scale)
    appear = apply("EASE_OUT_EARLY", progress(ctx.t, el.start, el.start + 0.3))
    ctx.paste_sprite(spr, el.center[0], el.center[1], alpha=appear, size_ref=size * scale_mul)


def paint_pulse_rings(ctx: Ctx, el: Element) -> None:
    p = el.props
    beats, period = _beat_phase(ctx, el)
    life = float(p.get("life", 1.4))
    rmax = float(p.get("radius_to", 600))
    stroke = max(1, int(round(float(p.get("stroke", 3)) * ctx.scale)))
    d = ctx.draw()
    first = math.floor(beats - life / period)
    for k in range(int(first), int(math.floor(beats)) + 1):
        if k < 0:
            continue
        bt = float(p.get("phase_start", el.start)) + k * period
        e = apply("EXPO_OUT", progress(ctx.t, bt, bt + life))
        if e <= 0 or e >= 1:
            continue
        r = rmax * e * ctx.scale
        a = clamp(1.0 - e) * 0.85
        cx, cy = el.center[0] * ctx.scale, el.center[1] * ctx.scale
        d.ellipse([cx - r, cy - r, cx + r, cy + r],
                  outline=(*C.color(p.get("color", "blue")), int(255 * a)), width=stroke)


def paint_panel_numbers(ctx: Ctx, el: Element) -> None:
    p = el.props
    size = int(p.get("size", 96))
    for c in p.get("counters", []):
        e = apply("EASE_IO", progress(ctx.t, el.start, el.end))
        value = lerp(float(c["from"]), float(c["to"]), e)
        dec = int(c.get("decimals", 0))
        s = C.de_int(value) if dec == 0 else f"{value:.{dec}f}".replace(".", ",")
        draw_dynamic_text(ctx, s, "panel_number", at=c["at"], size=size, tag=c["text_id"])


# ============================================================ cut 8 (R-SCN-09)
def _stage_sprite(glyph: str, size_ref: float, scale: float, props: dict) -> Image.Image:
    if glyph == "galaxy":
        return sprites.sprite("galaxy", size_ref, scale, particles=int(props.get("particles", 2000)))
    if glyph == "earth":
        return sprites.sprite("planet", size_ref, scale)
    if glyph == "sun":
        return sprites.sprite("sun", size_ref, scale)
    return sprites.sprite(glyph, size_ref, scale)


def paint_zoom_stages(ctx: Ctx, el: Element) -> None:
    stages = el.props["stages"]
    tr = float(el.props.get("transition", 0.25))
    cur_i = 0
    for i, s in enumerate(stages):
        if ctx.t >= float(s["at"]):
            cur_i = i
    cur = stages[cur_i]
    base = 560.0
    p = apply("EXPO_OUT", progress(ctx.t, float(cur["at"]), float(cur["at"]) + tr)) if cur_i else 1.0
    ctx.paste_sprite(_stage_sprite(cur["glyph"], base, ctx.scale, cur), el.center[0], el.center[1],
                     alpha=0.35 + 0.65 * p, size_ref=base * lerp(1.22, 1.0, p))
    if cur_i and p < 1.0:
        prev = stages[cur_i - 1]
        ctx.paste_sprite(_stage_sprite(prev["glyph"], base, ctx.scale, prev), el.center[0], el.center[1],
                         alpha=(1.0 - p) * 0.9, size_ref=base * lerp(1.0, 0.62, p))


def paint_telescope_icon(ctx: Ctx, el: Element) -> None:
    p = el.props
    h = float(p.get("height", 120))
    draw_in = float(p.get("draw_in", 0.5))
    e = apply("EASE_OUT_EARLY", progress(ctx.t, el.start, el.start + draw_in))
    if e <= 0:
        return
    spr = sprites.sprite("telescope", h, ctx.scale, color=p.get("color", "white"), stroke=float(p.get("stroke", 6)))
    reveal_h = max(1, int(spr.height * e))
    crop = spr.crop((0, 0, spr.width, reveal_h))
    box = (int(round(el.center[0] * ctx.scale - spr.width / 2)), int(round(el.center[1] * ctx.scale - spr.height / 2)))
    ctx.img.paste(crop, box, crop)


# ============================================================ hero (R-SCN-10)
def paint_hero_sphere(ctx: Ctx, el: Element) -> None:
    p = el.props
    r = float(p.get("radius", 200))
    amp = float(p.get("pulse_amp", 0.03))
    hz = float(p.get("pulse_hz", 0.5))
    push = lerp(float(p.get("push_in_from", 1.0)), float(p.get("push_in_to", 1.15)), ctx.p(el))
    rr = r * (1.0 + amp * math.sin(math.tau * hz * ctx.t)) * push
    base = sprites.sprite("core", 480, ctx.scale, core=C.WHITE, mid=C.BLUE, rim=C.ORANGE, glow=90.0)
    ctx.paste_sprite(base, el.center[0], el.center[1], size_ref=rr * 2 * 1.45)
    ctx.glow_ellipse(el.center[0], el.center[1], rr * 1.25, C.BLUE, 0.18, blur=44.0)


def paint_orbiters(ctx: Ctx, el: Element) -> None:
    p = el.props
    w = float(p.get("angular_speed", 0.3))
    phase0 = float(p.get("phase0", 0.0))
    size = float(p.get("sprite_px", 76))
    dt = ctx.t - el.start
    for ring in p.get("rings", []):
        radius = float(ring["radius"])
        direction = float(ring.get("direction", 1))
        for i, name in enumerate(ring.get("sprites", [])):
            ang = phase0 + direction * w * dt + i * (math.tau / max(1, len(ring["sprites"])))
            ox = el.center[0] + math.cos(ang) * radius
            oy = el.center[1] + math.sin(ang) * radius * 0.36
            depth = 0.55 + 0.45 * ((math.sin(ang) + 1) / 2)
            spr = sprites.sprite(name, int(size), ctx.scale)
            ctx.paste_sprite(spr, ox, oy, alpha=depth, size_ref=size * lerp(0.72, 1.0, depth))


def paint_background_drift(ctx: Ctx, el: Element) -> None:
    pts = particles.drift(ctx.t, el.start, el.rect, el.props, ctx.scale)
    ctx.additive(lambda a: particles.draw_points(a, pts, ctx.scale))


# ============================================================ CTA (R-SCN-11)
def paint_explosion(ctx: Ctx, el: Element) -> None:
    pts = particles.explosion(ctx.t, el.start, el.center, el.props, ctx.scale)
    ctx.additive(lambda a: particles.draw_points(a, pts, ctx.scale))


def paint_reform_text(ctx: Ctx, el: Element) -> None:
    entry = ctx.find_text(el.props["text_id"])
    if entry is None:
        return
    targets = ctx.text.sample_points(entry, int(el.props.get("count", 2600)))
    pts = particles.reform(ctx.t, el.start, el.end, targets, el.center, el.props, ctx.scale)
    ctx.additive(lambda a: particles.draw_points(a, pts, ctx.scale))


def paint_underline_sweep(ctx: Ctx, el: Element) -> None:
    p = el.props
    entry = ctx.find_text(p.get("text_id", ""))
    sweep = float(p.get("sweep", 1.0))
    e = apply(el.ease, progress(ctx.t, el.start, el.start + sweep))
    if entry is not None and e > 0:
        m = ctx.text.metrics(entry)
        width = m.ink_ref[2]
    else:
        width = float(p.get("width", 900))
    h = float(p.get("height", 6)) * ctx.scale
    w = width * e * ctx.scale
    if w < 1:
        return
    x0 = el.center[0] * ctx.scale - width * ctx.scale / 2
    y0 = el.center[1] * ctx.scale - h / 2
    grad = layers.linear_gradient((max(2, int(w)), max(2, int(h))), C.BLUE, C.ORANGE, axis="x")
    bar = Image.fromarray(grad.astype(np.uint8), "RGB").convert("RGBA")
    mask = Image.new("L", bar.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, bar.width - 1, bar.height - 1], radius=h / 2, fill=255)
    bar.putalpha(mask)
    ctx.img.paste(bar, (int(x0), int(y0)), bar)


def paint_cta_pill(ctx: Ctx, el: Element) -> None:
    p = el.props
    fade = float(p.get("fade_in", 2.0))
    a = apply("EASE_OUT_EARLY", progress(ctx.t, el.start, el.start + fade))
    if a <= 0.01:
        return
    pulse_at = float(p.get("pulse_at", 0)) or None
    mul = 1.0
    if pulse_at:
        pd = float(p.get("pulse_duration", 0.2))
        pp = progress(ctx.t, pulse_at, pulse_at + pd)
        mul = 1.0 + (float(p.get("pulse_scale", 1.06)) - 1.0) * math.sin(math.pi * clamp(pp))
    x, y, w, h = (v * ctx.scale for v in el.rect)
    cx, cy = x + w / 2, y + h / 2
    bw, bh = w * mul, h * mul
    r = float(p.get("radius", 60)) * ctx.scale * mul
    ov = Image.new("RGBA", (int(bw) + 4, int(bh) + 4), (0, 0, 0, 0))
    ImageDraw.Draw(ov).rounded_rectangle([2, 2, bw + 1, bh + 1], radius=r,
                                         fill=(*C.color(p.get("color", "orange")), int(round(255 * a))))
    ctx.img.paste(ov, (int(cx - bw / 2), int(cy - bh / 2)), ov)
    ctx.mods["pill_scale"] = mul


PAINTERS: dict[str, Callable[[Ctx, Element], None]] = {
    # opening
    "particle_tunnel": paint_particle_tunnel,
    "converge_to_title": paint_converge_to_title,
    "anamorphic_flare": paint_anamorphic_flare,
    "letter_trails": paint_letter_trails,
    "offscreen_flicker": paint_offscreen_flicker,
    # shared
    "cut_pop": paint_cut_pop,
    "glass_panel": paint_glass_panel,
    "light_streaks": paint_light_streaks,
    "transition_out": paint_transition_out,
    "camera_shake": paint_camera_shake,
    "background_drift": paint_background_drift,
    # cut 1
    "coin_cascade": paint_coin_cascade,
    # cut 2
    "lock_body": paint_lock_body,
    "shackle": paint_shackle,
    "glyph_rows": paint_glyph_rows,
    "lock_click": paint_lock_click,
    "check_circles": paint_check_circles,
    # cut 3
    "sea_gradient": paint_sea_gradient,
    "dive_particles": paint_dive_particles,
    "creatures": paint_creatures,
    "bubbles": paint_bubbles,
    "depth_counter": paint_depth_counter,
    # cut 4
    "speed_streaks": paint_speed_streaks,
    "speedometer": paint_speedometer,
    "morph_glyph": paint_morph_glyph,
    "title_pulse": paint_title_pulse,
    # cut 5
    "planet_disk": paint_planet_disk,
    "meteor": paint_meteor,
    "shockwave": paint_shockwave,
    "crater": paint_crater,
    # cut 6
    "arc_draw": paint_arc_draw,
    "dashed_ring": paint_dashed_ring,
    # cut 7
    "heart_glyph": paint_heart_glyph,
    "pulse_rings": paint_pulse_rings,
    "panel_numbers": paint_panel_numbers,
    # cut 8
    "zoom_stages": paint_zoom_stages,
    "telescope_icon": paint_telescope_icon,
    # hero
    "hero_sphere": paint_hero_sphere,
    "orbiters": paint_orbiters,
    # cta
    "explosion": paint_explosion,
    "reform_text": paint_reform_text,
    "underline_sweep": paint_underline_sweep,
    "cta_pill": paint_cta_pill,
}
