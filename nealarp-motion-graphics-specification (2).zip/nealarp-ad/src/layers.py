"""Background, post-processing and light layers (R-VIS-01, 04, 05, 07, 08, 09).

Everything static is pre-computed once per output size and cached (R-PERF-01). All pixel
work is numpy-vectorised (R-PERF-02); there is no per-pixel Python loop in this module.
"""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter

from . import config as C
from .easing import clamp

_CACHE: dict[tuple, object] = {}


def _cached(key: tuple, builder):
    if key not in _CACHE:
        _CACHE[key] = builder()
    return _CACHE[key]


def clear_cache() -> None:
    _CACHE.clear()


# ------------------------------------------------------------------ background
def make_background(w: int, h: int) -> np.ndarray:
    """#0a0a0a with a radial depth haze to #0f172a at 40% opacity (R-VIS-01)."""

    def build() -> np.ndarray:
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        nx = (xx - w * 0.5) / (w * 0.5)
        ny = (yy - h * 0.5) / (h * 0.5)
        r = np.sqrt(nx * nx + ny * ny)
        falloff = np.clip(1.0 - r, 0.0, 1.0) ** 1.7
        base = np.array(C.BLACK, dtype=np.float32)
        haze = np.array(C.HAZE, dtype=np.float32)
        mix = (falloff * 0.40)[..., None]
        return (base[None, None, :] + (haze - base)[None, None, :] * mix).astype(np.uint8)

    return _cached(("bg", w, h), build)  # type: ignore[return-value]


def make_vignette(w: int, h: int, corner: float = C.VIGNETTE_CORNER) -> np.ndarray:
    """Radial multiplier: 0% loss at the centre, `corner` loss at the corners (R-VIS-08)."""

    def build() -> np.ndarray:
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        nx = (xx - w * 0.5) / (w * 0.5)
        ny = (yy - h * 0.5) / (h * 0.5)
        r = np.clip(np.sqrt(nx * nx + ny * ny) / math.sqrt(2.0), 0.0, 1.0)
        return (1.0 - corner * (r ** 2.2)).astype(np.float32)[..., None]

    return _cached(("vig", w, h, corner), build)  # type: ignore[return-value]


# ---------------------------------------------------------------------- grain
def make_grain_field(w: int, h: int, tile: int = C.GRAIN_TILE) -> np.ndarray:
    """One seeded tile, tiled across the frame (R-VIS-07). Offsets are applied per frame."""

    def build() -> np.ndarray:
        rng = C.rng("grain-tile")
        t = rng.standard_normal((tile, tile)).astype(np.float32)
        reps_y = int(math.ceil(h / tile)) + 1
        reps_x = int(math.ceil(w / tile)) + 1
        field = np.tile(t, (reps_y, reps_x))[:h, :w]
        return np.clip(field / 3.2, -1.0, 1.0).astype(np.float32)

    return _cached(("grain", w, h, tile), build)  # type: ignore[return-value]


def apply_grain(frame: np.ndarray, frame_index: int, opacity: float = C.GRAIN_OPACITY) -> np.ndarray:
    """frame: float32 HxWx3 in 0..255. Deterministic per-frame offset."""
    h, w = frame.shape[:2]
    field = make_grain_field(w, h)
    rng = C.rng(f"grain-offset:{frame_index}")
    ox = int(rng.integers(0, C.GRAIN_TILE))
    oy = int(rng.integers(0, C.GRAIN_TILE))
    shifted = np.roll(np.roll(field, oy, axis=0), ox, axis=1)
    return frame + shifted[..., None] * (opacity * 255.0)


# ---------------------------------------------------------------------- bloom
def bloom(frame: np.ndarray, blur: int = C.BLOOM_BLUR, strength: float = C.BLOOM_STRENGTH,
          threshold: int = C.BLOOM_THRESHOLD) -> np.ndarray:
    """Bright-pass bloom, blurred at 1/4 scale then upsampled (R-VIS-05, R-PERF-01)."""
    h, w = frame.shape[:2]
    luma = frame @ np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)
    k = np.clip((luma - threshold) / max(1.0, 255.0 - threshold), 0.0, 1.0)
    bright = frame * k[..., None]
    small = Image.fromarray(np.clip(bright, 0, 255).astype(np.uint8)).resize(
        (max(1, w // 4), max(1, h // 4)), Image.BILINEAR
    )
    small = small.filter(ImageFilter.GaussianBlur(max(0.4, blur / 4.0)))
    up = small.resize((w, h), Image.BILINEAR)
    return frame + np.asarray(up, dtype=np.float32) * strength


# ------------------------------------------------------------------- gradients
def linear_gradient(size: tuple[int, int], c0: Sequence[int], c1: Sequence[int],
                    axis: str = "x", mid_lift: float = 0.45) -> np.ndarray:
    """Linear blue->orange ramp (R-VIS-03) with exact endpoints.

    `mid_lift` pulls the crossover through white. It is not decoration: a raw RGB lerp
    from #3b82f6 to #f97316 passes through hues around 10 deg and 340 deg at ~40%
    saturation, which would break R-VIS-02 / R-NEG-01 and fail R-VER-06. Lifting the
    middle keeps saturation under the 0.35 check floor there, and both endpoints stay
    exactly the specified colours (lift is 0 at ramp 0 and 1).
    """
    w, h = size
    n = max(1, w if axis == "x" else h)
    ramp = np.linspace(0.0, 1.0, n, dtype=np.float32)
    a = np.array(c0, dtype=np.float32)
    b = np.array(c1, dtype=np.float32)
    line = a[None, :] + (b - a)[None, :] * ramp[:, None]
    if mid_lift > 0:
        lift = (np.sin(math.pi * ramp) ** 2 * mid_lift).astype(np.float32)[:, None]
        line = line + (255.0 - line) * lift
    line = np.clip(line, 0, 255)
    if axis == "x":
        return np.repeat(line[None, :, :], h, axis=0)
    return np.repeat(line[:, None, :], w, axis=1)


def radial_field(size: tuple[int, int], center: tuple[float, float] | None = None) -> np.ndarray:
    """Normalised radius field, 0 at `center`, 1 at the box edge."""
    w, h = size
    cx, cy = center if center else (w / 2.0, h / 2.0)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    return np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / max(1e-6, math.hypot(max(cx, w - cx), max(cy, h - cy)))


# --------------------------------------------------------------- glass (R-VIS-04)
def _rounded_mask(size: tuple[int, int], radius: float) -> Image.Image:
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size[0] - 1, size[1] - 1], radius=radius, fill=255)
    return m


def glass_panel(img: Image.Image, rect_ref: Sequence[float], radius_ref: float, scale: float,
                alpha: float = 1.0, blur: float = 20.0) -> None:
    """White 10% fill, 1px white 25% border, r=24, inner shadow, backdrop blur at 1/4 scale."""
    x, y, w, h = (float(v) * scale for v in rect_ref)
    W, H = img.size
    x0, y0 = int(max(0, math.floor(x))), int(max(0, math.floor(y)))
    x1, y1 = int(min(W, math.ceil(x + w))), int(min(H, math.ceil(y + h)))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return

    region = img.crop((x0, y0, x1, y1)).convert("RGB")
    rw, rh = region.size
    r = max(1.0, radius_ref * scale)
    mask = _rounded_mask((rw, rh), r)

    # backdrop blur on a 1/4-scale copy, then upsample (R-VIS-04)
    small = region.resize((max(1, rw // 4), max(1, rh // 4)), Image.BILINEAR)
    small = small.filter(ImageFilter.GaussianBlur(max(0.5, blur * scale / 4.0)))
    blurred = small.resize((rw, rh), Image.BILINEAR)
    out = Image.composite(blurred, region, mask).convert("RGBA")

    # fill: white at 10%
    fill = Image.new("RGBA", (rw, rh), (0, 0, 0, 0))
    ImageDraw.Draw(fill).rounded_rectangle(
        [0, 0, rw - 1, rh - 1], radius=r, fill=(255, 255, 255, int(round(25.5 * clamp(alpha))))
    )
    out.alpha_composite(fill)

    # inner shadow: 20% black, offset (0, 4), blur 12
    sh = Image.new("L", (rw, rh), 0)
    ImageDraw.Draw(sh).rounded_rectangle(
        [0, 0, rw - 1, rh - 1], radius=r, outline=255, width=max(2, int(round(7 * scale)))
    )
    sh = sh.filter(ImageFilter.GaussianBlur(max(0.5, 6.0 * scale)))
    sh = ImageChops.offset(sh, 0, int(round(4 * scale)))
    sh = ImageChops.multiply(sh, mask)
    shadow = Image.new("RGBA", (rw, rh), (0, 0, 0, 0))
    shadow.putalpha(sh.point(lambda v: int(round(v * 0.20 * clamp(alpha)))))
    out.alpha_composite(shadow)

    # border: 1 px white at 25%
    ImageDraw.Draw(out).rounded_rectangle(
        [0, 0, rw - 1, rh - 1], radius=r,
        outline=(255, 255, 255, int(round(63.75 * clamp(alpha)))),
        width=max(1, int(round(scale))),
    )

    img.paste(out.convert("RGB"), (x0, y0), mask)


# ----------------------------------------------------------------------- light
def light_streaks(img: Image.Image, center_ref: Sequence[float], count: int, colors: Sequence[str],
                  length_ref: float, alpha: float, scale: float, t: float, drift: float = 0.0) -> None:
    """Horizontal blue/orange light streaks (R-VIS-05)."""
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    rng = C.rng("streaks")
    cx, cy = center_ref[0] * scale, center_ref[1] * scale
    for i in range(count):
        col = C.color(colors[i % len(colors)])
        off = (rng.random() - 0.5) * 620 * scale
        y = cy + off + math.sin(t * 0.6 + i) * drift * scale
        half = length_ref * scale * (0.4 + 0.6 * rng.random()) / 2.0
        a = int(round(255 * alpha * (0.45 + 0.55 * rng.random())))
        d.line([(cx - half, y), (cx + half, y)], fill=(*col, a), width=max(1, int(round(3 * scale))))
    img.paste(Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB"), (0, 0))


def anamorphic_flare(img: Image.Image, center_ref: Sequence[float], p: float, length_ref: float,
                     height_ref: float, glow_ref: float, scale: float, color: str = "white") -> None:
    """One anamorphic streak per title reveal: 1400x6 plus a 120 px glow (R-VIS-05)."""
    if p <= 0:
        return
    env = math.sin(math.pi * clamp(p)) ** 0.7
    cx, cy = center_ref[0] * scale, center_ref[1] * scale
    L = length_ref * scale * (0.35 + 0.65 * clamp(p))
    H = max(1.0, height_ref * scale)
    col = C.color(color)
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    d.rounded_rectangle([cx - L / 2, cy - H / 2, cx + L / 2, cy + H / 2], radius=H / 2,
                        fill=(*col, int(round(235 * env))))
    glow_r = glow_ref * scale * (0.5 + 0.5 * clamp(p))
    d.ellipse([cx - glow_r, cy - glow_r, cx + glow_r, cy + glow_r], fill=(*col, int(round(70 * env))))
    overlay = overlay.filter(ImageFilter.GaussianBlur(max(0.6, 3.0 * scale)))
    img.paste(Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB"), (0, 0))


def offscreen_flicker_arr(arr: np.ndarray, center_ref: Sequence[float], p: float, color: str,
                          intensity: float, scale: float) -> None:
    """One off-screen flicker per act: light spilling in from outside the frame (R-VIS-05).

    Mutates a float32 HxWx3 buffer in place so it can run inside an additive pass.
    """
    if p <= 0:
        return
    rng = C.rng(f"flicker:{int(center_ref[0])}:{int(center_ref[1])}")
    flick = 0.55 + 0.45 * math.sin(p * 42.0 + rng.random() * 6.28)
    col = np.array(C.color(color), dtype=np.float32)
    h, w = arr.shape[:2]
    cx = clamp(center_ref[0] * scale, -w, 2 * w)
    cy = clamp(center_ref[1] * scale, -h, 2 * h)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d2 = (xx - cx) ** 2 + (yy - cy) ** 2
    radius = 620.0 * scale
    fall = np.exp(-d2 / (2 * radius * radius)) * (intensity * flick)
    arr += col[None, None, :] * fall[..., None]


def offscreen_flicker(img: Image.Image, center_ref: Sequence[float], p: float, color: str,
                      intensity: float, scale: float) -> None:
    arr = np.asarray(img, dtype=np.float32).copy()
    offscreen_flicker_arr(arr, center_ref, p, color, intensity, scale)
    img.paste(Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)), (0, 0))


# -------------------------------------------------------------------- camera
def project(x: float, y: float, z: float, cx: float, cy: float, f: float = C.FOCAL) -> tuple[float, float]:
    """Perspective projection (R-VIS-09): screen = c + v * f / (f + z)."""
    k = f / (f + max(0.0, z))
    return cx + x * k, cy + y * k


def project_array(pts: np.ndarray, z: np.ndarray, cx: float, cy: float, f: float = C.FOCAL):
    """Vectorised R-VIS-09. pts: (N,2) reference-space offsets, z: (N,)."""
    k = f / (f + np.clip(z, 0.0, None))
    return cx + pts[:, 0] * k, cy + pts[:, 1] * k, k


def camera_shake(t: float, start: float, end: float, amplitude: float, frequency: float,
                 scale: float, decay: bool = True) -> tuple[float, float]:
    if not (start <= t < end):
        return 0.0, 0.0
    p = (t - start) / max(1e-6, end - start)
    env = (1.0 - p) if decay else 1.0
    a = amplitude * env * scale
    dx = math.sin(t * frequency * 2.1) * a
    dy = math.cos(t * frequency * 1.7) * a * 0.7
    return dx, dy


# --------------------------------------------------------------- transitions
def transition_out(img: Image.Image, mode: str, p: float, color: str = "black",
                   alpha: float = 1.0) -> Image.Image:
    """Hard-cut exit: wipe_left / wipe_up / flash_white (declared per cut in timeline.yaml)."""
    if p <= 0:
        return img
    p = clamp(p)
    out = img.copy()
    d = ImageDraw.Draw(out)
    w, h = out.size
    if mode == "wipe_left":
        d.rectangle([w * (1.0 - p), 0, w, h], fill=C.color(color))
    elif mode == "wipe_up":
        d.rectangle([0, h * (1.0 - p), w, h], fill=C.color(color))
    elif mode == "flash_white":
        ov = Image.new("RGBA", out.size, (*C.color(color), int(round(255 * alpha * (1.0 - p) * p * 4))))
        out = Image.alpha_composite(out.convert("RGBA"), ov).convert("RGB")
    return out


def cut_pop(img: Image.Image, center_ref: Sequence[float], p: float, radius_ref: float,
            color: str, alpha: float, scale: float) -> None:
    """0.0-0.2 s flash ring at the start of every cut."""
    if p <= 0 or p >= 1:
        return
    col = np.array(C.color(color), dtype=np.float32)
    arr = np.asarray(img, dtype=np.float32)
    h, w = arr.shape[:2]
    cx, cy = center_ref[0] * scale, center_ref[1] * scale
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    r = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    radius = radius_ref * scale * (0.25 + 0.75 * p)
    band = np.exp(-((r - radius) ** 2) / (2 * (90 * scale) ** 2)) * (alpha * (1.0 - p))
    img_arr = np.clip(arr + col[None, None, :] * band[..., None], 0, 255).astype(np.uint8)
    img.paste(Image.fromarray(img_arr), (0, 0))
