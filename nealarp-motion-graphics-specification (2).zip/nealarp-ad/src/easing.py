"""Named easings, exactly as specified in R-VIS-10.

    EASE_IO        = cubic-bezier(0.65, 0.00, 0.35, 1.00)
    EASE_OUT_EARLY = cubic-bezier(0.25, 0.80, 0.25, 1.00)
    EXPO_OUT       = 1 - 2^(-10 t)
    STEP           = hold start value until the end time, then snap

All easings map [0, 1] -> [0, 1] (STEP is 0 then 1).
"""

from __future__ import annotations

import math

BEZIER_CONTROL_POINTS = {
    "EASE_IO": (0.65, 0.00, 0.35, 1.00),
    "EASE_OUT_EARLY": (0.25, 0.80, 0.25, 1.00),
}


def _bezier_axis(p1: float, p2: float, t: float) -> float:
    """Cubic bezier component with fixed endpoints 0 and 1."""
    u = 1.0 - t
    return 3.0 * u * u * t * p1 + 3.0 * u * t * t * p2 + t * t * t


def _bezier_axis_d(p1: float, p2: float, t: float) -> float:
    u = 1.0 - t
    return 3.0 * u * u * p1 + 6.0 * u * t * (p2 - p1) + 3.0 * t * t * (1.0 - p2)


def make_cubic_bezier(x1: float, y1: float, x2: float, y2: float):
    """Return f(x) for the CSS cubic-bezier(x1, y1, x2, y2) curve.

    Newton-Raphson with a bisection fallback; deterministic and allocation-free.
    """

    def f(x: float) -> float:
        if x <= 0.0:
            return 0.0
        if x >= 1.0:
            return 1.0
        t = x
        for _ in range(8):
            err = _bezier_axis(x1, x2, t) - x
            if abs(err) < 1e-7:
                break
            d = _bezier_axis_d(x1, x2, t)
            if abs(d) < 1e-7:
                break
            t -= err / d
            t = min(1.0, max(0.0, t))
        if abs(_bezier_axis(x1, x2, t) - x) > 1e-5:  # bisection fallback
            lo, hi = 0.0, 1.0
            t = x
            for _ in range(40):
                v = _bezier_axis(x1, x2, t)
                if abs(v - x) < 1e-7:
                    break
                if v < x:
                    lo = t
                else:
                    hi = t
                t = 0.5 * (lo + hi)
        return _bezier_axis(y1, y2, t)

    return f


def ease_io(p: float) -> float:
    return _EASE_IO(p)


def ease_out_early(p: float) -> float:
    return _EASE_OUT_EARLY(p)


def expo_out(p: float) -> float:
    if p <= 0.0:
        return 0.0
    if p >= 1.0:
        return 1.0
    return 1.0 - math.pow(2.0, -10.0 * p)


def step(p: float) -> float:
    """Hold the start value until the end, then snap (R-VIS-10)."""
    return 1.0 if p >= 1.0 else 0.0


_EASE_IO = make_cubic_bezier(*BEZIER_CONTROL_POINTS["EASE_IO"])
_EASE_OUT_EARLY = make_cubic_bezier(*BEZIER_CONTROL_POINTS["EASE_OUT_EARLY"])

EASINGS = {
    "EASE_IO": ease_io,
    "EASE_OUT_EARLY": ease_out_early,
    "EXPO_OUT": expo_out,
    "STEP": step,
}


def apply(name: str, p: float) -> float:
    try:
        return EASINGS[name](p)
    except KeyError as exc:  # pragma: no cover - guarded by tests/test_easing.py
        raise KeyError(f"unknown ease '{name}'; allowed: {sorted(EASINGS)}") from exc


def progress(t: float, start: float, end: float) -> float:
    """Normalised, clamped local progress of `t` inside [start, end]."""
    if end <= start:
        return 1.0 if t >= end else 0.0
    return min(1.0, max(0.0, (t - start) / (end - start)))


def segment(t: float, start: float, end: float, ease: str = "EASE_IO") -> float:
    """Eased progress — the single entry point used by every painter."""
    return apply(ease, progress(t, start, end))


def active(t: float, start: float, end: float) -> bool:
    return start <= t < end or (t >= end and math.isclose(t, end, abs_tol=1e-9))


def lerp(a: float, b: float, p: float) -> float:
    return a + (b - a) * p


def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return lo if v < lo else (hi if v > hi else v)
