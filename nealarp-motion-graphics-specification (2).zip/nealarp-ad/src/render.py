"""CLI renderer (R-OUT-03/04/05/06, R-PERF-04/05, R-GATE).

One code path renders both masters; only the preset differs:

    python -m src.render --preset test          -> out/nealarp-ad-1080p-test.mp4   (1920x1080)
    python -m src.render --preset final --i-approve-4k
                                                -> out/nealarp-ad-2160p60-final.mp4 (3840x2160)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

from . import config as C
from .compose import Composer
from .timeline import load

ROOT = C.ROOT
OUT_DIR = ROOT / "out"
MIX_PATH = ROOT / "audio" / "render" / "mix.m4a"
VO_PROVIDER_PATH = ROOT / "audio" / "render" / "vo_provider.txt"
PERF_PATH = OUT_DIR / "perf-report.json"
LAYOUT_LOG = OUT_DIR / "layout_log.json"
MAX_4K_HOURS = 6.0  # R-PERF-05


def ffmpeg_exe() -> str:
    import imageio_ffmpeg

    return imageio_ffmpeg.get_ffmpeg_exe()


def assert_neural_vo() -> None:
    """R-GATE-03: the 4K master may only be built with a real German neural voice."""
    provider = VO_PROVIDER_PATH.read_text(encoding="utf-8").strip().lower() if VO_PROVIDER_PATH.exists() else ""
    neural = {"azure", "azure_female", "elevenlabs", "google", "polly"}
    if provider not in neural or "espeak" in provider or "placeholder" in provider:
        raise SystemExit(
            "4K render blocked (R-GATE-03): voiceover is "
            f"{provider or 'MISSING'} (PLACEHOLDER).\n"
            "  1. render the VO with a German neural voice:\n"
            "       python -m src.vo --provider azure|elevenlabs|google|polly\n"
            "  2. confirm audio/render/vo_provider.txt names that provider\n"
            "  3. re-run: python -m src.mix && python -m src.render --preset final --i-approve-4k"
        )


def render_video(preset: str, out_path: Path | None = None, frames: list[int] | None = None,
                 with_audio: bool = True, quiet: bool = False) -> dict:
    spec = C.PRESETS[preset]
    scale = float(spec["scale"])
    w, h = int(spec["width"]), int(spec["height"])
    out_path = Path(out_path or (ROOT / spec["out"]))
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if preset == "final":
        assert_neural_vo()

    tl = load()
    comp = Composer(tl, scale=scale)

    indices = frames if frames is not None else list(range(C.TOTAL_FRAMES))
    video_tmp = out_path.with_suffix(".video.mp4") if with_audio else out_path

    import imageio_ffmpeg

    writer = imageio_ffmpeg.write_frames(
        str(video_tmp), (w, h), pix_fmt_in="rgb24", pix_fmt_out=C.PIXEL_FORMAT,
        fps=C.FPS, codec=C.VIDEO_CODEC, macro_block_size=1,
        input_params=["-f", "rawvideo"],
        output_params=[
            "-profile:v", C.VIDEO_PROFILE, "-crf", str(C.CRF), "-preset", "medium",
            "-g", "120", "-pix_fmt", C.PIXEL_FORMAT, "-movflags", "+faststart",
            "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
        ],
    )
    writer.send(None)

    t0 = time.perf_counter()
    per_frame: list[float] = []
    for n, idx in enumerate(indices):
        tf = time.perf_counter()
        arr = comp.frame(idx / C.FPS, idx)
        writer.send(np.ascontiguousarray(arr).tobytes())
        per_frame.append(time.perf_counter() - tf)
        if not quiet and (n % 120 == 0 or n == len(indices) - 1):
            done = n + 1
            avg = sum(per_frame) / done
            eta = avg * (len(indices) - done)
            print(f"  frame {idx:5d}/{indices[-1]}  {done:5d} done  "
                  f"avg {avg*1000:6.1f} ms/f  eta {eta/60:5.1f} min", flush=True)
    writer.close()
    total = time.perf_counter() - t0

    if with_audio:
        if not MIX_PATH.exists():
            raise SystemExit(
                f"audio mix not found at {MIX_PATH}\n"
                "  run: python -m src.vo --provider espeak   (placeholder, 1080p test only)\n"
                "  then: python -m src.audio && python -m src.mix"
            )
        mux_audio(video_tmp, MIX_PATH, out_path)
        video_tmp.unlink(missing_ok=True)

    comp.text.save_log(LAYOUT_LOG)
    avg = (sum(per_frame) / len(per_frame)) if per_frame else 0.0
    report = {
        "preset": preset, "path": str(out_path), "width": w, "height": h, "fps": C.FPS,
        "frames_rendered": len(indices), "avg_seconds_per_frame": round(avg, 5),
        "total_seconds": round(total, 2),
        "estimate_4k_seconds": round(avg * 4.0 * C.TOTAL_FRAMES, 1),
        "estimate_4k_hours": round(avg * 4.0 * C.TOTAL_FRAMES / 3600.0, 3),
        "audio": str(MIX_PATH) if with_audio else None,
    }
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    PERF_PATH.write_text(json.dumps(report, indent=2), encoding="utf-8")
    if not quiet:
        print(json.dumps(report, indent=2))
    return report


def mux_audio(video: Path, audio: Path, out: Path) -> None:
    """R-OUT-05: H.264 video copy + AAC 48 kHz stereo, exactly 60.000 s."""
    cmd = [
        ffmpeg_exe(), "-y", "-i", str(video), "-i", str(audio),
        "-map", "0:v:0", "-map", "1:a:0",
        "-c:v", "copy", "-c:a", C.AUDIO_CODEC, "-ar", str(C.AUDIO_RATE), "-ac", str(C.AUDIO_CHANNELS),
        "-b:a", "192k", "-t", f"{C.DURATION:.3f}", "-shortest", "-movflags", "+faststart", str(out),
    ]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def md5_frames(scale: float = 1.0, indices=(0, 900, 1800, 3000, 3599)) -> dict[str, list[str]]:
    """R-VER-13: render the same frames twice and compare MD5 of the raw RGB bytes."""
    tl = load()
    out: dict[str, list[str]] = {"indices": [str(i) for i in indices], "pass1": [], "pass2": []}
    for run in ("pass1", "pass2"):
        comp = Composer(tl, scale=scale)  # fresh caches, fresh timeline
        for idx in indices:
            arr = comp.frame(idx / C.FPS, idx)
            out[run].append(hashlib.md5(np.ascontiguousarray(arr).tobytes()).hexdigest())
    out["identical"] = out["pass1"] == out["pass2"]
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m src.render", description="nealarp-ad renderer")
    ap.add_argument("--preset", choices=sorted(C.PRESETS), default="test")
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--no-audio", action="store_true", help="video-only scratch pass")
    ap.add_argument("--frames", default=None, help="comma separated frame indices to render")
    ap.add_argument("--i-approve-4k", action="store_true",
                    help="R-GATE-02: explicit approval required before the 4K master is built")
    ap.add_argument("--force-4k", action="store_true",
                    help="R-PERF-05: override the 6 hour estimate guard")
    ap.add_argument("--md5", action="store_true", help="R-VER-13 reproducibility check, then exit")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args(argv)

    if a.md5:
        print(json.dumps(md5_frames(scale=C.PRESETS[a.preset]["scale"]), indent=2))
        return 0

    if a.preset == "final" and not a.i_approve_4k:
        raise SystemExit(
            "R-GATE-01/02: the 4K master is not built without explicit approval.\n"
            "  Re-run with --i-approve-4k once the 1080p test render has been reviewed."
        )

    if a.preset == "final" and PERF_PATH.exists() and not a.force_4k:
        prev = json.loads(PERF_PATH.read_text(encoding="utf-8"))
        est_h = float(prev.get("estimate_4k_hours", 0))
        if est_h > MAX_4K_HOURS:
            raise SystemExit(
                f"R-PERF-05: 4K estimate {est_h:.1f} h exceeds the {MAX_4K_HOURS} h budget.\n"
                "  Options: (a) lower particle counts in timeline.yaml, (b) pre-render sprite sheets,\n"
                "  (c) schedule a longer run window and re-run with --force-4k."
            )

    frames = [int(x) for x in a.frames.split(",")] if a.frames else None
    render_video(a.preset, a.out, frames, with_audio=not a.no_audio, quiet=a.quiet)
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
