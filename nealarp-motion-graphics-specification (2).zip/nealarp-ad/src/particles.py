"""Closed-form particle systems (R-VIS-06, R-VIS-09).

No system integrates state from the previous frame: every position is an explicit
function of `t`. That is what makes `compose.render_frame` a pure function of time
(R-OUT-02) and what makes two renders of the same frame byte-identical (R-VER-13).

Particles start large and shrink to 0 as they fade (R-VIS-06). Counts are capped by
`config.MAX_PARTICLES_1080P` at 1080p and scaled down for smaller previews.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from PIL import Image, ImageDraw

from . import config as C
from . import layers
from .easing import apply, clamp, progress


@dataclass
class Points:
    x: np.ndarray          # reference units
    y: np.ndarray
    r: np.ndarray          # reference radius
    color: np.ndarray      # (N, 3) uint8
    alpha: np.ndarray      # 0..1

    def __len__(self) -> int:
        return int(self.x.shape[0])


def cap(count: int, scale: float) -> int:
    """R-VIS-06: 3000 particles max per frame at 1080p (proportionally fewer below)."""
    return int(max(1, min(count, C.MAX_PARTICLES_1080P * min(1.0, scale))))


def draw_points(frame: np.ndarray, pts: Points, scale: float, additive: bool = True) -> None:
    """Composite points into `frame` (float32 HxWx3, 0..255). Vectorised compositing,
    per-particle ellipse rasterisation only (no per-pixel Python)."""
    if len(pts) == 0:
        return
    h, w = frame.shape[:2]
    keep = (pts.alpha > 0.004) & (pts.r > 0.05)
    if not np.any(keep):
        return
    xs = pts.x[keep] * scale
    ys = pts.y[keep] * scale
    rs = np.maximum(0.6, pts.r[keep] * scale)
    cols = pts.color[keep].astype(np.float32)
    als = np.clip(pts.alpha[keep], 0.0, 1.0)

    add = Image.new("RGB", (w, h), (0, 0, 0))
    d = ImageDraw.Draw(add)
    for i in range(xs.shape[0]):
        v = cols[i] * als[i]
        r = float(rs[i])
        if r <= 1.15:
            d.point((float(xs[i]), float(ys[i])), fill=(int(v[0]), int(v[1]), int(v[2])))
        else:
            d.ellipse([xs[i] - r, ys[i] - r, xs[i] + r, ys[i] + r], fill=(int(v[0]), int(v[1]), int(v[2])))
    layer = np.asarray(add, dtype=np.float32)
    if additive:
        frame += layer
    else:
        a = (layer.max(axis=2, keepdims=True) / 255.0)
        frame += layer * (1.0 - a)


def _colors(names: list[str], n: int, rng: np.random.Generator) -> np.ndarray:
    cols = np.array([C.color(c) for c in names], dtype=np.uint8)
    return cols[rng.integers(0, len(cols), n)]


# --------------------------------------------------------------- tunnel (R-SCN-01)
def tunnel(t: float, t0: float, center, props: dict, scale: float) -> Points:
    n = cap(int(props.get("count", 1800)), scale)
    rng = C.rng("tunnel")
    ang = rng.random(n) * math.tau
    rad = 260.0 + rng.random(n) * 1500.0
    z0 = rng.random(n) * float(props.get("z_max", 2000))
    speed = float(props.get("speed", 950))
    zmax = float(props.get("z_max", 2000))

    z = np.mod(z0 - speed * (t - t0), zmax)
    wx = np.cos(ang) * rad
    wy = np.sin(ang) * rad
    cx, cy = float(center[0]), float(center[1])
    sx, sy, k = layers.project_array(np.stack([wx, wy], axis=1), z, cx, cy)

    size = (float(props.get("size_min", 1.5)) +
            (float(props.get("size_max", 7.0)) - float(props.get("size_min", 1.5))) * (1.0 - z / zmax))
    near = clamp((z / 180.0), 0, 1)                 # fade as they pass the camera
    far = clamp((zmax - z) / 420.0, 0, 1)           # fade in at spawn
    alpha = near * far * (0.35 + 0.65 * (1.0 - z / zmax))

    left = wx < 0
    cols = np.empty((n, 3), dtype=np.uint8)
    cols[left] = C.color(props.get("left_color", "blue"))
    cols[~left] = C.color(props.get("right_color", "orange"))
    hot = z < 260
    cols[hot] = C.color(props.get("core_color", "white"))
    return Points(sx, sy, size, cols, alpha)


# ------------------------------------------------------------- explosion (R-SCN-11)
def explosion(t: float, t0: float, center, props: dict, scale: float) -> Points:
    n = cap(int(props.get("count", 3000)), scale)
    rng = C.rng("explosion")
    ang = rng.random(n) * math.tau
    el = np.arcsin(rng.random(n) * 2 - 1)
    speed = float(props.get("speed_min", 220)) + rng.random(n) * (
        float(props.get("speed_max", 1500)) - float(props.get("speed_min", 220)))
    life = float(props.get("life", 2.0)) * (0.65 + 0.7 * rng.random(n))

    dt = t - t0
    p = clamp(dt / life)
    eased = apply("EXPO_OUT", clamp(dt / max(1e-6, life * 0.85)))
    dist = speed * life * eased * 0.42

    cos_e = np.cos(el)
    x = center[0] + np.cos(ang) * cos_e * dist
    y = center[1] + np.sin(el) * dist * 0.62 + np.sin(ang) * cos_e * dist * 0.25

    fade = 1.0 - p
    size = (2.0 + 9.0 * rng.random(n)) * np.clip(fade, 0, 1)   # shrink as they fade
    alpha = np.clip(fade ** 1.4, 0, 1)
    hot = np.clip(1.0 - dt / 0.45, 0, 1)
    cols = _colors(list(props.get("colors", ["blue", "orange"])), n, rng).astype(np.float32)
    cols = cols + (np.array(C.WHITE, dtype=np.float32) - cols) * hot[:, None]
    return Points(x, y, size, np.clip(cols, 0, 255).astype(np.uint8), alpha)


# ----------------------------------------------------------- reform (R-SCN-11)
def reform(t: float, t0: float, t1: float, targets: np.ndarray, origin, props: dict,
           scale: float, spread: float = 620.0) -> Points:
    """Particles fly from `origin` and settle onto glyph sample points."""
    n = min(cap(int(props.get("count", 2600)), scale), targets.shape[0])
    tgt = targets[:n]
    rng = C.rng(f"reform:{n}:{round(float(origin[0]))}")
    ang = rng.random(n) * math.tau
    rad = spread * (0.25 + rng.random(n))
    sx = origin[0] + np.cos(ang) * rad
    sy = origin[1] + np.sin(ang) * rad * 0.7
    delay = rng.random(n) * 0.35 * float(props.get("snap", 0.9))

    span = max(1e-6, (t1 - t0) * float(props.get("snap", 0.9)))
    p = clamp((t - t0 - delay) / span)
    e = apply("EASE_IO", p)
    x = sx + (tgt[:, 0] - sx) * e
    y = sy + (tgt[:, 1] - sy) * e

    settled = p >= 1.0
    wob = (~settled) * (1.0 - e)
    size = 2.6 * (1.0 - wob * 0.55) + 1.2 * settled
    alpha = np.where(settled, 0.55, 0.35 + 0.65 * e)
    cols = np.empty((n, 3), dtype=np.uint8)
    cols[:] = C.WHITE
    blue = rng.random(n) < 0.35
    cols[blue & ~settled] = C.color("blue")
    cols[(~blue) & (~settled)] = C.color("orange")
    return Points(x, y, size, cols, alpha)


# --------------------------------------------------------------- bubbles (R-SCN-04)
def bubbles(t: float, t0: float, rect, props: dict, scale: float) -> Points:
    n = cap(int(props.get("count", 60)), scale)
    rng = C.rng("bubbles")
    x0, y0, w, h = (float(v) for v in rect)
    px = x0 + rng.random(n) * w
    py0 = y0 + rng.random(n) * h
    sp = float(props.get("speed_min", 80)) + rng.random(n) * (
        float(props.get("speed_max", 160)) - float(props.get("speed_min", 80)))
    size = float(props.get("size_min", 4)) + rng.random(n) * (
        float(props.get("size_max", 14)) - float(props.get("size_min", 4)))
    dt = t - t0
    py = y0 + h - np.mod((y0 + h - py0) + sp * dt, h)
    sway = np.sin(dt * 1.6 + px * 0.02) * 9.0
    col = np.tile(np.array(C.color(props.get("color", "white")), dtype=np.uint8), (n, 1))
    return Points(px + sway, py, size / 2.0, col, np.full(n, float(props.get("alpha", 0.45))))


# ------------------------------------------------------------- dive (R-SCN-04)
def dive(t: float, t0: float, rect, props: dict, scale: float) -> Points:
    n = cap(int(props.get("count", 420)), scale)
    rng = C.rng("dive")
    x0, y0, w, h = (float(v) for v in rect)
    px = x0 + rng.random(n) * w
    py0 = y0 + rng.random(n) * h
    speed = float(props.get("speed", 1200))
    e = apply(props.get("ease", "EASE_OUT_EARLY"), progress(t, t0, t0 + 1.2))
    dt = (t - t0) * (0.35 + 0.65 * e)
    py = y0 + np.mod(py0 - speed * dt, h)
    size = float(props.get("size_min", 1)) + rng.random(n) * (
        float(props.get("size_max", 4)) - float(props.get("size_min", 1)))
    cols = _colors(list(props.get("colors", ["white", "blue"])), n, rng)
    alpha = np.full(n, float(props.get("alpha", 0.55))) * (0.5 + 0.5 * e)
    return Points(px, py, size, cols, alpha)


# ------------------------------------------------------------- drift (R-SCN-11)
def drift(t: float, t0: float, rect, props: dict, scale: float) -> Points:
    n = cap(int(props.get("count", 260)), scale)
    rng = C.rng("drift")
    x0, y0, w, h = (float(v) for v in rect)
    px = x0 + rng.random(n) * w
    py = y0 + rng.random(n) * h
    vx = (rng.random(n) - 0.5) * float(props.get("speed", 26))
    vy = (rng.random(n) - 0.5) * float(props.get("speed", 26)) * 0.6
    dt = t - t0
    push = float(props.get("push_out", 0.0))
    cx, cy = x0 + w / 2, y0 + h / 2
    x = px + vx * dt + (px - cx) * push * dt * 0.1
    y = py + vy * dt + (py - cy) * push * dt * 0.1
    size = 1.4 + rng.random(n) * 3.2
    cols = _colors(list(props.get("colors", ["blue", "orange"])), n, rng)
    return Points(x, y, size, cols, np.full(n, float(props.get("alpha", 0.35))))


# ------------------------------------------------------- speed streaks (R-SCN-05)
def speed_streaks(t: float, t0: float, rect, props: dict, scale: float) -> Points:
    """40 horizontal motion-blur streaks moving left at 2400 px/s."""
    n = cap(int(props.get("count", 40)), scale)
    rng = C.rng("speed-streaks")
    x0, y0, w, h = (float(v) for v in rect)
    py = y0 + rng.random(n) * h
    length = float(props.get("length_min", 200)) + rng.random(n) * (
        float(props.get("length_max", 600)) - float(props.get("length_min", 200)))
    speed = float(props.get("speed", 2400))
    px = x0 + w - np.mod(rng.random(n) * (w + length) + speed * (t - t0), w + length)
    col = np.tile(np.array(C.color(props.get("color", "white")), dtype=np.uint8), (n, 1))
    alpha = np.full(n, float(props.get("alpha", 0.30))) * (0.4 + 0.6 * rng.random(n))
    return Streaks(px, py, length, col, alpha)


@dataclass
class Streaks:
    """Horizontal motion-blur lines — drawn by `draw_streaks`, not `draw_points`."""

    x: np.ndarray
    y: np.ndarray
    length: np.ndarray
    color: np.ndarray
    alpha: np.ndarray

    def __len__(self) -> int:
        return int(self.x.shape[0])


def draw_streaks(frame: np.ndarray, st, scale: float) -> None:
    h, w = frame.shape[:2]
    add = Image.new("RGB", (w, h), (0, 0, 0))
    d = ImageDraw.Draw(add)
    for i in range(st.x.shape[0]):
        v = st.color[i].astype(np.float32) * st.alpha[i]
        y = float(st.y[i] * scale)
        x = float(st.x[i] * scale)
        ln = float(st.length[i] * scale)
        d.line([(x, y), (x + ln, y)], fill=(int(v[0]), int(v[1]), int(v[2])),
               width=max(1, int(round(2 * scale))))
    frame += np.asarray(add, dtype=np.float32)
