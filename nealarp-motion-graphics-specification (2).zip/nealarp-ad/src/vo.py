"""Voiceover (R-AUD-01).

Provider ladder:
  azure | elevenlabs | google | polly  -> real German neural voice (required for 4K, R-GATE-03)
  espeak                               -> PLACEHOLDER, allowed for the 1080p test render only

Rules enforced here:
  * every line normalised to -18 dBFS RMS before mixing
  * at least 0.5 s between lines
  * a line that would overlap the next one pushes the NEXT line later — delivery is never
    sped up, and no line is ever time-stretched
  * the chosen provider name is written to audio/render/vo_provider.txt, which the 4K gate reads
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import wave
from pathlib import Path

import numpy as np

from . import config as C
from .audio import SR, db_to_amp, ffmpeg_resample, read_wav, write_wav
from .timeline import load

ROOT = C.ROOT
VO_DIR = ROOT / "audio" / "vo"
RENDER_DIR = ROOT / "audio" / "render"

VOICES = {
    "azure": {"voice": "de-DE-ConradNeural", "format": "riff-48khz-16bit-mono-pcm"},
    "azure_female": {"voice": "de-DE-KatjaNeural", "format": "riff-48khz-16bit-mono-pcm"},
    "elevenlabs": {"model": "eleven_multilingual_v2", "voice_id": os.environ.get("ELEVENLABS_VOICE_ID", "")},
    "google": {"voice": "de-DE-Neural2-B"},
    "polly": {"voice": "Hans", "engine": "neural"},
    "espeak": {"voice": "de", "speed": 168},
}


def normalize_rms(sig: np.ndarray, target_dbfs: float = C.VO_RMS_DBFS) -> np.ndarray:
    rms = float(np.sqrt(np.mean(sig ** 2))) or 1e-9
    gain = db_to_amp(target_dbfs) / rms
    peak = float(np.max(np.abs(sig))) or 1.0
    if peak * gain > 0.98:            # keep the normalised line below clipping
        gain = 0.98 / peak
    return sig * gain


def wav_duration(path: Path) -> float:
    with wave.open(str(path), "rb") as w:
        return w.getnframes() / float(w.getframerate())


# ------------------------------------------------------------------- providers
def synth_espeak(text: str, out: Path) -> None:
    cfg = VOICES["espeak"]
    raw = out.with_suffix(".raw.wav")
    binary = "espeak-ng"
    try:
        subprocess.run([binary, "--version"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except (OSError, subprocess.CalledProcessError):
        binary = "espeak"
    subprocess.run(
        [binary, "-v", cfg["voice"], "-s", str(cfg["speed"]), "-w", str(raw), text],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    ffmpeg_resample(raw, out, SR, channels=1)
    raw.unlink(missing_ok=True)


def synth_azure(text: str, out: Path, female: bool = False) -> None:
    import urllib.request

    key = os.environ["AZURE_SPEECH_KEY"]
    region = os.environ["AZURE_SPEECH_REGION"]
    cfg = VOICES["azure_female" if female else "azure"]
    ssml = (
        '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="de-DE">'
        f'<voice name="{cfg["voice"]}"><prosody rate="-2%" pitch="-2%">{text}</prosody></voice></speak>'
    )
    req = urllib.request.Request(
        f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1",
        data=ssml.encode("utf-8"),
        headers={
            "Ocp-Apim-Subscription-Key": key,
            "Content-Type": "application/ssml+xml",
            "X-Microsoft-OutputFormat": cfg["format"],
            "User-Agent": "nealarp-ad",
        },
    )
    out.write_bytes(urllib.request.urlopen(req, timeout=60).read())


def synth_elevenlabs(text: str, out: Path) -> None:
    import urllib.request

    key = os.environ["ELEVENLABS_API_KEY"]
    cfg = VOICES["elevenlabs"]
    voice = cfg["voice_id"] or os.environ.get("ELEVENLABS_VOICE_ID")
    if not voice:
        raise SystemExit("ELEVENLABS_VOICE_ID is required for the elevenlabs provider")
    body = json.dumps({
        "text": text, "model_id": cfg["model"],
        "voice_settings": {"stability": 0.45, "similarity_boost": 0.8, "style": 0.2},
    }).encode()
    req = urllib.request.Request(
        f"https://api.elevenlabs.io/v1/text-to-speech/{voice}?output_format=pcm_48000",
        data=body, headers={"xi-api-key": key, "Content-Type": "application/json"})
    pcm = urllib.request.urlopen(req, timeout=90).read()
    raw = out.with_suffix(".raw")
    raw.write_bytes(pcm)
    # pcm_48000 = raw 16-bit mono 48 kHz: wrap it in a WAV header
    data = np.frombuffer(pcm, dtype="<i2").astype(np.float64) / 32768.0
    raw.unlink(missing_ok=True)
    write_wav(out, data)


def synth_google(text: str, out: Path) -> None:
    import base64
    import urllib.request

    token = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS_TOKEN")
    if not token:
        out_json = subprocess.run(
            ["gcloud", "auth", "application-default", "print-access-token"],
            check=True, capture_output=True, text=True).stdout.strip()
        token = out_json
    body = json.dumps({
        "input": {"text": text},
        "voice": {"languageCode": "de-DE", "name": VOICES["google"]["voice"]},
        "audioConfig": {"audioEncoding": "LINEAR16", "sampleRateHertz": SR, "speakingRate": 0.98},
    }).encode()
    req = urllib.request.Request(
        "https://texttospeech.googleapis.com/v1/text:synthesize", data=body,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    payload = json.loads(urllib.request.urlopen(req, timeout=90).read())
    out.write_bytes(base64.b64decode(payload["audioContent"]))


def synth_polly(text: str, out: Path) -> None:
    cfg = VOICES["polly"]
    raw = out.with_suffix(".raw.mp3")
    subprocess.run(
        ["aws", "polly", "synthesize-speech", "--output", "text", "--voice-id", cfg["voice"],
         "--engine", cfg["engine"], "--language-code", "de-DE", "--text", text, str(raw)],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    ffmpeg_resample(raw, out, SR, channels=1)
    raw.unlink(missing_ok=True)


PROVIDERS = {
    "espeak": synth_espeak,
    "azure": synth_azure,
    "elevenlabs": synth_elevenlabs,
    "google": synth_google,
    "polly": synth_polly,
}


# ----------------------------------------------------------------------- build
def build(provider: str = "espeak", dry_run: bool = False) -> dict:
    tl = load()
    VO_DIR.mkdir(parents=True, exist_ok=True)
    RENDER_DIR.mkdir(parents=True, exist_ok=True)

    lines = sorted(tl.vo_lines, key=lambda v: float(v["at"]))
    manifest: list[dict] = []
    cursor = 0.0
    shifts: list[dict] = []

    for i, line in enumerate(lines):
        declared = float(line["at"])
        at = max(declared, cursor)
        if at - declared > 1e-6:
            shifts.append({"id": line["id"], "declared": declared, "used": round(at, 3),
                           "reason": f"previous line still speaking (+{at - declared:.3f}s)"})
        path = VO_DIR / f"{line['id']}.wav"

        if not dry_run:
            PROVIDERS[provider](line["string"], path)
            sig = read_wav(path)
            write_wav(path, normalize_rms(sig, C.VO_RMS_DBFS))

        dur = 0.0 if dry_run else wav_duration(path)
        manifest.append({"id": line["id"], "string": line["string"], "declared_at": declared,
                         "at": round(at, 4), "duration": round(dur, 4), "path": str(path),
                         "provider": provider,
                         "placeholder": provider == "espeak"})
        cursor = at + dur + 0.5            # R-AUD-01: >= 0.5 s between lines

    payload = {
        "provider": provider,
        "placeholder": provider == "espeak",
        "sample_rate": SR,
        "target_rms_dbfs": C.VO_RMS_DBFS,
        "lines": manifest,
        "shifts": shifts,
    }
    if not dry_run:
        (RENDER_DIR / "vo_manifest.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                                                     encoding="utf-8")
        (RENDER_DIR / "vo_provider.txt").write_text(provider + ("\n" if provider != "espeak" else "  # PLACEHOLDER\n"),
                                                    encoding="utf-8")
    return payload


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m src.vo")
    ap.add_argument("--provider", choices=sorted(PROVIDERS), default="espeak")
    ap.add_argument("--dry-run", action="store_true", help="plan timings without synthesising")
    a = ap.parse_args(argv)

    payload = build(a.provider, dry_run=a.dry_run)
    for line in payload["lines"]:
        flag = "PLACEHOLDER" if line["placeholder"] else "neural"
        print(f"  {line['id']}  at {line['at']:6.3f}s  dur {line['duration']:5.3f}s  [{flag}]  {line['string'][:44]}")
    for s in payload["shifts"]:
        print(f"  ! shifted {s['id']}: {s['declared']} -> {s['used']} ({s['reason']})")
    if payload["placeholder"]:
        print("\n  NOTE: espeak output is a PLACEHOLDER. Allowed for the 1080p test only;")
        print("        the 4K master is blocked until a German neural voice is used (R-GATE-03).")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
