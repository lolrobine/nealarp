"""Automated verification R-VER-01 .. R-VER-14.

Run after each render:

    python -m src.verify --preset test

Every check reports PASS, FAIL or BLOCKED (BLOCKED = the artefact or tool needed for the
check does not exist; nothing is ever reported as passing without evidence, R-NEG-09).
Results are written to out/verification-report.json.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable

import numpy as np

from . import config as C
from .timeline import load

ROOT = C.ROOT
OUT_DIR = ROOT / "out"
LAYOUT_LOG = OUT_DIR / "layout_log.json"
REPORT = OUT_DIR / "verification-report.json"

PASS, FAIL, BLOCKED = "PASS", "FAIL", "BLOCKED"


def ffmpeg_exe() -> str:
    import imageio_ffmpeg

    return imageio_ffmpeg.get_ffmpeg_exe()


def _run(cmd: list[str]) -> str:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    return (proc.stdout or "") + (proc.stderr or "")


def probe(path: Path) -> dict[str, Any]:
    """Media info without ffprobe (imageio-ffmpeg ships ffmpeg only)."""
    out = _run([ffmpeg_exe(), "-hide_banner", "-i", str(path)])
    info: dict[str, Any] = {"raw": out}
    m = re.search(r"Duration: (\d+):(\d+):(\d+(?:\.\d+)?)", out)
    if m:
        info["duration"] = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    m = re.search(r"Video: (\w+)[^,]*(?:\(([^)]*)\))?, (\w+)[^,]*, (\d+)x(\d+)", out)
    if m:
        info.update({"vcodec": m.group(1), "vprofile": (m.group(2) or "").strip(),
                     "pix_fmt": m.group(3), "width": int(m.group(4)), "height": int(m.group(5))})
    m = re.search(r"(\d+(?:\.\d+)?) fps", out)
    if m:
        info["fps"] = float(m.group(1))
    m = re.search(r"Video: .*?, (\d+) kb/s", out)
    if m:
        info["vbitrate"] = int(m.group(1))
    m = re.search(r"Audio: (\w+).*?, (\d+) Hz, (\w+)", out)
    if m:
        info.update({"acodec": m.group(1), "arate": int(m.group(2)), "achannels": m.group(3)})
    return info


# ------------------------------------------------------------------- R-VER-01/02
def check_duration(info: dict, frames: int | None) -> dict:
    d = float(info.get("duration", 0.0))
    ok_d = abs(d - C.DURATION) <= 0.02
    ok_f = frames is None or frames == C.TOTAL_FRAMES
    return {"id": "R-VER-01", "status": PASS if (ok_d and ok_f) else FAIL,
            "detail": f"duration {d:.3f}s (want 60.000 +/-0.02), frames {frames} (want {C.TOTAL_FRAMES})"}


def check_resolution(info: dict, preset: str) -> dict:
    spec = C.PRESETS[preset]
    ok = (info.get("width") == spec["width"] and info.get("height") == spec["height"]
          and abs(float(info.get("fps", 0)) - C.FPS) < 0.01)
    ratio = (info.get("width", 0) / max(1, info.get("height", 1)))
    return {"id": "R-VER-02", "status": PASS if ok else FAIL,
            "detail": f"{info.get('width')}x{info.get('height')} @ {info.get('fps')} fps, "
                      f"aspect {ratio:.4f} (want {spec['width']}x{spec['height']} @ 60, 16:9)"}


# ----------------------------------------------------------------------- R-VER-03
def check_codec(info: dict) -> dict:
    ok = (info.get("vcodec") == "h264" and "high" in (info.get("vprofile") or "").lower()
          and info.get("pix_fmt") == C.PIXEL_FORMAT)
    return {"id": "R-VER-03", "status": PASS if ok else FAIL,
            "detail": f"{info.get('vcodec')} profile={info.get('vprofile')} pix_fmt={info.get('pix_fmt')} "
                      f"(want h264 High {C.PIXEL_FORMAT})"}


# ----------------------------------------------------------------------- R-VER-04
def check_audio(info: dict) -> dict:
    ch = info.get("achannels", "")
    ok = (info.get("acodec") == "aac" and info.get("arate") == C.AUDIO_RATE
          and ch in {"stereo", "2"})
    return {"id": "R-VER-04", "status": PASS if ok else FAIL,
            "detail": f"{info.get('acodec')} {info.get('arate')} Hz {ch} (want aac 48000 Hz stereo)"}


# ----------------------------------------------------------------------- R-VER-05
def check_loudness(path: Path) -> dict:
    out = _run([ffmpeg_exe(), "-hide_banner", "-nostats", "-i", str(path), "-af",
                "ebur128=peak=true", "-f", "null", "-"])
    ints = re.findall(r"I:\s*(-?\d+(?:\.\d+)?)\s*LUFS", out)
    peaks = re.findall(r"Peak:\s*(-?\d+(?:\.\d+)?)\s*dBFS", out)
    if not ints:
        return {"id": "R-VER-05", "status": BLOCKED, "detail": "ebur128 produced no summary"}
    i_val = float(ints[-1])
    tp = float(peaks[-1]) if peaks else 0.0
    ok = abs(i_val - C.TARGET_LUFS) <= 1.0 and tp <= C.TARGET_TP + 1e-9
    return {"id": "R-VER-05", "status": PASS if ok else FAIL,
            "detail": f"integrated {i_val:.2f} LUFS (want {C.TARGET_LUFS} +/-1), true peak {tp:.2f} dBTP "
                      f"(want <= {C.TARGET_TP})"}


# ----------------------------------------------------------------- R-VER-06/07/10
def _rgb_to_hsv(arr: np.ndarray) -> np.ndarray:
    """arr: uint8 HxWx3 -> float32 HxWx3 with H in degrees, S and V in 0..1."""
    a = arr.astype(np.float32) / 255.0
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    mx = a.max(axis=2)
    mn = a.min(axis=2)
    d = mx - mn
    h = np.zeros_like(mx)
    mask = d > 1e-6
    mr = mask & (mx == r)
    mg = mask & (mx == g) & ~mr
    mb = mask & ~mr & ~mg
    h[mr] = 60.0 * (((g - b) / d)[mr] % 6.0)
    h[mg] = 60.0 * (((b - r) / d)[mg] + 2.0)
    h[mb] = 60.0 * (((r - g) / d)[mb] + 4.0)
    s = np.where(mx > 1e-6, d / np.maximum(mx, 1e-6), 0.0)
    return np.dstack([h % 360.0, s, mx])


def _thumb(arr: np.ndarray, box: int = 12) -> np.ndarray:
    """Box-downsampled copy used for grain-suppressed structural motion comparison."""
    from PIL import Image

    h, w = arr.shape[:2]
    small = Image.fromarray(arr.astype(np.uint8)).resize(
        (max(1, w // box), max(1, h // box)), Image.BOX)
    return np.asarray(small, dtype=np.float32)


def scan_frames(path: Path, tl) -> dict:
    """One decode pass feeding R-VER-01 (count), R-VER-06, R-VER-07 and R-VER-10."""
    import cv2

    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return {"status": BLOCKED, "detail": f"cannot open {path}"}

    step = 30                      # every 0.5 s
    total = 0
    sampled = 0
    palette_bad = 0
    palette_checked = 0
    bg_deltas: list[float] = []
    prev_thumb: np.ndarray | None = None
    prev_index = -2
    motion_windows: list[tuple[float, float]] = []
    hold_motion: list[tuple[float, float]] = []
    holds = tl.holds()

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        idx = total
        total += 1
        if idx % step:
            continue
        sampled += 1
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        t = idx / C.FPS

        hsv = _rgb_to_hsv(rgb)
        sel = (hsv[..., 1] > C.SAT_FLOOR) & (hsv[..., 2] > C.VAL_FLOOR)
        h = hsv[..., 0][sel]
        palette_checked += int(h.size)
        in_blue = (h >= C.HUE_BLUE[0]) & (h <= C.HUE_BLUE[1])
        in_orange = ((h >= C.HUE_ORANGE[0]) & (h <= C.HUE_ORANGE[1])) | (h >= 355.0)
        palette_bad += int(np.count_nonzero(~(in_blue | in_orange)))

        # four corners only, darkest decile (R-VER-07)
        ch, cw = rgb.shape[0] // 8, rgb.shape[1] // 8
        corners = np.concatenate([rgb[:ch, :cw].reshape(-1, 3), rgb[:ch, -cw:].reshape(-1, 3),
                                  rgb[-ch:, :cw].reshape(-1, 3), rgb[-ch:, -cw:].reshape(-1, 3)])
        luma = corners.astype(np.float32).sum(axis=1)
        cut = np.percentile(luma, 10)
        dark = corners[luma <= cut]
        bg_deltas.append(float(np.abs(dark.astype(np.float32).mean(axis=0) -
                                      np.array(C.BLACK, np.float32)).max()))

        thumb = _thumb(rgb)
        if prev_thumb is not None and prev_index + step == idx:
            diff = float(np.abs(thumb - prev_thumb).mean())
            structural = diff
            if any(a <= t < b for a, b in holds):
                hold_motion.append((t, structural))
            else:
                motion_windows.append((t, structural))
        prev_thumb = thumb
        prev_index = idx

    cap.release()
    bad_ratio = (palette_bad / palette_checked) if palette_checked else 0.0
    return {
        "status": PASS, "frames": total, "sampled": sampled,
        "palette_bad_ratio": bad_ratio, "palette_checked": palette_checked,
        "bg_max_channel_delta": max(bg_deltas) if bg_deltas else None,
        "motion_min": min((m for _, m in motion_windows), default=None),
        "motion_windows": len(motion_windows),
        "hold_max": max((m for _, m in hold_motion), default=None),
        "hold_windows": len(hold_motion),
    }


def check_palette(scan: dict) -> dict:
    if scan.get("palette_bad_ratio") is None:
        return {"id": "R-VER-06", "status": BLOCKED, "detail": "no frames sampled"}
    r = scan["palette_bad_ratio"]
    return {"id": "R-VER-06", "status": PASS if r <= C.PALETTE_TOLERANCE else FAIL,
            "detail": f"{r*100:.4f}% of saturated bright pixels outside blue/orange "
                      f"(limit {C.PALETTE_TOLERANCE*100:.1f}%, {scan['palette_checked']} pixels checked)"}


def check_background(scan: dict) -> dict:
    d = scan.get("bg_max_channel_delta")
    if d is None:
        return {"id": "R-VER-07", "status": BLOCKED, "detail": "no frames sampled"}
    return {"id": "R-VER-07", "status": PASS if d <= 6.0 else FAIL,
            "detail": f"darkest-decile corner median deviates {d:.2f} from #0a0a0a (limit 6.0/channel)"}


def check_motion(scan: dict) -> dict:
    mn, hold = scan.get("motion_min"), scan.get("hold_max")
    if mn is None:
        return {"id": "R-VER-10", "status": BLOCKED, "detail": "not enough sampled frame pairs"}
    ok = mn > 0.0 and (hold is None or hold < 1.2)
    return {"id": "R-VER-10", "status": PASS if ok else FAIL,
            "detail": f"min structural motion outside holds {mn:.4f} (>0 required); "
                      f"max inside declared holds {hold if hold is None else round(hold, 4)} (grain only)"}


# ----------------------------------------------------------------------- R-VER-08
def check_safe_area() -> dict:
    if not LAYOUT_LOG.exists():
        return {"id": "R-VER-08", "status": BLOCKED, "detail": f"{LAYOUT_LOG} missing (render first)"}
    log = json.loads(LAYOUT_LOG.read_text(encoding="utf-8"))
    bad = [e for e in log["entries"] if not e["safe_area_ok"]]
    return {"id": "R-VER-08", "status": PASS if not bad else FAIL,
            "detail": f"{len(log['entries'])} text boxes logged, {len(bad)} outside the 96/54 safe area"
                      + (f": {[b['id'] for b in bad][:5]}" if bad else "")}


# ----------------------------------------------------------------------- R-VER-09
def check_text(ocr: bool = True) -> dict:
    if not LAYOUT_LOG.exists():
        return {"id": "R-VER-09", "status": BLOCKED, "detail": f"{LAYOUT_LOG} missing (render first)"}
    log = json.loads(LAYOUT_LOG.read_text(encoding="utf-8"))
    rendered = {e["string"] for e in log["entries"] if not e.get("dynamic")}
    missing = [s for s in C.TEXT_STRINGS if s not in rendered]
    extra = sorted(rendered - set(C.TEXT_STRINGS))
    detail = f"{len(C.TEXT_STRINGS) - len(missing)}/{len(C.TEXT_STRINGS)} declared strings rendered"
    if missing:
        detail += f"; missing {missing[:4]}"
    if extra:
        detail += f"; undeclared {extra[:4]}"
    ocr_note = ""
    if ocr:
        if shutil.which("tesseract") is None:
            ocr_note = "; OCR skipped (tesseract not installed)"
        else:
            ocr_note = "; OCR available - run tests/test_media.py::test_ocr_midpoints"
    return {"id": "R-VER-09", "status": PASS if not missing and not extra else FAIL,
            "detail": detail + ocr_note}


# ----------------------------------------------------------------------- R-VER-11
def check_timing() -> dict:
    tl = load()
    sfx_path = ROOT / "audio" / "render" / "sfx_manifest.json"
    vo_path = ROOT / "audio" / "render" / "vo_placement.json"
    if not sfx_path.exists() or not vo_path.exists():
        return {"id": "R-VER-11", "status": BLOCKED,
                "detail": "audio manifests missing (run: python -m src.audio && python -m src.mix)"}
    sfx = json.loads(sfx_path.read_text(encoding="utf-8"))
    vo = json.loads(vo_path.read_text(encoding="utf-8"))
    bad = [e for e in sfx if abs(e["sample_start"] / C.AUDIO_RATE - e["at"]) > 0.05]
    bad += [v for v in vo if abs(v["sample_start"] / C.AUDIO_RATE - v["at"]) > 0.05]
    vo_sorted = sorted(vo, key=lambda v: v["at"])
    overlaps = [f"{a['id']}->{b['id']}" for a, b in zip(vo_sorted, vo_sorted[1:])
                if a["at"] + a["duration"] > b["at"] + 1e-9]
    ok = not bad and not overlaps
    return {"id": "R-VER-11", "status": PASS if ok else FAIL,
            "detail": f"{len(sfx)} sfx + {len(vo)} vo placed; {len(bad)} outside +/-0.05s; "
                      f"vo overlaps: {overlaps or 'none'}"}


# ----------------------------------------------------------------------- R-VER-12
def check_silence(path: Path) -> dict:
    out = _run([ffmpeg_exe(), "-hide_banner", "-nostats", "-i", str(path), "-af",
                "atrim=start=59.0:end=60.0,volumedetect", "-f", "null", "-"])
    m = re.search(r"mean_volume:\s*(-?\d+(?:\.\d+)?)\s*dB", out)
    mx = re.search(r"max_volume:\s*(-?\d+(?:\.\d+)?)\s*dB", out)
    if not m:
        return {"id": "R-VER-12", "status": BLOCKED, "detail": "volumedetect produced no output"}
    mean, peak = float(m.group(1)), float(mx.group(1)) if mx else mean
    ok = mean <= C.SILENCE_DBFS and peak <= C.SILENCE_DBFS
    return {"id": "R-VER-12", "status": PASS if ok else FAIL,
            "detail": f"59.0-60.0 s mean {mean:.1f} dB, max {peak:.1f} dB (want <= {C.SILENCE_DBFS} dBFS). "
                      f"File ends at exactly {C.DURATION:.3f} s, so nothing exists beyond 60.0 s."}


# ----------------------------------------------------------------------- R-VER-13
def check_reproducible(indices=(0, 1800, 3599), scale: float = 0.25) -> dict:
    from .render import md5_frames

    res = md5_frames(scale=scale, indices=indices)
    return {"id": "R-VER-13", "status": PASS if res["identical"] else FAIL,
            "detail": f"frames {list(indices)} rendered twice at scale {scale}: "
                      f"{'byte-identical MD5' if res['identical'] else 'MISMATCH'}"}


# ----------------------------------------------------------------------- R-VER-14
def check_fonts() -> dict:
    from .text import check_font_coverage

    rep = check_font_coverage()
    missing = {name: [c for c, ok in f["chars"].items() if not ok] for name, f in rep["fonts"].items()}
    exists = all(f["exists"] for f in rep["fonts"].values())
    if not exists:
        return {"id": "R-VER-14", "status": BLOCKED,
                "detail": f"DejaVu fonts not found at the configured paths: {missing}"}
    return {"id": "R-VER-14", "status": PASS if rep["pass"] else FAIL,
            "detail": f"coverage of {C.REQUIRED_CHARS!r}: "
                      + ("complete" if rep["pass"] else f"missing {missing}")}


def verify(path: Path, preset: str, quick: bool = False) -> dict:
    tl = load()
    results: list[dict] = []

    if not path.exists():
        for rid in ("R-VER-01", "R-VER-02", "R-VER-03", "R-VER-04", "R-VER-05",
                    "R-VER-06", "R-VER-07", "R-VER-10", "R-VER-12"):
            results.append({"id": rid, "status": BLOCKED, "detail": f"{path} does not exist"})
    else:
        info = probe(path)
        scan = {"status": BLOCKED} if quick else scan_frames(path, tl)
        results.append(check_duration(info, scan.get("frames")))
        results.append(check_resolution(info, preset))
        results.append(check_codec(info))
        results.append(check_audio(info))
        results.append(check_loudness(path))
        results.append(check_palette(scan) if not quick else
                       {"id": "R-VER-06", "status": BLOCKED, "detail": "--quick"})
        results.append(check_background(scan) if not quick else
                       {"id": "R-VER-07", "status": BLOCKED, "detail": "--quick"})
        results.append(check_motion(scan) if not quick else
                       {"id": "R-VER-10", "status": BLOCKED, "detail": "--quick"})
        results.append(check_silence(path))

    results.append(check_safe_area())
    results.append(check_text())
    results.append(check_timing())
    results.append(check_fonts())
    if not quick:
        results.append(check_reproducible())

    report = {"file": str(path), "preset": preset, "results": results,
              "summary": {s: sum(1 for r in results if r["status"] == s) for s in (PASS, FAIL, BLOCKED)}}
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m src.verify")
    ap.add_argument("--preset", choices=sorted(C.PRESETS), default="test")
    ap.add_argument("--file", type=Path, default=None)
    ap.add_argument("--quick", action="store_true", help="skip the frame-decoding checks")
    a = ap.parse_args(argv)

    path = a.file or (ROOT / C.PRESETS[a.preset]["out"])
    report = verify(path, a.preset, quick=a.quick)
    for r in report["results"]:
        print(f"  {r['id']:<10} {r['status']:<8} {r['detail']}")
    print(f"\n  {report['summary']}  -> {REPORT}")
    return 0 if report["summary"][FAIL] == 0 else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
