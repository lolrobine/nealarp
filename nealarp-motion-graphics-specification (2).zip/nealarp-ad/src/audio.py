"""Original audio, generated in code (R-AUD-02, R-AUD-03).

No samples, no licensed material (R-NEG-07): every sound is synthesised from oscillators
and noise here. 48 kHz throughout, all levels in dBFS as specified.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from . import config as C
from .timeline import load

SR = C.AUDIO_RATE
ROOT = C.ROOT
RENDER_DIR = ROOT / "audio" / "render"


# --------------------------------------------------------------------- helpers
def db_to_amp(db: float) -> float:
    return float(10.0 ** (db / 20.0))


def timebase(dur: float) -> np.ndarray:
    return np.arange(int(round(dur * SR)), dtype=np.float64) / SR


def sine(freq: float, dur: float, phase: float = 0.0) -> np.ndarray:
    return np.sin(2 * math.pi * freq * timebase(dur) + phase)


def sweep(f0: float, f1: float, dur: float, exp: bool = True) -> np.ndarray:
    t = timebase(dur)
    if exp:
        f = f0 * (f1 / f0) ** (t / dur)
        phase = 2 * math.pi * f0 * dur / math.log(f1 / f0) * ((f1 / f0) ** (t / dur) - 1)
    else:
        f = f0 + (f1 - f0) * (t / dur)
        phase = 2 * math.pi * (f0 * t + (f1 - f0) * t * t / (2 * dur))
    return np.sin(phase)


def adsr(n: int, attack: float, decay: float, sustain: float = 0.0, release: float = 0.0) -> np.ndarray:
    """Simple percussive envelope: attack -> exponential decay to `sustain`."""
    env = np.zeros(n)
    a = max(1, int(attack * SR))
    d = max(1, int(decay * SR))
    env[:min(a, n)] = np.linspace(0, 1, min(a, n))
    idx = np.arange(min(a + d, n) - a)
    tail = sustain + (1 - sustain) * np.exp(-4.0 * idx / max(1, d))
    env[a:a + len(tail)] = tail
    if release > 0:
        r = min(int(release * SR), n)
        env[-r:] *= np.linspace(1, 0, r)
    return env


def peak_normalize(sig: np.ndarray, dbfs: float) -> np.ndarray:
    peak = float(np.max(np.abs(sig))) or 1.0
    return sig / peak * db_to_amp(dbfs)


_LP_BLOCK = 256
_LP_CACHE: dict[float, tuple[np.ndarray, np.ndarray]] = {}


def lowpass(sig: np.ndarray, cutoff: float) -> np.ndarray:
    """One-pole lowpass y[k] = a*x[k] + (1-a)*y[k-1], evaluated block-wise.

    A block is solved as a single triangular matrix-vector product, which is the exact
    recursion (no approximation) while staying numpy-vectorised — no scipy, no Python
    loop over samples (R-PERF-02 applied to audio).
    """
    n = int(sig.shape[0])
    if n == 0 or cutoff <= 0:
        return np.zeros(n)
    if cutoff >= SR / 2.0:
        return sig.copy()

    rc = 1.0 / (2 * math.pi * cutoff)
    a = (1.0 / SR) / (rc + 1.0 / SR)
    b = 1.0 - a

    key = round(cutoff, 3)
    cached = _LP_CACHE.get(key)
    if cached is None:
        j = np.arange(_LP_BLOCK)
        K = np.where(j[:, None] >= j[None, :], b ** (j[:, None] - j[None, :]), 0.0) * a
        carry = b ** (j + 1)
        _LP_CACHE[key] = (K, carry)
        cached = (K, carry)
    K, carry = cached

    out = np.empty(n)
    y_prev = 0.0
    for s in range(0, n, _LP_BLOCK):
        e = min(n, s + _LP_BLOCK)
        x = sig[s:e]
        if e - s == _LP_BLOCK:
            y = K @ x + carry * y_prev
        else:
            jj = np.arange(e - s)
            Ks = np.where(jj[:, None] >= jj[None, :], b ** (jj[:, None] - jj[None, :]), 0.0) * a
            y = Ks @ x + (b ** (jj + 1)) * y_prev
        out[s:e] = y
        y_prev = float(y[-1])
    return out


def bandpass(sig: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return lowpass(sig, hi) - lowpass(sig, lo)


def brown_noise(dur: float, seed: str = "brown") -> np.ndarray:
    rng = C.rng(seed)
    n = int(dur * SR)
    w = rng.standard_normal(n)
    b = np.cumsum(w)
    b -= np.linspace(b[0], b[-1], n)
    return b / (np.max(np.abs(b)) or 1.0)


def white_noise(dur: float, seed: str = "white") -> np.ndarray:
    return C.rng(seed).standard_normal(int(dur * SR))


def write_wav(path: Path, sig: np.ndarray, stereo: bool = False) -> Path:
    import wave

    path.parent.mkdir(parents=True, exist_ok=True)
    data = np.clip(sig, -1.0, 1.0)
    pcm = (data * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2 if stereo else 1)
        w.setsampwidth(2)
        w.setframerate(SR)
        if stereo:
            w.writeframes(pcm.tobytes())
        else:
            w.writeframes(pcm.tobytes())
    return path


def ffmpeg_exe() -> str:
    import imageio_ffmpeg

    return imageio_ffmpeg.get_ffmpeg_exe()


def ffmpeg_resample(src: Path, dst: Path, sr: int = SR, channels: int = 1) -> Path:
    """Canonicalise any synthesiser output to 48 kHz / 16-bit PCM."""
    import subprocess

    dst.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [ffmpeg_exe(), "-y", "-i", str(src), "-ar", str(sr), "-ac", str(channels),
         "-c:a", "pcm_s16le", str(dst)],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    return dst


def read_wav(path: Path) -> np.ndarray:
    """Read a PCM WAV as mono float64, resampling to SR if needed (linear, deterministic)."""
    import wave

    with wave.open(str(path), "rb") as w:
        n, ch, sw, sr = w.getnframes(), w.getnchannels(), w.getsampwidth(), w.getframerate()
        raw = w.readframes(n)
    dtype = {1: np.int8, 2: "<i2", 4: "<i4"}[sw]
    scale = {1: 128.0, 2: 32768.0, 4: 2147483648.0}[sw]
    data = np.frombuffer(raw, dtype=dtype).astype(np.float64) / scale
    if ch > 1:
        data = data.reshape(-1, ch).mean(axis=1)
    if sr != SR and data.size:
        target = int(round(data.size * SR / sr))
        x_old = np.linspace(0.0, 1.0, data.size)
        x_new = np.linspace(0.0, 1.0, target)
        data = np.interp(x_new, x_old, data)
    return data


def read_wav_stereo(path: Path) -> np.ndarray:
    """Read a PCM WAV as (N,2) float64 without downmixing (the music bed is panned)."""
    import wave

    with wave.open(str(path), "rb") as w:
        n, ch, sw, sr = w.getnframes(), w.getnchannels(), w.getsampwidth(), w.getframerate()
        raw = w.readframes(n)
    dtype = {1: np.int8, 2: "<i2", 4: "<i4"}[sw]
    scale = {1: 128.0, 2: 32768.0, 4: 2147483648.0}[sw]
    data = np.frombuffer(raw, dtype=dtype).astype(np.float64) / scale
    if ch >= 2:
        data = data[: (data.size // 2) * 2].reshape(-1, 2)
    else:
        data = np.stack([data, data], axis=1)
    if sr != SR and data.shape[0]:
        target = int(round(data.shape[0] * SR / sr))
        x_old = np.linspace(0.0, 1.0, data.shape[0])
        x_new = np.linspace(0.0, 1.0, target)
        data = np.stack([np.interp(x_new, x_old, data[:, c]) for c in range(2)], axis=1)
    return data


def to_stereo(sig: np.ndarray, width: float = 0.0) -> np.ndarray:
    """(N,) -> (N,2). `width` decorrelates the sides slightly for a wider bed."""
    n = sig.shape[0]
    if width <= 0:
        return np.stack([sig, sig], axis=1)
    d = max(1, int(width * SR * 0.001))
    right = np.concatenate([np.zeros(d), sig])[:n]
    return np.stack([sig, right], axis=1)


def place(bed: np.ndarray, sig: np.ndarray, at: float, gain: float = 1.0) -> None:
    start = int(round(at * SR))
    end = min(bed.shape[0], start + sig.shape[0])
    if start >= bed.shape[0] or end <= start:
        return
    bed[start:end] += sig[: end - start] * gain


# --------------------------------------------------------------- sfx (R-AUD-03)
def sfx_pop() -> np.ndarray:
    sig = sweep(1200, 600, 0.080) * adsr(int(0.080 * SR), 0.001, 0.079)
    sig[: int(0.005 * SR)] += white_noise(0.005, "pop-transient") * 0.6
    return peak_normalize(sig, -6)


def sfx_click() -> np.ndarray:
    """White noise, 4 ms, bandpass 2-4 kHz, 25 ms decay. Peak -8 dBFS."""
    dur = 0.029
    n = int(dur * SR)
    noise = white_noise(dur, "click")
    noise[int(0.004 * SR):] *= np.exp(-np.arange(n - int(0.004 * SR)) / (0.025 * SR))
    sig = bandpass(noise, 2000, 4000) * adsr(n, 0.0005, dur - 0.0005)
    return peak_normalize(sig, -8)


def sfx_coin_clink(seed: int = 0) -> np.ndarray:
    rng = C.rng(f"clink:{seed}")
    f1 = 3000 * (1 + (rng.random() * 2 - 1) * 0.03)
    f2 = 4500 * (1 + (rng.random() * 2 - 1) * 0.03)
    n = int(0.300 * SR)
    env = adsr(n, 0.001, 0.300)
    sig = (sine(f1, 0.300) * 0.6 + sine(f2, 0.300) * 0.4) * env
    return peak_normalize(sig, -10)


def sfx_lock_clunk() -> np.ndarray:
    sig = sweep(90, 55, 0.180) * adsr(int(0.180 * SR), 0.002, 0.178)
    head = sfx_click()
    sig[: head.shape[0]] += head * 0.9
    return peak_normalize(sig, -6)


def sfx_bubble(seed: int = 0) -> np.ndarray:
    rng = C.rng(f"bubble:{seed}")
    dur = 0.060 + rng.random() * 0.060
    n = int(dur * SR)
    sig = sweep(300, 900, dur) * adsr(n, 0.004, dur - 0.004)
    return peak_normalize(sig, -14)


def sfx_whirr(dur: float = 3.0) -> np.ndarray:
    n = int(dur * SR)
    t = timebase(dur)
    p = t / dur
    sig = np.zeros(n)
    for i in range(8):
        detune = 1.0 + (i - 3.5) * 0.006
        f = (200 + (1200 - 200) * p) * detune
        sig += np.sin(2 * math.pi * np.cumsum(f) / SR) / (1 + i * 0.4)
    env = np.sin(math.pi * p) ** 0.6
    return peak_normalize(sig * env, -12)


def sfx_boom() -> np.ndarray:
    dur = 1.5
    n = int(dur * SR)
    sub = sine(60, dur) * adsr(n, 0.004, 1.2)
    body = lowpass(brown_noise(dur, "boom-brown"), 600) * adsr(n, 0.002, 1.5)
    return peak_normalize(sub * 0.75 + body * 0.55, -4)


def sfx_pen_draw(dur: float = 1.2) -> np.ndarray:
    n = int(dur * SR)
    t = timebase(dur)
    sig = bandpass(white_noise(dur, "pen"), 2000, 5000)
    sig *= (0.55 + 0.45 * np.sin(2 * math.pi * 18 * t)) * adsr(n, 0.02, dur - 0.02, sustain=0.7)
    return peak_normalize(sig, -18)


def sfx_heartbeat() -> np.ndarray:
    dur = 0.42
    n = int(dur * SR)
    sig = np.zeros(n)
    thump = sine(55, 0.120) * adsr(int(0.120 * SR), 0.004, 0.116)
    sig[: thump.shape[0]] += thump
    off = int(0.300 * SR)
    sig[off:off + thump.shape[0]] += thump * 0.7
    return peak_normalize(sig, -8)


def sfx_whoosh_zoom(dur: float = 1.2) -> np.ndarray:
    n = int(dur * SR)
    t = timebase(dur)
    p = t / dur
    sig = white_noise(dur, "whoosh")
    lo = 300 * (3000 / 300) ** p
    out = np.zeros(n)
    step = max(1, n // 60)
    for i in range(0, n, step):
        j = min(n, i + step)
        out[i:j] = lowpass(sig[i:j], max(120.0, float(lo[i])))
    out *= np.sin(math.pi * p) ** 1.2
    return peak_normalize(out, -10)


def sfx_bass_drop() -> np.ndarray:
    dur = 1.5
    sig = sweep(120, 35, dur) * adsr(int(dur * SR), 0.01, dur - 0.01)
    return peak_normalize(sig, -4)


def sfx_bass_hit() -> np.ndarray:
    dur = 0.8
    n = int(dur * SR)
    sig = sine(45, dur) * adsr(n, 0.002, dur - 0.002)
    tr = white_noise(0.02, "hit-transient") * 0.5
    sig[: tr.shape[0]] += tr
    sig = peak_normalize(sig, -3)
    # echo: delay 0.25 s, feedback 0.3 (R-AUD-02)
    out = np.zeros(int((dur + 1.6) * SR))
    out[: sig.shape[0]] += sig
    fb, d = 0.3, int(0.25 * SR)
    gain = fb
    for k in range(1, 5):
        s = int(k * d)
        if s + sig.shape[0] > out.shape[0]:
            break
        out[s:s + sig.shape[0]] += sig * gain
        gain *= fb
    return peak_normalize(out, -3)


SFX = {
    "sfx_pop": sfx_pop,
    "sfx_click": sfx_click,
    "sfx_coin_clink": sfx_coin_clink,
    "sfx_lock_clunk": sfx_lock_clunk,
    "sfx_bubble": sfx_bubble,
    "sfx_whirr": sfx_whirr,
    "sfx_boom": sfx_boom,
    "sfx_pen_draw": sfx_pen_draw,
    "sfx_heartbeat": sfx_heartbeat,
    "sfx_whoosh_zoom": sfx_whoosh_zoom,
    "sfx_bass_drop": sfx_bass_drop,
    "sfx_bass_hit": sfx_bass_hit,
}


def build(name: str, duration: float | None = None, seed: int = 0) -> np.ndarray:
    fn = SFX[name]
    if name == "sfx_whirr":
        return fn(duration or 3.0)
    if name == "sfx_pen_draw":
        return fn(duration or 1.2)
    if name in {"sfx_coin_clink", "sfx_bubble"}:
        return fn(seed)
    return fn()


def render_sfx_bed(tl=None) -> tuple[np.ndarray, list[dict]]:
    """Place every declared sfx at its declared time (R-VER-11 checks the manifest)."""
    tl = tl or load()
    bed = np.zeros(int(C.DURATION * SR))
    manifest: list[dict] = []
    for i, ev in enumerate(tl.sfx_events()):
        sig = build(ev["id"], ev.get("duration"), seed=i)
        place(bed, sig, ev["at"])
        manifest.append({**ev, "samples": int(sig.shape[0]),
                         "sample_start": int(round(ev["at"] * SR))})
    return bed, manifest


# --------------------------------------------------------------- music (R-AUD-02)
BPM = 120.0
BEAT = 60.0 / BPM            # 0.5 s
BAR = BEAT * 4               # 2.0 s
# A minor-ish progression, all frequencies derived in code (no samples, no licensing)
PROGRESSION = [
    [220.00, 261.63, 329.63, 440.00],   # Am
    [174.61, 220.00, 261.63, 349.23],   # F
    [130.81, 196.00, 261.63, 329.63],   # C
    [196.00, 246.94, 293.66, 392.00],   # G
]


def _voiced(freq: float, dur: float, warmth: float, detune: float = 0.004) -> np.ndarray:
    """'Sawtooth-like': 8 detuned sines, higher harmonics emphasised as `warmth` grows."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for k in range(1, 9):
        f = freq * k * (1 + (k - 4.5) * detune)
        weight = (1.0 / k) * (1.0 + warmth * (k - 1) * 0.34)
        out += np.sin(2 * math.pi * f * t + k * 0.7) * weight
    return out / 3.2


def render_music(dur: float = C.DURATION) -> np.ndarray:
    n = int(dur * SR)
    t = np.arange(n) / SR
    left = np.zeros(n)
    right = np.zeros(n)

    # --- 0-8 s: bass drop + cold blue arpeggios + riser
    drop = sfx_bass_drop()
    place(left, drop * 0.9, 0.0)
    place(right, drop * 0.9, 0.0)

    steps = int(dur / (BEAT / 4))
    for s in range(steps):
        st = s * (BEAT / 4)
        if st >= dur:
            break
        bar = int(st // BAR) % len(PROGRESSION)
        chord = PROGRESSION[bar]
        note = chord[s % len(chord)]
        d = BEAT / 4 * 0.92

        if st < 8.0:
            warmth = 0.0
            amp = 0.10 + 0.05 * (st / 8.0)
        elif st < 32.0:
            warmth = (st - 8.0) / 24.0          # warms toward orange harmonics by 32 s
            amp = 0.16 + 0.05 * warmth
        elif st < 44.0:
            warmth = 1.0
            swell = (st - 32.0) / 12.0
            amp = 0.20 + 0.20 * swell ** 1.6    # cinematic swell to the 44.0 s crescendo
        else:
            warmth = 1.0
            amp = 0.30 * max(0.0, 1.0 - (st - 44.0) / 14.0)

        sig = _voiced(note * 2, d, warmth) * adsr(int(d * SR), 0.006, d - 0.006, sustain=0.25) * amp
        sig = lowpass(sig, 2000.0 if warmth < 0.5 else 2000.0 + 2600.0 * warmth)
        if s % 2 == 0:
            place(left, sig, st, 1.0)
            place(right, sig, st, 0.62)
        else:
            place(left, sig, st, 0.62)
            place(right, sig, st, 1.0)

        # sub bass on every beat
        if s % 4 == 0:
            sub = sine(chord[0] / 2, BEAT * 0.9) * adsr(int(BEAT * 0.9 * SR), 0.01, BEAT * 0.85)
            gain = 0.34 if st < 32.0 else (0.42 if st < 44.0 else 0.42 * max(0.0, 1 - (st - 44.0) / 12.0))
            place(left, sub * gain, st)
            place(right, sub * gain, st)

    # risers
    for start, length, amp in ((4.5, 3.5, 0.16), (36.0, 8.0, 0.30)):
        noise = white_noise(length, f"riser:{start}")
        env = np.linspace(0.05, 1.0, int(length * SR)) ** 2.0
        sweep_up = bandpass(noise, 300, 6000) * env * amp
        place(left, sweep_up, start)
        place(right, sweep_up[::-1] * 0.9, start)

    # 44 s: confident bass hit with echo, then fade to silence by 60 s (R-AUD-02)
    hit = sfx_bass_hit()
    place(left, hit * 0.95, 44.0)
    place(right, hit * 0.95, 44.0)

    fade_start = int(52.0 * SR)
    ramp = np.linspace(1.0, 0.0, n - fade_start) ** 1.6
    left[fade_start:] *= ramp
    right[fade_start:] *= ramp
    left[int(59.5 * SR):] = 0.0
    right[int(59.5 * SR):] = 0.0

    stereo = np.stack([left, right], axis=1)
    peak = float(np.max(np.abs(stereo))) or 1.0
    return (stereo / peak * db_to_amp(-8.0)).astype(np.float64)


def main() -> int:
    RENDER_DIR.mkdir(parents=True, exist_ok=True)
    tl = load()

    music = render_music()
    write_wav(RENDER_DIR / "music.wav", music, stereo=True)

    bed, manifest = render_sfx_bed(tl)
    write_wav(RENDER_DIR / "sfx.wav", to_stereo(bed, width=6.0), stereo=True)

    (RENDER_DIR / "sfx_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"music.wav  {music.shape[0] / SR:.3f} s stereo")
    print(f"sfx.wav    {bed.shape[0] / SR:.3f} s, {len(manifest)} events")
    print(f"manifest   {RENDER_DIR / 'sfx_manifest.json'}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
