"""nealarp-ad renderer package.

Deterministic, code-only motion graphics. `src.compose.render_frame(t, scale)` is a pure
function of time: nothing is integrated across frames, so any frame can be rendered in
isolation and twice-rendered frames are byte-identical (R-VER-13).
"""

__all__ = ["config", "easing", "text", "layers", "sprites", "particles", "timeline", "scenes", "compose"]
__version__ = "1.0.0"
