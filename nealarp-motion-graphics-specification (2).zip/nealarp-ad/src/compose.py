"""The pure frame function (R-OUT-02).

    frame(t) -> uint8 HxWx3

`t` is the only input that changes between frames. Everything else — timeline, palette,
fonts, seeded randomness — is fixed at construction time, so any frame can be rendered
alone, out of order, or twice with byte-identical results (R-VER-13).
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np
from PIL import Image

from . import config as C
from . import layers
from .easing import apply, clamp, lerp, progress
from .scenes import PAINTERS, Ctx
from .text import TextSystem
from .timeline import Element, Timeline, load as load_timeline

# Layers handled by the post pipeline rather than by a painter.
POST_TYPES = {"background_haze", "film_grain", "bloom", "vignette", "fade_out"}


class Composer:
    def __init__(self, timeline: Timeline | None = None, scale: float = 1.0,
                 width: int | None = None, height: int | None = None) -> None:
        self.tl = timeline or load_timeline()
        self.scale = float(scale)
        self.w = int(width or round(C.REF_W * self.scale))
        self.h = int(height or round(C.REF_H * self.scale))
        self.text = TextSystem(self.scale)
        self._bg_img = Image.fromarray(layers.make_background(self.w, self.h)).convert("RGB")
        self._vig = layers.make_vignette(self.w, self.h)
        self._globals: dict[str, Element] = {g.type: g for g in self.tl.globals}

    # ---------------------------------------------------------------- helpers
    def _global(self, kind: str) -> Element | None:
        return self._globals.get(kind)

    def _global_active(self, kind: str, t: float) -> bool:
        g = self._global(kind)
        return bool(g and g.start <= t < g.end)

    def _collect_mods(self, t: float, elements: list[Element]) -> dict[str, Any]:
        mods: dict[str, Any] = {"shake": (0.0, 0.0), "pulse": {}, "lock_scale": 1.0}
        for el in elements:
            if el.type == "camera_shake":
                dx, dy = layers.camera_shake(t, el.start, el.end, float(el.props.get("amplitude", 12)),
                                             float(el.props.get("frequency", 24)), self.scale,
                                             bool(el.props.get("decay", True)))
                mods["shake"] = (mods["shake"][0] + dx, mods["shake"][1] + dy)
            elif el.type == "lock_click":
                p = apply(el.ease, progress(t, el.start, el.end))
                mods["lock_scale"] = lerp(float(el.props.get("scale_from", 1.04)),
                                          float(el.props.get("scale_to", 1.0)), p)
            elif el.type == "title_pulse":
                tid = str(el.props.get("text_id", ""))
                period = float(el.props.get("period", 0.2))
                mul = 1.0
                for at in el.props.get("at", []):
                    pp = progress(t, float(at), float(at) + period)
                    if 0 < pp < 1:
                        mul = max(mul, 1.0 + (float(el.props.get("scale_to", 1.08)) - 1.0)
                                  * math.sin(math.pi * pp))
                mods["pulse"][tid] = mul
        return mods

    def _particle_form_alpha(self, t: float, entry, scene) -> float:
        """Solid glyphs only appear once the reforming particles have settled."""
        reform = next((e for e in scene.elements
                       if e.type == "reform_text" and e.props.get("text_id") == entry.id), None)
        if reform is None:
            return 1.0
        settle = float(reform.props.get("settle", 0.3))
        return clamp(progress(t, reform.end - settle, reform.end))

    # ------------------------------------------------------------------ frame
    def frame_image(self, t: float) -> Image.Image:
        scene = self.tl.scene_at(t)
        elements = [g for g in self.tl.globals if g.type not in POST_TYPES and g.start <= t < g.end]
        if scene:
            elements += [e for e in scene.elements if e.type not in POST_TYPES and e.start <= t < e.end]

        img = self._bg_img.copy()
        mods = self._collect_mods(t, elements)
        ctx = Ctx(img=img, t=t, scale=self.scale, text=self.text, scene=scene, mods=mods)

        for el in elements:
            painter = PAINTERS.get(el.type)
            if painter is None:
                raise KeyError(f"no painter for element type '{el.type}' (id={el.id}) — "
                               f"nothing may appear without a declared painter (R-TIME-04)")
            painter(ctx, el)
        ctx.flush()

        # camera shake: shift the whole frame over a fresh background (R-SCN-03/06)
        dx, dy = mods["shake"]
        if abs(dx) > 0.05 or abs(dy) > 0.05:
            shifted = self._bg_img.copy()
            shifted.paste(img, (int(round(dx)), int(round(dy))))
            img = shifted

        # text last, so titles always sit on top of their key visual (R-TXT-02)
        if scene:
            for entry in scene.text:
                if not (entry.start <= t < entry.end):
                    continue
                if entry.props.get("anchor_only"):
                    continue  # rendered by its counter element through the same text system
                alpha = 1.0
                if entry.props.get("particle_form"):
                    alpha = self._particle_form_alpha(t, entry, scene)
                    if alpha <= 0.01:
                        continue
                mul = float(mods["pulse"].get(entry.id, 1.0))
                self.text.draw(img, entry, t, alpha=alpha, scale_mul=mul)

        return img

    def frame(self, t: float, frame_index: int | None = None) -> np.ndarray:
        """uint8 RGB frame for time `t` (R-OUT-02)."""
        arr = np.asarray(self.frame_image(t), dtype=np.float32)

        if self._global_active("bloom", t):
            g = self._global("bloom")
            arr = layers.bloom(arr, int(g.props.get("blur", C.BLOOM_BLUR)) * self.scale / 1.0,
                               float(g.props.get("strength", C.BLOOM_STRENGTH)),
                               int(g.props.get("threshold", C.BLOOM_THRESHOLD)))

        if self._global_active("film_grain", t) and frame_index is not None:
            g = self._global("film_grain")
            arr = layers.apply_grain(arr, frame_index, float(g.props.get("opacity", C.GRAIN_OPACITY)))

        if self._global_active("vignette", t):
            g = self._global("vignette")
            arr = arr * layers.make_vignette(self.w, self.h, float(g.props.get("corner", C.VIGNETTE_CORNER)))

        fades = [apply(e.ease, progress(t, e.start, e.end))
                 for e in self.tl.globals if e.type == "fade_out" and e.start <= t < e.end]
        if self.tl.scene_at(t):
            fades += [apply(e.ease, progress(t, e.start, e.end))
                      for e in self.tl.scene_at(t).elements
                      if e.type == "fade_out" and e.start <= t < e.end]
        if fades:
            arr = arr * (1.0 - max(fades))

        return np.clip(arr, 0, 255).astype(np.uint8)


_COMPOSERS: dict[tuple[float, int, int], Composer] = {}


def get_composer(scale: float = 1.0, timeline: Timeline | None = None) -> Composer:
    key = (float(scale), id(timeline) if timeline is not None else 0, 0)
    comp = _COMPOSERS.get(key)
    if comp is None or timeline is not None:
        comp = Composer(timeline, scale)
        if timeline is None:
            _COMPOSERS[key] = comp
    return comp


def render_frame(t: float, scale: float = 1.0, frame_index: int | None = None,
                 composer: Composer | None = None) -> np.ndarray:
    """Convenience wrapper: pure function of time (see module docstring)."""
    comp = composer or get_composer(scale)
    idx = frame_index if frame_index is not None else int(round(t * C.FPS))
    return comp.frame(t, idx)
