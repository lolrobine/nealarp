"""timeline.yaml loader, model and validation (R-TIME-04, R-VER-11).

Nothing in the renderer reads a YAML key directly: everything goes through the
dataclasses below, so a missing or malformed field fails loudly at load time instead
of silently changing a frame.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from . import config as C
from .easing import EASINGS

ROOT = Path(__file__).resolve().parent.parent
TIMELINE_PATH = ROOT / "timeline.yaml"

# speaking-rate model used only to prove the >= 0.5 s gap rule (R-AUD-01)
CHARS_PER_SECOND = 13.5
MIN_VO_GAP = 0.5


@dataclass
class Element:
    id: str
    type: str
    start: float
    end: float
    ease: str = "EASE_IO"
    rect: tuple[float, float, float, float] | None = None
    center: tuple[float, float] | None = None
    props: dict[str, Any] = field(default_factory=dict)


@dataclass
class TextEntry:
    id: str
    string: str
    layout: str
    start: float
    end: float
    ease: str = "EASE_IO"
    at: tuple[float, float] | None = None
    size: int | None = None
    props: dict[str, Any] = field(default_factory=dict)


@dataclass
class Scene:
    scene: str
    start: float
    end: float
    layout: str
    elements: list[Element]
    text: list[TextEntry]
    sfx: list[dict[str, Any]]
    vo: list[dict[str, Any]]
    hold_frames: list[tuple[float, float]]

    def element(self, eid: str) -> Element | None:
        return next((e for e in self.elements if e.id == eid), None)

    def text_entry(self, tid: str) -> TextEntry | None:
        return next((e for e in self.text if e.id == tid), None)


@dataclass
class Timeline:
    meta: dict[str, Any]
    globals: list[Element]
    vo_lines: list[dict[str, Any]]
    scenes: list[Scene]

    # ---------------------------------------------------------------- queries
    def scene_at(self, t: float) -> Scene | None:
        for s in self.scenes:
            if s.start <= t < s.end:
                return s
        return self.scenes[-1] if t >= self.scenes[-1].end else None

    def active_elements(self, t: float) -> list[Element]:
        out = [g for g in self.globals if g.start <= t < g.end]
        s = self.scene_at(t)
        if s:
            out += [e for e in s.elements if e.start <= t < e.end]
        return out

    def active_text(self, t: float) -> list[TextEntry]:
        s = self.scene_at(t)
        if not s:
            return []
        return [e for e in s.text if e.start <= t < e.end]

    def holds(self) -> list[tuple[float, float]]:
        return [h for s in self.scenes for h in s.hold_frames]

    def in_hold(self, t: float) -> bool:
        return any(a <= t < b for a, b in self.holds())

    def sfx_events(self) -> list[dict[str, Any]]:
        ev: list[dict[str, Any]] = []
        for s in self.scenes:
            for e in s.sfx:
                ev.append({"scene": s.scene, "id": e["id"], "at": float(e["at"]),
                           "duration": float(e.get("duration", 0.0))})
        return sorted(ev, key=lambda e: e["at"])

    def vo_events(self) -> list[dict[str, Any]]:
        by_id = {v["id"]: v for v in self.vo_lines}
        ev = []
        for s in self.scenes:
            for e in s.vo:
                line = by_id.get(e["id"], {})
                ev.append({"scene": s.scene, "id": e["id"], "at": float(e["at"]),
                           "string": line.get("string", ""),
                           "est_duration": vo_duration(line.get("string", ""))})
        return sorted(ev, key=lambda e: e["at"])

    # ------------------------------------------------------------- validation
    def validate(self) -> list[str]:
        errs: list[str] = []
        if abs(self.meta.get("duration", 0) - C.DURATION) > 1e-9:
            errs.append(f"meta.duration != {C.DURATION}")
        if int(self.meta.get("total_frames", 0)) != C.TOTAL_FRAMES:
            errs.append(f"meta.total_frames != {C.TOTAL_FRAMES}")

        # acts must tile 0..60 exactly (R-TIME-02)
        prev = 0.0
        for s in sorted(self.scenes, key=lambda x: x.start):
            if abs(s.start - prev) > 1e-9:
                errs.append(f"scene {s.scene}: gap/overlap at {prev}->{s.start}")
            prev = s.end
            for e in s.elements:
                if e.ease not in EASINGS:
                    errs.append(f"{s.scene}/{e.id}: unknown ease {e.ease}")
                if not (s.start - 1e-9 <= e.start < e.end <= s.end + 1e-9):
                    errs.append(f"{s.scene}/{e.id}: {e.start}-{e.end} outside scene {s.start}-{s.end}")
                if e.rect is None and e.center is None:
                    errs.append(f"{s.scene}/{e.id}: needs rect or center")
            for tx in s.text:
                if tx.layout not in TEXT_LAYOUT_IDS:
                    errs.append(f"{s.scene}/{tx.id}: unknown text layout {tx.layout}")
                if not (s.start - 1e-9 <= tx.start < tx.end <= s.end + 1e-9):
                    errs.append(f"{s.scene}/{tx.id}: {tx.start}-{tx.end} outside scene")
            for a, b in s.hold_frames:
                if not (s.start <= a < b <= s.end):
                    errs.append(f"{s.scene}: hold_frames [{a},{b}] outside scene")

        # eight 3.0 s cuts between 8 and 32 (R-TIME-02)
        cuts = [s for s in self.scenes if s.scene.startswith("game_")]
        if len(cuts) != 8:
            errs.append(f"expected 8 game cuts, found {len(cuts)}")
        for s in cuts:
            if abs((s.end - s.start) - 3.0) > 1e-9:
                errs.append(f"cut {s.scene} is {s.end - s.start}s, expected 3.0s")

        # exact string list (R-TXT-01)
        declared = [tx.string for s in self.scenes for tx in s.text]
        for needed in C.TEXT_STRINGS:
            if needed not in declared:
                errs.append(f"R-TXT-01 string missing from timeline: {needed!r}")
        for extra in declared:
            if extra not in C.TEXT_STRINGS:
                errs.append(f"on-screen string not in R-TXT-01: {extra!r}")

        # voiceover: >= 0.5 s apart, never overlapping (R-AUD-01 / R-VER-11)
        vo = self.vo_events()
        for a, b in zip(vo, vo[1:]):
            end_a = a["at"] + a["est_duration"]
            if end_a > b["at"] + 1e-9:
                errs.append(f"vo overlap: {a['id']} ends {end_a:.2f} > {b['id']} at {b['at']:.2f}")
            if b["at"] - a["at"] < MIN_VO_GAP - 1e-9:
                errs.append(f"vo gap < {MIN_VO_GAP}s between {a['id']} and {b['id']}")
        if vo and vo[-1]["at"] + vo[-1]["est_duration"] > C.DURATION:
            errs.append("last vo line runs past 60.000 s")

        # at most two simultaneous effects (R-AUD-03)
        sfx = self.sfx_events()
        for i, a in enumerate(sfx):
            stack = [b for b in sfx if b is not a and b["at"] == a["at"]]
            if len(stack) > 1:
                errs.append(f"more than two sfx at t={a['at']}")
        return errs


TEXT_LAYOUT_IDS: set[str] = set()  # filled by load() to avoid an import cycle with text.py


def vo_duration(string: str) -> float:
    return max(1.2, len(string) / CHARS_PER_SECOND)


def _element(d: dict[str, Any]) -> Element:
    rect = d.get("rect")
    center = d.get("center")
    return Element(
        id=d["id"], type=d["type"], start=float(d["start"]), end=float(d["end"]),
        ease=d.get("ease", "EASE_IO"),
        rect=tuple(float(v) for v in rect) if rect else None,
        center=tuple(float(v) for v in center) if center else None,
        props=d.get("props") or {},
    )


def _text(d: dict[str, Any]) -> TextEntry:
    at = d.get("at")
    return TextEntry(
        id=d["id"], string=d["string"], layout=d["layout"],
        start=float(d["start"]), end=float(d["end"]), ease=d.get("ease", "EASE_IO"),
        at=tuple(float(v) for v in at) if at else None,
        size=int(d["size"]) if d.get("size") else None,
        props=d.get("props") or {},
    )


def load(path: str | Path = TIMELINE_PATH) -> Timeline:
    global TEXT_LAYOUT_IDS
    from .text import LAYOUTS

    TEXT_LAYOUT_IDS = set(LAYOUTS)

    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    scenes = [
        Scene(
            scene=s["scene"], start=float(s["start"]), end=float(s["end"]), layout=s["layout"],
            elements=[_element(e) for e in s.get("elements", [])],
            text=[_text(t) for t in s.get("text", [])],
            sfx=list((s.get("audio") or {}).get("sfx") or []),
            vo=list((s.get("audio") or {}).get("vo") or []),
            hold_frames=[(float(a), float(b)) for a, b in (s.get("hold_frames") or [])],
        )
        for s in raw["scenes"]
    ]
    tl = Timeline(
        meta=raw.get("meta", {}),
        globals=[_element(g) for g in raw.get("globals", [])],
        vo_lines=raw.get("vo_lines", []),
        scenes=scenes,
    )
    errs = tl.validate()
    if errs:
        raise ValueError("timeline.yaml failed validation:\n  - " + "\n  - ".join(errs))
    return tl


if __name__ == "__main__":  # pragma: no cover
    t = load()
    print(f"scenes={len(t.scenes)} elements={sum(len(s.elements) for s in t.scenes)} "
          f"text={sum(len(s.text) for s in t.scenes)} sfx={len(t.sfx_events())} vo={len(t.vo_events())}")
    print("validation: OK")
