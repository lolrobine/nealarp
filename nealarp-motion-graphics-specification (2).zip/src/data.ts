export type MetricKey = "lcp" | "inp" | "cls" | "ttfb" | "js" | "req";

export type Metric = {
  key: MetricKey;
  label: string;
  short: string;
  unit: string;
  worst: number;
  target: number;
  digits: number;
  note: string;
};

export type Optimization = {
  id: string;
  code: string;
  label: string;
  blurb: string;
  /** engine gains */
  power: number;
  top: number;
  /** metric deltas (negative = improvement) */
  deltas: Partial<Record<MetricKey, number>>;
};

export const OPTIMIZATIONS: Optimization[] = [
  {
    id: "split",
    code: "01",
    label: "Route-level code splitting",
    blurb: "Ship the screen the user asked for. Nothing else. Everything else streams later.",
    power: 9.5,
    top: 26,
    deltas: { js: -920, req: -42, inp: -70 },
  },
  {
    id: "edge",
    code: "02",
    label: "Edge cache + HTTP/3",
    blurb: "Terminate TLS 11ms from the user, not 140ms from your origin region.",
    power: 8,
    top: 22,
    deltas: { ttfb: -980, lcp: -1.3, req: -22 },
  },
  {
    id: "avif",
    code: "03",
    label: "Modern image codecs",
    blurb: "AVIF and WebP at responsive widths. Same art, a fifth of the bytes.",
    power: 7,
    top: 18,
    deltas: { lcp: -1.5, js: -60, req: -14 },
  },
  {
    id: "font",
    code: "04",
    label: "Self-hosted variable fonts",
    blurb: "One file, preloaded, size-adjusted. No third-party round trip, no reflow jump.",
    power: 6,
    top: 16,
    deltas: { cls: -0.28, lcp: -0.5, req: -10 },
  },
  {
    id: "preload",
    code: "05",
    label: "Critical-path preload",
    blurb: "Tell the browser what matters before the parser has to admit it.",
    power: 7.5,
    top: 15,
    deltas: { lcp: -0.8, inp: -60, req: -8, ttfb: -70 },
  },
  {
    id: "hydrate",
    code: "06",
    label: "Partial hydration islands",
    blurb: "Static shell renders instantly; scripts wake only where fingers land.",
    power: 10,
    top: 20,
    deltas: { inp: -190, js: -500, cls: -0.08 },
  },
];

export const METRICS: Metric[] = [
  {
    key: "lcp",
    label: "Largest Contentful Paint",
    short: "LCP",
    unit: "s",
    worst: 5.4,
    target: 2.5,
    digits: 2,
    note: "Field p75, 4G cold visit",
  },
  {
    key: "inp",
    label: "Interaction to Next Paint",
    short: "INP",
    unit: "ms",
    worst: 486,
    target: 200,
    digits: 0,
    note: "Field p75, all interactions",
  },
  {
    key: "cls",
    label: "Cumulative Layout Shift",
    short: "CLS",
    unit: "",
    worst: 0.42,
    target: 0.1,
    digits: 2,
    note: "Worst session, no exclusions",
  },
  {
    key: "ttfb",
    label: "Time to First Byte",
    short: "TTFB",
    unit: "ms",
    worst: 1420,
    target: 400,
    digits: 0,
    note: "Origin miss, no cache",
  },
  {
    key: "js",
    label: "JavaScript shipped",
    short: "JS",
    unit: "KB",
    worst: 1840,
    target: 400,
    digits: 0,
    note: "Transfer size, entry route",
  },
  {
    key: "req",
    label: "Requests to interactive",
    short: "REQ",
    unit: "",
    worst: 132,
    target: 40,
    digits: 0,
    note: "Waterfall row count",
  },
];

export type MetricReading = Metric & {
  value: number;
  gain: number;
  pct: number;
  passing: boolean;
};

export function computeMetrics(enabled: Record<string, boolean>): MetricReading[] {
  return METRICS.map((m) => {
    const value = OPTIMIZATIONS.reduce(
      (acc, o) => (enabled[o.id] ? acc + (o.deltas[m.key] ?? 0) : acc),
      m.worst,
    );
    const clamped = Math.max(m.target * 0.42, value);
    return {
      ...m,
      value: clamped,
      gain: m.worst - clamped,
      pct: (m.worst - clamped) / m.worst,
      passing: clamped <= m.target,
    };
  });
}

export function computeSpecs(enabled: Record<string, boolean>) {
  const on = OPTIMIZATIONS.filter((o) => enabled[o.id]);
  const power = 40 + on.reduce((a, o) => a + o.power, 0);
  const top = 190 + on.reduce((a, o) => a + o.top, 0);
  return { power, top, tune: on.length / OPTIMIZATIONS.length, count: on.length };
}

/* ------------------------------------------------------------------ */

export type WaterfallRow = {
  id: string;
  label: string;
  kind: "doc" | "css" | "js" | "img" | "font" | "api";
  opt: string;
  off: { start: number; dur: number; kb: number };
  on: { start: number; dur: number; kb: number };
};

export const WATERFALL: WaterfallRow[] = [
  {
    id: "doc",
    label: "GET /  document",
    kind: "doc",
    opt: "edge",
    off: { start: 0, dur: 820, kb: 64 },
    on: { start: 0, dur: 180, kb: 38 },
  },
  {
    id: "css",
    label: "critical.css",
    kind: "css",
    opt: "preload",
    off: { start: 830, dur: 410, kb: 212 },
    on: { start: 180, dur: 120, kb: 86 },
  },
  {
    id: "font",
    label: "Archivo[wdth,wght].woff2",
    kind: "font",
    opt: "font",
    off: { start: 1250, dur: 520, kb: 340 },
    on: { start: 300, dur: 150, kb: 96 },
  },
  {
    id: "hero",
    label: "hero.avif  2560w",
    kind: "img",
    opt: "avif",
    off: { start: 1290, dur: 1180, kb: 940 },
    on: { start: 310, dur: 280, kb: 186 },
  },
  {
    id: "vendor",
    label: "vendor.chunk.js",
    kind: "js",
    opt: "split",
    off: { start: 1250, dur: 1640, kb: 1180 },
    on: { start: 320, dur: 240, kb: 210 },
  },
  {
    id: "app",
    label: "app.js  hydrate",
    kind: "js",
    opt: "hydrate",
    off: { start: 2900, dur: 980, kb: 660 },
    on: { start: 560, dur: 170, kb: 120 },
  },
  {
    id: "api",
    label: "api/v2/session",
    kind: "api",
    opt: "edge",
    off: { start: 2400, dur: 760, kb: 18 },
    on: { start: 600, dur: 90, kb: 9 },
  },
];

export const SPLITS = [
  {
    site: "Northwind Commerce",
    stack: "Next.js · 12,400 SKUs",
    before: 6.2,
    after: 1.3,
    lift: "+18.4%",
    laps: ["1:42.883", "1:38.110", "1:31.402"],
    sector: "S1",
  },
  {
    site: "Atlas Freight Portal",
    stack: "Angular · 40k rows",
    before: 8.9,
    after: 2.1,
    lift: "+7.2%",
    laps: ["2:11.007", "2:04.661", "1:49.228"],
    sector: "S2",
  },
  {
    site: "Kestrel News",
    stack: "Astro · 90k DAU",
    before: 4.1,
    after: 0.9,
    lift: "+31.6%",
    laps: ["0:58.412", "0:52.908", "0:41.117"],
    sector: "S1",
  },
  {
    site: "Meridian Banking",
    stack: "SPA · auth-gated",
    before: 11.4,
    after: 2.6,
    lift: "+12.9%",
    laps: ["2:44.771", "2:31.204", "2:07.990"],
    sector: "S3",
  },
  {
    site: "Foundry D2C",
    stack: "Shopify Hydrogen",
    before: 5.5,
    after: 1.1,
    lift: "+22.7%",
    laps: ["1:16.330", "1:09.884", "0:55.601"],
    sector: "S2",
  },
  {
    site: "Halcyon Streaming",
    stack: "Remix · video grid",
    before: 7.3,
    after: 1.8,
    lift: "+9.4%",
    laps: ["1:52.006", "1:44.318", "1:28.774"],
    sector: "S3",
  },
];

export const PLAYBOOK = [
  {
    n: "01",
    title: "Measure in the field, not the lab",
    tag: "INSTRUMENT",
    gain: "truth",
    body: "Synthetic runs flatter you. Wire real-user monitoring to your Core Web Vitals, slice by route and connection class, and let the p75 of your worst segment set the agenda. Every fix after that has a receipt.",
  },
  {
    n: "02",
    title: "Set a performance budget with teeth",
    tag: "GOVERN",
    gain: "−340 KB",
    body: "Kilobytes per route, requests per page, milliseconds to interactive — declared in the repo, enforced in CI, failing the build when a dependency sneaks past. Budgets that only live in a slide deck are decoration.",
  },
  {
    n: "03",
    title: "Move the origin closer to the finger",
    tag: "EDGE",
    gain: "−980 ms",
    body: "Cache the shell at the edge, stream the dynamic parts from a worker, keep the database where it was. A single TLS handshake saved is worth more than any amount of minification.",
  },
  {
    n: "04",
    title: "Render the frame, then earn the script",
    tag: "PAINT",
    gain: "−1.9 s",
    body: "Server-render what is seen. Hydrate only what is touched, and do it in islands on idle. The fastest JavaScript is the JavaScript the browser never had to parse on the critical path.",
  },
  {
    n: "05",
    title: "Reserve space for everything that arrives late",
    tag: "STABILITY",
    gain: "0.42 → 0.06",
    body: "Explicit aspect-ratio boxes for media, size-adjust and ascent-override for swapped fonts, skeleton heights that match the real component. Nothing on screen should ever have to move out of the way.",
  },
  {
    n: "06",
    title: "Compress twice, then compress the compressor",
    tag: "TRANSFER",
    gain: "−61%",
    body: "Brotli at level 11 for static assets, level 5 for dynamic, dictionary-primed where the payloads repeat. Re-encode images per device class and serve them from a CDN that understands content negotiation.",
  },
  {
    n: "07",
    title: "Kill the third-party you cannot defend",
    tag: "AUDIT",
    gain: "−7 req",
    body: "Every tag manager, chat widget and analytics beacon is a main-thread tenant with no lease agreement. Load them in a facade behind an interaction, sandbox them in a worker, or drop them entirely.",
  },
  {
    n: "08",
    title: "Ship the fix before the meeting ends",
    tag: "CADENCE",
    gain: "9 days",
    body: "Small pull requests, one lever each, benchmarked on the same throttled profile. Speed work dies in quarterly roadmaps; it survives in a weekly rhythm where the delta is visible to everyone.",
  },
];

export const TICKER = [
  "SHAVE MILLISECONDS",
  "CUT KILOBYTES",
  "EDGE EVERYTHING",
  "PRELOAD THE CRITICAL PATH",
  "HYDRATE ONLY WHAT YOU TOUCH",
  "RESERVE THE SPACE",
  "BROTLI ALL THE WAY DOWN",
  "FIELD DATA OR IT DIDN'T HAPPEN",
];
