import { useMemo, useState } from "react";
import { Ambient, Reveal, SectionHead } from "./Chrome";
import { WATERFALL, type MetricReading } from "../data";
import { useCountUp, useInView } from "../hooks/useEngine";

const fmt = (v: number, digits: number) =>
  digits === 0 ? Math.round(v).toLocaleString("en-US") : v.toFixed(digits);

/* ------------------------------------------------------------ metric row */

function MetricRow({ m, i }: { m: MetricReading; i: number }) {
  const { ref, inView } = useInView<HTMLDivElement>(0.4);
  const shown = useCountUp(m.value, 750, inView);
  const fill = (shown / m.worst) * 100;
  const marker = (m.target / m.worst) * 100;
  const saved = Math.round(m.pct * 100);

  return (
    <div
      ref={ref}
      data-in={inView}
      className="reveal group grid grid-cols-1 gap-2 border-b border-ink/12 py-4 transition-colors duration-200 hover:bg-ink/[0.045] sm:grid-cols-[minmax(0,15.5rem)_minmax(0,1fr)_auto] sm:items-center sm:gap-6"
      style={{ "--rd": `${i * 70}ms` } as React.CSSProperties}
    >
      <div className="flex items-baseline gap-3">
        <span
          className={`label-mono w-11 shrink-0 transition-colors ${
            m.passing ? "text-turbo" : "text-signal"
          }`}
        >
          {m.short}
        </span>
        <span className="min-w-0">
          <span className="block truncate font-display text-[0.95rem] font-bold tracking-tight text-ink uppercase">
            {m.label}
          </span>
          <span className="label-mono block h-3.5 pt-0.5 text-mute opacity-0 transition-opacity duration-200 group-hover:opacity-100">
            {m.note}
          </span>
        </span>
      </div>

      <div className="relative h-9">
        <div className="absolute inset-x-0 top-3 h-3 bg-ink/8">
          <div
            className="h-full origin-left transition-[width] duration-500 ease-out"
            style={{
              width: `${Math.max(1.5, fill)}%`,
              background: m.passing
                ? "linear-gradient(90deg,#2a4bff,#4f6bff)"
                : "linear-gradient(90deg,#ff4b12,#ff8a3d)",
            }}
          />
          <div
            className="absolute inset-y-[-4px] w-px bg-ink/55"
            style={{ left: `${marker}%` }}
            title={`target ${m.target}${m.unit}`}
          />
        </div>
        <span className="label-mono absolute right-0 bottom-0 text-mute">
          stock {fmt(m.worst, m.digits)}
          {m.unit}
        </span>
        <span
          className="label-mono absolute bottom-0 -translate-x-1/2 text-turbo transition-[left] duration-500"
          style={{ left: `${marker}%` }}
        >
          ▲ target {fmt(m.target, m.digits)}
          {m.unit}
        </span>
      </div>

      <div className="flex items-baseline gap-4 sm:justify-end">
        <span className="font-mono text-2xl font-semibold tabular-nums text-ink">
          {fmt(shown, m.digits)}
          <span className="ml-0.5 text-xs font-normal text-mute">{m.unit}</span>
        </span>
        <span
          className={`label-mono w-16 text-right transition-colors ${
            m.passing ? "text-turbo" : "text-signal"
          }`}
        >
          −{saved}%
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------- telemetry */

export function Telemetry({ metrics }: { metrics: MetricReading[] }) {
  const totals = useMemo(() => {
    const get = (k: string) => metrics.find((m) => m.key === k);
    return {
      lcp: get("lcp")!,
      js: get("js")!,
      req: get("req")!,
      inp: get("inp")!,
    };
  }, [metrics]);
  const passing = metrics.filter((m) => m.passing).length;

  return (
    <section id="telemetry" className="relative overflow-x-clip bg-paper py-20 text-ink sm:py-28">
      <Ambient tone="light" />
      <div className="relative mx-auto max-w-[1400px] px-4 sm:px-6">
        <SectionHead
          index="01"
          kicker="telemetry · field p75"
          tone="light"
          note="retunes live with the pit-wall setup ↑"
          title={
            <>
              The numbers
              <br />
              <span className="text-signal">move.</span>
            </>
          }
        />

        <div className="mt-12 grid gap-10 lg:grid-cols-12 lg:gap-12">
          <div className="lg:col-span-7 xl:col-span-8">
            <div className="border-t border-ink/20">
              {metrics.map((m, i) => (
                <MetricRow key={m.key} m={m} i={i} />
              ))}
            </div>
            <p className="mt-4 text-xs leading-relaxed text-mute">
              Bars are scaled against the unoptimised baseline for the same route. The hairline on
              each track is the Core Web Vitals "good" threshold — blue means we crossed it.
            </p>
          </div>

          <aside className="lg:col-span-5 xl:col-span-4">
            <div className="sticky top-24 border border-ink/15 bg-paper-2 p-6">
              <div className="label-mono flex items-center justify-between text-mute">
                <span>setup delta</span>
                <span className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 animate-blink rounded-full bg-signal" />
                  live
                </span>
              </div>

              <div className="mt-5 flex items-end gap-2">
                <span className="display-wide text-[clamp(3.4rem,9vw,5rem)] text-signal">
                  {passing}
                </span>
                <span className="pb-2 font-mono text-sm text-mute">/ {metrics.length} passing</span>
              </div>

              <dl className="mt-6 space-y-3 border-t border-ink/12 pt-4">
                {[
                  { k: "LCP reclaimed", v: `${totals.lcp.gain.toFixed(2)} s` },
                  { k: "JS not shipped", v: `${Math.round(totals.js.gain).toLocaleString()} KB` },
                  { k: "Requests avoided", v: `${Math.round(totals.req.gain)}` },
                  { k: "Main thread freed", v: `${Math.round(totals.inp.gain)} ms` },
                ].map((row) => (
                  <div key={row.k} className="flex items-baseline justify-between gap-3">
                    <dt className="label-mono text-mute">{row.k}</dt>
                    <span className="h-px flex-1 bg-ink/12" />
                    <dd className="font-mono text-sm font-semibold tabular-nums text-ink">{row.v}</dd>
                  </div>
                ))}
              </dl>

              <div className="mt-6 bg-ink p-4 text-paper-2">
                <p className="font-display text-[1.05rem] leading-tight font-bold uppercase">
                  “Nobody ever quit a checkout because it was <span className="text-volt">fast</span>.”
                </p>
                <p className="label-mono mt-3 text-white/40">pit wall, standing order</p>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------- waterfall */

const KIND_COLOR: Record<string, string> = {
  doc: "#ff4b12",
  css: "#d8f24b",
  js: "#2a4bff",
  img: "#ff8a3d",
  font: "#8ea2ff",
  api: "#f3f4f0",
};

const SCALE_BASE = 4000;

const PROFILES = [
  { id: "3g", label: "slow 3g", k: 2.7 },
  { id: "4g", label: "fast 4g", k: 1 },
  { id: "fibre", label: "fibre", k: 0.45 },
];

export function Waterfall({ enabled }: { enabled: Record<string, boolean> }) {
  const [armed, setArmed] = useState(true);
  const [replay, setReplay] = useState(0);
  const [hover, setHover] = useState<string | null>(null);
  const [profile, setProfile] = useState(PROFILES[1]);

  const k = profile.k;
  const SCALE = SCALE_BASE * k;

  const rows = useMemo(
    () =>
      WATERFALL.map((r) => {
        const on = !!enabled[r.opt];
        const src = on ? r.on : r.off;
        return {
          ...r,
          cur: { start: src.start * k, dur: src.dur * k, kb: src.kb },
          ghost: { start: r.off.start * k, dur: r.off.dur * k },
          on,
        };
      }),
    [enabled, k],
  );

  const total = Math.max(...rows.map((r) => r.cur.start + r.cur.dur));
  const stockTotal = Math.max(...WATERFALL.map((r) => r.off.start + r.off.dur));
  const kb = rows.reduce((a, r) => a + r.cur.kb, 0);
  const stockKb = WATERFALL.reduce((a, r) => a + r.off.kb, 0);

  const runReplay = () => {
    setArmed(false);
    setReplay((k) => k + 1);
    requestAnimationFrame(() => requestAnimationFrame(() => setArmed(true)));
  };

  return (
    <section id="waterfall" className="relative overflow-hidden bg-ink py-20 text-paper-2 sm:py-28">
      <Ambient tone="dark" />
      <div className="relative mx-auto max-w-[1400px] px-4 sm:px-6">
        <SectionHead
          index="02"
          kicker="waterfall · entry route"
          tone="dark"
          note="ghost bars = unoptimised baseline"
          title={
            <>
              Waterfall,
              <br />
              <span className="text-outline-paper">collapsed.</span>
            </>
          }
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-12">
          <div className="flex flex-wrap items-end gap-x-8 gap-y-3 lg:col-span-5">
            <div>
              <div className="label-mono text-white/40">page complete</div>
              <div className="font-mono text-4xl font-semibold tabular-nums text-volt">
                {total.toLocaleString()}
                <span className="ml-1 text-sm text-white/40">ms</span>
              </div>
            </div>
            <div>
              <div className="label-mono text-white/40">stock</div>
              <div className="font-mono text-4xl font-semibold tabular-nums text-white/30 line-through decoration-signal decoration-2">
                {stockTotal.toLocaleString()}
              </div>
            </div>
            <div>
              <div className="label-mono text-white/40">transfer</div>
              <div className="font-mono text-4xl font-semibold tabular-nums text-paper-2">
                {kb.toLocaleString()}
                <span className="ml-1 text-sm text-white/40">KB</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-start gap-4 lg:col-span-7 lg:items-end">
            <div className="flex flex-wrap items-center gap-3">
              <span className="label-mono text-white/35">connection</span>
              <div className="flex gap-px bg-white/12">
                {PROFILES.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setProfile(p)}
                    aria-pressed={profile.id === p.id}
                    className={`label-mono px-3 py-2 transition-colors duration-200 ${
                      profile.id === p.id
                        ? "bg-volt text-ink"
                        : "bg-ink text-white/50 hover:bg-ink-3 hover:text-paper-2"
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={runReplay}
                className="group relative overflow-hidden border border-volt/60 px-5 py-3 text-volt transition-colors hover:text-ink"
              >
                <span className="label-mono relative z-10">replay requests</span>
                <span className="absolute inset-0 origin-left scale-x-0 bg-volt transition-transform duration-300 group-hover:scale-x-100" />
              </button>
            </div>
            <p className="max-w-sm text-xs leading-relaxed text-white/40 lg:text-right">
              Each row is governed by one pit-wall lever. Switch a lever off and its request drifts
              back down the timeline; switch the connection and the whole chart stretches.
            </p>
          </div>
        </div>

        {/* chart */}
        <div className="relative mt-8 border border-white/12 bg-ink-2/60">
          {/* replay scan line */}
          <div
            aria-hidden
            key={replay}
            className="pointer-events-none absolute inset-0 z-10 grid grid-cols-[minmax(6.5rem,11rem)_minmax(0,1fr)] sm:grid-cols-[minmax(9rem,15rem)_minmax(0,1fr)]"
          >
            <span />
            <span className="relative block overflow-hidden">
              <span
                className="absolute inset-y-0 w-px bg-volt"
                style={{
                  animation: "sweep 1.5s cubic-bezier(.16,1,.3,1) forwards",
                  boxShadow: "0 0 14px rgba(216,242,75,0.7)",
                }}
              />
            </span>
          </div>

          <div className="grid grid-cols-[minmax(6.5rem,11rem)_minmax(0,1fr)] sm:grid-cols-[minmax(9rem,15rem)_minmax(0,1fr)]">
            <div className="border-r border-white/10 p-3">
              <span className="label-mono text-white/35">resource</span>
            </div>
            <div className="relative p-3">
              <span className="label-mono text-white/35">time (ms)</span>
              <div className="mt-2 flex justify-between font-mono text-[0.62rem] text-white/25">
                {Array.from({ length: 9 }).map((_, i) => (
                  <span key={i}>{Math.round(i * 500 * k).toLocaleString()}</span>
                ))}
              </div>
            </div>
          </div>

          {rows.map((r, i) => {
            const left = (r.cur.start / SCALE) * 100;
            const width = Math.max(0.9, (r.cur.dur / SCALE) * 100);
            const ghostLeft = (r.ghost.start / SCALE) * 100;
            const ghostWidth = (r.ghost.dur / SCALE) * 100;
            const isHover = hover === r.id;
            return (
              <Reveal key={r.id} delay={i * 45}>
                <div
                  onMouseEnter={() => setHover(r.id)}
                  onMouseLeave={() => setHover(null)}
                  className={`grid grid-cols-[minmax(6.5rem,11rem)_minmax(0,1fr)] border-t border-white/10 transition-colors duration-200 sm:grid-cols-[minmax(9rem,15rem)_minmax(0,1fr)] ${
                    isHover ? "bg-white/[0.06]" : ""
                  }`}
                >
                  <div className="flex items-center gap-2 border-r border-white/10 px-3 py-3">
                    <span
                      className="h-2.5 w-2.5 shrink-0"
                      style={{ background: KIND_COLOR[r.kind] }}
                    />
                    <span className="truncate font-mono text-[0.72rem] text-white/75">{r.label}</span>
                  </div>

                  <div className="relative py-3 pr-3 pl-3">
                    {/* grid guides */}
                    <div className="pointer-events-none absolute inset-y-0 left-3 right-3 flex justify-between">
                      {Array.from({ length: 9 }).map((_, g) => (
                        <span key={g} className="w-px bg-white/[0.07]" />
                      ))}
                    </div>

                    {/* ghost (stock) */}
                    <div
                      className="absolute top-1/2 h-2.5 -translate-y-1/2 border border-dashed border-white/25"
                      style={{ left: `calc(${ghostLeft}% * 0.94 + 0.75rem)`, width: `${ghostWidth * 0.94}%` }}
                    />

                    {/* live bar */}
                    <div
                      className="absolute top-1/2 h-3.5 -translate-y-1/2 origin-left"
                      style={{
                        left: `calc(${left}% * 0.94 + 0.75rem)`,
                        width: `${width * 0.94}%`,
                        background: r.on ? KIND_COLOR[r.kind] : "rgba(255,255,255,0.28)",
                        transform: `translateY(-50%) scaleX(${armed ? 1 : 0})`,
                        transition: `left 650ms cubic-bezier(.16,1,.3,1), width 650ms cubic-bezier(.16,1,.3,1), transform 500ms cubic-bezier(.16,1,.3,1)`,
                        transitionDelay: armed ? `${(r.cur.start / SCALE) * 700}ms, 0ms, 0ms` : "0ms",
                        boxShadow: isHover ? `0 0 0 1px rgba(255,255,255,.5), 0 0 22px ${KIND_COLOR[r.kind]}66` : "none",
                      }}
                    />

                    <span
                      className={`absolute top-1/2 -translate-y-1/2 font-mono text-[0.66rem] tabular-nums transition-all duration-300 ${
                        isHover ? "text-volt" : "text-white/45"
                      }`}
                      style={{ left: `calc((${left} + ${width})% * 0.94 + 1.1rem)` }}
                    >
                      {Math.round(r.cur.dur)}ms · {r.cur.kb}KB
                    </span>
                  </div>
                </div>
              </Reveal>
            );
          })}

          {/* sweep line + footer */}
          <div className="relative border-t border-white/10">
            <div className="grid grid-cols-1 items-center gap-2 px-3 py-3 sm:grid-cols-[minmax(9rem,15rem)_minmax(0,1fr)]">
              <span className="label-mono text-white/35">
                {armed ? "all requests settled" : "replaying…"}
              </span>
              <div className="label-mono flex flex-wrap items-center gap-x-5 gap-y-1 text-white/40">
                <span>
                  saved <b className="text-volt">{(stockTotal - total).toLocaleString()} ms</b>
                </span>
                <span>
                  saved <b className="text-paper-2">{(stockKb - kb).toLocaleString()} KB</b>
                </span>
                <span>
                  rows <b className="text-paper-2">{rows.filter((r) => r.on).length}/{rows.length}</b> optimised
                </span>
                <span className="ml-auto font-mono normal-case">run #{replay}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
