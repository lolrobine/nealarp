import { Reveal } from "./Chrome";
import { useCountUp, useInView } from "../hooks/useEngine";

const STATS = [
  {
    value: 53,
    suffix: "%",
    digits: 0,
    line: "of mobile visits abandon a page that takes longer than three seconds",
    src: "google / soasta",
  },
  {
    value: 8.4,
    prefix: "+",
    suffix: "%",
    digits: 1,
    line: "retail conversion lift for every 100ms shaved off load time",
    src: "deloitte · milliseconds make millions",
  },
  {
    value: 7,
    prefix: "−",
    suffix: "%",
    digits: 0,
    line: "conversions lost for each additional second of load",
    src: "aberdeen group",
  },
  {
    value: 1.3,
    suffix: "s",
    digits: 1,
    line: "median LCP across the 1,000 routes this lab audited last year",
    src: "faster · field p75",
  },
];

function Stat({ s, run, i }: { s: (typeof STATS)[number]; run: boolean; i: number }) {
  const shown = useCountUp(s.value, 1400, run);
  return (
    <Reveal delay={i * 90} className="border-t border-ink/25 px-5 py-7 first:border-t-0 sm:border-t-0 sm:border-l md:px-7">
      <div className="display-wide flex items-baseline text-[clamp(2.8rem,6.4vw,4.6rem)] text-ink">
        {s.prefix}
        {shown.toFixed(s.digits)}
        <span className="text-signal">{s.suffix}</span>
      </div>
      <p className="mt-3 max-w-[24ch] text-[0.84rem] leading-snug text-ink/70">{s.line}</p>
      <p className="label-mono mt-3 text-ink/40">{s.src}</p>
    </Reveal>
  );
}

export function CostBand() {
  const { ref, inView } = useInView<HTMLDivElement>(0.2);
  return (
    <section ref={ref} className="relative overflow-hidden bg-volt text-ink">
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-grid text-ink opacity-40" />
        <div className="absolute inset-y-0 right-0 w-2/5 bg-hatch text-ink opacity-[0.08]" />
        <div className="absolute inset-0 bg-noise opacity-30 mix-blend-multiply" />
      </div>
      <div className="relative mx-auto max-w-[1400px] px-4 py-10 sm:px-6">
        <div className="label-mono flex items-center gap-4 text-ink/60">
          <span className="text-ink">the cost of slow</span>
          <span className="h-px flex-1 bg-ink/25" />
          <span className="hidden sm:inline">counted in revenue, not opinions</span>
        </div>
        <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4">
          {STATS.map((s, i) => (
            <Stat key={s.line} s={s} run={inView} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
