import { useEffect, useRef } from "react";
import { Ambient, Reveal } from "./Chrome";
import { Gauge } from "./Gauge";
import { OPTIMIZATIONS } from "../data";
import type { Engine } from "../hooks/useEngine";

/** closed-form 0→100 time for v' = P(1 − v/top) */
const predict = (power: number, top: number) =>
  top > 100 ? (top / power) * Math.log(top / (top - 100)) : Infinity;

const STOCK = predict(40, 190);

function Stat({ label, value, unit, hot }: { label: string; value: string; unit?: string; hot?: boolean }) {
  return (
    <div className="px-4 py-3">
      <div className="label-mono text-white/35">{label}</div>
      <div className={`mt-1 font-mono text-xl font-semibold tabular-nums ${hot ? "text-volt" : "text-paper-2"}`}>
        {value}
        {unit ? <span className="ml-1 text-[0.6em] font-normal text-white/40">{unit}</span> : null}
      </div>
    </div>
  );
}

export function Hero({ engine }: { engine: Engine }) {
  const { hud, specs, enabled, toggle, all, holding, setHolding, launch, release } = engine;
  const sim = predict(specs.power, specs.top);
  const delta = sim === Infinity ? 0 : Math.round((1 - sim / STOCK) * 100);

  /* one courtesy demo run, cancelled the moment the visitor touches anything */
  const touched = useRef(false);
  useEffect(() => {
    const reduce =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const stop = () => {
      touched.current = true;
    };
    const id = window.setTimeout(() => {
      if (!touched.current) launch();
    }, 1500);
    window.addEventListener("pointerdown", stop, { once: true });
    window.addEventListener("keydown", stop, { once: true });
    return () => {
      window.clearTimeout(id);
      window.removeEventListener("pointerdown", stop);
      window.removeEventListener("keydown", stop);
    };
  }, [launch]);

  return (
    <section id="top" className="relative overflow-hidden bg-ink text-paper-2">
      <Ambient tone="dark" />
      {/* velocity streaks react to the throttle */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        {Array.from({ length: 16 }).map((_, i) => {
          const base = 9 + ((i * 61) % 82);
          const dur = Math.max(0.28, 3.4 - hud.speed / 95);
          const len = 120 + ((i * 71) % 340) * (0.4 + hud.speed / 260);
          return (
            <span
              key={i}
              className="absolute h-px bg-gradient-to-r from-transparent via-signal to-transparent"
              style={{
                top: `${base}%`,
                width: `${len}px`,
                right: "-20%",
                opacity: Math.min(0.75, hud.speed / 210) * (0.35 + (i % 3) * 0.28),
                animation: `streak ${dur}s linear infinite`,
                animationDelay: `${-i * 0.31}s`,
              }}
            />
          );
        })}
      </div>

      <div className="relative mx-auto max-w-[1400px] px-4 pt-8 pb-14 sm:px-6">
        {/* session strip */}
        <div className="label-mono flex flex-wrap items-center gap-x-5 gap-y-2 text-white/40">
          <span className="flex items-center gap-2 text-signal">
            <span className="h-2 w-2 animate-blink rounded-full bg-signal" />
            live telemetry
          </span>
          <span>session #{String(hud.runs + 1).padStart(3, "0")}</span>
          <span className="hidden sm:inline">circuit: critical rendering path</span>
          <span className="hidden md:inline">surface: 4g · cold cache</span>
          <span className="ml-auto text-volt">setup {specs.count}/6</span>
        </div>

        <div className="mt-6 grid items-start gap-10 lg:grid-cols-12 lg:gap-10">
          {/* ---------------------------------------------------------- copy */}
          <div className="lg:col-span-7">
            <div className="flex items-center gap-3">
              <span className="h-px w-10 bg-signal" />
              <span className="label-mono text-white/55">web performance engineering</span>
            </div>

            <h1 className="display-wide mt-4 text-[clamp(4.4rem,15vw,12.5rem)]">
              <span className="block">Fast</span>
              <span className="flex items-start gap-3">
                <span className="text-signal">er</span>
                <span className="text-outline-dim mt-[0.14em]">.</span>
              </span>
            </h1>

            <div className="mt-5 flex flex-col gap-5 sm:flex-row sm:items-start sm:gap-8">
              <p className="max-w-md text-[0.98rem] leading-relaxed text-white/60">
                We take products that are technically finished and make them <em className="text-paper-2 not-italic">felt</em>.
                Six levers, one machine. Retune the setup below, hold the throttle, and watch the
                numbers answer — this page is running the same physics it sells.
              </p>
              <div className="shrink-0 border-l border-white/15 pl-5 sm:pl-6">
                <div className="label-mono text-white/35">0–100 simulated</div>
                <div className="mt-1 font-mono text-3xl font-semibold tabular-nums text-volt">
                  {sim === Infinity ? "—" : `${sim.toFixed(2)}s`}
                </div>
                <div className="label-mono mt-1 text-white/40">
                  stock {STOCK.toFixed(2)}s · {delta > 0 ? `−${delta}%` : "+0%"}
                </div>
              </div>
            </div>

            {/* controls */}
            <div className="mt-8 flex flex-wrap items-stretch gap-3">
              <button
                type="button"
                onPointerDown={(e) => {
                  e.currentTarget.setPointerCapture(e.pointerId);
                  setHolding(true);
                }}
                onPointerUp={release}
                onPointerCancel={release}
                onKeyDown={(e) => {
                  if (e.key === " " || e.key === "Enter") {
                    e.preventDefault();
                    setHolding(true);
                  }
                }}
                onKeyUp={release}
                aria-pressed={holding}
                className={`group relative touch-none overflow-hidden px-6 py-4 transition-all duration-150 select-none ${
                  holding ? "scale-[0.985] bg-signal text-white" : "bg-paper-2 text-ink hover:bg-volt"
                }`}
              >
                <span className="label-mono relative z-10 text-[0.78rem]">hold to accelerate</span>
                <span className="absolute inset-0 -translate-x-full bg-signal/25 transition-transform duration-500 group-hover:translate-x-0" />
              </button>

              <button
                type="button"
                onClick={launch}
                className="group relative overflow-hidden border border-volt/60 px-6 py-4 text-volt transition-colors hover:border-volt hover:text-ink"
              >
                <span className="label-mono relative z-10 text-[0.78rem]">launch 0–100 sprint</span>
                <span className="absolute inset-0 origin-left scale-x-0 bg-volt transition-transform duration-300 group-hover:scale-x-100" />
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => all(true)}
                  className="label-mono border border-white/15 px-3 py-2 text-white/55 transition-colors hover:border-white/40 hover:text-paper-2"
                >
                  max setup
                </button>
                <button
                  type="button"
                  onClick={() => all(false)}
                  className="label-mono border border-white/15 px-3 py-2 text-white/55 transition-colors hover:border-signal hover:text-signal"
                >
                  strip to stock
                </button>
              </div>
            </div>

            {/* sprint stats */}
            <Reveal delay={120}>
              <div className="mt-8 grid grid-cols-2 divide-x divide-y divide-white/10 border border-white/10 bg-white/[0.03] sm:grid-cols-4 sm:divide-y-0">
                <Stat
                  label="sprint time"
                  value={hud.t > 0 ? hud.t.toFixed(3) : "—"}
                  unit="s"
                  hot={hud.active}
                />
                <Stat label="personal best" value={hud.best !== null ? hud.best.toFixed(3) : "—"} unit="s" />
                <Stat label="peak velocity" value={hud.peak.toFixed(0)} unit="km/h" />
                <Stat label="power / limiter" value={`${specs.power.toFixed(0)}/${specs.top.toFixed(0)}`} />
              </div>
            </Reveal>
          </div>

          {/* --------------------------------------------------------- gauge */}
          <div className="lg:col-span-5">
            <div className="relative border border-white/12 bg-ink-2/70 p-4 sm:p-5">
              {/* corner brackets */}
              {[
                "left-0 top-0 border-l-2 border-t-2",
                "right-0 top-0 border-r-2 border-t-2",
                "left-0 bottom-0 border-b-2 border-l-2",
                "right-0 bottom-0 border-b-2 border-r-2",
              ].map((c) => (
                <span key={c} className={`pointer-events-none absolute h-3 w-3 border-signal ${c}`} />
              ))}

              <div className="flex items-end justify-between gap-3">
                <span className="label-mono text-white/40">velocity · sim v4.2</span>
                <span className="flex items-baseline gap-2">
                  <span className={`label-mono ${hud.active ? "text-volt" : "text-white/25"}`}>
                    {hud.active ? "◉ sprint" : hud.best !== null ? "best" : "idle"}
                  </span>
                  <span
                    className={`font-mono text-lg leading-none font-semibold tabular-nums transition-colors ${
                      hud.active ? "text-volt" : "text-white/35"
                    }`}
                  >
                    {(hud.active ? hud.t : (hud.best ?? 0)).toFixed(3)}s
                  </span>
                </span>
              </div>

              <div className="relative mt-1">
                <Gauge speed={hud.speed} top={specs.top} sprinting={hud.active} holding={holding} />
              </div>

              <div className="mt-2 grid grid-cols-3 gap-px border-t border-white/10 bg-white/10 text-center">
                {[
                  { k: "tune", v: `${Math.round(specs.tune * 100)}%` },
                  { k: "throttle", v: holding || hud.active ? "OPEN" : "CLOSED" },
                  { k: "delta", v: `${delta > 0 ? "−" : ""}${delta}%` },
                ].map((x) => (
                  <div key={x.k} className="bg-ink-2 px-2 py-2.5">
                    <div className="label-mono text-white/35">{x.k}</div>
                    <div className="font-mono text-sm font-semibold tabular-nums text-paper-2">{x.v}</div>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[0.72rem] leading-relaxed text-white/35">
                Analogy, honestly labelled: the physics are simulated. The deltas in the next
                sections are measured on real routes.
              </p>
            </div>
          </div>
        </div>

        {/* -------------------------------------------------------- pit rack */}
        <div className="mt-14">
          <div className="label-mono flex flex-wrap items-center gap-4 text-white/40">
            <span className="text-signal">pit wall</span>
            <span>setup · six levers</span>
            <span className="h-px flex-1 bg-white/12" />
            <span className="hidden sm:inline">toggle a lever → the whole page retunes</span>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-px bg-white/10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            {OPTIMIZATIONS.map((o, i) => {
              const on = !!enabled[o.id];
              return (
                <Reveal key={o.id} delay={i * 60}>
                  <button
                    type="button"
                    onClick={() => toggle(o.id)}
                    aria-pressed={on}
                    className={`group flex h-full w-full flex-col p-4 text-left transition-colors duration-200 ${
                      on ? "bg-ink-3" : "bg-ink hover:bg-ink-2"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`label-mono ${on ? "text-volt" : "text-white/30"}`}>{o.code}</span>
                      <span
                        className={`relative h-[18px] w-[34px] rounded-full border transition-colors duration-200 ${
                          on ? "border-volt bg-volt/25" : "border-white/25 bg-white/5"
                        }`}
                      >
                        <span
                          className={`absolute top-1/2 h-3 w-3 -translate-y-1/2 rounded-full transition-all duration-200 ${
                            on ? "left-[17px] bg-volt" : "left-[2px] bg-white/40 group-hover:bg-white/60"
                          }`}
                        />
                      </span>
                    </div>
                    <span
                      className={`mt-3 font-display text-[0.92rem] leading-tight font-bold tracking-tight uppercase transition-colors ${
                        on ? "text-paper-2" : "text-white/55"
                      }`}
                    >
                      {o.label}
                    </span>
                    <span className="mt-2 text-[0.74rem] leading-snug text-white/40">{o.blurb}</span>
                    <span className="label-mono mt-auto flex gap-3 pt-3">
                      <span className={on ? "text-volt" : "text-white/22"}>+{o.power} pwr</span>
                      <span className={on ? "text-signal" : "text-white/22"}>+{o.top} top</span>
                    </span>
                  </button>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
