import { useState, type FormEvent } from "react";
import { Ambient, Reveal, SectionHead } from "./Chrome";
import type { Hud } from "../hooks/useEngine";

const STATUS = [
  { k: "global p75 lcp", v: "1.24 s" },
  { k: "edge nodes", v: "214" },
  { k: "monitor uptime", v: "99.98%" },
  { k: "slots open · q2", v: "2" },
];

export function Pit({ hud }: { hud: Hud }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "sent" | "error">("idle");
  const [ticket, setTicket] = useState("—");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
      setState("error");
      return;
    }
    setTicket(`FASTER-${Math.floor(1000 + Math.random() * 8999)}`);
    setState("sent");
  };

  return (
    <section id="pit" className="relative overflow-hidden bg-paper-2 py-20 text-ink sm:py-28">
      <Ambient tone="light" />
      <div className="relative mx-auto max-w-[1400px] px-4 sm:px-6">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-14">
          <div className="lg:col-span-7">
            <SectionHead
              index="05"
              kicker="pit wall · booking"
              tone="light"
              note="diagnostics run in 5 working days"
              title={
                <>
                  Find your
                  <br />
                  <span className="text-signal">three seconds.</span>
                </>
              }
            />

            <Reveal delay={100}>
              <p className="mt-6 max-w-lg text-[0.98rem] leading-relaxed text-ink/70">
                Send one route — the one that hurts. We profile it on a throttled mid-tier Android
                over cold 4G, publish the waterfall, and hand back a sequenced fix list with the
                expected delta against each item. No deck, no discovery phase.
              </p>
            </Reveal>

            <Reveal delay={180}>
              <form onSubmit={submit} className="mt-8 max-w-xl">
                <div className="flex flex-col gap-3 sm:flex-row">
                  <div className="relative flex-1">
                    <label htmlFor="route" className="label-mono absolute -top-2 left-3 bg-paper-2 px-1 text-mute">
                      work email
                    </label>
                    <input
                      id="route"
                      type="email"
                      value={email}
                      placeholder="you@company.com"
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (state !== "idle") setState("idle");
                      }}
                      className={`w-full border bg-transparent px-4 py-3.5 font-mono text-sm text-ink outline-none transition-colors placeholder:text-mute/60 focus:border-ink ${
                        state === "error" ? "border-signal" : "border-ink/25"
                      }`}
                    />
                  </div>
                  <button
                    type="submit"
                    className="group relative overflow-hidden bg-ink px-6 py-3.5 text-paper-2 transition-colors hover:text-ink"
                  >
                    <span className="label-mono relative z-10">request diagnostic</span>
                    <span className="absolute inset-0 origin-bottom scale-y-0 bg-volt transition-transform duration-300 group-hover:scale-y-100" />
                  </button>
                </div>

                <div className="mt-3 h-6" aria-live="polite">
                  {state === "error" && (
                    <span className="label-mono text-signal">signal lost — check the address</span>
                  )}
                  {state === "sent" && (
                    <span className="label-mono text-turbo">
                      logged · ticket {ticket} · we reply inside a day
                    </span>
                  )}
                  {state === "idle" && (
                    <span className="label-mono text-mute">
                      one email back. we never add you to a newsletter.
                    </span>
                  )}
                </div>
              </form>
            </Reveal>

            <Reveal delay={240}>
              <div className="mt-10 flex flex-wrap gap-x-10 gap-y-6 border-t border-ink/15 pt-6">
                {[
                  { k: "pit line", v: "pit@faster.dev" },
                  { k: "voice", v: "+44 20 7946 0102" },
                  { k: "garage", v: "Unit 7, Silvergate Yard, London E8" },
                ].map((c) => (
                  <div key={c.k}>
                    <div className="label-mono text-mute">{c.k}</div>
                    <div className="mt-1 font-display text-[0.98rem] font-bold tracking-tight uppercase">
                      {c.v}
                    </div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-5">
            <Reveal delay={120}>
              <div className="relative border border-ink/20 bg-ink p-6 text-paper-2">
                <span className="absolute -top-px -left-px h-3 w-3 border-t-2 border-l-2 border-signal" />
                <span className="absolute -right-px -bottom-px h-3 w-3 border-r-2 border-b-2 border-signal" />

                <div className="label-mono flex items-center justify-between text-white/40">
                  <span>your session</span>
                  <span className="flex items-center gap-2 text-volt">
                    <span className="h-1.5 w-1.5 animate-blink rounded-full bg-volt" />
                    recorded
                  </span>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-px bg-white/10">
                  <div className="bg-ink px-4 py-5">
                    <div className="label-mono text-white/35">best 0–100</div>
                    <div className="mt-1 font-mono text-3xl font-semibold tabular-nums text-volt">
                      {hud.best !== null ? hud.best.toFixed(3) : "—"}
                      <span className="ml-1 text-xs text-white/40">s</span>
                    </div>
                  </div>
                  <div className="bg-ink px-4 py-5">
                    <div className="label-mono text-white/35">peak velocity</div>
                    <div className="mt-1 font-mono text-3xl font-semibold tabular-nums text-paper-2">
                      {hud.peak.toFixed(0)}
                      <span className="ml-1 text-xs text-white/40">km/h</span>
                    </div>
                  </div>
                </div>

                <div className="mt-5">
                  <div className="label-mono text-white/35">studio standing board</div>
                  <dl className="mt-3 space-y-2.5">
                    {STATUS.map((s) => (
                      <div key={s.k} className="flex items-baseline gap-3">
                        <dt className="label-mono text-white/45">{s.k}</dt>
                        <span className="h-px flex-1 bg-white/12" />
                        <dd className="font-mono text-sm font-semibold tabular-nums text-paper-2">{s.v}</dd>
                      </div>
                    ))}
                  </dl>
                </div>

                <p className="mt-6 border-t border-white/12 pt-4 text-[0.74rem] leading-relaxed text-white/40">
                  Runs this session: {hud.runs}. Every lever you flipped on this page is a real line
                  item in the report we would send you.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

export function FooterBar() {
  return (
    <footer className="relative overflow-hidden bg-ink py-8 text-paper-2">
      <Ambient tone="dark" />
      <div className="relative mx-auto flex max-w-[1400px] flex-col gap-5 px-4 sm:px-6 md:flex-row md:items-center">
        <div className="flex items-center gap-3">
          <svg viewBox="0 0 24 24" className="h-5 w-5 text-signal" aria-hidden>
            <path d="M3 5h9l-5 7h6l-11 8 4-9H2z" fill="currentColor" />
          </svg>
          <span className="display-wide text-[1.05rem]">Faster</span>
          <span className="label-mono text-white/30">© 2026 · built in the pit lane</span>
        </div>

        <nav className="label-mono flex flex-wrap items-center gap-x-5 gap-y-2 text-white/45 md:ml-auto">
          {[
            { href: "#telemetry", label: "telemetry" },
            { href: "#waterfall", label: "waterfall" },
            { href: "#splits", label: "splits" },
            { href: "#playbook", label: "playbook" },
            { href: "#pit", label: "pit wall" },
          ].map((l) => (
            <a key={l.href} href={l.href} className="transition-colors hover:text-volt">
              {l.label}
            </a>
          ))}
          <a
            href="#top"
            className="group flex items-center gap-2 border border-white/15 px-3 py-1.5 text-paper-2 transition-colors hover:border-volt hover:text-volt"
          >
            back to grid
            <svg viewBox="0 0 12 12" className="h-2.5 w-2.5 transition-transform group-hover:-translate-y-0.5" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden>
              <path d="M6 10V2M2.5 5.5L6 2l3.5 3.5" />
            </svg>
          </a>
        </nav>
      </div>
    </footer>
  );
}
