import { useMemo } from "react";
import { GAUGE_MAX } from "../hooks/useEngine";

const CX = 170;
const CY = 170;
const R = 128;
const START = 135;
const SWEEP = 270;

const polar = (r: number, deg: number) => {
  const a = (deg * Math.PI) / 180;
  return [CX + r * Math.cos(a), CY + r * Math.sin(a)] as const;
};

const arcPath = (r: number, from: number, to: number) => {
  const [x1, y1] = polar(r, from);
  const [x2, y2] = polar(r, to);
  const large = Math.abs(to - from) > 180 ? 1 : 0;
  return `M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`;
};

export function Gauge({
  speed,
  top,
  sprinting,
  holding,
}: {
  speed: number;
  top: number;
  sprinting: boolean;
  holding: boolean;
}) {
  const pct = Math.min(1, speed / GAUGE_MAX);
  const angle = START + SWEEP * pct;
  const limiterPct = Math.min(1, top / GAUGE_MAX);
  const atLimiter = speed >= top * 0.985 && speed > 2;

  const ticks = useMemo(() => {
    const out: { deg: number; major: boolean; v: number }[] = [];
    for (let v = 0; v <= GAUGE_MAX; v += 10) {
      out.push({ v, deg: START + (v / GAUGE_MAX) * SWEEP, major: v % 40 === 0 });
    }
    return out;
  }, []);

  const accent = sprinting ? "var(--color-volt)" : "var(--color-signal)";

  return (
    <svg viewBox="0 0 340 336" className="h-auto w-full select-none" role="img" aria-label={`Velocity ${speed.toFixed(0)} kilometres per hour`}>
      <defs>
        <filter id="g-glow" x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="5" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <radialGradient id="g-face" cx="50%" cy="42%" r="62%">
          <stop offset="0%" stopColor="#24282f" />
          <stop offset="100%" stopColor="#101217" />
        </radialGradient>
      </defs>

      {/* face */}
      <circle cx={CX} cy={CY} r={R + 26} fill="url(#g-face)" stroke="rgba(255,255,255,0.09)" />
      <circle cx={CX} cy={CY} r={R + 18} fill="none" stroke="rgba(255,255,255,0.05)" />

      {/* track */}
      <path d={arcPath(R, START, START + SWEEP)} fill="none" stroke="rgba(255,255,255,0.09)" strokeWidth={15} />

      {/* unreachable band above current top speed */}
      {limiterPct < 0.999 && (
        <>
          <path
            d={arcPath(R, START + SWEEP * limiterPct, START + SWEEP)}
            fill="none"
            stroke="rgba(255,255,255,0.16)"
            strokeWidth={15}
            strokeDasharray="2 7"
          />
          <text
            x={CX}
            y={CY - R + 46}
            textAnchor="middle"
            className="font-mono"
            fontSize="9"
            letterSpacing="2.4"
            fill="rgba(255,255,255,0.4)"
          >
            LIMITER {top.toFixed(0)}
          </text>
        </>
      )}

      {/* ticks */}
      {ticks.map((t) => {
        const [x1, y1] = polar(R + (t.major ? -9 : -4), t.deg);
        const [x2, y2] = polar(R - (t.major ? 22 : 16), t.deg);
        const lit = speed >= t.v;
        return (
          <g key={t.v}>
            <line
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={lit ? accent : "rgba(255,255,255,0.28)"}
              strokeWidth={t.major ? 2.4 : 1}
              opacity={lit ? 1 : 0.75}
            />
            {t.major && (
              <text
                x={polar(R - 38, t.deg)[0]}
                y={polar(R - 38, t.deg)[1] + 3.5}
                textAnchor="middle"
                className="font-mono"
                fontSize="10.5"
                fontWeight={500}
                fill={lit ? "rgba(243,244,240,0.95)" : "rgba(243,244,240,0.34)"}
              >
                {t.v}
              </text>
            )}
          </g>
        );
      })}

      {/* progress arc */}
      {pct > 0.004 && (
        <path
          d={arcPath(R, START, angle)}
          fill="none"
          stroke={accent}
          strokeWidth={15}
          filter="url(#g-glow)"
          style={{ transition: "stroke 200ms linear" }}
        />
      )}

      {/* needle */}
      <g transform={`rotate(${angle.toFixed(3)} ${CX} ${CY})`}>
        <path
          d={`M ${CX - 22} ${CY - 5.5} L ${CX + R - 24} ${CY - 1.6} L ${CX + R - 24} ${CY + 1.6} L ${CX - 22} ${CY + 5.5} Z`}
          fill={atLimiter ? "var(--color-paper-2)" : accent}
        />
      </g>
      <circle cx={CX} cy={CY} r={13} fill="#0d0f13" stroke={accent} strokeWidth={2} />
      <circle cx={CX} cy={CY} r={4} fill={accent} />

      {/* digital readout */}
      <text
        x={CX}
        y={CY + 78}
        textAnchor="middle"
        className="font-mono"
        fontSize="42"
        fontWeight={600}
        fill="var(--color-paper-2)"
        style={{ fontVariantNumeric: "tabular-nums" }}
      >
        {speed.toFixed(0).padStart(3, "0")}
      </text>
      <text
        x={CX}
        y={CY + 98}
        textAnchor="middle"
        className="font-mono"
        fontSize="9.5"
        letterSpacing="3"
        fill="rgba(243,244,240,0.45)"
      >
        KM / H  ·  SIMULATED
      </text>

      {/* status lamps */}
      <g>
        <circle cx={CX - 84} cy={CY + 112} r={4} fill={holding || sprinting ? "var(--color-volt)" : "rgba(255,255,255,0.18)"} />
        <text x={CX - 74} y={CY + 115} className="font-mono" fontSize="8.5" letterSpacing="1.6" fill="rgba(243,244,240,0.45)">
          THROTTLE
        </text>
        <circle cx={CX + 84} cy={CY + 112} r={4} fill={atLimiter ? "var(--color-signal)" : "rgba(255,255,255,0.18)"} className={atLimiter ? "animate-blink" : ""} />
        <text x={CX + 74} y={CY + 115} textAnchor="end" className="font-mono" fontSize="8.5" letterSpacing="1.6" fill="rgba(243,244,240,0.45)">
          REDLINE
        </text>
      </g>
    </svg>
  );
}
