import { useState } from "react";
import { Ambient, Reveal, SectionHead } from "./Chrome";
import { PLAYBOOK, SPLITS } from "../data";

const SCALE = 12;

export function Splits() {
  const fastest = Math.min(...SPLITS.map((s) => s.after));

  return (
    <section id="splits" className="relative overflow-hidden bg-paper py-20 text-ink sm:py-28">
      <Ambient tone="light" />
      <div className="relative mx-auto max-w-[1400px] px-4 sm:px-6">
        <SectionHead
          index="03"
          kicker="splits · recent engagements"
          tone="light"
          note="six routes, one weekend each"
          title={
            <>
              Sector
              <br />
              times.
            </>
          }
        />

        <div className="mt-12 border-t border-ink/20">
          {/* header */}
          <div className="label-mono hidden grid-cols-[3.5rem_minmax(0,2.4fr)_5rem_5.5rem_minmax(0,1.6fr)_6.5rem_9rem] gap-4 border-b border-ink/15 py-3 text-mute md:grid">
            <span>sec</span>
            <span>route</span>
            <span className="text-right">before</span>
            <span className="text-right">after</span>
            <span>delta</span>
            <span className="text-right">conv. lift</span>
            <span className="text-right">sector laps</span>
          </div>

          {SPLITS.map((s, i) => (
            <Reveal key={s.site} delay={i * 60}>
              <div className="group grid grid-cols-2 items-center gap-x-4 gap-y-2 border-b border-ink/12 px-2 py-4 transition-colors duration-250 hover:bg-ink md:grid-cols-[3.5rem_minmax(0,2.4fr)_5rem_5.5rem_minmax(0,1.6fr)_6.5rem_9rem] md:px-0">
                <span className="label-mono w-fit border border-ink/25 px-1.5 py-0.5 text-mute transition-colors group-hover:border-volt group-hover:text-volt">
                  {s.sector}
                </span>

                <span className="col-span-1 min-w-0">
                  <span className="flex items-center gap-2">
                    <span className="truncate font-display text-[1.02rem] font-bold tracking-tight text-ink uppercase transition-colors group-hover:text-paper-2">
                      {s.site}
                    </span>
                    {s.after === fastest && (
                      <span className="label-mono shrink-0 bg-volt px-1.5 py-0.5 text-ink">fastest lap</span>
                    )}
                  </span>
                  <span className="label-mono mt-0.5 block truncate text-mute transition-colors group-hover:text-white/45">
                    {s.stack}
                  </span>
                </span>

                <span className="font-mono text-sm tabular-nums text-mute transition-colors group-hover:text-white/45 md:text-right">
                  {s.before.toFixed(1)}s
                </span>

                <span className="font-mono text-lg font-semibold tabular-nums text-signal md:text-right">
                  {s.after.toFixed(1)}s
                </span>

                <span className="col-span-2 md:col-span-1">
                  <span className="relative block h-2 w-full bg-ink/10 transition-colors group-hover:bg-white/15">
                    <span
                      className="absolute inset-y-0 left-0 bg-ink/25 transition-all duration-700 group-hover:bg-white/25"
                      style={{ width: `${(s.before / SCALE) * 100}%` }}
                    />
                  </span>
                  <span className="relative mt-1 block h-2 w-full">
                    <span
                      className="absolute inset-y-0 left-0 bg-signal transition-all duration-700 group-hover:bg-volt"
                      style={{ width: `${(s.after / SCALE) * 100}%` }}
                    />
                  </span>
                </span>

                <span className="label-mono text-right text-ink transition-colors group-hover:text-volt">
                  {s.lift}
                </span>

                <span className="col-span-2 hidden font-mono text-[0.66rem] tabular-nums text-mute transition-colors group-hover:text-white/50 md:col-span-1 md:block md:text-right">
                  {s.laps.join("  ·  ")}
                </span>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-x-8 gap-y-2">
          <p className="max-w-lg text-xs leading-relaxed text-mute">
            LCP measured at p75 from field telemetry, seven days before and seven days after each
            engagement. Conversion lift reported by the client's own analytics — we don't grade our
            own homework.
          </p>
          <div className="label-mono ml-auto flex items-center gap-4">
            <span className="flex items-center gap-2 text-mute">
              <span className="h-2 w-4 bg-ink/25" /> before
            </span>
            <span className="flex items-center gap-2 text-signal">
              <span className="h-2 w-4 bg-signal" /> after
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------- playbook */

export function Playbook() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="playbook" className="relative overflow-x-clip bg-ink-2 py-20 text-paper-2 sm:py-28">
      <Ambient tone="dark" />
      <div className="relative mx-auto max-w-[1400px] px-4 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-12 lg:gap-14">
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-24">
              <SectionHead
                index="04"
                kicker="playbook · how we work"
                tone="dark"
                title={
                  <>
                    Eight
                    <br />
                    plays,
                    <br />
                    <span className="text-volt">in order.</span>
                  </>
                }
              />
              <p className="mt-6 max-w-sm text-sm leading-relaxed text-white/55">
                No play is exotic and none is optional. The work is in the sequence: you cannot
                hydrate your way out of a page that was never measured, and you cannot cache a
                bundle that should not have existed.
              </p>
              <div className="mt-6 flex items-center gap-3">
                <span className="h-px w-10 bg-volt" />
                <span className="label-mono text-white/40">click a play to open it</span>
              </div>
              <div className="mt-8 hidden gap-px bg-white/10 lg:grid lg:grid-cols-4">
                {PLAYBOOK.map((p, i) => (
                  <button
                    key={p.n}
                    type="button"
                    onClick={() => setOpen(open === i ? null : i)}
                    className={`label-mono bg-ink-2 px-2 py-3 text-center transition-colors ${
                      open === i ? "bg-volt text-ink" : "text-white/35 hover:text-paper-2"
                    }`}
                  >
                    {p.n}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-8">
            <ul className="border-t border-white/12">
              {PLAYBOOK.map((p, i) => {
                const isOpen = open === i;
                return (
                  <Reveal as="li" key={p.n} delay={i * 40}>
                    <div className="border-b border-white/12">
                      <button
                        type="button"
                        onClick={() => setOpen(isOpen ? null : i)}
                        aria-expanded={isOpen}
                        className="group flex w-full items-center gap-4 py-5 text-left sm:gap-6"
                      >
                        <span
                          className={`label-mono w-8 shrink-0 transition-colors duration-200 ${
                            isOpen ? "text-volt" : "text-white/30 group-hover:text-signal"
                          }`}
                        >
                          {p.n}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span
                            className={`block font-display text-[clamp(1.15rem,2.6vw,1.85rem)] leading-tight font-bold tracking-tight uppercase transition-all duration-300 ${
                              isOpen
                                ? "translate-x-1 text-volt"
                                : "text-paper-2 group-hover:translate-x-1"
                            }`}
                          >
                            {p.title}
                          </span>
                        </span>
                        <span className="label-mono hidden shrink-0 border border-white/15 px-2 py-1 text-white/45 transition-colors group-hover:border-signal group-hover:text-signal sm:block">
                          {p.tag}
                        </span>
                        <span className="label-mono w-24 shrink-0 text-right text-white/40 transition-colors group-hover:text-paper-2">
                          {p.gain}
                        </span>
                        <span
                          className={`shrink-0 text-signal transition-transform duration-300 ${
                            isOpen ? "rotate-45" : "group-hover:translate-x-1"
                          }`}
                          aria-hidden
                        >
                          <svg viewBox="0 0 16 16" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
                            <path d="M8 2v12M2 8h12" />
                          </svg>
                        </span>
                      </button>

                      <div
                        className={`grid transition-[grid-template-rows,opacity] duration-500 ease-out ${
                          isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                        }`}
                      >
                        <div className="overflow-hidden">
                          <div className="flex gap-4 pb-6 sm:gap-6">
                            <span className="w-8 shrink-0" />
                            <div className="relative max-w-2xl border-l border-signal/60 pl-5">
                              <p className="text-[0.95rem] leading-relaxed text-white/65">{p.body}</p>
                              <span className="label-mono mt-3 block text-white/30 sm:hidden">
                                {p.tag}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Reveal>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
