import { type CSSProperties, type ReactNode } from "react";
import { useInView, useScrollProgress } from "../hooks/useEngine";

/* ---------------------------------------------------------------- ambient */

export function Ambient({
  tone = "dark",
  streaks = 0,
  children,
}: {
  tone?: "dark" | "light";
  streaks?: number;
  children?: ReactNode;
}) {
  const light = tone === "light";
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <div
        className={`absolute inset-0 bg-grid ${light ? "text-ink" : "text-white"}`}
        style={{ opacity: light ? 0.5 : 0.34 }}
      />
      <div
        className={`absolute inset-0 ${
          light
            ? "bg-[radial-gradient(120%_80%_at_50%_0%,rgba(255,255,255,0.9),rgba(231,232,228,0)_60%)]"
            : "bg-[radial-gradient(120%_90%_at_15%_-10%,rgba(255,75,18,0.22),rgba(19,21,26,0)_55%),radial-gradient(90%_70%_at_100%_10%,rgba(42,75,255,0.22),rgba(19,21,26,0)_60%)]"
        }`}
      />
      {streaks > 0 && (
        <div className="absolute inset-0">
          {Array.from({ length: streaks }).map((_, i) => {
            const top = (i * 97) % 100;
            const dur = 1.6 + ((i * 37) % 60) / 22;
            const w = 90 + ((i * 53) % 220);
            return (
              <span
                key={i}
                className="absolute h-px bg-signal/45"
                style={{
                  top: `${top}%`,
                  width: `${w}px`,
                  animation: `streak ${dur * 3}s linear infinite`,
                  animationDelay: `${-i * 0.7}s`,
                  opacity: 0.25 + (i % 4) * 0.16,
                }}
              />
            );
          })}
        </div>
      )}
      <div className="absolute inset-0 bg-noise opacity-[0.5] mix-blend-overlay" />
      {children}
    </div>
  );
}

/* ----------------------------------------------------------------- reveal */

export function Reveal({
  children,
  delay = 0,
  mask = false,
  className = "",
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  mask?: boolean;
  className?: string;
  as?: "div" | "li" | "tr" | "section";
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.15);
  return (
    <Tag
      ref={ref as never}
      data-in={inView}
      className={`${mask ? "reveal-mask" : "reveal"} ${className}`}
      style={{ "--rd": `${delay}ms` } as CSSProperties}
    >
      {children}
    </Tag>
  );
}

/* ------------------------------------------------------------- section hd */

export function SectionHead({
  index,
  title,
  kicker,
  note,
  tone = "light",
}: {
  index: string;
  title: ReactNode;
  kicker: string;
  note?: ReactNode;
  tone?: "dark" | "light";
}) {
  const dark = tone === "dark";
  return (
    <div className="relative">
      <div className={`flex items-baseline gap-4 ${dark ? "text-white/45" : "text-mute"}`}>
        <span className="label-mono text-signal">{index}</span>
        <span className="label-mono">{kicker}</span>
        <span className={`h-px flex-1 ${dark ? "bg-white/15" : "bg-ink/15"}`} />
        {note ? <span className="label-mono hidden sm:block">{note}</span> : null}
      </div>
      <Reveal mask>
        <h2
          className={`display-wide mt-4 text-[clamp(2.6rem,7.4vw,6rem)] ${
            dark ? "text-paper-2" : "text-ink"
          }`}
        >
          {title}
        </h2>
      </Reveal>
    </div>
  );
}

/* -------------------------------------------------------------------- nav */

const LINKS = [
  { href: "#telemetry", label: "Telemetry" },
  { href: "#waterfall", label: "Waterfall" },
  { href: "#splits", label: "Splits" },
  { href: "#playbook", label: "Playbook" },
];

export function Chrome({ speed, top }: { speed: number; top: number }) {
  const p = useScrollProgress();
  const pct = Math.min(1, speed / 360);

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-ink/92 backdrop-blur-[3px]">
        <div className="mx-auto flex h-14 max-w-[1400px] items-center gap-4 px-4 sm:px-6">
          <a href="#top" className="group flex items-center gap-2.5">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-signal" aria-hidden>
              <path d="M3 5h9l-5 7h6l-11 8 4-9H2z" fill="currentColor" />
              <path
                d="M14 4h7l-5 6h5"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.6"
                className="opacity-45 transition-opacity group-hover:opacity-100"
              />
            </svg>
            <span className="display-wide text-[1.05rem] text-paper-2">Faster</span>
            <span className="label-mono hidden text-white/30 md:inline">/ telemetry lab</span>
          </a>

          <nav className="ml-auto hidden items-center gap-1 md:flex">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="label-mono relative px-3 py-2 text-white/55 transition-colors hover:text-paper-2"
              >
                {l.label}
                <span className="absolute inset-x-3 bottom-1 h-px origin-left scale-x-0 bg-signal transition-transform duration-300 hover:scale-x-100" />
              </a>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-3 md:ml-0">
            <div className="hidden items-end gap-2 sm:flex">
              <span className="label-mono text-white/35">vel</span>
              <span className="font-mono text-sm font-semibold tabular-nums text-volt">
                {speed.toFixed(0).padStart(3, "0")}
              </span>
              <span className="relative h-1.5 w-16 overflow-hidden rounded-full bg-white/12">
                <span
                  className="absolute inset-y-0 left-0 rounded-full bg-signal transition-[width] duration-75"
                  style={{ width: `${pct * 100}%` }}
                />
              </span>
              <span className="label-mono text-white/25">top {top.toFixed(0)}</span>
            </div>
            <a
              href="#pit"
              className="group relative overflow-hidden bg-volt px-3.5 py-2 text-ink transition-colors hover:bg-paper-2"
            >
              <span className="label-mono relative z-10">Book a tune-up</span>
              <span className="absolute inset-0 -translate-x-full bg-signal transition-transform duration-300 group-hover:translate-x-0" />
            </a>
          </div>
        </div>
        <div className="relative h-[3px] w-full bg-white/8">
          <div
            className="h-full origin-left bg-signal"
            style={{ transform: `scaleX(${p})`, boxShadow: "0 0 12px rgba(255,75,18,0.8)" }}
          />
        </div>
      </header>
      <div className="h-14" aria-hidden />
    </>
  );
}

/* ----------------------------------------------------------------- ticker */

export function Ticker() {
  const row = (dir: "fwd" | "rev", tone: "signal" | "ink") => (
    <div
      className={`flex w-max ${dir === "fwd" ? "animate-marquee" : "animate-marquee-rev"} ${
        tone === "signal" ? "bg-signal text-ink" : "bg-ink text-volt"
      } items-center gap-8 py-2.5`}
    >
      {Array.from({ length: 2 }).map((_, dup) => (
        <div key={dup} className="flex items-center gap-8">
          {[
            "SHAVE MILLISECONDS",
            "CUT KILOBYTES",
            "EDGE EVERYTHING",
            "PRELOAD THE CRITICAL PATH",
            "HYDRATE ONLY WHAT YOU TOUCH",
            "RESERVE THE SPACE",
            "BROTLI ALL THE WAY DOWN",
            "FIELD DATA OR IT DIDN'T HAPPEN",
          ].map((t) => (
            <span key={t} className="flex items-center gap-8">
              <span className="display-wide text-[0.95rem] whitespace-nowrap sm:text-[1.15rem]">{t}</span>
              <svg viewBox="0 0 12 12" className="h-2.5 w-2.5 shrink-0 opacity-70" aria-hidden>
                <path d="M6 0l6 6-6 6-6-6z" fill="currentColor" />
              </svg>
            </span>
          ))}
        </div>
      ))}
    </div>
  );

  return (
    <div className="relative z-10 -my-2 select-none">
      <div className="-rotate-[1.4deg] scale-[1.03] space-y-1.5">
        {row("fwd", "signal")}
        {row("rev", "ink")}
      </div>
    </div>
  );
}
