import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { OPTIMIZATIONS, computeMetrics, computeSpecs } from "../data";

export const GAUGE_MAX = 360;
export const SPRINT_TARGET = 100;

export type Hud = {
  speed: number;
  t: number;
  active: boolean;
  last: number | null;
  best: number | null;
  runs: number;
  peak: number;
};

const DEFAULT_ON: Record<string, boolean> = { split: true, avif: true };

/** Physics-driven throttle simulation: hold to accelerate, release to coast. */
export function useEngine() {
  const [enabled, setEnabled] = useState<Record<string, boolean>>(DEFAULT_ON);
  const [holding, setHolding] = useState(false);

  const specs = useMemo(() => computeSpecs(enabled), [enabled]);
  const metrics = useMemo(() => computeMetrics(enabled), [enabled]);

  const cfgRef = useRef(specs);
  const holdRef = useRef(holding);
  const sim = useRef({ v: 0, t0: 0, active: false, best: null as number | null, last: null as number | null, runs: 0, peak: 0 });

  useEffect(() => {
    cfgRef.current = specs;
  }, [specs]);
  useEffect(() => {
    holdRef.current = holding;
  }, [holding]);

  const [hud, setHud] = useState<Hud>({
    speed: 0,
    t: 0,
    active: false,
    last: null,
    best: null,
    runs: 0,
    peak: 0,
  });
  const lastHud = useRef<Hud>(hud);

  useEffect(() => {
    let raf = 0;
    let prev = performance.now();

    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - prev) / 1000);
      prev = now;
      const s = sim.current;
      const cfg = cfgRef.current;
      const gas = holdRef.current || s.active;

      if (gas) {
        s.v += cfg.power * (1 - s.v / cfg.top) * dt;
      } else {
        s.v = Math.max(0, s.v - (s.v * 0.75 + 16) * dt);
      }
      if (s.v > s.peak) s.peak = s.v;

      if (s.active) {
        const t = (now - s.t0) / 1000;
        if (s.v >= SPRINT_TARGET) {
          s.active = false;
          s.last = t;
          s.runs += 1;
          s.best = s.best === null ? t : Math.min(s.best, t);
        }
      }

      const next: Hud = {
        speed: Math.round(s.v * 10) / 10,
        t: s.active ? (now - s.t0) / 1000 : (s.last ?? 0),
        active: s.active,
        last: s.last,
        best: s.best,
        runs: s.runs,
        peak: Math.round(s.peak * 10) / 10,
      };
      const p = lastHud.current;
      const changed =
        Math.abs(p.speed - next.speed) > 0.04 ||
        p.active !== next.active ||
        (next.active && Math.abs(p.t - next.t) > 0.008) ||
        p.best !== next.best ||
        p.runs !== next.runs ||
        Math.abs(p.peak - next.peak) > 0.04;
      if (changed) {
        lastHud.current = next;
        setHud(next);
      }
      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const launch = useCallback(() => {
    const s = sim.current;
    s.v = 0;
    s.peak = 0;
    s.active = true;
    s.t0 = performance.now();
  }, []);

  const release = useCallback(() => setHolding(false), []);

  const toggle = useCallback((id: string) => {
    setEnabled((prev) => ({ ...prev, [id]: !prev[id] }));
  }, []);

  const all = useCallback((value: boolean) => {
    setEnabled(Object.fromEntries(OPTIMIZATIONS.map((o) => [o.id, value])));
  }, []);

  return { enabled, toggle, all, specs, metrics, hud, holding, setHolding, launch, release };
}

export type Engine = ReturnType<typeof useEngine>;

/* ------------------------------------------------------------------ */

export function useInView<T extends HTMLElement>(threshold = 0.25, once = true) {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setInView(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setInView(true);
            if (once) io.unobserve(e.target);
          } else if (!once) {
            setInView(false);
          }
        });
      },
      { threshold, rootMargin: "0px 0px -8% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, once]);

  return { ref, inView };
}

/** Eases a displayed number toward its target whenever it changes. */
export function useCountUp(target: number, duration = 900, run = true) {
  const [value, setValue] = useState(run ? 0 : target);
  const valueRef = useRef(value);
  const rafRef = useRef(0);

  useEffect(() => {
    valueRef.current = value;
  }, [value]);

  useEffect(() => {
    if (!run) {
      valueRef.current = target;
      setValue(target);
      return;
    }
    const from = valueRef.current;
    const start = performance.now();
    cancelAnimationFrame(rafRef.current);
    const step = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      const v = from + (target - from) * eased;
      setValue(v);
      if (p < 1) rafRef.current = requestAnimationFrame(step);
      else valueRef.current = target;
    };
    rafRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafRef.current);
  }, [target, duration, run]);

  return value;
}

export function useScrollProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const h = document.documentElement.scrollHeight - window.innerHeight;
        setP(h > 0 ? Math.min(1, window.scrollY / h) : 0);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);
  return p;
}
