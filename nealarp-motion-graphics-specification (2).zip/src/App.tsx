import { Chrome, Ticker } from "./components/Chrome";
import { Hero } from "./components/Hero";
import { Telemetry, Waterfall } from "./components/Benchmarks";
import { Playbook, Splits } from "./components/Splits";
import { CostBand } from "./components/CostBand";
import { FooterBar, Pit } from "./components/Footer";
import { useEngine } from "./hooks/useEngine";

export default function App() {
  const engine = useEngine();

  return (
    <div className="min-h-screen bg-ink font-body antialiased">
      <Chrome speed={engine.hud.speed} top={engine.specs.top} />

      <main>
        <Hero engine={engine} />

        <div className="relative bg-ink py-4">
          <Ticker />
        </div>

        <Telemetry metrics={engine.metrics} />
        <Waterfall enabled={engine.enabled} />
        <CostBand />
        <Splits />
        <Playbook />
        <Pit hud={engine.hud} />
      </main>

      <FooterBar />
    </div>
  );
}
