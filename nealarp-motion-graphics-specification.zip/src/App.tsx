import { useEffect, useRef, useState } from "react";
import Stage from "./components/Stage";
import TimelineStrip from "./components/TimelineStrip";
import { ChecklistPanel, ReportPanel, TextPanel, VerifyPanel } from "./components/Panels";
import { buildTextSystem, type TextSystem } from "./ad/layout";
import { FPS, PALETTE, TOTAL_FRAMES } from "./ad/constants";
import { clock } from "./ad/store";
import { CANON_TEXT, SCENES, SFX, VO } from "./ad/timeline";
import { CHECKLIST } from "./ad/checklistData";

type Tab = "verify" | "text" | "checklist" | "report";

export default function App() {
  const [sys, setSys] = useState<TextSystem | null>(null);
  const [fontNote, setFontNote] = useState("loading DejaVu…");
  const [tab, setTab] = useState<Tab>("verify");

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        await document.fonts.ready;
        await Promise.all([
          document.fonts.load('700 96px "DejaVu Sans"'),
          document.fonts.load('400 12px "DejaVu Sans Mono"'),
        ]);
        const ok = document.fonts.check('700 96px "DejaVu Sans"');
        if (alive) setFontNote(ok ? "DejaVu Sans Bold · loaded by URL" : "DejaVu requested · system fallback active");
      } catch {
        if (alive) setFontNote("DejaVu unavailable · fallback metrics");
      }
      if (alive) setSys(buildTextSystem());
    })();
    return () => {
      alive = false;
    };
  }, []);

  const counts = CHECKLIST.reduce(
    (a, i) => ({ ...a, [i.status]: (a[i.status] ?? 0) + 1 }),
    {} as Record<string, number>,
  );

  return (
    <div className="bg-console min-h-screen text-white/85">
      <TopBar fontNote={fontNote} />

      <main className="mx-auto w-full max-w-[1720px] px-4 pb-16 pt-4 sm:px-6">
        <section className="grid gap-4 xl:grid-cols-[minmax(0,1.62fr)_minmax(380px,1fr)]">
          <div className="min-w-0 space-y-4">
            <Stage sys={sys ?? { records: new Map(), log: [] }} ready={!!sys} />
            <TimelineStrip />
            <VoTicker />
          </div>

          <aside className="panel flex min-h-[620px] flex-col xl:sticky xl:top-4 xl:max-h-[calc(100vh-2rem)]">
            <div className="flex shrink-0 border-b border-white/10">
              {(
                [
                  ["verify", "Verify"],
                  ["text", "Text log"],
                  ["checklist", "Checklist"],
                  ["report", "Report"],
                ] as [Tab, string][]
              ).map(([id, label]) => (
                <button
                  key={id}
                  onClick={() => setTab(id)}
                  className={[
                    "relative flex-1 px-2 py-2.5 font-mono text-[10.5px] uppercase tracking-[0.16em] transition",
                    tab === id ? "text-white" : "text-white/35 hover:text-white/70",
                  ].join(" ")}
                >
                  {label}
                  {tab === id && <span className="absolute inset-x-0 bottom-0 h-[2px] bg-[#f97316]" />}
                </button>
              ))}
            </div>
            <div className="min-h-0 flex-1">
              {tab === "verify" && sys && <VerifyPanel sys={sys} />}
              {tab === "text" && sys && <TextPanel sys={sys} />}
              {tab === "checklist" && <ChecklistPanel />}
              {tab === "report" && <ReportPanel />}
              {!sys && tab !== "checklist" && tab !== "report" && (
                <div className="px-4 py-10 font-mono text-[11px] text-white/35">building layout log…</div>
              )}
            </div>
          </aside>
        </section>

        <StatsBand counts={counts} />
        <GateNotice />
      </main>

      <footer className="border-t border-white/10 px-6 py-6">
        <div className="mx-auto flex max-w-[1720px] flex-wrap items-center justify-between gap-3 font-mono text-[10.5px] text-white/30">
          <span>
            nealarp · AD-60 · 60.000 s · {TOTAL_FRAMES} frames · 1920×1080 / 3840×2160 @ 60 fps
          </span>
          <span>
            every frame = f(t), t = frame / {FPS} · palette {PALETTE.blue} / {PALETTE.orange} / #ffffff / {PALETTE.nearBlack}
          </span>
        </div>
      </footer>
    </div>
  );
}

function TopBar({ fontNote }: { fontNote: string }) {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#050506]/88 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1720px] flex-wrap items-center gap-x-5 gap-y-2 px-4 py-2.5 sm:px-6">
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-6 w-6 items-center justify-center">
            <span className="absolute inset-0 bg-[#3b82f6]/25" />
            <span className="absolute inset-[5px] bg-[#f97316]" />
          </span>
          <span className="font-display text-[19px] font-bold leading-none tracking-[0.02em] text-white">nealarp</span>
          <span className="hidden font-mono text-[10px] uppercase tracking-[0.2em] text-white/35 sm:inline">
            ad-60 render console
          </span>
        </div>

        <div className="ml-auto flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[0.14em]">
          <Meta k="stack" v="python 3.11 · numpy · pillow · ffmpeg" tone="blue" />
          <Meta k="test" v="1080p60 · not encoded" tone="orange" />
          <Meta k="final" v="2160p60 · gated" tone="orange" />
          <Meta k="fonts" v={fontNote} tone="dim" />
        </div>
      </div>
    </header>
  );
}

function Meta({ k, v, tone }: { k: string; v: string; tone: "blue" | "orange" | "dim" }) {
  const c =
    tone === "blue"
      ? "border-[#3b82f6]/40 text-[#9dc4ff]"
      : tone === "orange"
        ? "border-[#f97316]/45 text-[#fdba74]"
        : "border-white/12 text-white/45";
  return (
    <span className={`flex items-center gap-1.5 border px-2 py-1 ${c}`}>
      <span className="text-white/30">{k}</span>
      <span className="max-w-[240px] truncate">{v}</span>
    </span>
  );
}

/** live German voiceover read-out, driven by the same clock as the renderer */
function VoTicker() {
  const lineRef = useRef<HTMLSpanElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const idRef = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const t = clock.frame / FPS;
      const v = [...VO].reverse().find((l) => t >= l.start && t < l.start + l.dur);
      if (lineRef.current) lineRef.current.textContent = v ? v.string : "—";
      if (idRef.current) idRef.current.textContent = v ? v.id : "silence";
      if (barRef.current)
        barRef.current.style.width = v ? `${Math.min(100, ((t - v.start) / v.dur) * 100)}%` : "0%";
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);
  return (
    <div className="panel flex items-center gap-4 px-4 py-2.5">
      <span className="shrink-0 font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/30">voiceover de-DE</span>
      <span ref={idRef} className="shrink-0 font-mono text-[10px] text-[#fdba74]">
        silence
      </span>
      <span ref={lineRef} className="min-w-0 flex-1 truncate text-[13px] text-white/85">
        —
      </span>
      <span className="relative hidden h-[3px] w-40 shrink-0 bg-white/10 sm:block">
        <span ref={barRef} className="absolute inset-y-0 left-0 w-0 bg-[#f97316]" />
      </span>
      <span className="hidden shrink-0 font-mono text-[9.5px] uppercase tracking-[0.16em] text-white/25 md:inline">
        placeholder voice · r-gate-03
      </span>
    </div>
  );
}

function StatsBand({ counts }: { counts: Record<string, number> }) {
  const stats: [string, string, string?][] = [
    ["duration", "60.000 s"],
    ["frames", "3600"],
    ["scenes", String(SCENES.length)],
    ["cuts", "8 × 3.0 s"],
    ["canonical strings", String(CANON_TEXT.length)],
    ["sfx events", String(SFX.length)],
    ["vo lines", String(VO.length)],
    ["particle cap", "3000"],
    ["seed", "7"],
  ];
  return (
    <section className="panel mt-4 grid grid-cols-2 gap-px overflow-hidden bg-white/[0.06] sm:grid-cols-3 lg:grid-cols-5">
      {stats.map(([k, v]) => (
        <div key={k} className="group bg-[#08090c] px-4 py-3 transition hover:bg-[#0d1015]">
          <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/30 transition group-hover:text-[#9dc4ff]">
            {k}
          </p>
          <p className="mt-1 font-display text-[22px] font-bold leading-none text-white/90">{v}</p>
        </div>
      ))}
      <div className="col-span-2 bg-[#08090c] px-4 py-3 sm:col-span-3 lg:col-span-1">
        <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/30">checklist</p>
        <p className="mt-1 font-display text-[22px] font-bold leading-none">
          <span className="text-[#9dc4ff]">{counts.PASS ?? 0}</span>
          <span className="mx-1 text-white/20">/</span>
          <span className="text-[#fdba74]">{counts.BLOCKED ?? 0}</span>
          <span className="mx-1 text-white/20">/</span>
          <span className="text-white/70">{counts.FAIL ?? 0}</span>
        </p>
        <p className="mt-1 font-mono text-[9.5px] text-white/30">pass / blocked / fail</p>
      </div>
    </section>
  );
}

function GateNotice() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("in")),
      { threshold: 0.2 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <section
      ref={ref}
      className="reveal panel panel-ticks mt-4 grid gap-6 px-5 py-5 md:grid-cols-[auto_minmax(0,1fr)]"
    >
      <div className="flex items-start gap-4">
        <span className="mt-1 inline-block h-2.5 w-2.5 shrink-0 rounded-full bg-[#f97316] shadow-[0_0_16px_rgba(249,115,22,0.9)] blip" />
        <div>
          <h2 className="font-display text-[26px] font-bold uppercase leading-none tracking-[0.02em] text-white">
            Approval gate holding
          </h2>
          <p className="mt-2 max-w-xl font-mono text-[11px] leading-relaxed text-white/50">
            R-GATE-01 — the pipeline stops after the 1080p test render and its verification report. No 4K job was
            started, and R-GATE-03 additionally refuses the 2160p master while the German voiceover is a placeholder.
          </p>
        </div>
      </div>
      <div className="grid gap-2 sm:grid-cols-3">
        {[
          ["1", "Encode the 1080p test", "python -m src.render --preset test"],
          ["2", "Supply a neural de-DE voice", "unblocks R-GATE-03"],
          ["3", "Approve the 4K master", "python -m src.render --preset final"],
        ].map(([n, t, s]) => (
          <div key={n} className="border border-white/10 bg-black/30 px-3 py-2.5 transition hover:border-[#3b82f6]/60">
            <span className="font-mono text-[10px] text-[#3b82f6]">{n}</span>
            <p className="mt-0.5 text-[12.5px] font-semibold text-white/85">{t}</p>
            <p className="mt-0.5 font-mono text-[10px] text-white/40">{s}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
