/**
 * sprites.ts — cached sprites and deterministic geometry (R-PERF-01/03).
 * Coins, creatures and icons are rendered once into offscreen canvases and
 * re-used; text→particle targets are sampled once per string.
 */
import { PALETTE, REF_H, REF_W, DEG } from "./constants";
import { Rng } from "./rng";
import { roundRect, type LayoutRecord } from "./layout";

const cache = new Map<string, HTMLCanvasElement>();

function make(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.ceil(w));
  c.height = Math.max(1, Math.ceil(h));
  return [c, c.getContext("2d")!];
}

/** R-SCN-02 chrome coin: radial gradient white centre → blue mid → orange rim 2 px. */
export function coinSprite(d = 110): HTMLCanvasElement {
  const key = `coin${d}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const pad = 6;
  const [c, x] = make(d + pad * 2, d + pad * 2);
  const cx = c.width / 2;
  const g = x.createRadialGradient(cx - d * 0.18, cx - d * 0.22, d * 0.05, cx, cx, d / 2);
  g.addColorStop(0, "#ffffff");
  g.addColorStop(0.32, "#cfe2ff");
  g.addColorStop(0.62, PALETTE.blue);
  g.addColorStop(0.9, "#1b3f7a");
  g.addColorStop(1, "#0d1b33");
  x.fillStyle = g;
  x.beginPath();
  x.arc(cx, cx, d / 2, 0, Math.PI * 2);
  x.fill();
  x.strokeStyle = PALETTE.orange;
  x.lineWidth = 2;
  x.beginPath();
  x.arc(cx, cx, d / 2 - 1, 0, Math.PI * 2);
  x.stroke();
  // inner ring + euro-free geometric mark (no logos: R-NEG-04)
  x.strokeStyle = "rgba(255,255,255,0.45)";
  x.lineWidth = 2;
  x.beginPath();
  x.arc(cx, cx, d * 0.3, 0, Math.PI * 2);
  x.stroke();
  cache.set(key, c);
  return c;
}

/** R-SCN-04 bioluminescent creature: rounded ellipse with glow. */
export function creatureSprite(size: number, color: string): HTMLCanvasElement {
  const key = `cr${size}${color}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const pad = size * 0.9;
  const [c, x] = make(size + pad * 2, size * 0.72 + pad * 2);
  const cx = c.width / 2;
  const cy = c.height / 2;
  const g = x.createRadialGradient(cx, cy, 0, cx, cy, size * 0.95);
  g.addColorStop(0, "rgba(255,255,255,0.95)");
  g.addColorStop(0.22, color);
  g.addColorStop(1, "rgba(0,0,0,0)");
  x.fillStyle = g;
  x.beginPath();
  x.ellipse(cx, cy, size * 0.95, size * 0.62, 0, 0, Math.PI * 2);
  x.fill();
  x.fillStyle = "rgba(255,255,255,0.85)";
  x.beginPath();
  x.ellipse(cx, cy, size * 0.24, size * 0.16, 0, 0, Math.PI * 2);
  x.fill();
  cache.set(key, c);
  return c;
}

/** R-VIS-11 telescope: tube on a tripod, stroke 6, white. */
export function telescopeIcon(h = 120, color = PALETTE.white): HTMLCanvasElement {
  const key = `tel${h}${color}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const w = h * 1.3;
  const [c, x] = make(w, h);
  x.strokeStyle = color;
  x.lineWidth = 6;
  x.lineCap = "round";
  x.lineJoin = "round";
  // tube
  x.save();
  x.translate(w * 0.5, h * 0.34);
  x.rotate(-22 * DEG);
  roundRect(x, -w * 0.36, -h * 0.1, w * 0.72, h * 0.2, 6);
  x.stroke();
  x.restore();
  // tripod: two lines + mount
  x.beginPath();
  x.moveTo(w * 0.5, h * 0.46);
  x.lineTo(w * 0.28, h * 0.95);
  x.moveTo(w * 0.5, h * 0.46);
  x.lineTo(w * 0.72, h * 0.95);
  x.moveTo(w * 0.5, h * 0.46);
  x.lineTo(w * 0.5, h * 0.95);
  x.stroke();
  cache.set(key, c);
  return c;
}

/** R-VIS-11 flame: teardrop path, stroke 6, orange. */
export function flameIcon(h = 120): HTMLCanvasElement {
  const key = `flame${h}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const [c, x] = make(h, h * 1.3);
  x.strokeStyle = PALETTE.orange;
  x.lineWidth = 6;
  x.lineJoin = "round";
  x.beginPath();
  x.moveTo(h * 0.5, h * 0.08);
  x.bezierCurveTo(h * 0.95, h * 0.55, h * 0.86, h * 1.12, h * 0.5, h * 1.18);
  x.bezierCurveTo(h * 0.14, h * 1.12, h * 0.05, h * 0.55, h * 0.5, h * 0.08);
  x.stroke();
  cache.set(key, c);
  return c;
}

/** R-SCN-08 heart: two circles + a triangle. */
export function heartPath(ctx: CanvasRenderingContext2D, cx: number, cy: number, size: number) {
  const r = size * 0.25;
  ctx.beginPath();
  ctx.arc(cx - r, cy - size * 0.12, r, 0, Math.PI * 2);
  ctx.arc(cx + r, cy - size * 0.12, r, 0, Math.PI * 2);
  ctx.moveTo(cx - size * 0.49, cy - size * 0.02);
  ctx.lineTo(cx + size * 0.49, cy - size * 0.02);
  ctx.lineTo(cx, cy + size * 0.46);
  ctx.closePath();
}

/** R-VIS-09 perspective projection. */
export function project(x: number, y: number, z: number, f = 900) {
  const k = f / (f + z);
  return { sx: REF_W / 2 + x * k, sy: REF_H / 2 + y * k, k };
}

/* ------------------------------------------------------------------ */
/* text → particle targets (R-SCN-11 reform)                           */
/* ------------------------------------------------------------------ */
const pointCache = new Map<string, Float32Array>();

export function sampleTextPoints(rec: LayoutRecord, count: number): Float32Array {
  const key = `${rec.id}:${count}`;
  const hit = pointCache.get(key);
  if (hit) return hit;
  const pad = 8;
  const w = Math.ceil(rec.box.w + pad * 2);
  const h = Math.ceil(rec.box.h + pad * 2);
  const [, x] = make(w, h);
  x.fillStyle = "#fff";
  x.font = `700 ${rec.size}px "DejaVu Sans", "Liberation Sans", sans-serif`;
  x.textBaseline = "alphabetic";
  const ox = pad - rec.box.x;
  const oy = pad - rec.box.y;
  for (const g of rec.glyphs) x.fillText(g.ch, g.x + ox, rec.baselineY + oy);

  const data = x.getImageData(0, 0, w, h).data;
  const pts: number[] = [];
  const stepX = 2;
  const stepY = 2;
  for (let py = 0; py < h; py += stepY) {
    for (let px = 0; px < w; px += stepX) {
      if (data[(py * w + px) * 4 + 3] > 150) {
        pts.push(px + ox - pad + rec.box.x, py + oy - pad + rec.box.y);
      }
    }
  }
  const n = pts.length / 2;
  const out = new Float32Array(count * 2);
  const rng = new Rng(7);
  if (n === 0) {
    for (let i = 0; i < count; i++) {
      out[i * 2] = rec.cx + rng.range(-300, 300);
      out[i * 2 + 1] = rec.baselineY + rng.range(-60, 60);
    }
  } else {
    for (let i = 0; i < count; i++) {
      const j = Math.floor(rng.f() * n) % n;
      out[i * 2] = pts[j * 2] + rng.range(-1.5, 1.5);
      out[i * 2 + 1] = pts[j * 2 + 1] + rng.range(-1.5, 1.5);
    }
  }
  pointCache.set(key, out);
  return out;
}

/* ------------------------------------------------------------------ */
/* shared deterministic field definitions                              */
/* ------------------------------------------------------------------ */
export interface P3 {
  x: number;
  y: number;
  z: number;
  size: number;
  blue: boolean;
}

/** R-SCN-01 tunnel field: blue left, orange right, converging on (960,540). */
export function tunnelField(n: number): P3[] {
  const rng = new Rng(7);
  const out: P3[] = [];
  for (let i = 0; i < n; i++) {
    const side = rng.sign();
    out.push({
      x: side * rng.range(180, 1500),
      y: rng.range(-700, 700),
      z: rng.range(0, 2000),
      size: rng.range(2, 9),
      blue: side < 0,
    });
  }
  return out;
}

export function bubbleField(n: number): { x: number; y: number; r: number; v: number }[] {
  const rng = new Rng(7);
  return Array.from({ length: n }, () => ({
    x: rng.range(0, REF_W),
    y: rng.range(0, REF_H * 1.6),
    r: rng.range(4, 14),
    v: rng.range(80, 160),
  }));
}

export function creatureField(n: number) {
  const rng = new Rng(7);
  return Array.from({ length: n }, () => ({
    x: rng.range(-800, 800),
    y: rng.range(-420, 420),
    z: rng.range(0, 1800),
    size: rng.range(60, 140),
    blue: rng.f() > 0.32,
    drift: rng.range(-30, 30),
  }));
}

export function galaxyField(n: number) {
  const rng = new Rng(7);
  const out: { a: number; r: number; size: number; blue: boolean }[] = [];
  const arms = 2;
  for (let i = 0; i < n; i++) {
    const arm = i % arms;
    const rr = Math.pow(rng.f(), 0.62);
    out.push({
      a: arm * Math.PI + rr * 3.1 + rng.range(-0.22, 0.22),
      r: rr,
      size: rng.range(1.2, 3.4),
      blue: rng.f() > 0.42,
    });
  }
  return out;
}
