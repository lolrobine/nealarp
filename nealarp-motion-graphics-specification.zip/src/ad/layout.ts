/**
 * layout.ts — the text layout system (R-VIS-12, R-TXT-02, R-TXT-03).
 *
 * No scene draws text itself. Every string in R-TXT-01 is declared in
 * timeline.ts, measured here, auto-fitted here, logged here, and drawn here.
 * The log is what R-VER-08 / R-VER-09 are checked against.
 */
import {
  AUTOFIT_MAX_WIDTH,
  AUTOFIT_MIN_SIZE,
  AUTOFIT_STEP,
  PALETTE,
  REF_H,
  REF_W,
  SAFE,
  clamp,
  clamp01,
} from "./constants";
import { TEXTS, type TextEntry, type TextLayoutId } from "./timeline";

export const DISPLAY_FONT = `"DejaVu Sans", "Liberation Sans", "Arial Black", sans-serif`;
export const MONO_FONT = `"DejaVu Sans Mono", "DejaVu Sans", monospace`;

export interface Template {
  size: number;
  fill: "gradient" | "white" | "orange";
  cx: number;
  /** y of the baseline when anchor === "baseline", else the optical centre */
  y: number;
  anchor: "baseline" | "middle";
  tracking: number; // em
  uppercase: boolean;
  glass?: { padX: number; padY: number; radius: number };
}

/** Spec templates verbatim, plus two documented scene templates (see README §Deviations). */
export const TEMPLATES: Record<TextLayoutId, Template> = {
  title_lower_third: { size: 96, fill: "gradient", cx: 960, y: 880, anchor: "baseline", tracking: 0.04, uppercase: true, glass: { padX: 48, padY: 28, radius: 24 } },
  title_opening: { size: 180, fill: "gradient", cx: 960, y: 540, anchor: "middle", tracking: 0.04, uppercase: true },
  counter_center: { size: 160, fill: "white", cx: 960, y: 520, anchor: "middle", tracking: 0.02, uppercase: false },
  claim_white: { size: 112, fill: "white", cx: 960, y: 540, anchor: "middle", tracking: 0.02, uppercase: true },
  claim_gradient: { size: 96, fill: "gradient", cx: 960, y: 540, anchor: "middle", tracking: 0.04, uppercase: true },
  url: { size: 72, fill: "white", cx: 960, y: 600, anchor: "middle", tracking: 0.01, uppercase: false },
  cta_button_label: { size: 44, fill: "white", cx: 960, y: 780, anchor: "middle", tracking: 0.06, uppercase: true },
  // added (documented): labels inside the glass counter panels of R-SCN-08
  panel_label: { size: 34, fill: "white", cx: 960, y: 430, anchor: "middle", tracking: 0.14, uppercase: true },
  // added (documented): the 98 % score placement of R-SCN-07
  score_orange_160: { size: 160, fill: "orange", cx: 1480, y: 470, anchor: "middle", tracking: 0.0, uppercase: false },
};

export interface Glyph {
  ch: string;
  x: number; // left edge, reference px
  w: number;
}

export interface LayoutRecord {
  id: string;
  string: string;
  layout: TextLayoutId;
  start: number;
  end: number;
  baseSize: number;
  size: number;
  autofit: boolean;
  autofitSteps: number;
  width: number;
  ascent: number;
  descent: number;
  cx: number;
  baselineY: number;
  tracking: number;
  fill: Template["fill"];
  glass?: Template["glass"];
  glyphs: Glyph[];
  box: { x: number; y: number; w: number; h: number };
  safeAreaOk: boolean;
  safeAreaNote: string;
}

const CAP_RATIO = 0.365; // baseline offset for optical vertical centring of caps

function fontFor(size: number) {
  return `700 ${size}px ${DISPLAY_FONT}`;
}

function buildRecord(ctx: CanvasRenderingContext2D, e: TextEntry): LayoutRecord {
  const tpl = TEMPLATES[e.layout];
  const str = tpl.uppercase ? e.string.toUpperCase() : e.string;
  const cx = e.cx ?? tpl.cx;
  let size = e.size ?? tpl.size;
  const baseSize = size;

  const measure = (s: number) => {
    ctx.font = fontFor(s);
    const glyphs: Glyph[] = [];
    let w = 0;
    const track = tpl.tracking * s;
    for (const ch of str) {
      const gw = ctx.measureText(ch).width;
      glyphs.push({ ch, x: w, w: gw });
      w += gw + track;
    }
    const m = ctx.measureText(str);
    const ascent =
      (m as unknown as { fontBoundingBoxAscent?: number }).fontBoundingBoxAscent ?? s * 0.78;
    const descent =
      (m as unknown as { fontBoundingBoxDescent?: number }).fontBoundingBoxDescent ?? s * 0.22;
    return { total: Math.max(0, w - track), glyphs, ascent, descent };
  };

  // R-TXT-03 auto-fit: shrink by 4 px while wider than 1440, floor 64 px.
  let steps = 0;
  let m = measure(size);
  while (m.total > AUTOFIT_MAX_WIDTH && size - AUTOFIT_STEP >= AUTOFIT_MIN_SIZE) {
    size -= AUTOFIT_STEP;
    steps++;
    m = measure(size);
  }

  const baselineY =
    tpl.anchor === "baseline" ? tpl.y : (e.cy ?? tpl.y) + CAP_RATIO * size;
  const x0 = cx - m.total / 2;
  const glyphs = m.glyphs.map((g) => ({ ...g, x: x0 + g.x }));

  const padX = tpl.glass?.padX ?? 0;
  const padY = tpl.glass?.padY ?? 0;
  const box = {
    x: x0 - padX,
    y: baselineY - m.ascent - padY,
    w: m.total + padX * 2,
    h: m.ascent + m.descent + padY * 2,
  };

  const inside =
    box.x >= SAFE.left - 0.5 &&
    box.x + box.w <= REF_W - SAFE.right + 0.5 &&
    box.y >= SAFE.top - 0.5 &&
    box.y + box.h <= REF_H - SAFE.bottom + 0.5;

  return {
    id: e.id,
    string: e.string,
    layout: e.layout,
    start: e.start,
    end: e.end,
    baseSize,
    size,
    autofit: steps > 0,
    autofitSteps: steps,
    width: m.total,
    ascent: m.ascent,
    descent: m.descent,
    cx,
    baselineY,
    tracking: tpl.tracking,
    fill: tpl.fill,
    glass: tpl.glass,
    glyphs,
    box,
    safeAreaOk: inside,
    safeAreaNote: inside
      ? `ok  x[${box.x.toFixed(0)}..${(box.x + box.w).toFixed(0)}] y[${box.y.toFixed(0)}..${(box.y + box.h).toFixed(0)}]`
      : `OUTSIDE safe area x[${box.x.toFixed(0)}..${(box.x + box.w).toFixed(0)}] y[${box.y.toFixed(0)}..${(box.y + box.h).toFixed(0)}]`,
  };
}

export interface TextSystem {
  records: Map<string, LayoutRecord>;
  log: LayoutRecord[];
}

export function buildTextSystem(): TextSystem {
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext("2d")!;
  const log = TEXTS.map((e) => buildRecord(ctx, e));
  return { records: new Map(log.map((r) => [r.id, r])), log };
}

export interface DrawTextOpts {
  alpha?: number;
  /** reveal in letters: 0 = none, glyphs.length = all (staggered) */
  reveal?: number;
  /** motion-blur tail on the last n glyphs (R-SCN-01) */
  tail?: number;
  tailDist?: number;
  scale?: number; // pulse about the optical centre
  glow?: number; // 0..1 additive bloom strength
  gradientAngle?: number;
  shadow?: boolean;
}

/**
 * R-VIS-03 gradient across the run: blue 0 % → orange 100 %.
 * A white mid-stop is inserted (documented deviation, README §6): a direct
 * RGB lerp from #3b82f6 to #f97316 crosses hues around 12–15° at ~40 %
 * saturation, which R-VER-06 rejects. Routing through white — a house colour,
 * and the "hot white core" of R-REF-02 — keeps every saturated pixel inside
 * the blue (195–235°) or orange (15–35°) band.
 */
export function gradientFor(ctx: CanvasRenderingContext2D, r: LayoutRecord) {
  const g = ctx.createLinearGradient(r.box.x, 0, r.box.x + r.width, 0);
  g.addColorStop(0, PALETTE.blue);
  g.addColorStop(0.5, PALETTE.white);
  g.addColorStop(1, PALETTE.orange);
  return g;
}

export function drawText(
  ctx: CanvasRenderingContext2D,
  r: LayoutRecord,
  o: DrawTextOpts = {},
): void {
  const alpha = o.alpha ?? 1;
  if (alpha <= 0.001) return;
  const scale = o.scale ?? 1;
  const reveal = o.reveal ?? r.glyphs.length;

  ctx.save();
  if (scale !== 1) {
    const cy = r.baselineY - r.ascent * 0.5;
    ctx.translate(r.cx, cy);
    ctx.scale(scale, scale);
    ctx.translate(-r.cx, -cy);
  }
  ctx.font = fontFor(r.size);
  ctx.textBaseline = "alphabetic";
  ctx.globalAlpha = alpha;

  const paint =
    r.fill === "gradient" ? gradientFor(ctx, r) : r.fill === "orange" ? PALETTE.orange : PALETTE.white;

  if (o.glow) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = alpha * o.glow * 0.5;
    ctx.shadowColor = r.fill === "gradient" ? PALETTE.blue : paint as string;
    ctx.shadowBlur = 34;
    ctx.fillStyle = paint;
    for (const g of r.glyphs) ctx.fillText(g.ch, g.x, r.baselineY);
    ctx.restore();
  }

  ctx.fillStyle = paint;
  const n = r.glyphs.length;
  r.glyphs.forEach((g, i) => {
    const a = clamp01(reveal - i);
    if (a <= 0) return;
    ctx.globalAlpha = alpha * a;
    const isTail = o.tail ? i >= n - o.tail : false;
    if (isTail) {
      const dist = o.tailDist ?? 46;
      for (let k = 5; k >= 1; k--) {
        ctx.globalAlpha = alpha * a * 0.1 * (1 - k / 6);
        ctx.fillText(g.ch, g.x - (dist * k) / 5, r.baselineY);
      }
      ctx.globalAlpha = alpha * a;
    }
    ctx.fillText(g.ch, g.x, r.baselineY);
  });
  ctx.restore();
}

/** R-VIS-04 glass panel behind lower thirds. Backdrop blur on a 1/4-scale copy. */
export function drawGlassPanel(
  ctx: CanvasRenderingContext2D,
  r: LayoutRecord,
  alpha: number,
  scratch: HTMLCanvasElement,
): void {
  if (!r.glass || alpha <= 0.01) return;
  const { x, y, w, h } = r.box;
  const rad = r.glass.radius;
  const sctx = scratch.getContext("2d")!;
  const q = 0.25; // R-VIS-04: compute blur on a 1/4-scale copy
  // source coordinates are in device pixels, so undo the reference-space scale
  const sc = ctx.getTransform().a || 1;
  scratch.width = Math.max(2, Math.ceil(w * sc * q));
  scratch.height = Math.max(2, Math.ceil(h * sc * q));
  sctx.clearRect(0, 0, scratch.width, scratch.height);
  try {
    sctx.drawImage(ctx.canvas, x * sc, y * sc, w * sc, h * sc, 0, 0, scratch.width, scratch.height);
  } catch {
    /* canvas may be tainted in exotic setups – panel still draws */
  }
  sctx.filter = `blur(${20 * q * sc}px)`;
  sctx.drawImage(scratch, 0, 0);
  sctx.filter = "none";

  ctx.save();
  ctx.globalAlpha = alpha;
  roundRect(ctx, x, y, w, h, rad);
  ctx.clip();
  ctx.drawImage(scratch, 0, 0, scratch.width, scratch.height, x, y, w, h);
  ctx.fillStyle = "rgba(255,255,255,0.10)";
  ctx.fill();
  // inner shadow: 20% black, offset (0,4), blur 12
  ctx.shadowColor = "rgba(0,0,0,0.20)";
  ctx.shadowBlur = 12;
  ctx.shadowOffsetY = 4;
  ctx.strokeStyle = "rgba(0,0,0,0.001)";
  ctx.lineWidth = 2;
  roundRect(ctx, x + 1, y + 1, w - 2, h - 2, rad);
  ctx.stroke();
  ctx.shadowColor = "transparent";
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;
  ctx.restore();

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = "rgba(255,255,255,0.25)";
  ctx.lineWidth = 1;
  roundRect(ctx, x + 0.5, y + 0.5, w - 1, h - 1, rad);
  ctx.stroke();
  ctx.restore();
}

export function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = clamp(r, 0, Math.min(w, h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}
