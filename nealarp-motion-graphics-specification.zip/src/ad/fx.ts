/**
 * fx.ts — post and light layers: depth haze, grain, vignette, bloom,
 * anamorphic flare, light streaks, glass backdrop helper (R-VIS-01/04/05/07/08).
 * Static layers are built once and reused (R-PERF-01).
 */
import { GRAIN_OPACITY, PALETTE, REF_H, REF_W } from "./constants";
import { grainOffset, getGrainTile } from "./rng";

let haze: HTMLCanvasElement | null = null;
let vignette: HTMLCanvasElement | null = null;

/** R-VIS-01 — radial #0a0a0a edges → #0f172a centre at 40% opacity. */
export function getHazeLayer(): HTMLCanvasElement {
  if (haze) return haze;
  const c = document.createElement("canvas");
  c.width = REF_W / 2;
  c.height = REF_H / 2;
  const x = c.getContext("2d")!;
  x.fillStyle = PALETTE.nearBlack;
  x.fillRect(0, 0, c.width, c.height);
  const g = x.createRadialGradient(c.width / 2, c.height / 2, 0, c.width / 2, c.height / 2, c.width * 0.62);
  g.addColorStop(0, "rgba(15,23,42,0.40)");
  g.addColorStop(1, "rgba(10,10,10,0.0)");
  x.fillStyle = g;
  x.fillRect(0, 0, c.width, c.height);
  haze = c;
  return c;
}

/** R-VIS-08 — radial vignette, 0% centre → 25% black corners. */
export function getVignette(): HTMLCanvasElement {
  if (vignette) return vignette;
  const c = document.createElement("canvas");
  c.width = REF_W / 2;
  c.height = REF_H / 2;
  const x = c.getContext("2d")!;
  const g = x.createRadialGradient(c.width / 2, c.height / 2, c.height * 0.22, c.width / 2, c.height / 2, c.width * 0.78);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,0.25)");
  x.fillStyle = g;
  x.fillRect(0, 0, c.width, c.height);
  vignette = c;
  return c;
}

export function drawBackdrop(ctx: CanvasRenderingContext2D) {
  ctx.drawImage(getHazeLayer(), 0, 0, REF_W, REF_H);
}

export function drawVignette(ctx: CanvasRenderingContext2D) {
  ctx.drawImage(getVignette(), 0, 0, REF_W, REF_H);
}

/** R-VIS-07 — tiled seeded grain with a per-frame offset, 3.5% opacity. */
export function drawGrain(ctx: CanvasRenderingContext2D, frame: number) {
  const tile = getGrainTile();
  const [ox, oy] = grainOffset(frame);
  ctx.save();
  ctx.globalAlpha = GRAIN_OPACITY;
  ctx.globalCompositeOperation = "overlay";
  const pat = ctx.createPattern(tile, "repeat")!;
  ctx.translate(-ox, -oy);
  ctx.fillStyle = pat;
  ctx.fillRect(0, 0, REF_W + 512, REF_H + 512);
  ctx.restore();
}

/** R-VIS-05 — bloom: blurred additive copy of the bright layer, 35%. */
/**
 * R-VIS-05 bloom: re-draw the bright element blurred (24 px) and additive at
 * 35%. `fn` must be idempotent and pure in `t`.
 */
export function withBloom(
  ctx: CanvasRenderingContext2D,
  fn: (c: CanvasRenderingContext2D) => void,
  strength = 0.35,
  blurPx = 24,
) {
  fn(ctx);
  if (strength <= 0) return;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.globalAlpha = strength;
  ctx.filter = `blur(${blurPx}px)`;
  fn(ctx);
  ctx.filter = "none";
  ctx.restore();
}

/** R-VIS-05 — one anamorphic flare per title reveal. */
export function drawFlare(ctx: CanvasRenderingContext2D, cx: number, cy: number, p: number) {
  if (p <= 0 || p >= 1) return;
  const env = Math.sin(Math.PI * p); // rise + fall
  const len = 1400;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  // horizontal streak 1400 x 6
  const g = ctx.createLinearGradient(cx - len / 2, 0, cx + len / 2, 0);
  g.addColorStop(0, "rgba(59,130,246,0)");
  g.addColorStop(0.35, `rgba(120,180,255,${0.55 * env})`);
  g.addColorStop(0.5, `rgba(255,255,255,${0.95 * env})`);
  g.addColorStop(0.65, `rgba(249,115,22,${0.55 * env})`);
  g.addColorStop(1, "rgba(249,115,22,0)");
  ctx.fillStyle = g;
  ctx.fillRect(cx - len / 2, cy - 3, len, 6);
  // 120 px glow
  const rg = ctx.createRadialGradient(cx, cy, 0, cx, cy, 120);
  rg.addColorStop(0, `rgba(255,255,255,${0.75 * env})`);
  rg.addColorStop(0.35, `rgba(140,190,255,${0.28 * env})`);
  rg.addColorStop(1, "rgba(59,130,246,0)");
  ctx.fillStyle = rg;
  ctx.beginPath();
  ctx.arc(cx, cy, 120, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** R-VIS-05 — horizontal light streaks in blue and orange. */
export function drawStreaks(ctx: CanvasRenderingContext2D, t: number, alpha: number) {
  if (alpha <= 0) return;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const rows = [
    { y: 210, c: PALETTE.blue, sp: 190, len: 620 },
    { y: 872, c: PALETTE.orange, sp: -240, len: 780 },
    { y: 540, c: PALETTE.blue, sp: 130, len: 420 },
  ];
  for (const r of rows) {
    const x = ((t * r.sp) % (REF_W + r.len * 2)) - r.len;
    const g = ctx.createLinearGradient(x, 0, x + r.len, 0);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(0.5, r.c);
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.globalAlpha = alpha * 0.22;
    ctx.fillStyle = g;
    ctx.fillRect(x, r.y - 1.5, r.len, 3);
  }
  ctx.restore();
}

/** R-VIS-05 — one off-screen flicker per act (subtle, no strobe: R-NEG-05). */
export function actFlicker(ctx: CanvasRenderingContext2D, t: number, actStart: number) {
  const d = t - actStart;
  if (d < 0 || d > 0.42) return;
  const env = Math.sin(Math.PI * (d / 0.42));
  const wob = 0.5 + 0.5 * Math.sin(d * 78);
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.globalAlpha = 0.05 * env * wob;
  const g = ctx.createLinearGradient(0, 0, REF_W, 0);
  g.addColorStop(0, PALETTE.blue);
  g.addColorStop(1, PALETTE.orange);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, REF_W, REF_H);
  ctx.restore();
}

/** camera shake (R-SCN-03 / R-SCN-06) — returns translate offsets */
export function shake(t: number, start: number, dur: number, amp: number) {
  const d = t - start;
  if (d < 0 || d > dur) return [0, 0] as const;
  const env = 1 - d / dur;
  const s = (n: number) => Math.sin(d * n * Math.PI * 2);
  return [s(23) * amp * env, s(31) * amp * env * 0.7] as const;
}
