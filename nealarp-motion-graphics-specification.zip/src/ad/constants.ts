/**
 * nealarp AD-60 — global constants.
 * Everything is expressed in the 1920x1080 reference space (R-VIS-12).
 * The renderer is a pure function of `frame`; t = frame / 60 (R-TIME-01).
 */

export const REF_W = 1920;
export const REF_H = 1080;
export const FPS = 60;
export const DURATION = 60.0;
export const TOTAL_FRAMES = Math.round(DURATION * FPS); // 3600 (R-VER-01)

/** R-STACK-06 / R-TXT-01 — characters that must be covered by the font. */
export const REQUIRED_GLYPHS = ["Ä", "ä", "Ö", "ö", "Ü", "ü", "ß", ".", ",", "%", "m"];

/** R-VIS-02 — the only four permitted colours. */
export const PALETTE = {
  blue: "#3b82f6",
  orange: "#f97316",
  white: "#ffffff",
  nearBlack: "#0a0a0a",
  haze: "#0f172a", // R-VIS-01 depth haze centre
} as const;

export const RGB = {
  blue: [59, 130, 246] as const,
  orange: [249, 115, 22] as const,
  white: [255, 255, 255] as const,
  nearBlack: [10, 10, 10] as const,
  haze: [15, 23, 42] as const,
};

/** R-VIS-06 / R-VIS-07 */
export const RNG_SEED = 7;
export const PARTICLE_CAP = 3000;
export const GRAIN_TILE = 512;
export const GRAIN_OPACITY = 0.035;

/** R-VIS-09 */
export const FOCAL = 900;
export const Z_NEAR = 0;
export const Z_FAR = 2000;

/** Text layout safe area (R-VIS-12). */
export const SAFE = { left: 96, right: 96, top: 54, bottom: 54 };
export const AUTOFIT_MAX_WIDTH = 1440; // 75% of 1920
export const AUTOFIT_MIN_SIZE = 64;
export const AUTOFIT_STEP = 4;

export const clamp = (v: number, lo: number, hi: number) => (v < lo ? lo : v > hi ? hi : v);
export const clamp01 = (v: number) => clamp(v, 0, 1);
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const DEG = Math.PI / 180;
