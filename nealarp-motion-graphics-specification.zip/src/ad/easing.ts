/**
 * R-VIS-10 — named easings, exact definitions.
 *   EASE_IO        = cubic-bezier(0.65, 0.00, 0.35, 1.00)
 *   EASE_OUT_EARLY = cubic-bezier(0.25, 0.80, 0.25, 1.00)
 *   EXPO_OUT       = 1 - 2^(-10 t)
 *   STEP           = hold start value, snap at the end
 */
import { clamp01 } from "./constants";

export type EaseName = "EASE_IO" | "EASE_OUT_EARLY" | "EXPO_OUT" | "STEP";

export function cubicBezier(x1: number, y1: number, x2: number, y2: number) {
  const A = (a: number, b: number) => 1 - 3 * b + 3 * a;
  const B = (a: number, b: number) => 3 * b - 6 * a;
  const C = (a: number) => 3 * a;
  const calc = (t: number, a: number, b: number) => ((A(a, b) * t + B(a, b)) * t + C(a)) * t;
  const slope = (t: number, a: number, b: number) =>
    3 * A(a, b) * t * t + 2 * B(a, b) * t + C(a);

  return (x: number): number => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const s = slope(t, x1, x2);
      if (Math.abs(s) < 1e-6) break;
      const err = calc(t, x1, x2) - x;
      if (Math.abs(err) < 1e-7) break;
      t -= err / s;
    }
    return calc(t, y1, y2);
  };
}

const EASE_IO_FN = cubicBezier(0.65, 0.0, 0.35, 1.0);
const EASE_OUT_EARLY_FN = cubicBezier(0.25, 0.8, 0.25, 1.0);

export const expoOut = (p: number) => (p >= 1 ? 1 : 1 - Math.pow(2, -10 * p));

/** named constants so timeline data can reference easings by identity */
export const EASE_IO: EaseName = "EASE_IO";
export const EASE_OUT_EARLY: EaseName = "EASE_OUT_EARLY";
export const EXPO_OUT: EaseName = "EXPO_OUT";
export const STEP: EaseName = "STEP";

export function ease(name: EaseName, p: number): number {
  const x = clamp01(p);
  switch (name) {
    case "EASE_IO":
      return EASE_IO_FN(x);
    case "EASE_OUT_EARLY":
      return EASE_OUT_EARLY_FN(x);
    case "EXPO_OUT":
      return expoOut(x);
    case "STEP":
      return x >= 1 ? 1 : 0;
  }
}

/** normalised progress of `t` inside [start, end] */
export const prog = (t: number, start: number, end: number) =>
  clamp01((t - start) / Math.max(1e-6, end - start));

/** progress through an easing, 0 before start, 1 after end */
export const eased = (name: EaseName, t: number, start: number, end: number) =>
  ease(name, prog(t, start, end));

/** true while start <= t < end */
export const active = (t: number, start: number, end: number) => t >= start && t < end;
