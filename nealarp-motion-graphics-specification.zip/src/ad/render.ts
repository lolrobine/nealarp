/**
 * render.ts — the compositor. renderFrame() is a pure function of `frame`
 * (R-OUT-02): same frame in → same pixels out, no accumulation, no state.
 */
import { FPS, REF_H, REF_W } from "./constants";
import { actFlicker, drawBackdrop, drawGrain, drawStreaks, drawVignette } from "./fx";
import type { TextSystem } from "./layout";
import {
  sceneAsteroid,
  sceneCircle,
  sceneCta,
  sceneDeepSea,
  sceneHero,
  sceneLifeStats,
  sceneOpening,
  scenePassword,
  sceneTempo,
  sceneUniverse,
  sceneWallet,
  type Stage,
} from "./scenes";
import { prog } from "./easing";

/** one off-screen flicker per act (R-VIS-05) */
const ACT_FLICKERS = [0.35, 8.05, 32.05, 44.05];
const ACTS = [0, 8, 32, 44];

export interface RenderTarget {
  ctx: CanvasRenderingContext2D;
  sys: TextSystem;
  scratch: HTMLCanvasElement;
}

export function renderFrame(target: RenderTarget, frame: number, scale: number): void {
  const { ctx, sys, scratch } = target;
  const t = frame / FPS; // R-TIME-01

  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";
  ctx.filter = "none";
  ctx.fillStyle = "#0a0a0a"; // R-VIS-01
  ctx.fillRect(0, 0, REF_W, REF_H);
  drawBackdrop(ctx);

  for (let i = 0; i < ACT_FLICKERS.length; i++) actFlicker(ctx, t, ACT_FLICKERS[i]);
  const streakAlpha = t < 8 ? prog(t, 0.5, 3) * 0.6 : t < 32 ? 0.5 : t < 44 ? 0.8 : 0.35;
  drawStreaks(ctx, t, streakAlpha);

  const s: Stage = { ctx, t, frame, sys, scratch };

  if (t < 8) sceneOpening(s);
  else if (t < 11) sceneWallet(s);
  else if (t < 14) scenePassword(s);
  else if (t < 17) sceneDeepSea(s);
  else if (t < 20) sceneTempo(s);
  else if (t < 23) sceneAsteroid(s);
  else if (t < 26) sceneCircle(s);
  else if (t < 29) sceneLifeStats(s);
  else if (t < 32) sceneUniverse(s);
  else if (t < 44) sceneHero(s);
  else sceneCta(s);

  // global post layers
  drawGrain(ctx, frame); // R-VIS-07
  drawVignette(ctx); // R-VIS-08

  // R-SCN-11: fade to black 59.0 → 60.0
  if (t >= 59) {
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    ctx.globalAlpha = prog(t, 59, 60);
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, REF_W, REF_H);
    ctx.globalAlpha = 1;
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
}

/** act index for a given time (used by the console UI) */
export function actAt(t: number) {
  let i = 0;
  for (let k = 0; k < ACTS.length; k++) if (t >= ACTS[k]) i = k;
  return i;
}
