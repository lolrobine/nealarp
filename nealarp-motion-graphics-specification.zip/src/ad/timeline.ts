/**
 * timeline.ts — machine mirror of nealarp-ad/timeline.yaml (R-TIME-04).
 * The YAML file is authoritative for the Python renderer; this module is the
 * same data typed for the browser preview so both stacks share one schedule.
 */
import { DURATION, FPS, TOTAL_FRAMES } from "./constants";

export type TextLayoutId =
  | "title_lower_third"
  | "title_opening"
  | "counter_center"
  | "claim_white"
  | "claim_gradient"
  | "url"
  | "cta_button_label"
  | "panel_label"
  | "score_orange_160";

export type SfxRecipe =
  | "sfx_pop"
  | "sfx_click"
  | "sfx_coin_clink"
  | "sfx_lock_clunk"
  | "sfx_bubble"
  | "sfx_whirr"
  | "sfx_boom"
  | "sfx_pen_draw"
  | "sfx_heartbeat"
  | "sfx_whoosh_zoom"
  | "sfx_bass_drop"
  | "sfx_bass_hit";

export interface TextEntry {
  id: string;
  string: string;
  layout: TextLayoutId;
  start: number;
  end: number;
  /** scene-local overrides that stay inside the layout system (logged) */
  cx?: number;
  cy?: number;
  size?: number;
}

export interface SfxEvent {
  id: string;
  recipe: SfxRecipe;
  start: number;
  end?: number;
  scene: string;
}

export interface VoEvent {
  id: string;
  string: string;
  start: number;
  /** estimated duration; never allowed to overlap the next line (R-VER-11) */
  dur: number;
}

export interface SceneDef {
  id: string;
  act: "opening" | "showcase" | "hero" | "cta";
  title: string;
  start: number;
  end: number;
  layout: string;
  note: string;
}

/** R-TIME-02 — fixed structure. */
export const SCENES: SceneDef[] = [
  { id: "opening", act: "opening", title: "SPIELE UND ZEUG", start: 0, end: 8, layout: "title_opening", note: "Partikel-Tunnel, Konvergenz in den Titel, Anamorphic-Flare bei 2.0 s" },
  { id: "game_01_wallet", act: "showcase", title: "GELD AUSGEBEN", start: 8, end: 11, layout: "title_lower_third", note: "24 Chrom-Münzen, Glas-Wallet, 4 Clinks" },
  { id: "game_02_password", act: "showcase", title: "DAS PASSWORT-SPIEL", start: 11, end: 14, layout: "title_lower_third", note: "Schloss, Regel-Glyphen, 5 orange Checkmarks" },
  { id: "game_03_deepsea", act: "showcase", title: "DIE TIEFSEE", start: 14, end: 17, layout: "counter_center", note: "Tauchgang, 12 Leuchtwesen, 60 Blasen, Tiefenzähler" },
  { id: "game_04_tempo", act: "showcase", title: "TEMPO", start: 17, end: 20, layout: "title_lower_third", note: "Tachometer, 40 Streaks, 4 Glyph-Morphs" },
  { id: "game_05_asteroid", act: "showcase", title: "ASTEROIDEN-WERFER", start: 20, end: 23, layout: "title_lower_third", note: "Erde, Meteor, Einschlag 21.6 s, 5 Schockwellen" },
  { id: "game_06_circle", act: "showcase", title: "PERFEKTER KREIS", start: 23, end: 26, layout: "title_lower_third", note: "Oranger Bogen 0→360°, Punktering, 98 %" },
  { id: "game_07_lifestats", act: "showcase", title: "LEBENSSTATISTIK", start: 26, end: 29, layout: "title_lower_third", note: "Herz 72 bpm, Pulsringe, 3 Glas-Zähler" },
  { id: "game_08_universe", act: "showcase", title: "GRÖSSE DES WELTALLS", start: 29, end: 32, layout: "title_lower_third", note: "6 Zoomstufen à 10x, Galaxie aus 2000 Partikeln" },
  { id: "hero", act: "hero", title: "nealarp", start: 32, end: 44, layout: "claim_white", note: "Pulsierende Sphäre, 8 Orbit-Sprites auf 2 Ringen, Push-in" },
  { id: "cta", act: "cta", title: "AB 12. OKTOBER", start: 44, end: 60, layout: "cta_button_label", note: "Explosion → Reform → URL → Pill → Fade" },
];

/** R-TXT-01 — exact strings, exact order, nothing added or removed. */
export const CANON_TEXT: string[] = [
  "SPIELE UND ZEUG",
  "GELD AUSGEBEN",
  "DAS PASSWORT-SPIEL",
  "DIE TIEFSEE",
  "0 m",
  "1.000 m",
  "5.000 m",
  "11.034 m",
  "TEMPO",
  "ASTEROIDEN-WERFER",
  "100 MEGATONNEN",
  "PERFEKTER KREIS",
  "98 %",
  "LEBENSSTATISTIK",
  "HERZSCHLÄGE",
  "ATEMZÜGE",
  "SCHRITTE",
  "GRÖSSE DES WELTALLS",
  "nealarp",
  "BALD VERFÜGBAR",
  "AB 12. OKTOBER",
  "nealarp.vercel.app",
  "ERHÄLTLICH AB 12. OKTOBER",
];

export const TEXTS: TextEntry[] = [
  { id: "title_opening_main", string: "SPIELE UND ZEUG", layout: "title_opening", start: 2.0, end: 8.0 },

  { id: "title_01", string: "GELD AUSGEBEN", layout: "title_lower_third", start: 8.3, end: 11.0 },
  { id: "title_02", string: "DAS PASSWORT-SPIEL", layout: "title_lower_third", start: 11.3, end: 14.0 },
  { id: "title_03", string: "DIE TIEFSEE", layout: "title_lower_third", start: 14.3, end: 17.0 },

  { id: "depth_0", string: "0 m", layout: "counter_center", start: 14.0, end: 14.3 },
  { id: "depth_1", string: "1.000 m", layout: "counter_center", start: 14.3, end: 15.0 },
  { id: "depth_2", string: "5.000 m", layout: "counter_center", start: 15.0, end: 15.6 },
  { id: "depth_3", string: "11.034 m", layout: "counter_center", start: 15.6, end: 17.0 },

  { id: "title_04", string: "TEMPO", layout: "title_lower_third", start: 17.3, end: 20.0 },
  { id: "title_05", string: "ASTEROIDEN-WERFER", layout: "title_lower_third", start: 20.3, end: 23.0 },
  { id: "megatons", string: "100 MEGATONNEN", layout: "claim_white", start: 21.8, end: 23.0, cy: 220 },
  { id: "title_06", string: "PERFEKTER KREIS", layout: "title_lower_third", start: 23.3, end: 26.0 },
  { id: "score_98", string: "98 %", layout: "score_orange_160", start: 24.5, end: 26.0 },
  { id: "title_07", string: "LEBENSSTATISTIK", layout: "title_lower_third", start: 26.3, end: 29.0 },

  { id: "label_heart", string: "HERZSCHLÄGE", layout: "panel_label", start: 26.2, end: 29.0, cx: 420, cy: 430 },
  { id: "label_breath", string: "ATEMZÜGE", layout: "panel_label", start: 26.2, end: 29.0, cx: 1500, cy: 430 },
  { id: "label_steps", string: "SCHRITTE", layout: "panel_label", start: 26.2, end: 29.0, cx: 960, cy: 690 },

  { id: "title_08", string: "GRÖSSE DES WELTALLS", layout: "title_lower_third", start: 29.3, end: 32.0 },

  { id: "hero_brand", string: "nealarp", layout: "claim_white", start: 36.5, end: 44.0, size: 144, cy: 500 },
  { id: "cta_bald", string: "BALD VERFÜGBAR", layout: "claim_white", start: 46.0, end: 48.5 },
  { id: "cta_ab", string: "AB 12. OKTOBER", layout: "claim_gradient", start: 48.5, end: 50.0 },
  { id: "cta_url", string: "nealarp.vercel.app", layout: "url", start: 50.0, end: 59.0 },
  { id: "cta_pill", string: "ERHÄLTLICH AB 12. OKTOBER", layout: "cta_button_label", start: 53.0, end: 59.0 },
];

/** R-AUD-03 — one clear sound per cut, never more than two stacked. */
export const SFX: SfxEvent[] = [
  { id: "sfx_000", recipe: "sfx_bass_drop", start: 0.0, scene: "opening" },
  { id: "sfx_001", recipe: "sfx_pop", start: 8.0, scene: "game_01_wallet" },
  { id: "sfx_002", recipe: "sfx_coin_clink", start: 8.2, scene: "game_01_wallet" },
  { id: "sfx_003", recipe: "sfx_coin_clink", start: 8.5, scene: "game_01_wallet" },
  { id: "sfx_004", recipe: "sfx_coin_clink", start: 8.9, scene: "game_01_wallet" },
  { id: "sfx_005", recipe: "sfx_coin_clink", start: 9.3, scene: "game_01_wallet" },
  { id: "sfx_006", recipe: "sfx_pop", start: 11.0, scene: "game_02_password" },
  { id: "sfx_007", recipe: "sfx_lock_clunk", start: 11.4, scene: "game_02_password" },
  { id: "sfx_008", recipe: "sfx_pop", start: 14.0, scene: "game_03_deepsea" },
  ...Array.from({ length: 8 }, (_, i) => ({
    id: `sfx_bubble_${i}`,
    recipe: "sfx_bubble" as SfxRecipe,
    start: 14.15 + i * 0.35,
    scene: "game_03_deepsea",
  })),
  { id: "sfx_009", recipe: "sfx_pop", start: 17.0, scene: "game_04_tempo" },
  { id: "sfx_010", recipe: "sfx_whirr", start: 17.0, end: 20.0, scene: "game_04_tempo" },
  { id: "sfx_011", recipe: "sfx_pop", start: 20.0, scene: "game_05_asteroid" },
  { id: "sfx_012", recipe: "sfx_boom", start: 21.6, scene: "game_05_asteroid" },
  { id: "sfx_013", recipe: "sfx_pop", start: 23.0, scene: "game_06_circle" },
  { id: "sfx_014", recipe: "sfx_pen_draw", start: 23.0, end: 24.2, scene: "game_06_circle" },
  { id: "sfx_015", recipe: "sfx_pop", start: 26.0, scene: "game_07_lifestats" },
  ...Array.from({ length: 4 }, (_, i) => ({
    id: `sfx_heart_${i}`,
    recipe: "sfx_heartbeat" as SfxRecipe,
    start: 26.0 + i * (60 / 72),
    scene: "game_07_lifestats",
  })),
  { id: "sfx_016", recipe: "sfx_pop", start: 29.0, scene: "game_08_universe" },
  { id: "sfx_017", recipe: "sfx_whoosh_zoom", start: 29.0, end: 30.2, scene: "game_08_universe" },
  { id: "sfx_018", recipe: "sfx_bass_hit", start: 44.0, scene: "cta" },
];

/** R-AUD-01 — German voiceover lines. */
export const VO: VoEvent[] = [
  { id: "vo_01", string: "Alles, was du jemals im Internet machen wolltest … an einem Ort.", start: 0.5, dur: 5.2 },
  { id: "vo_02", string: "Gib eine Billion Dollar aus.", start: 9.0, dur: 2.2 },
  { id: "vo_03", string: "Brich jede Passwortregel.", start: 11.5, dur: 2.2 },
  { id: "vo_04", string: "Tauche 11.000 Meter tief in die Tiefsee.", start: 14.5, dur: 3.4 },
  { id: "vo_05", string: "Schleudere Asteroiden. Zeichne perfekte Kreise.", start: 20.5, dur: 4.2 },
  { id: "vo_06", string: "Entdecke deine Lebensstatistik.", start: 26.0, dur: 2.8 },
  { id: "vo_07", string: "Acht Spiele. Keine Downloads. Eine Adresse.", start: 32.5, dur: 4.0 },
  { id: "vo_08", string: "Ab dem 12. Oktober erhältlich auf nealarp.vercel.app.", start: 44.8, dur: 5.4 },
];

/** R-TIME-04 — windows in which no element transform is expected to change. */
export const HOLD_FRAMES: Array<[number, number]> = [
  [4.0, 8.0],
  [8.6, 10.6],
  [12.8, 13.6],
  [15.6, 16.6],
  [25.7, 26.0],
];

export const frameToTime = (frame: number) => frame / FPS;
export const timeToFrame = (t: number) => Math.round(t * FPS);
export { DURATION, FPS, TOTAL_FRAMES };
