/**
 * R-VIS-06 — seeded random generator, fixed seed 7.
 * Deterministic: identical output on every run and in every language binding.
 */
import { GRAIN_TILE, RNG_SEED } from "./constants";

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function next(): number {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class Rng {
  private next: () => number;
  constructor(seed: number = RNG_SEED) {
    this.next = mulberry32(seed);
  }
  f = () => this.next();
  range = (lo: number, hi: number) => lo + (hi - lo) * this.next();
  int = (lo: number, hi: number) => Math.floor(this.range(lo, hi + 1));
  pick = <T,>(arr: readonly T[]): T => arr[Math.floor(this.next() * arr.length) % arr.length];
  sign = () => (this.next() < 0.5 ? -1 : 1);
}

/** R-VIS-07 — one pre-generated seeded 512x512 grayscale noise tile. */
let grainTile: HTMLCanvasElement | null = null;
export function getGrainTile(): HTMLCanvasElement {
  if (grainTile) return grainTile;
  const c = document.createElement("canvas");
  c.width = GRAIN_TILE;
  c.height = GRAIN_TILE;
  const ctx = c.getContext("2d")!;
  const img = ctx.createImageData(GRAIN_TILE, GRAIN_TILE);
  const rng = new Rng(RNG_SEED);
  for (let i = 0; i < GRAIN_TILE * GRAIN_TILE; i++) {
    const v = 110 + Math.floor(rng.f() * 90); // mid-grey, low contrast (R-NEG-05: no heavy noise)
    img.data[i * 4] = v;
    img.data[i * 4 + 1] = v;
    img.data[i * 4 + 2] = v;
    img.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  grainTile = c;
  return c;
}

/** deterministic per-frame grain offset (R-VIS-07) */
export function grainOffset(frame: number) {
  const a = (frame * 137) % GRAIN_TILE;
  const b = (frame * 311) % GRAIN_TILE;
  return [a, b] as const;
}
