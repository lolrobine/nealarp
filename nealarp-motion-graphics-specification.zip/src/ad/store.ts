/**
 * store.ts — a tiny observable clock. The playhead is read inside rAF by the
 * components that need it, so 60 fps playback never triggers React renders.
 */
import { useSyncExternalStore } from "react";
import { TOTAL_FRAMES } from "./constants";

export interface ClockState {
  frame: number;
  playing: boolean;
  muted: boolean;
  scale: number;
  speed: number;
}

export const clock: ClockState = {
  frame: 0,
  playing: false,
  muted: true,
  scale: 0.5,
  speed: 1,
};

const subs = new Set<() => void>();
export function subscribeClock(fn: () => void) {
  subs.add(fn);
  return () => subs.delete(fn);
}
function emit() {
  subs.forEach((f) => f());
}

export function patchClock(p: Partial<ClockState>) {
  Object.assign(clock, p);
  emit();
}

export function seekFrame(f: number) {
  clock.frame = Math.max(0, Math.min(TOTAL_FRAMES - 1, Math.round(f)));
}

export function useClock<T>(sel: (s: ClockState) => T): T {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => sel(clock),
    () => sel(clock),
  );
}
