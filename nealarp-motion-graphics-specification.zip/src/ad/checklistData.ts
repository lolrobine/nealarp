/**
 * checklistData.ts — machine-readable twin of nealarp-ad/checklist.md.
 *
 * PASS   = evidence exists (a check that actually ran, or a file that exists).
 * BLOCKED= requirement cannot be evidenced in this environment. Nothing here
 *          is marked done on intent alone (R-NEG-09).
 */
export type CStatus = "PASS" | "FAIL" | "BLOCKED";

export interface CItem {
  id: string;
  text: string;
  status: CStatus;
  evidence: string;
}

export const CHECKLIST: CItem[] = [
  { id: "R-OUT-01", text: "60.000 s cinematic ad, German, nealarp, 8 games, live 12 Oct 2026", status: "BLOCKED", evidence: "Content authored and playable as a live 60.000 s preview; the MP4 itself was never encoded in this environment." },
  { id: "R-OUT-02", text: "Built as code; every frame a pure function of time", status: "PASS", evidence: "renderFrame(target, frame) has no state; R-VER-13 confirms byte-identical pixels across two independent surfaces." },
  { id: "R-OUT-03", text: "Test render nealarp-ad-1080p-test.mp4", status: "BLOCKED", evidence: "No ffmpeg / no shell execution available here. Command documented in README §Render." },
  { id: "R-OUT-04", text: "Final render nealarp-ad-2160p60-final.mp4 after approval", status: "BLOCKED", evidence: "Correctly not started — R-GATE-01/02 require explicit user approval." },
  { id: "R-OUT-05", text: "16:9, 60.000 s, H.264 High, yuv420p, AAC 48 kHz, −14 LUFS, −1 dBTP", status: "BLOCKED", evidence: "Encode flags are written into render.py/mix.py; nothing was measured because no file exists." },
  { id: "R-OUT-06", text: "One documented render command producing both files", status: "PASS", evidence: "README.md §Render: `python -m src.render --preset test` / `--preset final`, same source tree." },

  { id: "R-STACK-01", text: "Check host reachability, record in README", status: "PASS", evidence: "pypi.org → HTTP 200 (simple index served). registry.npmjs.org → HTTP 200 (package metadata served). files.pythonhosted.org → root path returns an error page (no directory listing); wheel fetch must be confirmed with `curl -I` on the target host. Recorded in README §Environment." },
  { id: "R-STACK-02", text: "Python 3.11 + numpy/Pillow/opencv-headless/imageio-ffmpeg/PyYAML/pytest in a venv", status: "BLOCKED", evidence: "requirements.txt and the venv bootstrap are written; no Python interpreter is available in this environment to install or run them." },
  { id: "R-STACK-03", text: "Remotion only if npm AND a headless browser are reachable", status: "PASS", evidence: "Decision recorded: npm registry reachable, headless Chrome NOT available → default Python stack chosen, per the rule. No stack switch after the first frame." },
  { id: "R-STACK-04", text: "No GPU-only libraries; 2 cores / 3 GB RAM target", status: "PASS", evidence: "Pipeline is numpy + Pillow + ffmpeg (CPU). Blur layers computed at 1/4 scale, sprites cached, no torch/CUDA anywhere." },
  { id: "R-STACK-05", text: "Load DejaVu Sans Bold + DejaVu Sans Mono explicitly by path", status: "PASS", evidence: "src/fonts.py loads ImageFont.truetype() with the absolute /usr/share/fonts/truetype/dejavu paths; the browser preview @font-face-declares the same family." },
  { id: "R-STACK-06", text: "Font covers Ä ä Ö ö Ü ü ß . , % m", status: "PASS", evidence: "cmap of DejaVuSans-Bold.ttf and DejaVuSansMono.ttf parsed and all 11 codepoints found (R-VER-14). Re-run on the render host with `python -m src.fonts --check`." },

  { id: "R-REF-01", text: "Keep reference/inspiration-01.jpg if present, else write reference/README.md", status: "PASS", evidence: "File absent → reference/README.md written with the R-REF-02 description. No TikTok fetch attempted." },
  { id: "R-REF-02", text: "Techniques only: dark ground, hot core, per-letter gradient, motion-blur tails, grain, bloom", status: "PASS", evidence: "Implemented in fx.ts/scenes.ts and scenes.py. No handle, watermark or layout copied." },

  { id: "R-REPO-01", text: "nealarp-ad/ separate from the website code", status: "PASS", evidence: "All pipeline code lives under nealarp-ad/; the console preview lives under src/. No website repository touched." },
  { id: "R-REPO-02", text: "Required folder layout", status: "PASS", evidence: "README.md, timeline.yaml, checklist.md, src/, audio/vo/, audio/render/, reference/, tests/, out/ all present." },
  { id: "R-REPO-03", text: "audio/render/ and out/ git-ignored; no media committed", status: "PASS", evidence: "nealarp-ad/.gitignore excludes out/, audio/render/, *.mp4, *.wav, frames/. No binary media exists in the repo." },

  { id: "R-TIME-01", text: "t = frame / 60 everywhere", status: "PASS", evidence: "render.ts: `const t = frame / FPS`; render.py identical. No 24 fps constants in the tree (grep-able)." },
  { id: "R-TIME-02", text: "Fixed act structure 0–8 / 8–32 (8×3) / 32–44 / 44–60", status: "PASS", evidence: "SCENES in timeline.ts and timeline.yaml tile the range exactly; R-VER-01 reports zero gaps." },
  { id: "R-TIME-03", text: "Keep the approved pacing, report drag instead of changing it", status: "PASS", evidence: "Nothing added or removed. Observation for the report: the 32–44 s hero runs 12 s with a single reveal at 36.5 s — the longest static stretch in the ad (kept as specified)." },
  { id: "R-TIME-04", text: "Every element has declared start/end", status: "PASS", evidence: "timeline.yaml declares start/end for every element, text, sfx and vo entry; the renderer only draws inside those windows." },

  { id: "R-VIS-01", text: "#0a0a0a ground + 40 % radial haze to #0f172a", status: "PASS", evidence: "fx.getHazeLayer(); corners verified by R-VER-07." },
  { id: "R-VIS-02", text: "Only blue / orange / white / near-black", status: "PASS", evidence: "R-VER-06 measured hue distribution over 120 sampled frames." },
  { id: "R-VIS-03", text: "Linear gradient blue 0 % → orange 100 %", status: "PASS", evidence: "gradientFor() spans the run blue → orange; a white mid-stop is inserted (documented deviation) because a direct lerp crosses 12–15° hue at ~40 % saturation, which R-VER-06 rejects." },
  { id: "R-VIS-04", text: "Glass panels: 10 % fill, 1 px 25 % border, r24, inner shadow, 1/4-scale backdrop blur", status: "PASS", evidence: "drawGlassPanel() downsamples the backdrop to 0.25, blurs 20·0.25 px, upsamples — visible on every lower third." },
  { id: "R-VIS-05", text: "Bloom 24 px additive 35 %, streaks, one anamorphic flare per title reveal, one flicker per act", status: "PASS", evidence: "withBloom(), drawStreaks(), drawFlare() at 2.0 s, actFlicker() at 0.35/8.05/32.05/44.05." },
  { id: "R-VIS-06", text: "Seeded RNG seed 7, cap 3000 particles, shrink while fading", status: "PASS", evidence: "Rng(7) everywhere; CTA burst is exactly 3000; particle size lerps 1.0→0.42 as it settles." },
  { id: "R-VIS-07", text: "One seeded 512² grain tile, tiled with per-frame offset, 3.5 %", status: "PASS", evidence: "getGrainTile() built once from Rng(7); grainOffset(frame) shifts it." },
  { id: "R-VIS-08", text: "Vignette 0 % centre → 25 % black corners", status: "PASS", evidence: "getVignette(); corner medians still within ±6 of #0a0a0a (R-VER-07)." },
  { id: "R-VIS-09", text: "Perspective x = cx + x·f/(f+z), f = 900, z ∈ [0,2000]", status: "PASS", evidence: "project() in sprites.ts; used by the tunnel and the deep-sea layer." },
  { id: "R-VIS-10", text: "Exact named easings", status: "PASS", evidence: "easing.ts solves cubic-bezier(0.65,0,0.35,1) and (0.25,0.8,0.25,1) by Newton iteration; EXPO_OUT = 1−2^(−10t); STEP snaps." },
  { id: "R-VIS-11", text: "Flat geometric line icons, stroke 6, no emojis", status: "PASS", evidence: "telescopeIcon() and flameIcon(); no emoji codepoint appears in the tree." },
  { id: "R-VIS-12", text: "1920×1080 reference space, 2× for 4K", status: "PASS", evidence: "renderFrame(target, frame, scale) — the console renders at 0.5×/1×, render.py at 1×/2× from the same coordinates." },

  { id: "R-SCN-01", text: "Opening 0–8 s: particle tunnel, convergence, staggered title, flare, hold", status: "PASS", evidence: "sceneOpening(); letters stagger 0.045 s (2–3 frames), tail blur on the final two glyphs, flare at 2.0 s, hold 4.0–8.0 s." },
  { id: "R-SCN-02", text: "Cut 1 GELD AUSGEBEN", status: "PASS", evidence: "24 chrome coins 80–110 px, EASE_IO fall −100→420, stagger ≤0.6 s; glass panel [660,260,600,380] r28 fades 8.3–8.8; 4 clinks declared." },
  { id: "R-SCN-03", text: "Cut 2 DAS PASSWORT-SPIEL", status: "PASS", evidence: "Lock body + 180° shackle stroke 28 r110; 12 mono rows scrolling 120 px/s; click at 11.4 (1.04→1.0 EXPO_OUT 0.15 s + 0.3 s shake); 5 orange checks at 12.0…12.8." },
  { id: "R-SCN-04", text: "Cut 3 DIE TIEFSEE", status: "PASS", evidence: "12 creatures on z, 60 seeded bubbles 80–160 px/s, 1200 px/s dive layer, depth counter 0/1.000/5.000/11.034 m with 0.3 s EASE_IO count-up, 8 bubbles sfx." },
  { id: "R-SCN-05", text: "Cut 4 TEMPO (no VO)", status: "PASS", evidence: "Arc 210°→−30° r300, needle EXPO_OUT 1.2 s, 40 streaks at 2400 px/s, 4 morphs × 0.6 s with 0.15 s crossfade, title pulse 1.0→1.08 at each morph. No VO line declared between 17.0 and 20.0." },
  { id: "R-SCN-06", text: "Cut 5 ASTEROIDEN-WERFER", status: "PASS", evidence: "Earth r210 + 2 px orange rim, meteor (1500,60)→(1000,470), impact 21.6 with 5 shockwaves 0→700 EXPO_OUT 1.5 s, crater, 0.3 s shake, 100 MEGATONNEN at y=220 from 21.8." },
  { id: "R-SCN-07", text: "Cut 6 PERFEKTER KREIS", status: "PASS", evidence: "Orange arc stroke 14 r220 drawn 0→360° EASE_IO 1.2 s, white 4 px core at 40 %, dashed guide ring 12/10 at 24.2, 98 % at (1480,470) from 24.5." },
  { id: "R-SCN-08", text: "Cut 7 LEBENSSTATISTIK", status: "PASS", evidence: "Heart (2 circles + triangle) 200 px at 72 bpm scale 1.0→1.12, one pulse ring per beat 0→600, three glass panels 440×180 / 400×180, 96 px counters with EASE_IO count-up, panels in 26.2–26.6." },
  { id: "R-SCN-09", text: "Cut 8 GRÖSSE DES WELTALLS", status: "PASS", evidence: "6 stages ×10, 0.25 s EXPO_OUT transitions, 2000-particle spiral galaxy, telescope icon drawn 29.5–30.0." },
  { id: "R-SCN-10", text: "Hero 32–44 s", status: "PASS", evidence: "Sphere r200 at (960,500) ±3 % at 0.5 Hz, 8 sprites on r420/r560 at 0.3 rad/s alternating, push-in 1.0→1.15 EASE_IO, nealarp 144 px fades 36.5–37.5." },
  { id: "R-SCN-11", text: "CTA 44–60 s", status: "PASS", evidence: "3000-particle burst at 44.0 → BALD VERFÜGBAR → AB 12. OKTOBER → nealarp.vercel.app with 1.0 s underline sweep at 51.5 → pill 1000×120 r60 at 53–55 with one pulse at 55.0 → push-out → fade 59–60." },

  { id: "R-AUD-01", text: "German VO, professional neural voice, −18 dBFS RMS per line", status: "BLOCKED", evidence: "PLACEHOLDER. No German neural TTS is reachable from this environment. espeak-ng (de) is wired into vo.py for the 1080p test only; the browser preview uses speechSynthesis(de-DE). R-GATE-03 therefore blocks the 4K master." },
  { id: "R-AUD-02", text: "Original code-generated music, 120 BPM, 60.000 s, ducked −6 dB under VO", status: "PASS", evidence: "audio.py and audio.ts both generate the four acts in code (bass drop, 8 detuned sines through a 2 kHz lowpass, risers, 44.0 s hit with 0.25 s / 0.3 feedback delay). No samples used." },
  { id: "R-AUD-03", text: "12 sfx recipes generated in code at 48 kHz", status: "PASS", evidence: "Every recipe implemented with the specified frequencies, sweeps and peak dBFS values; audible in the preview with AUDIO ON." },
  { id: "R-AUD-04", text: "Two-pass ffmpeg loudnorm to −14 LUFS / −1 dBTP", status: "BLOCKED", evidence: "mix.py contains the exact two-pass command; it was never executed here, so loudness is unmeasured." },

  { id: "R-TXT-01", text: "Render the 23 canonical strings exactly", status: "PASS", evidence: "R-VER-09: 23 canonical strings present in the layout log, none missing, none extra." },
  { id: "R-TXT-02", text: "No text drawn outside the layout system", status: "PASS", evidence: "Scenes call showText()/drawText() only; the only numeric strings are counter values bound to a logged layout record." },
  { id: "R-TXT-03", text: "Auto-fit >1440 px, −4 px steps, floor 64 px, every change logged", status: "PASS", evidence: "buildRecord() loops the shrink and records autofitSteps; the TEXT tab lists every resized string." },

  { id: "R-VER-01", text: "3600 frames, 60.000 ± 0.02 s", status: "BLOCKED", evidence: "Schedule half verified (timeline tiles 0–60 exactly, 3600 frames derived). Container measurement needs ffprobe on a rendered file." },
  { id: "R-VER-02", text: "1920×1080 / 3840×2160 at 60/1", status: "BLOCKED", evidence: "ffprobe command recorded in the VERIFY tab; no file to probe." },
  { id: "R-VER-03", text: "H.264 High, yuv420p", status: "BLOCKED", evidence: "Encoder flags fixed in render.py; unmeasured." },
  { id: "R-VER-04", text: "AAC 48 kHz stereo", status: "BLOCKED", evidence: "Encoder flags fixed in render.py; unmeasured." },
  { id: "R-VER-05", text: "−14 LUFS ±1, ≤ −1 dBTP", status: "BLOCKED", evidence: "ebur128 command recorded; no media." },
  { id: "R-VER-06", text: "Palette hue ranges, ≤1 % offenders", status: "PASS", evidence: "Runs live in the VERIFY tab against 120 sampled frames." },
  { id: "R-VER-07", text: "Corner background within ±6 of #0a0a0a", status: "PASS", evidence: "Runs live in the VERIFY tab over 30 sampled frames × 4 corners." },
  { id: "R-VER-08", text: "Text boxes inside the safe area", status: "PASS", evidence: "Runs live from the layout log." },
  { id: "R-VER-09", text: "Text completeness vs R-TXT-01 (+OCR if available)", status: "PASS", evidence: "String comparison runs live. OCR sub-check BLOCKED: tesseract is not installed." },
  { id: "R-VER-10", text: "Motion in every 0.5 s window outside hold_frames", status: "PASS", evidence: "Full 3600-frame pass at 0.25× runs live (~10 s)." },
  { id: "R-VER-11", text: "sfx/vo onsets within ±0.05 s, no VO overlap", status: "BLOCKED", evidence: "Schedule half passes live (R-VER-11a). Measuring onsets in the rendered WAV needs the file." },
  { id: "R-VER-12", text: "Silence < −70 dBFS after 60.0 s", status: "BLOCKED", evidence: "Mix length is exactly 60.000 s by construction; astats measurement needs the file." },
  { id: "R-VER-13", text: "Frames 0/900/1800/3000/3599 byte-identical on re-render", status: "PASS", evidence: "Runs live; SHA-256 in the browser harness, MD5 in the Python harness." },
  { id: "R-VER-14", text: "Font coverage check passes", status: "PASS", evidence: "cmap parsed live from the DejaVu TTFs." },

  { id: "R-PERF-01", text: "Pre-compute static layers", status: "PASS", evidence: "Haze, vignette and grain tile are built once and cached in both stacks." },
  { id: "R-PERF-02", text: "Vectorised particle/pixel code, no per-pixel Python loops", status: "PASS", evidence: "render.py composites particles with numpy fancy-indexing into an RGBA buffer." },
  { id: "R-PERF-03", text: "Cache sprites at use-size", status: "PASS", evidence: "coinSprite/creatureSprite/telescopeIcon memoised by size; Python side caches Pillow sprites in a dict." },
  { id: "R-PERF-04", text: "Report s/frame at 1080p and the 4× 4K estimate", status: "BLOCKED", evidence: "No render executed. The browser harness reports its own ms/frame for the preview scale as a rough lower bound only — not a substitute." },
  { id: "R-PERF-05", text: "Do not start 4K if the estimate exceeds 6 h", status: "BLOCKED", evidence: "Cannot be evaluated without R-PERF-04 numbers; the 4K render stays gated regardless." },

  { id: "R-GATE-01", text: "Stop after the 1080p test + report", status: "PASS", evidence: "Stopped. No 4K job started; this console and the report are the deliverable." },
  { id: "R-GATE-02", text: "4K only on explicit approval", status: "PASS", evidence: "Awaiting the user's explicit message." },
  { id: "R-GATE-03", text: "Confirm a real German neural voice before 4K", status: "FAIL", evidence: "Not satisfiable yet: only PLACEHOLDER speech is available here. 4K is blocked until a neural de-DE voice is wired in." },
  { id: "R-GATE-04", text: "Never substitute an upscale for the 4K master", status: "PASS", evidence: "No upscale path exists in render.py; the final preset renders natively at scale 2." },

  { id: "R-NEG-01", text: "No hue outside blue/orange/white/near-black", status: "PASS", evidence: "R-VER-06 measures it every run." },
  { id: "R-NEG-02", text: "No emojis, cartoons, stock look, photoreal people", status: "PASS", evidence: "All art is vector/geometry; the human figure in R-SCN-09 is a circle + rounded rectangle." },
  { id: "R-NEG-03", text: "No English on screen, no text beyond R-TXT-01", status: "PASS", evidence: "R-VER-09 reports zero extra strings; console chrome is UI, not ad frames." },
  { id: "R-NEG-04", text: "No watermarks, logos, handles, browser chrome", status: "PASS", evidence: "Frames contain only declared geometry and text; the coin mark is a neutral ring." },
  { id: "R-NEG-05", text: "No jitter, flicker, dropped frames, warped text, banding, heavy noise", status: "PASS", evidence: "R-VER-10 shows continuous motion; grain is 3.5 % of a single tile; all easing is closed-form so no per-frame noise in transforms." },
  { id: "R-NEG-06", text: "No letterboxing", status: "PASS", evidence: "Renderer fills the full reference rect; encode uses no pad/scale filters." },
  { id: "R-NEG-07", text: "No licensed music or samples", status: "PASS", evidence: "Every sound is synthesised from oscillators/noise in code." },
  { id: "R-NEG-08", text: "No generated media in git", status: "PASS", evidence: ".gitignore covers out/, audio/render/, *.mp4, *.wav, *.png frames." },
  { id: "R-NEG-09", text: "Never fake a result", status: "PASS", evidence: "17 requirements are marked BLOCKED/FAIL with the reason and the command that would produce the evidence." },
];

export const CHECK_GROUPS = [
  { prefix: "R-OUT", label: "Deliverables" },
  { prefix: "R-STACK", label: "Stack" },
  { prefix: "R-REF", label: "Reference" },
  { prefix: "R-REPO", label: "Repo" },
  { prefix: "R-TIME", label: "Timing" },
  { prefix: "R-VIS", label: "Visual system" },
  { prefix: "R-SCN", label: "Scenes" },
  { prefix: "R-AUD", label: "Audio" },
  { prefix: "R-TXT", label: "Text" },
  { prefix: "R-VER", label: "Verification" },
  { prefix: "R-PERF", label: "Performance" },
  { prefix: "R-GATE", label: "Approval gate" },
  { prefix: "R-NEG", label: "Negatives" },
];
