/**
 * audio.ts — browser preview of the R-AUD audio model.
 *
 * The authoritative mix for the MP4 masters is synthesised in Python
 * (nealarp-ad/src/audio.py) as 48 kHz WAV buses. This module re-implements the
 * same recipes with the Web Audio API so the console can audition the timeline:
 *   R-AUD-02 music (120 BPM, code-generated, no samples)
 *   R-AUD-03 sfx recipes
 *   R-AUD-01 voiceover — PLACEHOLDER via speechSynthesis(de-DE) in the browser.
 * Music bus is ducked 6 dB while voiceover plays (R-AUD-02).
 */
import { SFX, VO, type SfxRecipe } from "./timeline";

const SR_FALLBACK = 48000;
const db = (v: number) => Math.pow(10, v / 20);
const BPM = 120;
const STEP = 60 / BPM / 4; // 16th = 0.125 s

export const VO_IS_PLACEHOLDER = true;

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class AdAudio {
  ac: AudioContext | null = null;
  master!: GainNode;
  music!: GainNode;
  sfx!: GainNode;
  vo!: GainNode;
  echo!: DelayNode;
  private noise!: AudioBuffer;
  private timer: number | null = null;
  private step = 0;
  private origin = 0; // ac.currentTime when t=0
  private sfxQueue: { start: number; end?: number; recipe: SfxRecipe; id: string }[] = [];
  private voTimer: number[] = [];
  playing = false;
  muted = false;

  async ensure(): Promise<AudioContext> {
    if (!this.ac) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ac = new AC({ sampleRate: SR_FALLBACK });
      this.master = this.ac.createGain();
      this.master.gain.value = db(-6);
      this.master.connect(this.ac.destination);

      this.music = this.ac.createGain();
      this.music.gain.value = db(-9);
      this.sfx = this.ac.createGain();
      this.sfx.gain.value = db(-6);
      this.vo = this.ac.createGain();
      this.vo.gain.value = db(-6);

      // R-AUD-02 echo: delay 0.25 s, feedback 0.3
      this.echo = this.ac.createDelay(1.0);
      this.echo.delayTime.value = 0.25;
      const fb = this.ac.createGain();
      fb.gain.value = 0.3;
      const wet = this.ac.createGain();
      wet.gain.value = 0.45;
      this.echo.connect(fb);
      fb.connect(this.echo);
      this.echo.connect(wet);
      wet.connect(this.master);

      this.music.connect(this.master);
      this.sfx.connect(this.master);
      this.vo.connect(this.master);

      const len = this.ac.sampleRate * 2;
      this.noise = this.ac.createBuffer(1, len, this.ac.sampleRate);
      const d = this.noise.getChannelData(0);
      const rnd = mulberry(7);
      for (let i = 0; i < len; i++) d[i] = rnd() * 2 - 1;

      this.applyDucking();
    }
    if (this.ac.state === "suspended") await this.ac.resume();
    return this.ac;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ac) this.master.gain.setTargetAtTime(m ? 0 : db(-6), this.ac.currentTime, 0.02);
    if (m && "speechSynthesis" in window) window.speechSynthesis.cancel();
  }

  /** R-AUD-02: music bus ducked by 6 dB while voiceover plays. */
  private applyDucking() {
    if (!this.ac) return;
    const base = db(-9);
    for (const v of VO) {
      const a = this.origin + v.start - 0.08;
      const b = this.origin + v.start + v.dur + 0.2;
      this.music.gain.cancelScheduledValues(a);
      this.music.gain.setValueAtTime(base, a);
      this.music.gain.linearRampToValueAtTime(base * db(-6), a + 0.12);
      this.music.gain.setValueAtTime(base * db(-6), b - 0.25);
      this.music.gain.linearRampToValueAtTime(base, b);
    }
  }

  async play(from = 0) {
    const ac = await this.ensure();
    this.stop();
    this.origin = ac.currentTime + 0.12 - from;
    this.step = Math.floor(from / STEP);
    this.sfxQueue = SFX.filter((e) => e.start >= from).map((e) => ({ ...e }));
    this.applyDucking();
    this.playing = true;
    for (const v of VO) {
      if (v.start < from) continue;
      const id = window.setTimeout(() => this.speak(v.string), Math.max(0, (v.start - from) * 1000));
      this.voTimer.push(id);
    }
    this.tick();
  }

  stop() {
    this.playing = false;
    if (this.timer) window.clearTimeout(this.timer);
    this.timer = null;
    for (const id of this.voTimer) window.clearTimeout(id);
    this.voTimer = [];
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  }

  seek(t: number) {
    if (this.playing) this.play(t);
  }

  private tick = () => {
    if (!this.playing || !this.ac) return;
    const horizon = this.ac.currentTime + 0.3;
    while (this.origin + this.step * STEP < horizon && this.step * STEP < 60.2) {
      const at = this.origin + this.step * STEP;
      if (at >= this.ac.currentTime - 0.02) this.musicStep(this.step, at);
      this.step++;
    }
    while (this.sfxQueue.length && this.origin + this.sfxQueue[0].start < horizon) {
      const e = this.sfxQueue.shift()!;
      this.sfxAt(e.recipe, this.origin + e.start, e.end !== undefined ? e.end - e.start : undefined);
    }
    this.timer = window.setTimeout(this.tick, 60);
  };

  /* ---------------- music (R-AUD-02) ---------------- */

  private musicStep(step: number, at: number) {
    const t = step * STEP;
    const ac = this.ac!;
    if (t >= 60) return;
    // A-minor pentatonic arp, 16ths
    const scale = [0, 3, 5, 7, 10, 12, 15, 12, 10, 7, 5, 3];
    const progIdx = Math.floor(t / 8) % 4;
    const roots = [110, 98, 87.31, 110];
    const root = roots[progIdx];
    const semis = scale[step % scale.length] + (progIdx === 2 ? 12 : 0);
    const f = root * Math.pow(2, semis / 12);

    const warmth = Math.min(1, Math.max(0, (t - 8) / 24)); // → orange harmonics by 32 s
    const cutoff = 2000 + warmth * 2600;
    const amp = t < 8 ? 0.1 + 0.05 * Math.sin(t) : t < 32 ? 0.15 : t < 44 ? 0.17 : 0.09 * (1 - (t - 44) / 16);
    if (amp <= 0.001) return;

    // 8 detuned sines, lowpass
    const lp = ac.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = cutoff;
    lp.Q.value = 0.9;
    const g = ac.createGain();
    g.gain.setValueAtTime(0, at);
    g.gain.linearRampToValueAtTime(amp, at + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0008, at + STEP * 1.7);
    lp.connect(g);
    g.connect(this.music);
    for (let i = 0; i < 8; i++) {
      const o = ac.createOscillator();
      o.type = "sine";
      o.frequency.value = f * (i < 4 ? 1 : 2) * (1 + (i - 3.5) * 0.0022);
      const og = ac.createGain();
      og.gain.value = i < 4 ? 0.32 : 0.08 + warmth * 0.2; // higher-harmonic emphasis
      o.connect(og);
      og.connect(lp);
      o.start(at);
      o.stop(at + STEP * 1.8);
    }

    // kick on every beat from 8 s
    if (t >= 8 && step % 4 === 0 && t < 58) {
      const o = ac.createOscillator();
      const kg = ac.createGain();
      o.type = "sine";
      o.frequency.setValueAtTime(t >= 44 ? 70 : 96, at);
      o.frequency.exponentialRampToValueAtTime(40, at + 0.16);
      kg.gain.setValueAtTime(t >= 44 ? 0.05 : 0.5, at);
      kg.gain.exponentialRampToValueAtTime(0.001, at + 0.26);
      o.connect(kg);
      kg.connect(this.music);
      o.start(at);
      o.stop(at + 0.3);
    }
    // risers into each act boundary
    const riserWindows: Array<[number, number, number]> = [
      [5.5, 8.0, 0.16],
      [30.0, 32.0, 0.2],
      [40.0, 44.0, 0.3],
    ];
    for (const [a, b, peak] of riserWindows) {
      if (t >= a && t < a + STEP * 1.01) this.riser(at, b - a, peak);
    }
    // 32–44 swell pad
    if (t >= 32 && t < 44 && step % 32 === 0) {
      for (const mult of [1, 1.5, 2, 2.996]) {
        const o = ac.createOscillator();
        o.type = "sawtooth";
        o.frequency.value = 110 * mult;
        const g2 = ac.createGain();
        const lp2 = ac.createBiquadFilter();
        lp2.type = "lowpass";
        lp2.frequency.value = 900;
        g2.gain.setValueAtTime(0.0001, at);
        g2.gain.linearRampToValueAtTime(0.05, at + 2.0);
        g2.gain.linearRampToValueAtTime(0.0001, at + 4.0);
        o.connect(lp2);
        lp2.connect(g2);
        g2.connect(this.music);
        o.start(at);
        o.stop(at + 4.1);
      }
    }
  }

  private riser(at: number, dur: number, peak: number) {
    const ac = this.ac!;
    const src = ac.createBufferSource();
    src.buffer = this.noise;
    src.loop = true;
    const bp = ac.createBiquadFilter();
    bp.type = "bandpass";
    bp.Q.value = 1.4;
    bp.frequency.setValueAtTime(400, at);
    bp.frequency.exponentialRampToValueAtTime(6200, at + dur);
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, at);
    g.gain.exponentialRampToValueAtTime(peak, at + dur * 0.92);
    g.gain.linearRampToValueAtTime(0.0001, at + dur);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.music);
    src.start(at);
    src.stop(at + dur + 0.05);
  }

  /* ---------------- sfx (R-AUD-03) ---------------- */

  private env(at: number, dur: number, peakDb: number, attack = 0.004) {
    const g = this.ac!.createGain();
    g.gain.setValueAtTime(0.0001, at);
    g.gain.linearRampToValueAtTime(db(peakDb), at + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    g.connect(this.sfx);
    return g;
  }

  private tone(at: number, f0: number, f1: number, dur: number, peakDb: number, type: OscillatorType = "sine") {
    const o = this.ac!.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, at);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), at + dur);
    o.connect(this.env(at, dur, peakDb));
    o.start(at);
    o.stop(at + dur + 0.05);
  }

  private noiseBurst(at: number, dur: number, peakDb: number, type: BiquadFilterType, f0: number, f1: number, q = 1) {
    const ac = this.ac!;
    const src = ac.createBufferSource();
    src.buffer = this.noise;
    const bp = ac.createBiquadFilter();
    bp.type = type;
    bp.Q.value = q;
    bp.frequency.setValueAtTime(f0, at);
    if (f1 !== f0) bp.frequency.exponentialRampToValueAtTime(f1, at + dur);
    src.connect(bp);
    bp.connect(this.env(at, dur, peakDb));
    src.start(at);
    src.stop(at + dur + 0.05);
  }

  sfxAt(recipe: SfxRecipe, at: number, dur?: number) {
    if (!this.ac || this.muted) return;
    const d = dur ?? 0;
    switch (recipe) {
      case "sfx_pop":
        this.tone(at, 1200, 600, 0.08, -6);
        this.noiseBurst(at, 0.005, -14, "highpass", 3000, 3000);
        break;
      case "sfx_click":
        this.noiseBurst(at, 0.029, -8, "bandpass", 3000, 3000, 2);
        break;
      case "sfx_coin_clink": {
        const j = 1 + (mulberry(Math.round(at * 1000))() * 0.06 - 0.03);
        this.tone(at, 3000 * j, 3000 * j, 0.3, -10);
        this.tone(at, 4500 * j, 4500 * j, 0.3, -13);
        break;
      }
      case "sfx_lock_clunk":
        this.tone(at, 90, 55, 0.18, -6);
        this.noiseBurst(at, 0.029, -8, "bandpass", 3000, 3000, 2);
        break;
      case "sfx_bubble": {
        const len = 0.06 + mulberry(Math.round(at * 977))() * 0.06;
        this.tone(at, 300, 900, len, -14);
        break;
      }
      case "sfx_whirr": {
        const L = d || 3;
        const ac = this.ac;
        for (let i = 0; i < 8; i++) {
          const o = ac.createOscillator();
          o.type = "sine";
          o.frequency.setValueAtTime(200 * (1 + i * 0.004), at);
          o.frequency.exponentialRampToValueAtTime(1200 * (1 + i * 0.004), at + L);
          const g = ac.createGain();
          g.gain.setValueAtTime(0.0001, at);
          g.gain.linearRampToValueAtTime(db(-12) / 8, at + 0.4);
          g.gain.setValueAtTime(db(-12) / 8, at + L - 0.3);
          g.gain.linearRampToValueAtTime(0.0001, at + L);
          o.connect(g);
          g.connect(this.sfx);
          o.start(at);
          o.stop(at + L + 0.05);
        }
        break;
      }
      case "sfx_boom":
        this.tone(at, 60, 60, 1.2, -4);
        this.noiseBurst(at, 1.5, -8, "lowpass", 600, 600, 0.7);
        break;
      case "sfx_pen_draw": {
        const L = d || 1.2;
        const ac = this.ac;
        const src = ac.createBufferSource();
        src.buffer = this.noise;
        src.loop = true;
        const bp = ac.createBiquadFilter();
        bp.type = "bandpass";
        bp.frequency.value = 3400;
        bp.Q.value = 1.6;
        const am = ac.createGain();
        const lfo = ac.createOscillator();
        lfo.frequency.value = 18;
        const lg = ac.createGain();
        lg.gain.value = db(-18) * 0.5;
        am.gain.value = db(-18) * 0.5;
        lfo.connect(lg);
        lg.connect(am.gain);
        src.connect(bp);
        bp.connect(am);
        am.connect(this.sfx);
        src.start(at);
        lfo.start(at);
        src.stop(at + L);
        lfo.stop(at + L);
        break;
      }
      case "sfx_heartbeat":
        this.tone(at, 55, 55, 0.12, -8);
        this.tone(at + 0.3, 55, 55, 0.12, -10);
        break;
      case "sfx_whoosh_zoom": {
        const L = d || 1.2;
        this.noiseBurst(at, L, -10, "bandpass", 300, 3000, 1.1);
        break;
      }
      case "sfx_bass_drop":
        this.tone(at, 120, 35, 1.5, -4);
        break;
      case "sfx_bass_hit": {
        this.tone(at, 45, 45, 0.8, -3);
        this.noiseBurst(at, 0.02, -8, "highpass", 2500, 2500);
        // echo as in R-AUD-02
        const send = this.ac.createGain();
        send.gain.value = 0.8;
        const o = this.ac.createOscillator();
        o.frequency.value = 45;
        const g = this.ac.createGain();
        g.gain.setValueAtTime(db(-9), at);
        g.gain.exponentialRampToValueAtTime(0.0001, at + 0.6);
        o.connect(g);
        g.connect(send);
        send.connect(this.echo);
        o.start(at);
        o.stop(at + 0.7);
        break;
      }
    }
  }

  /* ---------------- voiceover (R-AUD-01) ---------------- */

  private speak(text: string) {
    if (this.muted || !("speechSynthesis" in window)) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "de-DE";
    const voices = window.speechSynthesis.getVoices();
    const de = voices.find((v) => v.lang?.toLowerCase().startsWith("de"));
    if (de) u.voice = de;
    u.rate = 0.95;
    u.pitch = 0.8;
    u.volume = 1;
    window.speechSynthesis.speak(u);
  }
}

export const adAudio = new AdAudio();
