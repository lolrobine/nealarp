/**
 * scenes.ts — R-SCN-01 … R-SCN-11.
 * Every function is a pure function of `t` (seconds) with t = frame / 60.
 * No scene holds mutable state; all randomness comes from the seeded RNG.
 */
import {
  DEG,
  PALETTE,
  REF_H,
  REF_W,
  clamp01,
  lerp,
} from "./constants";
import { EASE_IO, EASE_OUT_EARLY, active, ease, eased, prog } from "./easing";
import {
  drawGlassPanel,
  drawText,
  roundRect,
  type LayoutRecord,
  type TextSystem,
} from "./layout";
import { drawFlare, shake, withBloom } from "./fx";
import {
  bubbleField,
  coinSprite,
  creatureField,
  creatureSprite,
  galaxyField,
  heartPath,
  project,
  sampleTextPoints,
  telescopeIcon,
  tunnelField,
} from "./sprites";
import { Rng } from "./rng";

export interface Stage {
  ctx: CanvasRenderingContext2D;
  t: number;
  frame: number;
  sys: TextSystem;
  scratch: HTMLCanvasElement;
}

const de = new Intl.NumberFormat("de-DE");

/* ================= shared helpers ================= */

function rec(s: Stage, id: string): LayoutRecord | undefined {
  return s.sys.records.get(id);
}

function showText(s: Stage, id: string, opts: Parameters<typeof drawText>[2] = {}) {
  const r = rec(s, id);
  if (!r || !active(s.t, r.start, r.end)) return;
  const a = opts.alpha ?? 1;
  if (r.glass) {
    drawGlassPanel(s.ctx, r, a * fadeIn(s.t, r.start, r.start + 0.4), s.scratch);
  }
  drawText(s.ctx, r, opts);
}

function fadeIn(t: number, a: number, b: number, name: typeof EASE_IO = EASE_OUT_EARLY) {
  return ease(name, prog(t, a, b));
}

const line = (
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  w: number,
  c: string,
) => {
  ctx.strokeStyle = c;
  ctx.lineWidth = w;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
};

/* ================= R-SCN-01 opening ================= */

const TUNNEL = tunnelField(1400);

export function sceneOpening(s: Stage) {
  const { ctx, t } = s;
  const camZ = t * 260; // camera moves forward
  const converge = eased("EASE_IO", t, 1.2, 2.4);
  const titleR = rec(s, "title_opening_main");

  // focal white point grows as the particles converge
  const focal = clamp01(prog(t, 0.6, 2.0)) * (1 - 0.55 * clamp01(prog(t, 2.0, 4.0)));
  if (focal > 0.01) {
    withBloom(
      ctx,
      (c) => {
        const g = c.createRadialGradient(960, 540, 0, 960, 540, 260);
        g.addColorStop(0, `rgba(255,255,255,${0.95 * focal})`);
        g.addColorStop(0.25, `rgba(180,215,255,${0.35 * focal})`);
        g.addColorStop(1, "rgba(59,130,246,0)");
        c.fillStyle = g;
        c.beginPath();
        c.arc(960, 540, 260, 0, Math.PI * 2);
        c.fill();
      },
      0.35,
      24,
    );
  }

  // tunnel particles, converging toward (960,540)
  for (const p of TUNNEL) {
    let z = p.z - camZ;
    z = ((z % 2000) + 2000) % 2000;
    const k = 900 / (900 + z);
    const bx = lerp(p.x, 0, converge);
    const by = lerp(p.y, 0, converge);
    const sx = 960 + bx * k;
    const sy = 540 + by * k;
    if (sx < -20 || sx > REF_W + 20 || sy < -20 || sy > REF_H + 20) continue;
    const sz = Math.max(0.6, p.size * k);
    const a = clamp01(0.16 + k * 1.05) * (1 - 0.5 * converge);
    ctx.fillStyle = p.blue ? PALETTE.blue : PALETTE.orange;
    ctx.globalAlpha = a;
    // stretched toward the focal point → speed feel
    const stretch = 1 + 2.6 * k;
    const dx = (sx - 960) * 0.012 * stretch;
    const dy = (sy - 540) * 0.012 * stretch;
    ctx.fillRect(sx - sz / 2 + dx, sy - sz / 2 + dy, sz + Math.abs(dx), sz + Math.abs(dy));
  }
  ctx.globalAlpha = 1;

  // title: letters stagger 0.045 s (2–3 frames), tail blur on the last two
  if (titleR && t >= 2.0) {
    const n = titleR.glyphs.length;
    const reveal = (t - 2.0) / 0.045;
    const settled = clamp01(prog(t, 3.0, 3.8));
    drawText(ctx, titleR, {
      reveal: Math.min(n, reveal),
      tail: 2,
      tailDist: 60 * (1 - settled),
      glow: 0.55 * (1 - settled * 0.55),
      alpha: clamp01(reveal / 2),
    });
  }
  drawFlare(ctx, 960, 540, prog(t, 2.0, 2.75)); // one anamorphic flare at 2.0 s
}

/* ================= R-SCN-02 cut 1: GELD AUSGEBEN ================= */

const COINS = (() => {
  const rng = new Rng(7);
  return Array.from({ length: 24 }, (_, i) => ({
    x: 706 + (i % 8) * 74 + rng.range(-10, 10),
    d: rng.range(80, 110),
    delay: rng.range(0, 0.6),
    yEnd: 420 + rng.range(-26, 26),
    spin: rng.range(-0.5, 0.5),
  }));
})();

export function sceneWallet(s: Stage) {
  const { ctx, t } = s;
  const panelA = fadeIn(t, 8.3, 8.8);

  // glass wallet panel [660,260,600,380] r28
  if (panelA > 0.01) {
    ctx.save();
    ctx.globalAlpha = panelA;
    roundRect(ctx, 660, 260, 600, 380, 28);
    ctx.fillStyle = "rgba(255,255,255,0.10)";
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.25)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
  }

  for (const c of COINS) {
    const p = ease("EASE_IO", prog(t, 8.0 + c.delay, 8.0 + c.delay + 0.85));
    if (p <= 0) continue;
    const y = lerp(-100, c.yEnd, p);
    const squash = 1 - 0.35 * Math.sin(Math.PI * clamp01(p)) * Math.abs(c.spin);
    const spr = coinSprite(110);
    const size = c.d;
    ctx.save();
    ctx.translate(c.x, y);
    ctx.scale(1, squash);
    ctx.globalAlpha = clamp01(p * 4);
    ctx.drawImage(spr, -size / 2, -size / 2, size, size);
    ctx.restore();
  }
  // front glass highlight
  if (panelA > 0.01) {
    ctx.save();
    ctx.globalAlpha = panelA * 0.5;
    roundRect(ctx, 660, 260, 600, 380, 28);
    ctx.clip();
    const g = ctx.createLinearGradient(660, 260, 1260, 640);
    g.addColorStop(0, "rgba(255,255,255,0.14)");
    g.addColorStop(0.45, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(660, 260, 600, 380);
    ctx.restore();
  }
  showText(s, "title_01", { glow: 0.3, scale: 1 + 0.04 * (1 - fadeIn(t, 8.3, 8.75)) });
}

/* ================= R-SCN-03 cut 2: DAS PASSWORT-SPIEL ================= */

const GLYPH_ROWS = (() => {
  const rng = new Rng(7);
  const chars = "01§%$&!?#*+abcdefghijklmnopqrstuvwxyzÄÖÜß.,".split("");
  return Array.from({ length: 12 }, (_, r) => ({
    r,
    text: Array.from({ length: 26 }, () => rng.pick(chars)).join(""),
  }));
})();

export function scenePassword(s: Stage) {
  const { ctx, t } = s;
  const click = 11.4;
  const clickP = ease("EXPO_OUT", prog(t, click, click + 0.15));
  const scale = t < click ? 1 : lerp(1.04, 1.0, clickP);
  const [sx, sy] = shake(t, click, 0.3, 9);
  const build = fadeIn(t, 11.2, 11.6);

  ctx.save();
  ctx.translate(960 + sx, 430 + sy);
  ctx.scale(scale, scale);
  ctx.translate(-960, -430);
  ctx.globalAlpha = build;

  // shackle: 180° arc, stroke 28, centre (960,300), r 110
  ctx.strokeStyle = "#e8eef7";
  ctx.lineWidth = 28;
  ctx.lineCap = "butt";
  ctx.beginPath();
  ctx.arc(960, 300, 110, Math.PI, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = "rgba(59,130,246,0.45)";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(960, 300, 124, Math.PI, Math.PI * 2);
  ctx.stroke();

  // lock body [800,300,320,260] r32, white metal gradient + blue inner glow
  roundRect(ctx, 800, 300, 320, 260, 32);
  const g = ctx.createLinearGradient(800, 300, 1120, 560);
  g.addColorStop(0, "#ffffff");
  g.addColorStop(0.45, "#d7e2f0");
  g.addColorStop(1, "#93a6bd");
  ctx.fillStyle = g;
  ctx.shadowColor = "rgba(59,130,246,0.85)";
  ctx.shadowBlur = 16;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.save();
  roundRect(ctx, 800, 300, 320, 260, 32);
  ctx.clip();
  // rule text: 12 rows of 10 px mono glyphs scrolling up at 120 px/s
  ctx.font = `10px "DejaVu Sans Mono", monospace`;
  ctx.fillStyle = "rgba(10,10,10,0.55)";
  const scroll = ((t - 11.0) * 120) % 260;
  for (const row of GLYPH_ROWS) {
    const y = 300 + 260 - ((row.r * 24 + scroll) % 300);
    ctx.globalAlpha = build * 0.4;
    ctx.fillText(row.text, 812, y);
  }
  ctx.globalAlpha = build;
  const ig = ctx.createRadialGradient(960, 430, 20, 960, 430, 210);
  ig.addColorStop(0, "rgba(59,130,246,0.35)");
  ig.addColorStop(1, "rgba(59,130,246,0)");
  ctx.fillStyle = ig;
  ctx.fillRect(800, 300, 320, 260);
  ctx.restore();

  ctx.restore();

  // five orange checkmark circles r36 at 12.0 … 12.8
  for (let i = 0; i < 5; i++) {
    const st = 12.0 + i * 0.2;
    const p = ease("EXPO_OUT", prog(t, st, st + 0.28));
    if (p <= 0) continue;
    const cx = 960 + (i - 2) * 104;
    const cy = 648;
    ctx.save();
    ctx.globalAlpha = p;
    ctx.translate(cx, cy);
    ctx.scale(lerp(0.4, 1, p), lerp(0.4, 1, p));
    ctx.shadowColor = PALETTE.orange;
    ctx.shadowBlur = 26;
    ctx.fillStyle = "rgba(249,115,22,0.22)";
    ctx.beginPath();
    ctx.arc(0, 0, 36, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = PALETTE.orange;
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(0, 0, 36, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = PALETTE.white;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const cp = clamp01((p - 0.35) / 0.65);
    ctx.beginPath();
    ctx.moveTo(-16, 2);
    ctx.lineTo(lerp(-16, -3, cp), lerp(2, 16, cp));
    if (cp > 0.5) ctx.lineTo(lerp(-3, 18, (cp - 0.5) * 2), lerp(16, -14, (cp - 0.5) * 2));
    ctx.stroke();
    ctx.restore();
  }
  showText(s, "title_02", { glow: 0.3, scale: 1 + 0.04 * (1 - fadeIn(t, 11.3, 11.75)) });
}

/* ================= R-SCN-04 cut 3: DIE TIEFSEE ================= */

const CREATURES = creatureField(12);
const BUBBLES = bubbleField(60);
const DEPTH_KEYS = [
  { t: 14.0, v: 0 },
  { t: 14.3, v: 1000 },
  { t: 15.0, v: 5000 },
  { t: 15.6, v: 11034 },
];

export function sceneDeepSea(s: Stage) {
  const { ctx, t } = s;
  const g = ctx.createLinearGradient(0, 160, 0, 800);
  g.addColorStop(0, "rgba(10,10,10,0)");
  g.addColorStop(1, "rgba(59,130,246,0.12)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 160, REF_W, 640);

  // dive: particle layer moves upward at 1200 px/s with EASE_OUT_EARLY
  const dive = ease("EASE_OUT_EARLY", prog(t, 14.0, 17.0)) * 1200 * 3;
  const rng = new Rng(7);
  ctx.fillStyle = "rgba(255,255,255,0.5)";
  for (let i = 0; i < 220; i++) {
    const bx = rng.range(0, REF_W);
    const by = rng.range(0, REF_H * 2);
    const sp = rng.range(0.5, 1.4);
    const y = ((by + dive * sp) % (REF_H * 1.4)) - 200;
    const h = 8 + sp * 34;
    ctx.globalAlpha = 0.05 + sp * 0.1;
    ctx.fillRect(bx, y, 1.6, h);
  }
  ctx.globalAlpha = 1;

  for (const c of CREATURES) {
    const z = ((c.z + dive * 0.22) % 1800 + 1800) % 1800;
    const p = project(c.x, c.y, z);
    const size = c.size * p.k;
    if (size < 4) continue;
    const spr = creatureSprite(Math.round(size / 8) * 8, c.blue ? PALETTE.blue : PALETTE.orange);
    ctx.globalAlpha = clamp01(0.25 + p.k * 0.9);
    ctx.drawImage(spr, p.sx - spr.width / 2, p.sy - spr.height / 2 + Math.sin(t * 0.8 + c.drift) * 12 * p.k);
  }
  ctx.globalAlpha = 1;

  for (const b of BUBBLES) {
    const y = REF_H + 60 - (((t - 14.0) * b.v + b.y) % (REF_H + 200));
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(b.x + Math.sin(t * 2 + b.r) * 12, y, b.r, 0, Math.PI * 2);
    ctx.stroke();
  }

  // counter: count up with EASE_IO over 0.3 s between declared values
  let idx = 0;
  for (let i = 0; i < DEPTH_KEYS.length; i++) if (t >= DEPTH_KEYS[i].t) idx = i;
  const prev = idx === 0 ? 0 : DEPTH_KEYS[idx - 1].v;
  const cur = DEPTH_KEYS[idx].v;
  const ramp = ease("EASE_IO", prog(t, DEPTH_KEYS[idx].t, DEPTH_KEYS[idx].t + 0.3));
  const value = Math.round(lerp(prev, cur, ramp));
  const label = `${de.format(value)} m`;
  const rr = rec(s, `depth_${idx}`);
  if (rr) {
    ctx.save();
    ctx.font = `700 ${rr.size}px "DejaVu Sans", sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.shadowColor = PALETTE.blue;
    ctx.shadowBlur = 30;
    ctx.fillStyle = PALETTE.white;
    ctx.fillText(label, rr.cx, rr.baselineY - rr.ascent * 0.36);
    ctx.restore();
    ctx.textAlign = "left";
  }
  showText(s, "title_03", { glow: 0.3 });
}

/* ================= R-SCN-05 cut 4: TEMPO ================= */

const STREAKS = (() => {
  const rng = new Rng(7);
  return Array.from({ length: 40 }, () => ({
    y: rng.range(160, 900),
    len: rng.range(200, 600),
    x0: rng.range(0, REF_W),
    a: rng.range(0.12, 0.3),
  }));
})();

const MORPHS = ["snail", "cheetah", "rocket", "beam"] as const;

function drawMorph(ctx: CanvasRenderingContext2D, kind: (typeof MORPHS)[number], a: number) {
  ctx.save();
  ctx.translate(960, 470);
  ctx.globalAlpha = a;
  ctx.strokeStyle = PALETTE.white;
  ctx.fillStyle = PALETTE.white;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  if (kind === "snail") {
    ctx.beginPath();
    for (let i = 0; i <= 160; i++) {
      const th = (i / 160) * Math.PI * 3.2;
      const r = 8 + th * 17;
      const x = Math.cos(th) * r;
      const y = Math.sin(th) * r;
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    }
    ctx.stroke();
  } else if (kind === "cheetah") {
    for (let i = 0; i < 3; i++) {
      ctx.globalAlpha = a * (0.3 + i * 0.3);
      ctx.beginPath();
      ctx.arc(-70 + i * 46, 24 - i * 6, 9, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = a;
    ctx.beginPath();
    ctx.moveTo(-40, -10);
    ctx.lineTo(84, -34);
    ctx.lineTo(84, 26);
    ctx.closePath();
    ctx.strokeStyle = PALETTE.orange;
    ctx.stroke();
  } else if (kind === "rocket") {
    ctx.fillStyle = PALETTE.white;
    ctx.fillRect(-22, -20, 44, 84);
    ctx.beginPath();
    ctx.moveTo(0, -96);
    ctx.lineTo(40, -18);
    ctx.lineTo(-40, -18);
    ctx.closePath();
    ctx.fillStyle = PALETTE.orange;
    ctx.fill();
  } else {
    const g = ctx.createLinearGradient(0, -110, 0, 110);
    g.addColorStop(0, "rgba(255,255,255,0)");
    g.addColorStop(0.5, PALETTE.white);
    g.addColorStop(1, "rgba(59,130,246,0)");
    ctx.fillStyle = g;
    ctx.fillRect(-6, -110, 12, 220);
  }
  ctx.restore();
}

export function sceneTempo(s: Stage) {
  const { ctx, t } = s;
  for (const st of STREAKS) {
    const x = ((st.x0 - (t - 17.0) * 2400) % (REF_W + 700) + REF_W + 700) % (REF_W + 700) - 700;
    ctx.globalAlpha = st.a;
    ctx.fillStyle = PALETTE.white;
    ctx.fillRect(x, st.y, st.len, 2);
  }
  ctx.globalAlpha = 1;

  // speedometer arc 210° → -30°, r 300, centre (960,470)
  const a0 = 210 * DEG;
  const a1 = 330 * DEG;
  ctx.lineWidth = 10;
  ctx.strokeStyle = "rgba(255,255,255,0.14)";
  ctx.beginPath();
  ctx.arc(960, 470, 300, a0, a1);
  ctx.stroke();
  const sweep = ease("EXPO_OUT", prog(t, 17.2, 18.4));
  const grad = ctx.createLinearGradient(660, 470, 1260, 470);
  grad.addColorStop(0, PALETTE.blue);
  grad.addColorStop(0.5, PALETTE.white);
  grad.addColorStop(1, PALETTE.orange);
  ctx.strokeStyle = grad;
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.arc(960, 470, 300, a0, a0 + (a1 - a0) * sweep);
  ctx.stroke();
  for (let i = 0; i <= 12; i++) {
    const a = a0 + ((a1 - a0) * i) / 12;
    const on = i / 12 <= sweep;
    line(
      ctx,
      960 + Math.cos(a) * 268,
      470 + Math.sin(a) * 268,
      960 + Math.cos(a) * 246,
      470 + Math.sin(a) * 246,
      4,
      on ? PALETTE.white : "rgba(255,255,255,0.25)",
    );
  }
  // needle
  const na = a0 + (a1 - a0) * sweep;
  ctx.save();
  ctx.translate(960, 470);
  ctx.rotate(na);
  ctx.fillStyle = PALETTE.orange;
  ctx.beginPath();
  ctx.moveTo(-16, -7);
  ctx.lineTo(236, 0);
  ctx.lineTo(-16, 7);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  ctx.fillStyle = PALETTE.white;
  ctx.beginPath();
  ctx.arc(960, 470, 16, 0, Math.PI * 2);
  ctx.fill();

  // morph sequence: 4 x 0.6 s from 17.6, crossfade 0.15 s
  for (let i = 0; i < MORPHS.length; i++) {
    const st = 17.6 + i * 0.6;
    const en = st + 0.6;
    if (t < st - 0.15 || t > en) continue;
    const inA = clamp01(prog(t, st - 0.15, st));
    const outA = 1 - clamp01(prog(t, en - 0.15, en));
    drawMorph(ctx, MORPHS[i], Math.min(inA, outA) * 0.95);
  }

  // TEMPO pulses at each morph (1.0 → 1.08 → 1.0 over 0.2 s)
  const pulses = MORPHS.map((_, i) => 17.6 + i * 0.6);
  let pulse = 1;
  for (const p of pulses) {
    const d = t - p;
    if (d >= 0 && d < 0.2) pulse = Math.max(pulse, 1 + 0.08 * Math.sin((d / 0.2) * Math.PI));
  }
  showText(s, "title_04", { glow: 0.3, scale: pulse });
}

/* ================= R-SCN-06 cut 5: ASTEROIDEN-WERFER ================= */

export function sceneAsteroid(s: Stage) {
  const { ctx, t } = s;
  const impact = 21.6;
  const [sx, sy] = shake(t, impact, 0.3, 14);
  ctx.save();
  ctx.translate(sx, sy);

  // earth
  withBloom(
    ctx,
    (c) => {
      const g = c.createRadialGradient(890, 490, 20, 960, 560, 210);
      g.addColorStop(0, "#8fc0ff");
      g.addColorStop(0.5, PALETTE.blue);
      g.addColorStop(1, "#0f2b57");
      c.fillStyle = g;
      c.beginPath();
      c.arc(960, 560, 210, 0, Math.PI * 2);
      c.fill();
      c.strokeStyle = PALETTE.orange;
      c.lineWidth = 2;
      c.beginPath();
      c.arc(960, 560, 211, 0, Math.PI * 2);
      c.stroke();
    },
    0.22,
    24,
  );

  // meteor travels (1500,60) → (1000,470) between 20.3 and impact
  const mp = ease("EASE_IO", prog(t, 20.3, impact));
  if (mp > 0 && mp < 1) {
    const mx = lerp(1500, 1000, mp);
    const my = lerp(60, 470, mp);
    const tx = lerp(1500, 1000, Math.max(0, mp - 0.22));
    const ty = lerp(60, 470, Math.max(0, mp - 0.22));
    const g = ctx.createLinearGradient(tx, ty, mx, my);
    g.addColorStop(0, "rgba(249,115,22,0)");
    g.addColorStop(1, "rgba(249,115,22,1)");
    ctx.strokeStyle = g;
    ctx.lineWidth = 9;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(tx, ty);
    ctx.lineTo(mx, my);
    ctx.stroke();
    ctx.fillStyle = PALETTE.white;
    ctx.beginPath();
    ctx.arc(mx, my, 11, 0, Math.PI * 2);
    ctx.fill();
  }

  if (t >= impact) {
    // crater
    ctx.fillStyle = "rgba(6,8,12,0.92)";
    ctx.beginPath();
    ctx.ellipse(1000, 470, 74, 44, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = PALETTE.blue;
    ctx.lineWidth = 3;
    ctx.stroke();
    // five shockwaves 0 → 700 with EXPO_OUT over 1.5 s
    for (let i = 0; i < 5; i++) {
      const st = impact + i * 0.12;
      const p = ease("EXPO_OUT", prog(t, st, st + 1.5));
      if (p <= 0) continue;
      ctx.globalAlpha = (1 - p) * 0.85;
      ctx.strokeStyle = PALETTE.orange;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(1000, 470, p * 700, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    const flash = 1 - clamp01(prog(t, impact, impact + 0.35));
    if (flash > 0) {
      const g = ctx.createRadialGradient(1000, 470, 0, 1000, 470, 420);
      g.addColorStop(0, `rgba(255,255,255,${0.85 * flash})`);
      g.addColorStop(0.3, `rgba(249,115,22,${0.5 * flash})`);
      g.addColorStop(1, "rgba(249,115,22,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(1000, 470, 420, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
  showText(s, "megatons", { glow: 0.35, alpha: fadeIn(t, 21.8, 22.1) });
  showText(s, "title_05", { glow: 0.3, scale: 1 + 0.04 * (1 - fadeIn(t, 20.3, 20.75)) });
}

/* ================= R-SCN-07 cut 6: PERFEKTER KREIS ================= */

export function sceneCircle(s: Stage) {
  const { ctx, t } = s;
  const p = ease("EASE_IO", prog(t, 23.0, 24.2));
  if (p > 0) {
    withBloom(
      ctx,
      (c) => {
        c.strokeStyle = PALETTE.orange;
        c.lineWidth = 14;
        c.lineCap = "round";
        c.beginPath();
        c.arc(960, 470, 220, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p);
        c.stroke();
        c.strokeStyle = "rgba(255,255,255,0.40)";
        c.lineWidth = 4;
        c.beginPath();
        c.arc(960, 470, 216, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p);
        c.stroke();
      },
      0.35,
      24,
    );
    // pen head
    const a = -Math.PI / 2 + Math.PI * 2 * p;
    ctx.fillStyle = PALETTE.white;
    ctx.beginPath();
    ctx.arc(960 + Math.cos(a) * 220, 470 + Math.sin(a) * 220, 9, 0, Math.PI * 2);
    ctx.fill();
  }
  if (t >= 24.2) {
    ctx.save();
    ctx.globalAlpha = fadeIn(t, 24.2, 24.5) * 0.5;
    ctx.strokeStyle = PALETTE.white;
    ctx.lineWidth = 2;
    ctx.setLineDash([12, 10]);
    ctx.beginPath();
    ctx.arc(960, 470, 220, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }
  showText(s, "score_98", { glow: 0.4, alpha: fadeIn(t, 24.5, 24.85), scale: 1 + 0.08 * (1 - fadeIn(t, 24.5, 24.95)) });
  showText(s, "title_06", { glow: 0.3 });
}

/* ================= R-SCN-08 cut 7: LEBENSSTATISTIK ================= */

const PANELS = [
  { id: "label_heart", x: 200, y: 380, w: 440, h: 180, target: 889411200 },
  { id: "label_breath", x: 1280, y: 380, w: 440, h: 180, target: 37843200 },
  { id: "label_steps", x: 760, y: 640, w: 400, h: 180, target: 214500000 },
];

export function sceneLifeStats(s: Stage) {
  const { ctx, t } = s;
  const bps = 72 / 60;
  const beat = (t - 26.0) * bps;
  const beatPhase = beat - Math.floor(beat);
  const pulse = 1 + 0.12 * Math.exp(-beatPhase * 7) * (beat >= 0 ? 1 : 0);

  // pulse rings, one per beat
  for (let i = 0; i < 5; i++) {
    const bIdx = Math.floor(beat) - i;
    if (bIdx < 0) continue;
    const age = beat - bIdx;
    if (age > 1.6) continue;
    const p = age / 1.6;
    ctx.globalAlpha = (1 - p) * 0.7;
    ctx.strokeStyle = PALETTE.blue;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(960, 470, p * 600, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;

  withBloom(
    ctx,
    (c) => {
      c.save();
      c.translate(960, 470);
      c.scale(pulse, pulse);
      c.translate(-960, -470);
      c.fillStyle = PALETTE.white;
      c.shadowColor = PALETTE.blue;
      c.shadowBlur = 34;
      heartPath(c, 960, 470, 200);
      c.fill();
      c.restore();
    },
    0.35,
    24,
  );

  const panelA = fadeIn(t, 26.2, 26.6);
  const countP = ease("EASE_IO", prog(t, 26.6, 29.0));
  for (const p of PANELS) {
    ctx.save();
    ctx.globalAlpha = panelA;
    roundRect(ctx, p.x, p.y, p.w, p.h, 24);
    ctx.fillStyle = "rgba(255,255,255,0.10)";
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.25)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
    if (panelA < 0.05) continue;
    const r = rec(s, p.id);
    if (r) {
      ctx.save();
      ctx.globalAlpha = panelA;
      ctx.font = `700 ${r.size}px "DejaVu Sans", sans-serif`;
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(255,255,255,0.72)";
      const track = r.tracking * r.size;
      const label = r.string.toUpperCase();
      let w = 0;
      for (const ch of label) w += ctx.measureText(ch).width + track;
      w -= track;
      let x = p.x + p.w / 2 - w / 2;
      for (const ch of label) {
        ctx.fillText(ch, x + ctx.measureText(ch).width / 2, p.y + 46);
        x += ctx.measureText(ch).width + track;
      }
      ctx.font = `700 96px "DejaVu Sans", sans-serif`;
      ctx.fillStyle = p.id === "label_steps" ? PALETTE.orange : PALETTE.white;
      ctx.shadowColor = p.id === "label_steps" ? PALETTE.orange : PALETTE.blue;
      ctx.shadowBlur = 22;
      ctx.fillText(de.format(Math.round(p.target * countP)), p.x + p.w / 2, p.y + 132);
      ctx.restore();
      ctx.textAlign = "left";
    }
  }
  showText(s, "title_07", { glow: 0.3 });
}

/* ================= R-SCN-09 cut 8: GRÖSSE DES WELTALLS ================= */

const GALAXY = galaxyField(2000);
const STAGE_LEN = 0.5;

function drawZoomStage(ctx: CanvasRenderingContext2D, i: number, a: number, sc: number) {
  ctx.save();
  ctx.globalAlpha = a;
  ctx.translate(960, 480);
  ctx.scale(sc, sc);
  ctx.translate(-960, -480);
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  if (i === 0) {
    ctx.fillStyle = PALETTE.white;
    ctx.beginPath();
    ctx.arc(960, 410, 34, 0, Math.PI * 2);
    ctx.fill();
    roundRect(ctx, 918, 452, 84, 150, 34);
    ctx.fill();
  } else if (i === 1) {
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    for (let k = 0; k < 6; k++) {
      const w = 200 - k * 22;
      ctx.fillRect(960 - w / 2, 600 - k * 40, w, 38);
    }
    ctx.strokeStyle = PALETTE.blue;
    ctx.strokeRect(960 - 100, 360, 200, 240);
  } else if (i === 2) {
    ctx.beginPath();
    ctx.moveTo(960, 300);
    ctx.lineTo(1200, 620);
    ctx.lineTo(720, 620);
    ctx.closePath();
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(960, 300);
    ctx.lineTo(1040, 407);
    ctx.lineTo(880, 407);
    ctx.closePath();
    ctx.fillStyle = PALETTE.blue;
    ctx.fill();
  } else if (i === 3) {
    const g = ctx.createRadialGradient(900, 420, 20, 960, 480, 200);
    g.addColorStop(0, "#9cc6ff");
    g.addColorStop(0.6, PALETTE.blue);
    g.addColorStop(1, "#12305e");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(960, 480, 200, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = PALETTE.orange;
    ctx.lineWidth = 2;
    ctx.stroke();
  } else if (i === 4) {
    const g = ctx.createRadialGradient(960, 480, 10, 960, 480, 240);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.35, PALETTE.orange);
    g.addColorStop(1, "rgba(249,115,22,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(960, 480, 240, 0, Math.PI * 2);
    ctx.fill();
  } else {
    for (const p of GALAXY) {
      const r = p.r * 330;
      const a2 = p.a + p.r * 0.9;
      const x = 960 + Math.cos(a2) * r;
      const y = 480 + Math.sin(a2) * r * 0.42;
      ctx.globalAlpha = a * (0.25 + (1 - p.r) * 0.75);
      ctx.fillStyle = p.blue ? PALETTE.blue : PALETTE.orange;
      ctx.fillRect(x, y, p.size, p.size);
    }
    ctx.globalAlpha = a;
    const g = ctx.createRadialGradient(960, 480, 0, 960, 480, 90);
    g.addColorStop(0, "rgba(255,255,255,0.9)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(960, 480, 90, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function sceneUniverse(s: Stage) {
  const { ctx, t } = s;
  const p = (t - 29.0) / STAGE_LEN; // 0..6
  const i = Math.min(5, Math.max(0, Math.floor(p)));
  const frac = p - i;
  const trans = 0.25 / STAGE_LEN; // 0.25 s transition with EXPO_OUT
  const k = ease("EXPO_OUT", clamp01(frac / trans));
  // outgoing stage shrinks 1 → 0.1, incoming grows 10 → 1
  if (frac < trans) {
    drawZoomStage(ctx, i, 1 - k, lerp(1, 0.1, k));
    if (i + 1 <= 5) drawZoomStage(ctx, i + 1, k, lerp(10, 1, k));
  } else {
    drawZoomStage(ctx, i, 1, 1);
  }
  // telescope icon drawn 29.5 → 30.0
  const ta = ease("EASE_OUT_EARLY", prog(t, 29.5, 30.0));
  if (ta > 0) {
    const icon = telescopeIcon(120);
    ctx.save();
    ctx.globalAlpha = ta;
    ctx.translate(960, 180);
    const sc = lerp(0.7, 1, ta);
    ctx.scale(sc, sc);
    ctx.drawImage(icon, -icon.width / 2, -icon.height / 2);
    ctx.restore();
  }
  showText(s, "title_08", { glow: 0.3 });
}

/* ================= R-SCN-10 hero ================= */

const ORBIT_ICONS = ["coin", "lock", "creature", "speedo", "heart", "ring", "planet", "meteor"] as const;

function drawOrbitSprite(ctx: CanvasRenderingContext2D, kind: string, x: number, y: number, size: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.strokeStyle = PALETTE.white;
  ctx.fillStyle = PALETTE.white;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  const h = size / 2;
  if (kind === "coin") {
    ctx.drawImage(coinSprite(110), -h, -h, size, size);
  } else if (kind === "lock") {
    ctx.strokeStyle = PALETTE.orange;
    ctx.beginPath();
    ctx.arc(0, -h * 0.25, h * 0.42, Math.PI, Math.PI * 2);
    ctx.stroke();
    roundRect(ctx, -h * 0.62, -h * 0.25, h * 1.24, h * 0.95, 8);
    ctx.fillStyle = PALETTE.white;
    ctx.fill();
  } else if (kind === "creature") {
    const spr = creatureSprite(96, PALETTE.blue);
    ctx.drawImage(spr, -spr.width / 2, -spr.height / 2, size * 1.2, size * 0.9);
  } else if (kind === "speedo") {
    ctx.strokeStyle = PALETTE.white;
    ctx.beginPath();
    ctx.arc(0, 0, h * 0.8, 210 * DEG, 330 * DEG);
    ctx.stroke();
    ctx.strokeStyle = PALETTE.orange;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(285 * DEG) * h * 0.7, Math.sin(285 * DEG) * h * 0.7);
    ctx.stroke();
  } else if (kind === "heart") {
    ctx.fillStyle = PALETTE.orange;
    heartPath(ctx, 0, 0, size * 0.9);
    ctx.fill();
  } else if (kind === "ring") {
    ctx.strokeStyle = PALETTE.orange;
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(0, 0, h * 0.78, 0, Math.PI * 2);
    ctx.stroke();
  } else if (kind === "planet") {
    const g = ctx.createRadialGradient(-h * 0.3, -h * 0.3, 2, 0, 0, h);
    g.addColorStop(0, "#cfe4ff");
    g.addColorStop(1, PALETTE.blue);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, h * 0.72, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.strokeStyle = PALETTE.orange;
    ctx.beginPath();
    ctx.moveTo(h * 0.8, -h * 0.8);
    ctx.lineTo(-h * 0.5, h * 0.5);
    ctx.stroke();
    ctx.fillStyle = PALETTE.white;
    ctx.beginPath();
    ctx.arc(-h * 0.5, h * 0.5, 7, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function sceneHero(s: Stage) {
  const { ctx, t } = s;
  const push = 1 + 0.15 * ease("EASE_IO", prog(t, 32.0, 44.0));
  const starPulse = 1 + 0.03 * Math.sin(2 * Math.PI * 0.5 * (t - 32));
  ctx.save();
  ctx.translate(960, 500);
  ctx.scale(push, push);
  ctx.translate(-960, -500);

  const R = 200 * starPulse;
  withBloom(
    ctx,
    (c) => {
      const g = c.createRadialGradient(960 - R * 0.25, 500 - R * 0.3, R * 0.05, 960, 500, R);
      g.addColorStop(0, "#ffffff");
      g.addColorStop(0.22, "#bcd8ff");
      g.addColorStop(0.5, PALETTE.blue);
      g.addColorStop(0.68, "#ffffff"); // hot band keeps the ramp inside the legal hues
      g.addColorStop(0.88, PALETTE.orange);
      g.addColorStop(1, "rgba(249,115,22,0.05)");
      c.fillStyle = g;
      c.beginPath();
      c.arc(960, 500, R, 0, Math.PI * 2);
      c.fill();
    },
    0.35,
    24,
  );

  // orbit rings
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.lineWidth = 1;
  for (const rr of [420, 560]) {
    ctx.beginPath();
    ctx.ellipse(960, 500, rr, rr * 0.34, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  for (let i = 0; i < 8; i++) {
    const ring = i < 4 ? 420 : 560;
    const dir = i % 2 === 0 ? 1 : -1;
    const a = (i * Math.PI) / 4 + dir * 0.3 * (t - 32.0);
    const x = 960 + Math.cos(a) * ring;
    const y = 500 + Math.sin(a) * ring * 0.34;
    const depth = (Math.sin(a) + 1) / 2;
    ctx.globalAlpha = 0.45 + depth * 0.55;
    drawOrbitSprite(ctx, ORBIT_ICONS[i], x, y, 54 + depth * 22);
  }
  ctx.globalAlpha = 1;
  ctx.restore();

  const r = rec(s, "hero_brand");
  if (r) {
    const a = fadeIn(t, 36.5, 37.5);
    if (a > 0) drawText(ctx, r, { alpha: a, glow: 0.45 * a });
  }
}

/* ================= R-SCN-11 call to action ================= */

const CTA_N = 3000;
const CTA_SEED = (() => {
  const rng = new Rng(7);
  const pos = new Float32Array(CTA_N * 2);
  const vel = new Float32Array(CTA_N * 2);
  const col = new Uint8Array(CTA_N);
  const size = new Float32Array(CTA_N);
  for (let i = 0; i < CTA_N; i++) {
    const a = rng.f() * Math.PI * 2;
    const z = rng.f() * Math.PI - Math.PI / 2;
    const rr = 200 * Math.pow(rng.f(), 0.4);
    pos[i * 2] = 960 + Math.cos(a) * Math.cos(z) * rr;
    pos[i * 2 + 1] = 500 + Math.sin(z) * rr;
    const sp = rng.range(240, 1150);
    vel[i * 2] = Math.cos(a) * Math.cos(z) * sp;
    vel[i * 2 + 1] = Math.sin(z) * sp * 0.75;
    col[i] = rng.f() > 0.5 ? 1 : 0;
    size[i] = rng.range(1.8, 5.2);
  }
  return { pos, vel, col, size };
})();

let targets: Record<string, Float32Array> | null = null;
function ctaTargets(sys: TextSystem) {
  if (targets) return targets;
  const get = (id: string) => {
    const r = sys.records.get(id)!;
    return sampleTextPoints(r, CTA_N);
  };
  targets = { a: get("cta_bald"), b: get("cta_ab"), c: get("cta_url") };
  return targets;
}

export function sceneCta(s: Stage) {
  const { ctx, t } = s;
  const T = ctaTargets(s.sys);
  const drag = 1.5;
  const ballistic = (i: number, tau: number) => {
    const k = (1 - Math.exp(-drag * tau)) / drag;
    return [
      CTA_SEED.pos[i * 2] + CTA_SEED.vel[i * 2] * k,
      CTA_SEED.pos[i * 2 + 1] + CTA_SEED.vel[i * 2 + 1] * k,
    ] as const;
  };
  const SWITCH = 1.6; // tau at which the debris starts reforming (t = 45.6)
  const pushOut = t > 55 ? 1 + 0.05 * ease("EASE_IO", prog(t, 55, 59)) : 1;
  const drift = t > 55 ? (t - 55) * 6 : 0;

  const pA = ease("EASE_IO", prog(t, 45.6, 46.9));
  const pB = ease("EASE_IO", prog(t, 48.2, 49.2));
  const pC = ease("EASE_IO", prog(t, 49.7, 51.0));

  const fadeInOut = (a: number, b: number, c: number, d: number) =>
    clamp01(prog(t, a, b)) * (1 - clamp01(prog(t, c, d)));

  const alphaText = {
    a: fadeInOut(46.4, 47.0, 48.1, 48.5),
    b: fadeInOut(48.8, 49.3, 49.7, 50.0),
    c: fadeInOut(50.7, 51.3, 58.6, 59.2),
  };

  // particles
  ctx.save();
  ctx.translate(960, 540);
  ctx.scale(pushOut, pushOut);
  ctx.translate(-960, -540);
  for (let i = 0; i < CTA_N; i++) {
    const tau = t - 44;
    if (tau < 0) continue;
    let x: number;
    let y: number;
    let settled: number;
    if (tau < SWITCH) {
      [x, y] = ballistic(i, tau);
      settled = 0;
    } else if (t < 48.2) {
      const [bx, by] = ballistic(i, SWITCH);
      x = lerp(bx, T.a[i * 2], pA);
      y = lerp(by, T.a[i * 2 + 1], pA);
      settled = pA;
    } else if (t < 49.7) {
      x = lerp(T.a[i * 2], T.b[i * 2], pB);
      y = lerp(T.a[i * 2 + 1], T.b[i * 2 + 1], pB);
      settled = pB;
    } else {
      x = lerp(T.b[i * 2], T.c[i * 2], pC);
      y = lerp(T.b[i * 2 + 1], T.c[i * 2 + 1], pC);
      settled = pC;
    }
    x += Math.sin(t * 1.7 + i) * drift * 0.25;
    y += Math.cos(t * 1.3 + i * 0.7) * drift * 0.25;
    const sz = CTA_SEED.size[i] * lerp(1, 0.42, settled);
    const alpha = clamp01(0.35 + settled * 0.6) * (1 - clamp01(prog(t, 58.8, 60)));
    ctx.globalAlpha = alpha;
    ctx.fillStyle = CTA_SEED.col[i] ? PALETTE.orange : PALETTE.blue;
    ctx.fillRect(x - sz / 2, y - sz / 2, sz, sz);
  }
  ctx.globalAlpha = 1;
  ctx.restore();

  // reformed text drawn through the layout system
  const ra = rec(s, "cta_bald");
  if (ra && alphaText.a > 0.01) drawText(ctx, ra, { alpha: alphaText.a, glow: 0.4 });
  const rb = rec(s, "cta_ab");
  if (rb && alphaText.b > 0.01) drawText(ctx, rb, { alpha: alphaText.b, glow: 0.45 });
  const rc = rec(s, "cta_url");
  if (rc && alphaText.c > 0.01) {
    drawText(ctx, rc, { alpha: alphaText.c, glow: 0.3 });
    // gradient underline sweeps left → right over 1.0 s from 51.5
    const up = ease("EASE_IO", prog(t, 51.5, 52.5));
    if (up > 0) {
      const y = rc.box.y + rc.box.h - 6;
      const g = ctx.createLinearGradient(rc.box.x, 0, rc.box.x + rc.width, 0);
      g.addColorStop(0, PALETTE.blue);
      g.addColorStop(0.5, PALETTE.white);
      g.addColorStop(1, PALETTE.orange);
      ctx.fillStyle = g;
      ctx.globalAlpha = alphaText.c;
      ctx.fillRect(rc.box.x, y, rc.width * up, 5);
      ctx.globalAlpha = 1;
    }
  }

  // orange pill button 1000 x 120, radius 60, centred y = 780
  const rp = rec(s, "cta_pill");
  if (rp && t >= 53.0) {
    const a = fadeIn(t, 53.0, 55.0);
    const d = t - 55.0;
    const pulse = d >= 0 && d < 0.4 ? 1 + 0.06 * Math.sin((d / 0.4) * Math.PI) : 1;
    ctx.save();
    ctx.globalAlpha = a * (1 - clamp01(prog(t, 59.0, 59.8)));
    ctx.translate(960, 780);
    ctx.scale(pulse, pulse);
    ctx.translate(-960, -780);
    ctx.shadowColor = "rgba(249,115,22,0.55)";
    ctx.shadowBlur = 42;
    roundRect(ctx, 460, 720, 1000, 120, 60);
    const g = ctx.createLinearGradient(460, 720, 1460, 840);
    g.addColorStop(0, PALETTE.orange);
    g.addColorStop(1, "#fb923c");
    ctx.fillStyle = g;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.restore();
    drawText(ctx, rp, { alpha: a * (1 - clamp01(prog(t, 59.0, 59.8))) });
  }
}
