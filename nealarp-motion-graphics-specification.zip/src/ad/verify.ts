/**
 * verify.ts — R-VER automated verification, browser harness.
 *
 * Checks that can be computed from the renderer itself are executed for real
 * here (palette, corners, safe area, text completeness, motion,
 * reproducibility, font cmap coverage). Checks that require a finished MP4 /
 * WAV container are reported BLOCKED together with the exact ffmpeg command
 * that produces the evidence on the render machine (R-NEG-09: never fake).
 */
import {
  AUTOFIT_MAX_WIDTH,
  DURATION,
  FPS,
  PALETTE,
  REF_H,
  REF_W,
  REQUIRED_GLYPHS,
  SAFE,
  TOTAL_FRAMES,
} from "./constants";
import { buildTextSystem, type LayoutRecord, type TextSystem } from "./layout";
import { renderFrame } from "./render";
import { HOLD_FRAMES, SCENES, SFX, VO, CANON_TEXT } from "./timeline";

export type Status = "PASS" | "FAIL" | "BLOCKED";

export interface CheckResult {
  id: string;
  title: string;
  status: Status;
  evidence: string;
  ms: number;
}

export type Progress = (p: number, msg: string) => void;

export interface Surface {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  sys: TextSystem;
  scratch: HTMLCanvasElement;
  scale: number;
}

export function makeSurface(scale: number, sys?: TextSystem): Surface {
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(REF_W * scale);
  canvas.height = Math.round(REF_H * scale);
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
  return { canvas, ctx, sys: sys ?? buildTextSystem(), scratch: document.createElement("canvas"), scale };
}

export const inHold = (t: number) => HOLD_FRAMES.some(([a, b]) => t >= a && t < b);

function rgb2hsv(r: number, g: number, b: number): [number, number, number] {
  const rn = r / 255, gn = g / 255, bn = b / 255;
  const mx = Math.max(rn, gn, bn), mn = Math.min(rn, gn, bn);
  const d = mx - mn;
  let h = 0;
  if (d !== 0) {
    if (mx === rn) h = ((gn - bn) / d) % 6;
    else if (mx === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return [h, mx === 0 ? 0 : d / mx, mx];
}

/* ------------------------------------------------------------------ */
/* R-STACK-06 / R-VER-14: font cmap coverage                           */
/* ------------------------------------------------------------------ */

const FONT_URLS: Record<string, string> = {
  "DejaVuSans-Bold.ttf": "https://cdn.jsdelivr.net/npm/dejavu-fonts-ttf@2.37.3/ttf/DejaVuSans-Bold.ttf",
  "DejaVuSansMono.ttf": "https://cdn.jsdelivr.net/npm/dejavu-fonts-ttf@2.37.3/ttf/DejaVuSansMono.ttf",
};

async function cmapCoverage(url: string): Promise<(cp: number) => boolean> {
  const buf = await (await fetch(url)).arrayBuffer();
  const dv = new DataView(buf);
  const numTables = dv.getUint16(4);
  let cmapOff = -1;
  for (let i = 0; i < numTables; i++) {
    const rec = 12 + i * 16;
    const tag = String.fromCharCode(dv.getUint8(rec), dv.getUint8(rec + 1), dv.getUint8(rec + 2), dv.getUint8(rec + 3));
    if (tag === "cmap") cmapOff = dv.getUint32(rec + 8);
  }
  if (cmapOff < 0) throw new Error("no cmap table");
  const nSub = dv.getUint16(cmapOff + 2);
  let best = -1;
  let bestRank = -1;
  for (let i = 0; i < nSub; i++) {
    const rec = cmapOff + 4 + i * 8;
    const pid = dv.getUint16(rec);
    const eid = dv.getUint16(rec + 2);
    const off = cmapOff + dv.getUint32(rec + 4);
    const fmt = dv.getUint16(off);
    const rank = (pid === 3 && eid === 10 && fmt === 12 ? 100 : 0) + (pid === 3 && eid === 1 && fmt === 4 ? 80 : 0) + (pid === 0 ? 60 : 0);
    if (rank > bestRank) {
      bestRank = rank;
      best = off;
    }
  }
  if (best < 0) throw new Error("no usable cmap subtable");
  const fmt = dv.getUint16(best);
  if (fmt === 12) {
    const groups = dv.getUint32(best + 12);
    const ranges: number[][] = [];
    for (let i = 0; i < groups; i++) {
      const o = best + 16 + i * 12;
      ranges.push([dv.getUint32(o), dv.getUint32(o + 4), dv.getUint32(o + 8)]);
    }
    return (cp) => ranges.some(([a, b, g]) => cp >= a && cp <= b && g > 0);
  }
  const segCount = dv.getUint16(best + 6) / 2;
  const ends: number[] = [];
  const starts: number[] = [];
  const deltas: number[] = [];
  for (let i = 0; i < segCount; i++) {
    ends.push(dv.getUint16(best + 14 + i * 2));
    starts.push(dv.getUint16(best + 16 + segCount * 2 + i * 2));
    deltas.push(dv.getInt16(best + 16 + segCount * 4 + i * 2));
  }
  return (cp) => {
    for (let i = 0; i < segCount; i++) {
      if (cp >= starts[i] && cp <= ends[i]) {
        const gid = (cp + deltas[i]) & 0xffff;
        return gid !== 0;
      }
    }
    return false;
  };
}

/* ------------------------------------------------------------------ */
/* the harness                                                         */
/* ------------------------------------------------------------------ */

export interface Harness {
  sys: TextSystem;
  results: CheckResult[];
  frameMs: number;
}

/** FNV-1a fallback for non-secure contexts where crypto.subtle is unavailable. */
function fnvHex(bytes: Uint8Array): string {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < bytes.length; i += 2) {
    h1 = (h1 ^ bytes[i]) >>> 0;
    h1 = Math.imul(h1, 0x01000193) >>> 0;
    h2 = (h2 ^ (bytes[i + 1] ?? 0)) >>> 0;
    h2 = Math.imul(h2, 0x85ebca6b) >>> 0;
  }
  return (h1.toString(16).padStart(8, "0") + h2.toString(16).padStart(8, "0")).repeat(2);
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  if (typeof crypto === "undefined" || !crypto.subtle) return fnvHex(bytes);
  try {
    const h = await crypto.subtle.digest("SHA-256", bytes as unknown as ArrayBuffer);
    return Array.from(new Uint8Array(h))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  } catch {
    return fnvHex(bytes);
  }
}

export async function runVerification(
  sys: TextSystem,
  onProgress: Progress,
  signal?: { cancelled: boolean },
): Promise<CheckResult[]> {
  const out: CheckResult[] = [];
  const add = (id: string, title: string, status: Status, evidence: string, ms = 0) =>
    out.push({ id, title, status, evidence, ms });
  const timed = async (id: string, title: string, fn: () => Promise<[Status, string]> | [Status, string]) => {
    const t0 = performance.now();
    onProgress(out.length / 14, id);
    if (signal?.cancelled) return;
    try {
      const [status, evidence] = await fn();
      add(id, title, status, evidence, performance.now() - t0);
    } catch (e) {
      // a check that could not run is BLOCKED, never silently PASS (R-NEG-09)
      add(id, title, "BLOCKED", `check did not complete: ${(e as Error).message}`, performance.now() - t0);
    }
  };

  /* ---- R-VER-01 (schedule half) ---- */
  await timed("R-VER-01", "Duration + frame count", () => {
    const gaps: string[] = [];
    for (let i = 1; i < SCENES.length; i++) {
      if (Math.abs(SCENES[i].start - SCENES[i - 1].end) > 1e-9) gaps.push(`${SCENES[i - 1].id}→${SCENES[i].id}`);
    }
    const frames = Math.round(DURATION * FPS);
    const ok = frames === 3600 && Math.abs(SCENES[0].start) < 1e-9 && Math.abs(SCENES[SCENES.length - 1].end - 60) < 1e-9 && gaps.length === 0;
    return [
      ok ? "PASS" : "FAIL",
      `timeline tiles 0.000–60.000 s exactly, ${frames} frames @ ${FPS} fps (expected 3600); scene gaps: ${gaps.length ? gaps.join(", ") : "none"}. Container duration/frames must additionally be confirmed with ffprobe on the rendered MP4 (BLOCKED here).`,
    ];
  });

  /* ---- R-VER-02/03/04/05/12: need the rendered files ---- */
  add("R-VER-02", "Resolution + frame rate", "BLOCKED",
    `no MP4 in this environment. Command: ffprobe -v error -select_streams v:0 -show_entries stream=width,height,r_frame_rate -of csv=p=0 out/nealarp-ad-1080p-test.mp4  (expect 1920,1080,60/1). Preview buffer is ${REF_W}x${REF_H} reference space.`);
  add("R-VER-03", "Codec H.264 High + yuv420p", "BLOCKED",
    `no MP4 here. Command: ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,profile,pix_fmt -of csv=p=0 out/*.mp4 (expect h264,High,yuv420p).`);
  add("R-VER-04", "Audio 48 kHz / stereo / AAC", "BLOCKED",
    `no MP4 here. Command: ffprobe -v error -select_streams a:0 -show_entries stream=codec_name,sample_rate,channels -of csv=p=0 out/*.mp4 (expect aac,48000,2).`);
  add("R-VER-05", "Loudness −14 LUFS ±1 / ≤ −1 dBTP", "BLOCKED",
    `no MP4 here. Command: ffmpeg -i out/*.mp4 -filter_complex ebur128=framelog=verbose -f null - (read I: and Peak: from the summary).`);
  add("R-VER-12", "Silence after 60.000 s", "BLOCKED",
    `no WAV/MP4 here. Command: ffmpeg -ss 60 -i audio/render/mix.wav -af astats=metadata=1 -f null - (expect RMS < −70 dBFS); the mix is exactly 60.000 s long by construction.`);

  /* ---- R-VER-06 palette ---- */
  await timed("R-VER-06", "Palette hue ranges (blue 195–235°, orange 15–35°)", async () => {
    const s = makeSurface(0.5, sys);
    let qualified = 0;
    let bad = 0;
    let worst = "";
    const hueHist = new Map<number, number>();
    for (let f = 0; f < TOTAL_FRAMES; f += FPS / 2) {
      if (signal?.cancelled) return ["BLOCKED", "cancelled"];
      renderFrame(s, f, 0.5);
      const d = s.ctx.getImageData(0, 0, s.canvas.width, s.canvas.height).data;
      for (let i = 0; i < d.length; i += 16) {
        const [h, sat, v] = rgb2hsv(d[i], d[i + 1], d[i + 2]);
        if (sat > 0.35 && v > 0.3) {
          qualified++;
          const okHue = (h >= 195 && h <= 235) || (h >= 15 && h <= 35);
          if (!okHue) {
            bad++;
            const bin = Math.round(h / 5) * 5;
            hueHist.set(bin, (hueHist.get(bin) ?? 0) + 1);
          }
        }
      }
      onProgress(0.1 + 0.3 * (f / TOTAL_FRAMES), `R-VER-06 frame ${f}`);
      await new Promise((r) => setTimeout(r, 0));
    }
    const pct = qualified ? (bad / qualified) * 100 : 0;
    const top = [...hueHist.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([h, n]) => `${h}°×${n}`);
    worst = top.length ? ` dominant offenders ${top.join(", ")}` : "";
    return [
      pct <= 1 ? "PASS" : "FAIL",
      `${qualified.toLocaleString("de-DE")} saturated pixels sampled (every 0.5 s, 120 frames), ${bad.toLocaleString("de-DE")} outside blue/orange hue = ${pct.toFixed(3)} % (limit 1.000 %).${worst}`,
    ];
  });

  /* ---- R-VER-07 background corners ---- */
  await timed("R-VER-07", "Background #0a0a0a in the four corners", async () => {
    const s = makeSurface(0.5, sys);
    const cw = Math.round(SAFE.left * 0.5 * 2);
    const ch = Math.round(SAFE.top * 0.5 * 2);
    let worstDev = 0;
    let worstAt = "";
    for (let f = 0; f < TOTAL_FRAMES; f += FPS * 2) {
      renderFrame(s, f, 0.5);
      const img = s.ctx.getImageData(0, 0, s.canvas.width, s.canvas.height);
      const boxes = [
        [0, 0],
        [img.width - cw, 0],
        [0, img.height - ch],
        [img.width - cw, img.height - ch],
      ];
      for (const [bx, by] of boxes) {
        const px: number[][] = [];
        for (let y = by; y < by + ch; y++) {
          for (let x = bx; x < bx + cw; x++) {
            const i = (y * img.width + x) * 4;
            px.push([img.data[i], img.data[i + 1], img.data[i + 2]]);
          }
        }
        px.sort((a, b) => a[0] + a[1] + a[2] - (b[0] + b[1] + b[2]));
        const darkest = px.slice(0, Math.max(1, Math.floor(px.length * 0.1)));
        for (let c = 0; c < 3; c++) {
          const vals = darkest.map((p) => p[c]).sort((a, b) => a - b);
          const median = vals[Math.floor(vals.length / 2)];
          const dev = Math.abs(median - 10);
          if (dev > worstDev) {
            worstDev = dev;
            worstAt = `frame ${f} channel ${c} median ${median}`;
          }
        }
      }
      onProgress(0.42 + 0.12 * (f / TOTAL_FRAMES), `R-VER-07 frame ${f}`);
    }
    return [
      worstDev <= 6 ? "PASS" : "FAIL",
      `max deviation of the darkest-10 % corner median from #0a0a0a = ${worstDev.toFixed(1)} / 6.0 per channel (${worstAt}). Grain + vignette keep the corners at or below the base colour.`,
    ];
  });

  /* ---- R-VER-08 safe area ---- */
  await timed("R-VER-08", "Text bounding boxes inside the safe area", () => {
    const bad = sys.log.filter((r) => !r.safeAreaOk);
    const lim = `x∈[${SAFE.left},${REF_W - SAFE.right}] y∈[${SAFE.top},${REF_H - SAFE.bottom}]`;
    return [
      bad.length === 0 ? "PASS" : "FAIL",
      bad.length === 0
        ? `all ${sys.log.length} layout boxes inside the safe area ${lim}; widest = ${Math.max(...sys.log.map((r) => r.box.w)).toFixed(0)} px (auto-fit limit ${AUTOFIT_MAX_WIDTH}).`
        : `${bad.length} boxes outside ${lim}: ` + bad.map((r) => `${r.id} ${r.safeAreaNote}`).join(" | "),
    ];
  });

  /* ---- R-VER-09 text completeness ---- */
  await timed("R-VER-09", "Every R-TXT-01 string is laid out exactly", () => {
    const logged = sys.log.map((r) => r.string);
    const missing = CANON_TEXT.filter((c) => !logged.includes(c));
    const extra = [...new Set(logged.filter((l) => !CANON_TEXT.includes(l)))];
    const mismatched = sys.log.filter((r) => r.string.toUpperCase() !== r.string && TEMPLATES_UPPER.has(r.layout));
    const ok = missing.length === 0 && extra.length === 0;
    return [
      ok ? "PASS" : "FAIL",
      `${CANON_TEXT.length} canonical strings, ${new Set(logged).size} distinct strings in the layout log; missing: ${missing.length ? missing.join(", ") : "none"}; extra: ${extra.length ? extra.join(", ") : "none"}; uppercase forced where the template demands it: ${mismatched.length === 0 ? "yes" : "no"}. OCR skipped — tesseract is not installed in this environment.`,
    ];
  });

  /* ---- R-VER-10 motion ---- */
  await timed("R-VER-10", "Motion outside declared hold windows", async () => {
    const scale = 0.25;
    const s = makeSurface(scale, sys);
    const w = s.canvas.width;
    const h = s.canvas.height;
    let prev: Uint8ClampedArray | null = null;
    let identical = 0;
    const identicalAt: number[] = [];
    const winSum = new Float64Array(Math.ceil(TOTAL_FRAMES / 30));
    const winN = new Float64Array(winSum.length);
    for (let f = 0; f < TOTAL_FRAMES; f++) {
      if (signal?.cancelled) return ["BLOCKED", "cancelled"];
      renderFrame(s, f, scale);
      const d = s.ctx.getImageData(0, 0, w, h).data;
      if (prev) {
        let sum = 0;
        for (let i = 0; i < d.length; i += 16) sum += Math.abs(d[i] - prev[i]);
        const mean = sum / (d.length / 16);
        const t = f / FPS;
        if (mean === 0 && !inHold(t)) {
          identical++;
          if (identicalAt.length < 6) identicalAt.push(f);
        }
        const wi = Math.floor(f / 30);
        if (!inHold(t)) {
          winSum[wi] += mean;
          winN[wi]++;
        }
      }
      prev = d.slice();
      if (f % 240 === 0) {
        onProgress(0.55 + 0.3 * (f / TOTAL_FRAMES), `R-VER-10 frame ${f}/${TOTAL_FRAMES}`);
        await new Promise((r) => setTimeout(r, 0));
      }
    }
    const deadWindows: number[] = [];
    for (let i = 0; i < winSum.length; i++) if (winN[i] > 0 && winSum[i] / winN[i] <= 0) deadWindows.push(i);
    const ok = identical === 0 && deadWindows.length === 0;
    return [
      ok ? "PASS" : "FAIL",
      `${TOTAL_FRAMES} consecutive frame pairs compared at ${w}x${h}; identical pairs outside hold_frames: ${identical}${identicalAt.length ? ` (frames ${identicalAt.join(", ")})` : ""}; 0.5 s windows with zero mean abs difference: ${deadWindows.length}. Declared holds: ${HOLD_FRAMES.map(([a, b]) => `${a}–${b}s`).join(", ")}.`,
    ];
  });

  /* ---- R-VER-11 schedule (static) ---- */
  await timed("R-VER-11a", "Audio schedule: no overlapping voiceover", () => {
    const overlaps: string[] = [];
    for (let i = 1; i < VO.length; i++) {
      const prevEnd = VO[i - 1].start + VO[i - 1].dur;
      if (VO[i].start < prevEnd) overlaps.push(`${VO[i - 1].id}→${VO[i].id}`);
      if (VO[i].start - prevEnd < 0.5 && VO[i].start - prevEnd >= 0) overlaps.push(`gap<0.5s ${VO[i - 1].id}→${VO[i].id}`);
    }
    const drift = SFX.filter((e) => Math.abs(e.start * FPS - Math.round(e.start * FPS)) > 1e-6);
    return [
      overlaps.length === 0 ? "PASS" : "FAIL",
      `${VO.length} VO lines, min inter-line gap ${(Math.min(...VO.slice(1).map((v, i) => v.start - (VO[i].start + VO[i].dur)))).toFixed(2)} s (≥0.50 required); ${SFX.length} sfx events, all on the 1/60 s grid: ${drift.length === 0 ? "yes" : "no"}. Measured onset offsets inside the rendered WAV remain BLOCKED (no media here).`,
    ];
  });

  /* ---- R-VER-13 reproducibility ---- */
  await timed("R-VER-13", "Reproducibility of frames 0/900/1800/3000/3599", async () => {
    const frames = [0, 900, 1800, 3000, 3599];
    const a = makeSurface(0.5, sys);
    const b = makeSurface(0.5, sys);
    const hashes: string[] = [];
    for (const f of frames) {
      renderFrame(a, f, 0.5);
      const ha = await sha256Hex(new Uint8Array(a.ctx.getImageData(0, 0, a.canvas.width, a.canvas.height).data.buffer));
      renderFrame(b, f, 0.5);
      const hb = await sha256Hex(new Uint8Array(b.ctx.getImageData(0, 0, b.canvas.width, b.canvas.height).data.buffer));
      hashes.push(ha === hb ? `${f}: match ${ha.slice(0, 12)}…` : `${f}: MISMATCH ${ha.slice(0, 8)}≠${hb.slice(0, 8)}`);
    }
    const ok = hashes.every((h) => h.includes("match"));
    return [
      ok ? "PASS" : "FAIL",
      `two independent surfaces, five frames, byte-identical pixel buffers — hashed with SHA-256 (FNV-1a fallback outside a secure context); the Python harness uses MD5 per R-VER-13. ${hashes.join(" | ")}`,
    ];
  });

  /* ---- R-VER-14 font coverage ---- */
  await timed("R-VER-14", "Font covers Ä ä Ö ö Ü ü ß . , % m", async () => {
    try {
      const lines: string[] = [];
      let allOk = true;
      for (const [name, url] of Object.entries(FONT_URLS)) {
        const has = await cmapCoverage(url);
        const missing = REQUIRED_GLYPHS.filter((g) => !has(g.codePointAt(0)!));
        if (missing.length) allOk = false;
        lines.push(`${name}: ${missing.length ? "MISSING " + missing.join(" ") : `all ${REQUIRED_GLYPHS.length} glyphs present (cmap parsed)`}`);
      }
      return [
        allOk ? "PASS" : "FAIL",
        `${lines.join(" · ")}. Source: npm dejavu-fonts-ttf@2.37.3 (same family as /usr/share/fonts/truetype/dejavu/ used by the Python renderer).`,
      ];
    } catch (e) {
      return ["BLOCKED", `cmap could not be fetched/parsed in this environment: ${(e as Error).message}. Run: python -m src.fonts --check on the render machine.`];
    }
  });

  onProgress(1, "done");
  return out;
}

const TEMPLATES_UPPER = new Set(["title_lower_third", "title_opening", "claim_white", "claim_gradient", "cta_button_label", "panel_label"]);

export function autofitReport(log: LayoutRecord[]) {
  return log.filter((r) => r.autofit).map((r) => ({ id: r.id, string: r.string, from: r.baseSize, to: r.size, width: r.width }));
}

export const HOUSE = PALETTE;
