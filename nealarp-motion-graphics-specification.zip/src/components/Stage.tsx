import { useCallback, useEffect, useRef, useState } from "react";
import { FPS, REF_H, REF_W, SAFE, TOTAL_FRAMES } from "../ad/constants";
import type { TextSystem } from "../ad/layout";
import { renderFrame } from "../ad/render";
import { clock, patchClock, seekFrame, useClock } from "../ad/store";
import { SCENES } from "../ad/timeline";
import { adAudio } from "../ad/audio";

interface Props {
  sys: TextSystem;
  ready: boolean;
}

const fmt = (t: number) =>
  `${Math.floor(t / 60)}:${(t % 60).toFixed(3).padStart(6, "0")}`;

export default function Stage({ sys, ready }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const scratchRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef(0);
  const lastRef = useRef(0);
  const accRef = useRef(0);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const [overlay, setOverlay] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportPct, setExportPct] = useState(0);
  const [msPerFrame, setMsPerFrame] = useState(0);
  const playing = useClock((c) => c.playing);
  const muted = useClock((c) => c.muted);
  const scale = useClock((c) => c.scale);
  const speed = useClock((c) => c.speed);
  const readoutRef = useRef<HTMLSpanElement>(null);
  const sceneRef = useRef<HTMLSpanElement>(null);
  const frameReadRef = useRef<HTMLSpanElement>(null);

  /* resize the backing store with the chosen preview scale */
  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    c.width = Math.round(REF_W * scale);
    c.height = Math.round(REF_H * scale);
  }, [scale, ready]);

  const draw = useCallback(
    (frame: number) => {
      const c = canvasRef.current;
      if (!c || !ready) return;
      const ctx = c.getContext("2d", { alpha: false })!;
      if (!scratchRef.current) scratchRef.current = document.createElement("canvas");
      const t0 = performance.now();
      renderFrame({ ctx, sys, scratch: scratchRef.current }, frame, scale);
      setMsPerFrame(performance.now() - t0);
      if (overlay) {
        ctx.setTransform(scale, 0, 0, scale, 0, 0);
        ctx.strokeStyle = "rgba(255,255,255,0.28)";
        ctx.lineWidth = 1;
        ctx.setLineDash([10, 8]);
        ctx.strokeRect(SAFE.left, SAFE.top, REF_W - SAFE.left - SAFE.right, REF_H - SAFE.top - SAFE.bottom);
        ctx.setLineDash([]);
        const t = frame / FPS;
        for (const r of sys.log) {
          if (t < r.start || t >= r.end) continue;
          ctx.strokeStyle = "rgba(249,115,22,0.85)";
          ctx.strokeRect(r.box.x, r.box.y, r.box.w, r.box.h);
          ctx.font = `20px "IBM Plex Mono", monospace`;
          ctx.fillStyle = "rgba(249,115,22,0.95)";
          ctx.fillText(`${r.id} · ${r.size}px${r.autofit ? " (fit)" : ""}`, r.box.x, Math.max(24, r.box.y - 8));
        }
        ctx.setTransform(1, 0, 0, 1, 0, 0);
      }
    },
    [overlay, ready, scale, sys],
  );

  /* playback loop — the only place where the clock advances */
  useEffect(() => {
    if (!ready) return;
    let perfFrames = 0;
    let perfT0 = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - (lastRef.current || now)) / 1000);
      lastRef.current = now;
      if (clock.playing) {
        accRef.current += dt * clock.speed * FPS;
        const advance = Math.floor(accRef.current);
        if (advance > 0) {
          accRef.current -= advance;
          let f = clock.frame + advance;
          if (f >= TOTAL_FRAMES) f = 0;
          seekFrame(f);
        }
      }
      draw(clock.frame);
      const t = clock.frame / FPS;
      if (readoutRef.current) readoutRef.current.textContent = fmt(t);
      if (frameReadRef.current) frameReadRef.current.textContent = String(clock.frame).padStart(4, "0");
      if (sceneRef.current) {
        const sc = SCENES.find((s) => t >= s.start && t < s.end) ?? SCENES[SCENES.length - 1];
        sceneRef.current.textContent = sc.id;
      }
      perfFrames++;
      if (now - perfT0 > 1000) {
        perfT0 = now;
        perfFrames = 0;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [draw, ready]);

  const togglePlay = async () => {
    if (!clock.playing) {
      if (!muted) {
        await adAudio.play(clock.frame / FPS);
      }
      patchClock({ playing: true });
    } else {
      adAudio.stop();
      patchClock({ playing: false });
    }
  };

  const onScrub = (v: number) => {
    seekFrame(v);
    draw(clock.frame);
    if (clock.playing && !muted) adAudio.seek(clock.frame / FPS);
  };

  const toggleAudio = async () => {
    const next = !muted;
    patchClock({ muted: next });
    adAudio.setMuted(next);
    if (!next && clock.playing) await adAudio.play(clock.frame / FPS);
    if (next) adAudio.stop();
  };

  /** Preview export: MediaRecorder over the same pure renderer (WebM/VP9). */
  const exportPreview = async () => {
    const c = canvasRef.current;
    if (!c || exporting) return;
    setExporting(true);
    setExportPct(0);
    chunksRef.current = [];
    const stream = c.captureStream(FPS);
    let dest: MediaStreamAudioDestinationNode | null = null;
    try {
      const ac = await adAudio.ensure();
      dest = ac.createMediaStreamDestination();
      adAudio.master.connect(dest);
      dest.stream.getAudioTracks().forEach((tr) => stream.addTrack(tr));
    } catch {
      /* video only */
    }
    const mime = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"].find((m) =>
      MediaRecorder.isTypeSupported(m),
    );
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 12_000_000 });
    recRef.current = rec;
    rec.ondataavailable = (e) => e.data.size && chunksRef.current.push(e.data);
    rec.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "video/webm" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "nealarp-ad-preview.webm";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      if (dest) adAudio.master.disconnect(dest);
      setExporting(false);
    };
    seekFrame(0);
    patchClock({ playing: true, speed: 1 });
    rec.start(500);
    await adAudio.play(0);
    const started = performance.now();
    const iv = window.setInterval(() => {
      const p = Math.min(1, (performance.now() - started) / 60000);
      setExportPct(p);
      if (p >= 1) {
        window.clearInterval(iv);
        rec.stop();
        adAudio.stop();
        patchClock({ playing: false });
        seekFrame(0);
      }
    }, 250);
  };

  const jump = (dir: number) => {
    const t = clock.frame / FPS;
    const idx = SCENES.findIndex((s) => t >= s.start && t < s.end);
    const next = Math.max(0, Math.min(SCENES.length - 1, (idx < 0 ? 0 : idx) + dir));
    onScrub(Math.round(SCENES[next].start * FPS));
  };

  return (
    <div className="panel panel-ticks">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-4 py-2.5">
        <div className="flex items-baseline gap-3">
          <span className="font-display text-[13px] font-bold uppercase tracking-[0.28em] text-white/85">Stage</span>
          <span className="font-mono text-[11px] text-white/40">1920×1080 ref · scale {scale}× · 60 fps</span>
        </div>
        <div className="flex items-center gap-4 font-mono text-[11px]">
          <label className="flex cursor-pointer items-center gap-2 text-white/55 transition hover:text-white">
            <input type="checkbox" className="accent-[#f97316]" checked={overlay} onChange={(e) => setOverlay(e.target.checked)} />
            safe area + layout boxes
          </label>
          <span className="text-white/40">
            frame <span ref={frameReadRef} className="tabular text-[#f97316]">0000</span>
          </span>
          <span className="text-white/40">
            scene <span ref={sceneRef} className="text-[#3b82f6]">opening</span>
          </span>
          <span className="text-white/40">
            render <span className="tabular text-white/75">{msPerFrame.toFixed(1)} ms</span>
          </span>
        </div>
      </div>

      <div className="relative bg-black">
        <div className="pointer-events-none absolute inset-0 z-10 opacity-[0.06]">
          <div className="scanline h-[2px] w-full bg-[#3b82f6]" />
        </div>
        <canvas
          ref={canvasRef}
          className="block h-auto w-full"
          style={{ aspectRatio: "16 / 9", imageRendering: "auto" }}
        />
        {!ready && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-black/85 font-mono text-[12px] text-white/60">
            <div className="h-[3px] w-56 overflow-hidden bg-white/10">
              <div className="sweep relative h-full w-full" />
            </div>
            loading DejaVu metrics · building layout log
          </div>
        )}
        {exporting && (
          <div className="absolute bottom-3 left-3 z-20 flex items-center gap-3 border border-[#f97316]/60 bg-black/80 px-3 py-2 font-mono text-[11px] text-[#f97316]">
            <span className="blip inline-block h-2 w-2 rounded-full bg-[#f97316]" />
            REC · preview export {(exportPct * 100).toFixed(0)} %
          </div>
        )}
      </div>

      <div className="border-t border-white/10 px-4 py-3">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <TBtn label="previous scene" onClick={() => jump(-1)}>
              <path d="M14 5v14L4 12z" />
              <rect x="15" y="5" width="2" height="14" />
            </TBtn>
            <TBtn label={playing ? "pause" : "play"} onClick={togglePlay} primary>
              {playing ? <><rect x="6" y="5" width="4" height="14" /><rect x="14" y="5" width="4" height="14" /></> : <path d="M7 4.5v15l13-7.5z" />}
            </TBtn>
            <TBtn label="next scene" onClick={() => jump(1)}>
              <path d="M10 5v14l10-7z" />
              <rect x="7" y="5" width="2" height="14" />
            </TBtn>
            <TBtn label="back one frame" onClick={() => onScrub(clock.frame - 1)}>
              <path d="M9 6h2v12H9zM20 6v12l-9-6z" />
            </TBtn>
            <TBtn label="forward one frame" onClick={() => onScrub(clock.frame + 1)}>
              <path d="M13 6h2v12h-2zM4 6l9 6-9 6z" />
            </TBtn>
          </div>

          <span ref={readoutRef} className="tabular font-mono text-[22px] font-medium leading-none text-white">
            0:00.000
          </span>
          <span className="font-mono text-[11px] text-white/35">/ 1:00.000 · 3600 f</span>

          <input
            type="range"
            min={0}
            max={TOTAL_FRAMES - 1}
            value={clock.frame}
            onChange={(e) => onScrub(Number(e.target.value))}
            className="min-w-24 flex-1"
            aria-label="scrub timeline"
          />

          <div className="flex items-center gap-1.5">
            <SegBtn active={speed === 0.25} onClick={() => patchClock({ speed: 0.25 })}>¼×</SegBtn>
            <SegBtn active={speed === 0.5} onClick={() => patchClock({ speed: 0.5 })}>½×</SegBtn>
            <SegBtn active={speed === 1} onClick={() => patchClock({ speed: 1 })}>1×</SegBtn>
            <span className="mx-1 h-5 w-px bg-white/10" />
            <SegBtn active={scale === 0.5} onClick={() => patchClock({ scale: 0.5 })}>540p</SegBtn>
            <SegBtn active={scale === 1} onClick={() => patchClock({ scale: 1 })}>1080p</SegBtn>
            <span className="mx-1 h-5 w-px bg-white/10" />
            <TBtn label={muted ? "enable audio" : "mute audio"} onClick={toggleAudio} active={!muted}>
              {muted ? (
                <>
                  <path d="M4 9h3l5-4v14l-5-4H4z" />
                  <path d="M16 9l5 6M21 9l-5 6" stroke="currentColor" strokeWidth="1.8" fill="none" />
                </>
              ) : (
                <>
                  <path d="M4 9h3l5-4v14l-5-4H4z" />
                  <path d="M16 8.5a5 5 0 0 1 0 7M18.6 6a8.5 8.5 0 0 1 0 12" stroke="currentColor" strokeWidth="1.8" fill="none" />
                </>
              )}
            </TBtn>
            <button
              onClick={exportPreview}
              disabled={exporting}
              className="group relative ml-1 overflow-hidden border border-[#3b82f6]/50 bg-[#3b82f6]/10 px-3 py-[7px] font-mono text-[11px] uppercase tracking-[0.14em] text-[#9dc4ff] transition hover:border-[#3b82f6] hover:bg-[#3b82f6]/25 hover:text-white disabled:opacity-40"
            >
              {exporting ? "recording…" : "export webm"}
            </button>
          </div>
        </div>
        <p className="mt-2 font-mono text-[10.5px] leading-relaxed text-white/35">
          Export = browser MediaRecorder capture of this renderer (WebM/VP9, real-time). It is a review artefact only —
          the spec masters are H.264/AAC and come from <span className="text-white/60">nealarp-ad/src/render.py</span>.
        </p>
      </div>
    </div>
  );
}

function TBtn({
  children,
  onClick,
  label,
  primary,
  active,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
  primary?: boolean;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className={[
        "flex h-9 w-9 items-center justify-center border transition duration-150",
        primary
          ? "border-[#f97316] bg-[#f97316] text-black hover:bg-[#fb923c] hover:shadow-[0_0_22px_rgba(249,115,22,0.55)]"
          : active
            ? "border-[#3b82f6] bg-[#3b82f6]/25 text-[#9dc4ff]"
            : "border-white/12 bg-white/[0.03] text-white/60 hover:border-white/35 hover:text-white",
      ].join(" ")}
    >
      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
        {children}
      </svg>
    </button>
  );
}

function SegBtn({ children, active, onClick }: { children: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={[
        "border px-2 py-[7px] font-mono text-[10.5px] uppercase tracking-[0.1em] transition",
        active
          ? "border-[#f97316]/70 bg-[#f97316]/15 text-[#fdba74]"
          : "border-white/10 bg-white/[0.02] text-white/45 hover:border-white/30 hover:text-white/80",
      ].join(" ")}
    >
      {children}
    </button>
  );
}

/** small helper so other panels can draw a chip with the house radius */
export function Chip({ tone, children }: { tone: "blue" | "orange" | "dim"; children: React.ReactNode }) {
  const map = {
    blue: "border-[#3b82f6]/45 bg-[#3b82f6]/12 text-[#9dc4ff]",
    orange: "border-[#f97316]/50 bg-[#f97316]/12 text-[#fdba74]",
    dim: "border-white/12 bg-white/[0.03] text-white/45",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 border px-2 py-1 font-mono text-[10px] uppercase tracking-[0.16em] ${map[tone]}`}>
      {children}
    </span>
  );
}
