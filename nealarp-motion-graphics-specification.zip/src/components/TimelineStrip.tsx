import { useEffect, useRef, useState } from "react";
import { FPS, TOTAL_FRAMES } from "../ad/constants";
import { clock, seekFrame } from "../ad/store";
import { SCENES, SFX, VO } from "../ad/timeline";

const ACT_TONE: Record<string, { bar: string; text: string }> = {
  opening: { bar: "linear-gradient(180deg,rgba(255,255,255,.22),rgba(59,130,246,.30))", text: "text-white/80" },
  showcase: { bar: "linear-gradient(180deg,rgba(59,130,246,.34),rgba(59,130,246,.12))", text: "text-[#9dc4ff]" },
  hero: { bar: "linear-gradient(180deg,rgba(59,130,246,.42),rgba(249,115,22,.34))", text: "text-white/85" },
  cta: { bar: "linear-gradient(180deg,rgba(249,115,22,.42),rgba(249,115,22,.14))", text: "text-[#fdba74]" },
};

export default function TimelineStrip() {
  const headRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState<{ id: string; note: string; x: number; y: number } | null>(null);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      if (headRef.current) headRef.current.style.left = `${(clock.frame / (TOTAL_FRAMES - 1)) * 100}%`;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const scrubFromEvent = (clientX: number) => {
    const el = trackRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const p = Math.max(0, Math.min(1, (clientX - r.left) / r.width));
    seekFrame(Math.round(p * (TOTAL_FRAMES - 1)));
  };

  return (
    <div className="panel">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 px-4 py-2">
        <div className="flex items-baseline gap-3">
          <span className="font-display text-[12px] font-bold uppercase tracking-[0.28em] text-white/80">Timeline</span>
          <span className="font-mono text-[10.5px] text-white/35">timeline.yaml · 11 scenes · 4 acts · 0.5 s grid</span>
        </div>
        <div className="flex items-center gap-4 font-mono text-[10px] uppercase tracking-[0.14em] text-white/40">
          <LegendDot c="#3b82f6" label="sfx" />
          <LegendDot c="#f97316" label="voiceover" />
          <LegendDot c="#ffffff" label="hold" />
        </div>
      </div>

      <div
        ref={trackRef}
        className="relative cursor-crosshair select-none px-4 pb-3 pt-2"
        onPointerDown={(e) => {
          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
          scrubFromEvent(e.clientX);
        }}
        onPointerMove={(e) => {
          if (e.buttons === 1) scrubFromEvent(e.clientX);
        }}
      >
        {/* ruler */}
        <div className="relative h-5">
          {Array.from({ length: 61 }, (_, i) => (
            <div key={i} className="absolute top-0" style={{ left: `${(i / 60) * 100}%` }}>
              <div className={i % 5 === 0 ? "h-3 w-px bg-white/35" : "h-1.5 w-px bg-white/15"} />
              {i % 5 === 0 && (
                <span className="absolute left-1 top-2.5 font-mono text-[9.5px] text-white/35">{i}s</span>
              )}
            </div>
          ))}
        </div>

        {/* scene blocks */}
        <div className="relative mt-1 flex h-[52px] w-full gap-px">
          {SCENES.map((s) => {
            const w = ((s.end - s.start) / 60) * 100;
            const tone = ACT_TONE[s.act];
            return (
              <div
                key={s.id}
                className="group relative overflow-hidden border border-white/10 transition-all duration-200 hover:border-[#f97316]/70"
                style={{ width: `${w}%`, background: tone.bar }}
                onMouseEnter={(e) =>
                  setHover({ id: s.id, note: `${s.start.toFixed(1)}–${s.end.toFixed(1)} s · ${s.note}`, x: e.clientX, y: e.clientY })
                }
                onMouseLeave={() => setHover(null)}
                onDoubleClick={() => seekFrame(Math.round(s.start * FPS))}
              >
                <div className="absolute inset-x-1.5 bottom-1.5 truncate font-display text-[10.5px] font-semibold uppercase tracking-[0.1em] text-white/90">
                  {s.title}
                </div>
                <div className={`absolute inset-x-1.5 top-1.5 truncate font-mono text-[9px] ${tone.text}`}>{s.id}</div>
                <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              </div>
            );
          })}
        </div>

        {/* event lanes */}
        <div className="relative mt-1.5 h-4 w-full">
          {VO.map((v) => (
            <div
              key={v.id}
              title={`${v.id} @ ${v.start}s — ${v.string}`}
              className="absolute top-1 h-2 w-[3px] bg-[#f97316] shadow-[0_0_8px_rgba(249,115,22,0.9)] transition-transform hover:scale-y-150"
              style={{ left: `${(v.start / 60) * 100}%` }}
            />
          ))}
        </div>
        <div className="relative h-3 w-full">
          {SFX.map((e) => (
            <div
              key={e.id}
              title={`${e.recipe} @ ${e.start}s`}
              className="absolute top-0.5 h-1.5 w-1.5 rounded-full bg-[#3b82f6]/80 transition hover:bg-[#3b82f6]"
              style={{ left: `${(e.start / 60) * 100}%` }}
            />
          ))}
        </div>

        {/* playhead */}
        <div ref={headRef} className="pointer-events-none absolute bottom-2 top-2 z-10 w-px bg-[#f97316]" style={{ left: "0%" }}>
          <div className="absolute -left-[5px] -top-1 h-0 w-0 border-x-[5px] border-t-[7px] border-x-transparent border-t-[#f97316]" />
          <div className="absolute -left-[9px] top-0 h-full w-[19px] bg-[#f97316]/12" />
        </div>

        {hover && (
          <div
            className="pointer-events-none fixed z-50 max-w-[380px] border border-[#f97316]/50 bg-black/92 px-3 py-2 font-mono text-[10.5px] leading-relaxed text-white/75"
            style={{ left: Math.min(hover.x + 12, window.innerWidth - 400), top: hover.y + 16 }}
          >
            <span className="text-[#fdba74]">{hover.id}</span> — {hover.note}
          </div>
        )}
      </div>
    </div>
  );
}

function LegendDot({ c, label }: { c: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: c }} />
      {label}
    </span>
  );
}
