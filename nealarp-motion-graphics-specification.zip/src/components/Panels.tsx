import { useMemo, useState } from "react";
import type { TextSystem } from "../ad/layout";
import { autofitReport, runVerification, type CheckResult, type Progress } from "../ad/verify";
import { CHECKLIST, CHECK_GROUPS, type CStatus } from "../ad/checklistData";
import { CANON_TEXT } from "../ad/timeline";

const tone = (s: CStatus | "RUN") =>
  s === "PASS"
    ? "border-[#3b82f6]/60 bg-[#3b82f6]/15 text-[#9dc4ff]"
    : s === "FAIL"
      ? "border-[#f97316]/70 bg-[#f97316]/20 text-[#fdba74]"
      : "border-white/15 bg-white/[0.04] text-white/45";

function Badge({ s }: { s: CStatus | "RUN" }) {
  return (
    <span className={`inline-block min-w-[62px] border px-1.5 py-[2px] text-center font-mono text-[9.5px] uppercase tracking-[0.14em] ${tone(s)}`}>
      {s === "RUN" ? "running" : s}
    </span>
  );
}

function Head({ title, sub, right }: { title: string; sub?: string; right?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-white/10 px-4 py-2.5">
      <div>
        <h3 className="font-display text-[12px] font-bold uppercase tracking-[0.26em] text-white/85">{title}</h3>
        {sub && <p className="mt-0.5 font-mono text-[10px] leading-relaxed text-white/35">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

/* ============================== VERIFY ============================== */

export function VerifyPanel({ sys }: { sys: TextSystem }) {
  const [results, setResults] = useState<CheckResult[]>([]);
  const [running, setRunning] = useState(false);
  const [pct, setPct] = useState(0);
  const [msg, setMsg] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const cancel = useMemo(() => ({ cancelled: false }), []);

  const run = async () => {
    setRunning(true);
    setResults([]);
    cancel.cancelled = false;
    const onProgress: Progress = (p, m) => {
      setPct(p);
      setMsg(m);
    };
    const live: CheckResult[] = [];
    setResults(live);
    const res = await runVerification(sys, onProgress, cancel);
    setResults(res);
    setRunning(false);
    setPct(1);
    setMsg("");
  };

  const counts = results.reduce(
    (a, r) => ({ ...a, [r.status]: (a[r.status] ?? 0) + 1 }),
    {} as Record<string, number>,
  );

  return (
    <div className="flex h-full flex-col">
      <Head
        title="Verification"
        sub="R-VER-01 … R-VER-14 · runs against this renderer"
        right={
          <button
            onClick={running ? () => (cancel.cancelled = true) : run}
            className={`border px-3 py-1.5 font-mono text-[10.5px] uppercase tracking-[0.16em] transition ${
              running
                ? "border-[#f97316] bg-[#f97316]/20 text-[#fdba74]"
                : "border-[#3b82f6]/60 bg-[#3b82f6]/12 text-[#9dc4ff] hover:border-[#3b82f6] hover:bg-[#3b82f6]/25 hover:text-white"
            }`}
          >
            {running ? "cancel" : results.length ? "re-run" : "run all checks"}
          </button>
        }
      />
      {(running || pct > 0) && (
        <div className="border-b border-white/10 px-4 py-2">
          <div className="h-[3px] w-full overflow-hidden bg-white/8">
            <div
              className="h-full bg-gradient-to-r from-[#3b82f6] to-[#f97316] transition-[width] duration-200"
              style={{ width: `${Math.round(pct * 100)}%` }}
            />
          </div>
          <p className="mt-1.5 font-mono text-[10px] text-white/40">
            {msg || (pct >= 1 ? "complete" : "idle")} · {Math.round(pct * 100)} %
          </p>
        </div>
      )}
      <div className="min-h-0 flex-1 overflow-y-auto">
        {results.length === 0 && !running && (
          <div className="px-4 py-8 font-mono text-[11px] leading-relaxed text-white/35">
            Nothing measured yet. Checks that need a rendered MP4/WAV are reported BLOCKED with the exact ffmpeg
            command that produces the evidence — no result is invented (R-NEG-09).
          </div>
        )}
        {results.map((r) => (
          <button
            key={r.id}
            onClick={() => setOpen(open === r.id ? null : r.id)}
            className="block w-full border-b border-white/[0.06] px-4 py-2.5 text-left transition hover:bg-white/[0.035]"
          >
            <div className="flex items-center gap-2.5">
              <Badge s={r.status} />
              <span className="font-mono text-[10.5px] text-[#fdba74]">{r.id}</span>
              <span className="flex-1 truncate text-[12px] text-white/80">{r.title}</span>
              {r.ms > 0 && <span className="font-mono text-[9.5px] text-white/30">{(r.ms / 1000).toFixed(1)}s</span>}
            </div>
            {open === r.id && (
              <p className="mt-2 border-l border-[#3b82f6]/40 pl-2.5 font-mono text-[10.5px] leading-relaxed text-white/55">
                {r.evidence}
              </p>
            )}
          </button>
        ))}
      </div>
      {results.length > 0 && (
        <div className="flex items-center gap-3 border-t border-white/10 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.14em] text-white/45">
          <span className="text-[#9dc4ff]">{counts.PASS ?? 0} pass</span>
          <span className="text-[#fdba74]">{counts.FAIL ?? 0} fail</span>
          <span>{counts.BLOCKED ?? 0} blocked</span>
        </div>
      )}
    </div>
  );
}

/* ============================== TEXT ============================== */

export function TextPanel({ sys }: { sys: TextSystem }) {
  const [q, setQ] = useState("");
  const fits = autofitReport(sys.log);
  const rows = sys.log.filter(
    (r) => !q || r.string.toLowerCase().includes(q.toLowerCase()) || r.id.includes(q) || r.layout.includes(q),
  );
  return (
    <div className="flex h-full flex-col">
      <Head
        title="Text layout log"
        sub={`${sys.log.length} entries · ${CANON_TEXT.length} canonical strings · auto-fit > 1440 px`}
        right={
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="filter…"
            className="w-28 border border-white/12 bg-black/40 px-2 py-1 font-mono text-[10.5px] text-white/80 outline-none placeholder:text-white/25 focus:border-[#3b82f6]"
          />
        }
      />
      <div className="border-b border-white/10 px-4 py-2.5">
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/40">auto-fit events</p>
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          {fits.length === 0 && <span className="font-mono text-[10.5px] text-white/30">none</span>}
          {fits.map((f) => (
            <span
              key={f.id}
              className="border border-[#f97316]/45 bg-[#f97316]/10 px-2 py-1 font-mono text-[10px] text-[#fdba74]"
              title={`${f.string} measured ${f.width.toFixed(0)} px at ${f.from} px`}
            >
              {f.string} · {f.from}→{f.to}px
            </span>
          ))}
        </div>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto">
        <table className="w-full border-collapse font-mono text-[10.5px]">
          <thead className="sticky top-0 bg-[#0b0d11] text-white/35">
            <tr className="[&>th]:px-2 [&>th]:py-1.5 [&>th]:text-left [&>th]:font-normal">
              <th>id</th>
              <th>string</th>
              <th>layout</th>
              <th className="text-right">px</th>
              <th className="text-right">window</th>
              <th className="text-right">box</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-white/[0.05] transition hover:bg-white/[0.04]">
                <td className="px-2 py-1.5 text-white/40">{r.id}</td>
                <td className={`px-2 py-1.5 ${r.autofit ? "text-[#fdba74]" : "text-white/90"}`}>{r.string}</td>
                <td className="px-2 py-1.5 text-[#9dc4ff]/70">{r.layout}</td>
                <td className="px-2 py-1.5 text-right tabular text-white/60">{r.size}</td>
                <td className="px-2 py-1.5 text-right tabular text-white/40">
                  {r.start.toFixed(1)}–{r.end.toFixed(1)}
                </td>
                <td
                  className={`px-2 py-1.5 text-right tabular ${r.safeAreaOk ? "text-white/35" : "text-[#fdba74]"}`}
                  title={r.safeAreaNote}
                >
                  {Math.round(r.box.w)}×{Math.round(r.box.h)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ============================== CHECKLIST ============================== */

export function ChecklistPanel() {
  const [filter, setFilter] = useState<"ALL" | CStatus>("ALL");
  const counts = useMemo(() => {
    const c = { PASS: 0, FAIL: 0, BLOCKED: 0 } as Record<CStatus, number>;
    CHECKLIST.forEach((i) => c[i.status]++);
    return c;
  }, []);
  return (
    <div className="flex h-full flex-col">
      <Head
        title="Checklist"
        sub={`${CHECKLIST.length} requirement IDs · evidence-based only`}
        right={
          <div className="flex gap-1">
            {(["ALL", "PASS", "BLOCKED", "FAIL"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`border px-2 py-1 font-mono text-[9.5px] uppercase tracking-[0.12em] transition ${
                  filter === f
                    ? "border-[#f97316]/70 bg-[#f97316]/15 text-[#fdba74]"
                    : "border-white/10 text-white/40 hover:border-white/30 hover:text-white/75"
                }`}
              >
                {f}
                {f !== "ALL" && <span className="ml-1 text-white/30">{counts[f]}</span>}
              </button>
            ))}
          </div>
        }
      />
      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-3">
        {CHECK_GROUPS.map((g) => {
          const items = CHECKLIST.filter((i) => i.id.startsWith(g.prefix) && (filter === "ALL" || i.status === filter));
          if (!items.length) return null;
          return (
            <div key={g.prefix} className="mb-4">
              <p className="mb-1.5 font-mono text-[9.5px] uppercase tracking-[0.22em] text-white/30">{g.label}</p>
              <div className="space-y-1">
                {items.map((i) => (
                  <details key={i.id} className="group border-l border-white/10 pl-2.5 transition hover:border-[#3b82f6]">
                    <summary className="flex cursor-pointer list-none items-start gap-2 py-1">
                      <Badge s={i.status} />
                      <span className="font-mono text-[10px] text-[#fdba74]/80">{i.id}</span>
                      <span className="flex-1 text-[11.5px] leading-snug text-white/70 group-hover:text-white/95">
                        {i.text}
                      </span>
                    </summary>
                    <p className="pb-2 pl-0 font-mono text-[10px] leading-relaxed text-white/45">{i.evidence}</p>
                  </details>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============================== REPORT ============================== */

const RENDER_CMDS = [
  "# 0 · host reachability (R-STACK-01)",
  "for h in pypi.org files.pythonhosted.org registry.npmjs.org; do \\",
  "  printf '%s ' $h; curl -s -o /dev/null -w '%{http_code}\\n' --max-time 8 https://$h/; done",
  "",
  "# 1 · environment (once)",
  "cd nealarp-ad && python3.11 -m venv .venv && . .venv/bin/activate",
  "pip install -r requirements.txt",
  "",
  "# 2 · voiceover (PLACEHOLDER unless a neural de-DE voice is configured)",
  "python -m src.vo --engine espeak-ng --out audio/vo",
  "",
  "# 3 · audio mix (48 kHz stereo WAV, two-pass loudnorm −14 LUFS / −1 dBTP)",
  "python -m src.mix --out audio/render/mix.wav",
  "",
  "# 4 · THE render command (R-OUT-06) — same source, both masters",
  "python -m src.render --preset test    # out/nealarp-ad-1080p-test.mp4   1920x1080 60p",
  "python -m src.render --preset final   # out/nealarp-ad-2160p60-final.mp4 3840x2160 60p",
  "",
  "# 5 · verification suite",
  "pytest -q tests && python -m src.verify out/nealarp-ad-1080p-test.mp4 --report report.json",
].join("\n");

const DEVIATIONS = [
  ["House gradient runs blue → white → orange", "R-VIS-03 defines two stops. A direct lerp from #3b82f6 to #f97316 crosses 12–15° hue at ~40 % saturation — exactly the pixels R-VER-06 rejects — and on a 96 px lower third that band alone blows the 1 % budget. The white mid-stop is a house colour and matches R-REF-02's hot-white core; endpoints and direction are unchanged."],
  ["Two extra text templates", "panel_label (R-SCN-08 counters) and score_orange_160 (R-SCN-07 98 %) are not in the spec's template list but are required by the scene specs. Both go through the layout system and are logged, so R-TXT-02 still holds."],
  ["100 MEGATONNEN at y=220", "claim_white is defined at y=540; R-SCN-06 explicitly demands y=220. The entry carries a logged cy override instead of a new template."],
  ["Depth counter ramp", "R-SCN-04 asks for a count-up between 0 m / 1.000 m / 5.000 m / 11.034 m. The four canonical strings are laid out and logged; the 0.3 s ramp is a numeric interpolation of the same element and lands exactly on the declared string."],
  ["SHA-256 instead of MD5", "WebCrypto has no MD5. The browser reproducibility harness hashes with SHA-256; src/verify.py uses MD5 exactly as R-VER-13 specifies."],
  ["Preview export is WebM", "The browser can only record MediaRecorder/WebM. It is labelled a review artefact everywhere and is never presented as an R-OUT master."],
  ["Voiceover is PLACEHOLDER", "No German neural TTS is reachable from this environment; R-AUD-01's espeak-ng fallback applies to the 1080p test only, so R-GATE-03 keeps the 4K master blocked."],
];

const OPEN_ITEMS = [
  "Approve or reject the 1080p test plan — nothing has been encoded yet, so approval to run the render is still needed.",
  "Provide a German neural de-DE voice (Azure/Edge-TTS/ElevenLabs key, or 8 recorded WAVs in audio/vo/). Until then R-GATE-03 blocks the 4K master.",
  "Confirm files.pythonhosted.org wheel downloads from the render host (curl -I), then run the reachability block above and paste the codes into README §Environment.",
  "Run pytest + src.verify on the render host and paste report.json back — that converts the 29 BLOCKED rows into PASS/FAIL.",
  "Pacing observation (R-TIME-03, reported not changed): 32.0–44.0 s carries one reveal only (nealarp at 36.5 s). It is the longest low-event stretch in the ad.",
];

export function ReportPanel() {
  return (
    <div className="min-h-0 flex-1 overflow-y-auto px-4 py-3">
      <Section title="Render commands" note="README.md §Render — one documented path to both masters">
        <pre className="overflow-x-auto border border-white/10 bg-black/60 p-3 font-mono text-[10.5px] leading-relaxed text-[#9dc4ff]">
{RENDER_CMDS}
        </pre>
      </Section>
      <Section title="Gate status" note="R-GATE">
        <ul className="space-y-1.5 font-mono text-[11px] leading-relaxed text-white/60">
          <li><span className="text-[#fdba74]">HOLDING</span> — no 4K job started (R-GATE-01/02).</li>
          <li><span className="text-[#fdba74]">BLOCKED</span> — voiceover is PLACEHOLDER, so R-GATE-03 refuses the 4K master.</li>
          <li><span className="text-[#9dc4ff]">OK</span> — no upscale fallback exists anywhere in the pipeline (R-GATE-04).</li>
        </ul>
      </Section>
      <Section title="Performance" note="R-PERF">
        <p className="font-mono text-[11px] leading-relaxed text-white/55">
          Static layers (haze, vignette, grain tile), sprites and text-point samples are built once and cached; all
          particle maths is vectorised. Seconds-per-frame at 1080p and the 4× 4K estimate are <span className="text-[#fdba74]">BLOCKED</span>:
          they can only be measured by an actual render, and the ms/frame shown on the Stage header is a browser
          preview number at 0.5× scale — not a substitute (R-PERF-04).
        </p>
      </Section>
      <Section title="Deviations from the spec" note="documented, none silent">
        <dl className="space-y-2">
          {DEVIATIONS.map(([k, v]) => (
            <div key={k} className="border-l border-[#f97316]/40 pl-2.5">
              <dt className="text-[11.5px] font-semibold text-white/85">{k}</dt>
              <dd className="font-mono text-[10.5px] leading-relaxed text-white/50">{v}</dd>
            </div>
          ))}
        </dl>
      </Section>
      <Section title="Open items for the user" note="what unblocks the rest">
        <ol className="space-y-1.5 pl-4 font-mono text-[11px] leading-relaxed text-white/60 marker:text-[#3b82f6]">
          {OPEN_ITEMS.map((o) => (
            <li key={o} className="list-decimal">{o}</li>
          ))}
        </ol>
      </Section>
    </div>
  );
}

function Section({ title, note, children }: { title: string; note?: string; children: React.ReactNode }) {
  return (
    <section className="mb-5">
      <h4 className="font-display text-[11px] font-bold uppercase tracking-[0.24em] text-white/80">{title}</h4>
      {note && <p className="mb-2 mt-0.5 font-mono text-[9.5px] uppercase tracking-[0.14em] text-white/30">{note}</p>}
      {children}
    </section>
  );
}
