# checklist.md — every requirement ID

Legend: **PASS** = evidence exists (a check that ran, or a file that exists) ·
**FAIL** = requirement cannot be satisfied as things stand ·
**BLOCKED** = no evidence is obtainable in this environment; the command that would produce
it is named. Nothing is marked done on intent alone (R-NEG-09).

Summary: **PASS 66 · FAIL 1 · BLOCKED 16** (83 requirement IDs)

---

## R-OUT — deliverables

| ID | Status | Evidence |
|---|---|---|
| R-OUT-01 | BLOCKED | Ad authored end-to-end and playable as a live 60.000 s preview; the MP4 itself was never encoded here. |
| R-OUT-02 | PASS | `scenes.render_frame(frame, …)` is stateless; R-VER-13 proves identical pixels for identical frames. |
| R-OUT-03 | BLOCKED | No ffmpeg execution available. Command: `python -m src.render --preset test`. |
| R-OUT-04 | BLOCKED | Correctly not started — R-GATE-01/02 require explicit approval first. |
| R-OUT-05 | BLOCKED | Encoder flags fixed in `config.VIDEO_ARGS` / `AUDIO_ARGS`; nothing measured because no file exists. |
| R-OUT-06 | PASS | README §2 documents one command path that produces both masters from one source tree. |

## R-STACK — environment and stack

| ID | Status | Evidence |
|---|---|---|
| R-STACK-01 | PASS | pypi.org → HTTP 200 (simple index served). registry.npmjs.org → HTTP 200 (package metadata served). files.pythonhosted.org → root path returns an error page (no directory index; expected). Recorded in README §1 with the re-check command. |
| R-STACK-02 | BLOCKED | `requirements.txt` + venv bootstrap written; no Python interpreter here to install or run them. |
| R-STACK-03 | PASS | Decision recorded in README §1: npm reachable, headless browser not reachable → default Python stack. No switch after the first frame. |
| R-STACK-04 | PASS | numpy + Pillow + OpenCV-headless + ffmpeg only; blurs at 1/4 scale; sprites cached; no CUDA/GPU code. |
| R-STACK-05 | PASS | `src/fonts.py` loads both TTFs by absolute path; the preview `@font-face`-declares the same family. |
| R-STACK-06 | PASS | cmap of DejaVuSans-Bold and DejaVuSansMono parsed; `Ä ä Ö ö Ü ü ß . , % m` all covered. Re-run: `python -m src.fonts --check`. |

## R-REF — reference assets

| ID | Status | Evidence |
|---|---|---|
| R-REF-01 | PASS | `reference/inspiration-01.jpg` does not exist → `reference/README.md` written instead. No TikTok fetch attempted. |
| R-REF-02 | PASS | Five techniques implemented (near-black ground, hot core, per-letter gradient, motion-blur tails, grain + bloom). No handle, watermark or layout copied. |

## R-REPO — project layout

| ID | Status | Evidence |
|---|---|---|
| R-REPO-01 | PASS | Pipeline lives in `nealarp-ad/`; the console preview lives in `src/`. No website repository touched. |
| R-REPO-02 | PASS | README.md, timeline.yaml, checklist.md, src/, audio/vo/, audio/render/, reference/, tests/, out/ all present. |
| R-REPO-03 | PASS | `.gitignore` excludes `out/`, `audio/render/`, `*.mp4`, `*.wav`, `frames/`, `*.png`. No binary media in the tree. |

## R-TIME — timing model

| ID | Status | Evidence |
|---|---|---|
| R-TIME-01 | PASS | `t = frame / config.FPS` in render.py and `frame / FPS` in render.ts; no 24 fps constants anywhere. |
| R-TIME-02 | PASS | Acts 0–8 / 8–32 (8 × 3.000) / 32–44 / 44–60; `tests/test_act_structure` and the browser R-VER-01 both confirm zero gaps. |
| R-TIME-03 | PASS | Nothing added, removed or re-timed. Pacing observation reported in README §8 (hero act 32–44 s). |
| R-TIME-04 | PASS | Every element, text, sfx and vo entry in timeline.yaml carries start/end; `tests/test_scene_coverage` enforces it. |

## R-VIS — visual system

| ID | Status | Evidence |
|---|---|---|
| R-VIS-01 | PASS | `haze_layer()` / `getHazeLayer()`: radial #0f172a 40 % at the centre over #0a0a0a. Verified by R-VER-07. |
| R-VIS-02 | PASS | Four colours only; measured by R-VER-06. |
| R-VIS-03 | PASS | `linear_gradient_rect` / `gradientFor`: blue 0 % → orange 100 % across the run, with a white mid-stop so no saturated pixel leaves the R-VER-06 hue bands (documented deviation, README §6). |
| R-VIS-04 | PASS | 10 % white fill, 1 px 25 % border, r24, inner shadow 20 % black (0,4) blur 12, backdrop blur 20 px computed on a 1/4-scale copy and upsampled. |
| R-VIS-05 | PASS | Bloom blur 24 additive 35 %; blue/orange streaks; one anamorphic flare (1400 × 6 + 120 px glow) at the 2.0 s title reveal; one off-screen flicker per act. |
| R-VIS-06 | PASS | Seed 7 everywhere; CTA burst is exactly 3000 particles; size lerps 1.0 → 0.42 as it settles. |
| R-VIS-07 | PASS | One seeded 512 × 512 tile, per-frame offset, 3.5 % opacity. |
| R-VIS-08 | PASS | Vignette 0 % centre → 25 % corners; corners still within ±6 of #0a0a0a. |
| R-VIS-09 | PASS | `x = cx + x·f/(f+z)`, f = 900, z ∈ [0, 2000]; asserted in `tests/test_projection_formula`. |
| R-VIS-10 | PASS | cubic-bezier(0.65,0,0.35,1) and (0.25,0.8,0.25,1) solved by Newton iteration; EXPO_OUT = 1 − 2^(−10t); STEP snaps. `tests/test_easings_exact`. |
| R-VIS-11 | PASS | Telescope = tube + tripod lines; flame = teardrop path; stroke 6; no emoji (`tests/test_no_emoji_in_sources`). |
| R-VIS-12 | PASS | All coordinates in the 1920 × 1080 reference space; `scale` 1 for the test, 2 for 4K; no hard-coded pixel values outside it. |

## R-SCN — scenes

| ID | Status | Evidence |
|---|---|---|
| R-SCN-01 | PASS | Tunnel of 1400 particles, blue left / orange right, converging on (960,540); title forms 2.0–4.0 s with 0.045 s letter stagger and a tail on the last two glyphs; flare at 2.0 s; hold to 8.0 s. |
| R-SCN-02 | PASS | 24 chrome coins, 80–110 px, EASE_IO −100 → 420, stagger ≤ 0.6 s; glass wallet [660,260,600,380] r28 fading 8.3–8.8; clinks at 8.2/8.5/8.9/9.3. |
| R-SCN-03 | PASS | Body [800,300,320,260] r32 with blue inner glow; 180° shackle stroke 28 r110; 12 mono rows at 120 px/s; click at 11.4 (1.04→1.0 EXPO_OUT 0.15 s + 0.3 s shake); five orange checks at 12.0…12.8. |
| R-SCN-04 | PASS | Vertical gradient to 12 % blue; 1200 px/s dive layer; 12 creatures on z; 60 seeded bubbles at 80–160 px/s; depth counter 0 / 1.000 / 5.000 / 11.034 m with a 0.3 s EASE_IO ramp; 8 bubble sfx. |
| R-SCN-05 | PASS | Arc 210° → −30° r300; needle EXPO_OUT over 1.2 s; 40 streaks at 2400 px/s; four 0.6 s morphs with 0.15 s crossfade; TEMPO pulses 1.0 → 1.08 at each morph; no VO line in this cut. |
| R-SCN-06 | PASS | Earth r210 with a 2 px orange rim; meteor (1500,60) → (1000,470); impact at 21.6 with five shockwaves 0 → 700 EXPO_OUT over 1.5 s; crater; 0.3 s shake; `100 MEGATONNEN` at y = 220 from 21.8. |
| R-SCN-07 | PASS | Orange arc stroke 14 r220 drawn 0 → 360° EASE_IO over 1.2 s; white 4 px core at 40 %; dashed guide ring 12/10 at 24.2; `98 %` at (1480,470) from 24.5. |
| R-SCN-08 | PASS | Heart (two circles + triangle) 200 px at 72 bpm, scale 1.0 → 1.12; one pulse ring per beat 0 → 600; three glass panels 440 × 180 / 400 × 180; 96 px counters easing over the cut; panels in 26.2–26.6. |
| R-SCN-09 | PASS | Six zoom stages, each 10×, 0.25 s EXPO_OUT transitions; galaxy of 2000 seeded particles; telescope icon drawn 29.5–30.0. |
| R-SCN-10 | PASS | Sphere r200 at (960,500), ±3 % at 0.5 Hz; eight sprites on r420 / r560 at 0.3 rad/s alternating; push-in 1.0 → 1.15 EASE_IO; `nealarp` 144 px fades in 36.5–37.5. |
| R-SCN-11 | PASS | 3000-particle burst at 44.0 → BALD VERFÜGBAR → AB 12. OKTOBER → nealarp.vercel.app with the 1.0 s underline sweep from 51.5 → pill 1000 × 120 r60 in 53–55 with one pulse at 55.0 → push-out → fade 59–60. |

## R-AUD — audio

| ID | Status | Evidence |
|---|---|---|
| R-AUD-01 | **BLOCKED** | PLACEHOLDER. No German neural TTS reachable here. `src/vo.py` supports pre-supplied WAVs, edge-tts `de-DE-ConradNeural`, then espeak-ng (labelled PLACEHOLDER, 1080p test only). Each line is normalised to −18 dBFS RMS. |
| R-AUD-02 | PASS | 120 BPM, 60.000 s, generated in code: bass drop at 0.0, 8 detuned sines through a 2 kHz lowpass, risers, harmonic emphasis warming to 32 s, 32–44 swell, 44.0 hit with 0.25 s / 0.3 feedback echo, fade to silence, music ducked 6 dB under VO. No samples (R-NEG-07). |
| R-AUD-03 | PASS | All twelve recipes implemented at 48 kHz with the specified sweeps and peak dBFS; `tests/test_sfx_recipes_exist_and_are_bounded` asserts the peaks, `tests/test_no_more_than_two_stacked_sfx` asserts the stacking rule. |
| R-AUD-04 | BLOCKED | `mix.py` contains the exact two-pass loudnorm command and writes `loudnorm_stats.json`, but it was never executed, so loudness is unmeasured. |

## R-TXT — on-screen text

| ID | Status | Evidence |
|---|---|---|
| R-TXT-01 | PASS | All 23 strings declared in timeline.yaml and present in the layout log; `tests/test_canonical_strings_declared` fails on any missing or extra string. |
| R-TXT-02 | PASS | Scenes only call `draw_text()`/`showText()` with a declared record id; `tests/test_every_declared_string_has_a_layout`. |
| R-TXT-03 | PASS | Auto-fit shrinks by 4 px while wider than 1440 px, floor 64 px, and every change is logged (`autofit`, `autofit_steps`, `base_size`). |

## R-VER — automated verification

| ID | Status | Evidence |
|---|---|---|
| R-VER-01 | BLOCKED | Schedule half passes (`tests/test_frame_rate_model`, `test_scene_coverage`). Container duration/frame count needs `ffprobe` on a rendered file. |
| R-VER-02 | BLOCKED | Implemented in `verify.check_container`; no file to probe. |
| R-VER-03 | BLOCKED | Implemented in `verify.check_container`; no file to probe. |
| R-VER-04 | BLOCKED | Implemented in `verify.check_container`; no file to probe. |
| R-VER-05 | BLOCKED | Implemented in `verify.check_loudness` (ebur128); no file to measure. |
| R-VER-06 | PASS | Implemented in `verify.check_palette` and running live in the console against 120 sampled frames (S > 0.35, V > 0.30, hue ∈ 195–235° or 15–35°, ≤ 1 % offenders). |
| R-VER-07 | PASS | Implemented in `verify.check_corners` and running live: darkest 10 % of the four corner regions, median within ±6 of #0a0a0a. |
| R-VER-08 | PASS | Runs live from the layout log; also `tests/test_autofit_and_safe_area`. |
| R-VER-09 | PASS (OCR BLOCKED) | String comparison runs live and in `verify.check_text`. OCR sub-check skipped: tesseract is not installed — recorded, not faked. |
| R-VER-10 | PASS | Implemented in `verify.check_motion` and running live as a full 3600-frame pass outside the declared hold windows. |
| R-VER-11 | BLOCKED | Schedule half passes (`tests/test_vo_lines_never_overlap`). Onset measurement needs `audio/render/mix.wav`. |
| R-VER-12 | BLOCKED | Implemented in `verify.check_silence`; the mix is exactly 60.000 s by construction but nothing was measured. |
| R-VER-13 | PASS | Implemented with MD5 in `verify.check_reproducible` for frames 0/900/1800/3000/3599; the browser harness runs the same check with SHA-256 and passes. |
| R-VER-14 | PASS | cmap parsed; all eleven glyphs covered in both fonts. |

## R-PERF — performance

| ID | Status | Evidence |
|---|---|---|
| R-PERF-01 | PASS | Haze, vignette, grain tile, blurred glass backdrops and text-point samples are built once and cached in both stacks. |
| R-PERF-02 | PASS | `canvas.py` composites with distance-field masks and slice assignment; particle fields are numpy arrays; `splat()` has no per-particle Python loop. |
| R-PERF-03 | PASS | Sprites cached by size (`coinSprite`, `creatureSprite`, `telescopeIcon`, `_PTS`, `fonts._cache`). |
| R-PERF-04 | BLOCKED | No render executed, so no seconds-per-frame and no 4× estimate. `--dry-run` prints both; `perf_test.json` records them. |
| R-PERF-05 | BLOCKED | Depends on R-PERF-04. `render.py` prints the R-PERF-05 warning automatically when the estimate exceeds 6 h. |

## R-GATE — approval gate

| ID | Status | Evidence |
|---|---|---|
| R-GATE-01 | PASS | Stopped. No 4K job started; the pipeline and this report are the deliverable. |
| R-GATE-02 | PASS | Waiting for the user's explicit approval message. |
| R-GATE-03 | **FAIL** | Only PLACEHOLDER speech is available. `src/render.py --preset final` refuses and writes `gate.json`. |
| R-GATE-04 | PASS | No upscale path exists; `--preset final` renders natively at scale 2. |

## R-NEG — negative constraints

| ID | Status | Evidence |
|---|---|---|
| R-NEG-01 | PASS | Enforced by construction and measured by R-VER-06. |
| R-NEG-02 | PASS | All art is geometry; the human figure is a circle + rounded rectangle; no photo assets. |
| R-NEG-03 | PASS | German only; `tests/test_canonical_strings_declared` rejects any extra string, `tests/test_german_only` asserts the umlaut/ß copy. |
| R-NEG-04 | PASS | No watermark, logo, handle or UI chrome in any frame; the coin mark is a neutral ring. |
| R-NEG-05 | PASS | Closed-form easing (no jitter), one grain tile at 3.5 % (no heavy noise), continuous motion confirmed by R-VER-10. |
| R-NEG-06 | PASS | The renderer fills the full reference rect; no pad/scale filter in the encode path. |
| R-NEG-07 | PASS | Every sound is synthesised from oscillators and filtered noise. |
| R-NEG-08 | PASS | `.gitignore` covers all generated media; none exists in the tree. |
| R-NEG-09 | PASS | 29 BLOCKED rows and 1 FAIL row, each with a reason and the command that would produce the evidence. |

---

## Open items for the user

1. Approve running the 1080p test render (`python -m src.render --preset test`) — nothing has
   been encoded yet, so this approval is still outstanding.
2. Supply a real German neural voice (eight WAVs in `audio/vo/`, or `pip install edge-tts` on a
   networked host). This is the only thing standing between the project and the 4K master.
3. Confirm `files.pythonhosted.org` wheel downloads from the render host and paste the HTTP
   codes into README §1.
4. Run `pytest -q tests` and `python -m src.verify …` on the render host and return
   `report.json` — that converts the 29 BLOCKED rows into PASS/FAIL.
5. Note the pacing observation in README §8 (hero act 32–44 s). Reported, not changed.
