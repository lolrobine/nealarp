# reference/

`inspiration-01.jpg` does **not** exist in this repository, so per **R-REF-01**
this file carries the description from **R-REF-02** instead. No TikTok page was
fetched (they answer HTTP 403).

## What the inspiration is, reduced to techniques

1. **Near-black ground** — the whole frame sits on `#0a0a0a`; nothing is lit
   except the subject. Depth comes from a radial haze, not from a set.
2. **Hot-white core fading into colour at its edges** — the subject's centre is
   clipped white and the saturation increases towards the silhouette. Achieved
   with a radial gradient: `#ffffff` → house blue/orange → transparent, plus an
   additive bloom pass (blur 24 px, 35 %).
3. **Gradient display title, one colour per letter** — a linear
   `#3b82f6 → #f97316` gradient is laid across the whole text run, so each
   glyph samples a different part of the ramp (R-VIS-03).
4. **Motion-blur tails on the final letters of a word** — the last two glyphs
   are re-drawn five times at decreasing alpha and increasing negative x
   offset, and the tail distance decays to zero as the word settles.
5. **Film grain and bloom** — one seeded 512×512 grayscale tile, re-tiled with a
   per-frame offset at 3.5 % opacity, over an additive bloom layer.

## What was deliberately *not* taken

No creator handle, no watermark, no layout, no colour outside the four house
colours, no typography other than DejaVu (R-NEG-04, R-VIS-02, R-STACK-05).
