"""
fonts.py — R-STACK-05 / R-STACK-06 / R-VER-14.

Fonts are loaded explicitly by absolute path. Nothing falls back to a system
default. `python -m src.fonts --check` prints the coverage evidence that the
README records.
"""
from __future__ import annotations

import sys
from functools import lru_cache

from PIL import Image, ImageDraw, ImageFont

from . import config

_cache: dict[tuple[str, int], ImageFont.FreeTypeFont] = {}


def load(path: str, size: int) -> ImageFont.FreeTypeFont:
    """Load a TTF by absolute path and cache it per size (R-PERF-03)."""
    key = (path, int(size))
    if key not in _cache:
        _cache[key] = ImageFont.truetype(path, int(size))
    return _cache[key]


def bold(size: int) -> ImageFont.FreeTypeFont:
    return load(config.FONT_BOLD, size)


def mono(size: int) -> ImageFont.FreeTypeFont:
    return load(config.FONT_MONO, size)


def _cmap_coverage(path: str) -> set[int]:
    """Parse the cmap table directly — no fontTools dependency."""
    import struct

    with open(path, "rb") as fh:
        data = fh.read()
    num_tables = struct.unpack(">H", data[4:6])[0]
    cmap_off = None
    for i in range(num_tables):
        rec = 12 + i * 16
        tag = data[rec : rec + 4]
        if tag == b"cmap":
            cmap_off = struct.unpack(">I", data[rec + 8 : rec + 12])[0]
    if cmap_off is None:
        raise RuntimeError(f"{path}: no cmap table")
    n_sub = struct.unpack(">H", data[cmap_off + 2 : cmap_off + 4])[0]
    best, best_rank = None, -1
    for i in range(n_sub):
        rec = cmap_off + 4 + i * 8
        pid, eid = struct.unpack(">HH", data[rec : rec + 4])
        off = cmap_off + struct.unpack(">I", data[rec + 4 : rec + 8])[0]
        fmt = struct.unpack(">H", data[off : off + 2])[0]
        rank = 0
        if pid == 3 and eid == 10 and fmt == 12:
            rank = 100
        elif pid == 3 and eid == 1 and fmt == 4:
            rank = 80
        elif pid == 0:
            rank = 60
        if rank > best_rank:
            best_rank, best, best_fmt = rank, off, fmt
    covered: set[int] = set()
    if best_fmt == 12:
        groups = struct.unpack(">I", data[best + 12 : best + 16])[0]
        for g in range(groups):
            o = best + 16 + g * 12
            start, end, gid = struct.unpack(">III", data[o : o + 12])
            if gid:
                covered.update(range(start, end + 1))
    else:
        seg_count = struct.unpack(">H", data[best + 6 : best + 8])[0] // 2
        ends = struct.unpack(f">{seg_count}H", data[best + 14 : best + 14 + 2 * seg_count])
        starts_at = best + 16 + 2 * seg_count
        starts = struct.unpack(f">{seg_count}H", data[starts_at : starts_at + 2 * seg_count])
        deltas_at = starts_at + 2 * seg_count
        deltas = struct.unpack(f">{seg_count}h", data[deltas_at : deltas_at + 2 * seg_count])
        for i in range(seg_count):
            if (starts[i] + deltas[i]) & 0xFFFF != 0:
                covered.update(range(starts[i], ends[i] + 1))
    return covered


def check_coverage() -> dict[str, dict[str, bool]]:
    """Return {font: {glyph: covered}} for the characters R-STACK-06 demands."""
    report: dict[str, dict[str, bool]] = {}
    for name, path in (("DejaVuSans-Bold.ttf", config.FONT_BOLD), ("DejaVuSansMono.ttf", config.FONT_MONO)):
        try:
            covered = _cmap_coverage(path)
        except (OSError, RuntimeError) as exc:  # font missing on this host
            report[name] = {g: False for g in config.REQUIRED_GLYPHS}
            report[name]["__error__"] = str(exc)  # type: ignore[assignment]
            continue
        report[name] = {g: ord(g) in covered for g in config.REQUIRED_GLYPHS}
    return report


def render_probe() -> dict[str, bool]:
    """
    Fallback evidence when the TTF cannot be parsed: rasterise each glyph and
    require non-empty ink that differs from the .notdef box.
    """
    out: dict[str, bool] = {}
    for g in config.REQUIRED_GLYPHS:
        img = Image.new("L", (128, 128), 0)
        ImageDraw.Draw(img).text((16, 16), g, font=bold(72), fill=255)
        ref = Image.new("L", (128, 128), 0)
        ImageDraw.Draw(ref).text((16, 16), "\uffff", font=bold(72), fill=255)
        out[g] = bool(sum(img.getdata())) and list(img.getdata()) != list(ref.getdata())
    return out


def main() -> int:
    if "--check" in sys.argv:
        ok = True
        for font, glyphs in check_coverage().items():
            for g, covered in glyphs.items():
                if g == "__error__":
                    print(f"{font}: ERROR {covered}")
                    ok = False
                    continue
                print(f"{font}: {g!r} U+{ord(g):04X} {'COVERED' if covered else 'MISSING'}")
                ok = ok and bool(covered)
        print("R-STACK-06 / R-VER-14:", "PASS" if ok else "FAIL")
        return 0 if ok else 1
    print("usage: python -m src.fonts --check")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
