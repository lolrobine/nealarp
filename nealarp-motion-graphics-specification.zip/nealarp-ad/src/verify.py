"""
verify.py — R-VER-01 … R-VER-14, measured against the rendered artefacts.

    python -m src.verify out/nealarp-ad-1080p-test.mp4 --report report.json

Every check returns PASS / FAIL / BLOCKED with the evidence string that goes
into the final report. Nothing is asserted without a measurement (R-NEG-09).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np

from . import config, fonts, layout, scenes

CANON_TEXT = [
    "SPIELE UND ZEUG", "GELD AUSGEBEN", "DAS PASSWORT-SPIEL", "DIE TIEFSEE",
    "0 m", "1.000 m", "5.000 m", "11.034 m", "TEMPO", "ASTEROIDEN-WERFER",
    "100 MEGATONNEN", "PERFEKTER KREIS", "98 %", "LEBENSSTATISTIK",
    "HERZSCHLÄGE", "ATEMZÜGE", "SCHRITTE", "GRÖSSE DES WELTALLS", "nealarp",
    "BALD VERFÜGBAR", "AB 12. OKTOBER", "nealarp.vercel.app",
    "ERHÄLTLICH AB 12. OKTOBER",
]

BLUE_HUE = (195.0, 235.0)
ORANGE_HUE = (15.0, 35.0)


def ffmpeg_exe() -> str:
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def ffprobe_exe() -> str:
    exe = shutil.which("ffprobe")
    if exe:
        return exe
    return ffmpeg_exe().replace("ffmpeg", "ffprobe")


def probe(path: Path) -> dict:
    out = subprocess.run(
        [ffprobe_exe(), "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path)],
        capture_output=True, text=True, check=True,
    )
    return json.loads(out.stdout)


def decode_at(path: Path, times: list[float], width: int, height: int) -> list[np.ndarray]:
    """Decode one frame per requested timestamp through a rawvideo pipe."""
    frames = []
    for t in times:
        proc = subprocess.run(
            [ffmpeg_exe(), "-v", "error", "-ss", f"{t:.3f}", "-i", str(path),
             "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24",
             "-vf", f"scale={width}:{height}", "-"],
            capture_output=True, check=True,
        )
        buf = np.frombuffer(proc.stdout, dtype=np.uint8)
        if buf.size < width * height * 3:
            continue
        frames.append(buf[: width * height * 3].reshape(height, width, 3))
    return frames


def rgb_to_hsv(rgb: np.ndarray) -> np.ndarray:
    a = rgb.astype(np.float32) / 255.0
    mx = a.max(-1)
    mn = a.min(-1)
    d = mx - mn
    h = np.zeros_like(mx)
    idx = (d > 0) & (mx == a[..., 0])
    h[idx] = ((a[..., 1] - a[..., 2]) / d)[idx] % 6
    idx = (d > 0) & (mx == a[..., 1])
    h[idx] = ((a[..., 2] - a[..., 0]) / d)[idx] + 2
    idx = (d > 0) & (mx == a[..., 2])
    h[idx] = ((a[..., 0] - a[..., 1]) / d)[idx] + 4
    h = (h * 60) % 360
    s = np.where(mx > 0, d / np.maximum(mx, 1e-6), 0)
    return np.stack([h, s, mx], axis=-1)


# --------------------------------------------------------------------- checks
def check_container(path: Path, expect_w: int, expect_h: int) -> list[dict]:
    res = []
    try:
        info = probe(path)
    except Exception as exc:  # no file, no ffprobe
        for cid in ("R-VER-01", "R-VER-02", "R-VER-03", "R-VER-04"):
            res.append({"id": cid, "status": "BLOCKED", "evidence": f"probe failed: {exc}"})
        return res
    v = next((s for s in info["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in info["streams"] if s["codec_type"] == "audio"), None)
    dur = float(info["format"].get("duration", 0))
    frames = int(v.get("nb_frames") or round(dur * config.FPS))
    res.append({"id": "R-VER-01",
                "status": "PASS" if abs(dur - 60.0) <= 0.02 and frames == 3600 else "FAIL",
                "evidence": f"duration={dur:.4f}s (60.000±0.02), frames={frames} (3600)"})
    num, den = (v.get("r_frame_rate") or "0/1").split("/")
    fps = float(num) / float(den or 1)
    res.append({"id": "R-VER-02",
                "status": "PASS" if v and v["width"] == expect_w and v["height"] == expect_h and abs(fps - 60) < 1e-6 else "FAIL",
                "evidence": f"{v['width']}x{v['height']} @ {v.get('r_frame_rate')} (expect {expect_w}x{expect_h} @ 60/1)"})
    ok3 = v and v.get("codec_name") == "h264" and v.get("profile") == "High" and v.get("pix_fmt") == "yuv420p"
    res.append({"id": "R-VER-03", "status": "PASS" if ok3 else "FAIL",
                "evidence": f"{v.get('codec_name')} profile={v.get('profile')} pix_fmt={v.get('pix_fmt')}"})
    ok4 = a and a.get("codec_name") == "aac" and int(a.get("sample_rate", 0)) == 48000 and int(a.get("channels", 0)) == 2
    res.append({"id": "R-VER-04", "status": "PASS" if ok4 else "FAIL",
                "evidence": (f"{a.get('codec_name')} {a.get('sample_rate')} Hz {a.get('channels')} ch"
                             if a else "no audio stream")})
    return res


def check_loudness(path: Path) -> dict:
    try:
        proc = subprocess.run(
            [ffmpeg_exe(), "-hide_banner", "-nostats", "-i", str(path),
             "-filter_complex", "ebur128=framelog=verbose", "-f", "null", "-"],
            capture_output=True, text=True, check=True,
        )
    except Exception as exc:
        return {"id": "R-VER-05", "status": "BLOCKED", "evidence": f"ebur128 could not run: {exc}"}
    txt = proc.stderr
    i = tp = None
    if "I:" in txt:
        tail = txt[txt.rindex("Summary:"):] if "Summary:" in txt else txt
        for line in tail.splitlines():
            line = line.strip()
            if line.startswith("I:") and i is None:
                i = float(line.split()[1])
            if line.startswith("Peak:") and tp is None:
                tp = float(line.split()[1])
    if i is None or tp is None:
        return {"id": "R-VER-05", "status": "BLOCKED", "evidence": "could not parse the ebur128 summary"}
    ok = abs(i + 14) <= 1 and tp <= -1.0
    return {"id": "R-VER-05", "status": "PASS" if ok else "FAIL",
            "evidence": f"integrated {i:.2f} LUFS (−14±1), true peak {tp:.2f} dBTP (≤ −1)"}


def check_palette(frames: list[np.ndarray]) -> dict:
    qualified = bad = 0
    for f in frames:
        hsv = rgb_to_hsv(f)
        sel = (hsv[..., 1] > 0.35) & (hsv[..., 2] > 0.30)
        h = hsv[..., 0][sel]
        qualified += int(sel.sum())
        in_blue = (h >= BLUE_HUE[0]) & (h <= BLUE_HUE[1])
        in_orange = (h >= ORANGE_HUE[0]) & (h <= ORANGE_HUE[1])
        bad += int((~(in_blue | in_orange)).sum())
    pct = (bad / qualified * 100) if qualified else 0.0
    return {"id": "R-VER-06", "status": "PASS" if pct <= 1.0 else "FAIL",
            "evidence": f"{qualified} saturated px sampled, {bad} outside blue/orange = {pct:.3f} % (limit 1 %)"}


def check_corners(frames: list[np.ndarray]) -> dict:
    worst = 0.0
    for f in frames:
        h, w, _ = f.shape
        boxes = [f[:54, :96], f[:54, w - 96:], f[h - 54:, :96], f[h - 54:, w - 96:]]
        for b in boxes:
            flat = b.reshape(-1, 3).astype(np.float32)
            lum = flat.sum(1)
            cut = np.partition(lum, max(1, len(lum) // 10))[max(1, len(lum) // 10)]
            darkest = flat[lum <= cut]
            if len(darkest) == 0:
                continue
            med = np.median(darkest, axis=0)
            worst = max(worst, float(np.abs(med - np.array([10, 10, 10])).max()))
    return {"id": "R-VER-07", "status": "PASS" if worst <= 6 else "FAIL",
            "evidence": f"worst corner median deviation from #0a0a0a = {worst:.1f} / 6.0 per channel"}


def check_safe_area() -> dict:
    if not config.LAYOUT_LOG.exists():
        return {"id": "R-VER-08", "status": "BLOCKED", "evidence": "layout log missing — run src.render first"}
    data = json.loads(config.LAYOUT_LOG.read_text(encoding="utf-8"))
    bad = [e for e in data["entries"] if not e["safe_area_ok"]]
    return {"id": "R-VER-08", "status": "PASS" if not bad else "FAIL",
            "evidence": (f"all {len(data['entries'])} boxes inside 96/54 px safe area"
                         if not bad else "outside: " + ", ".join(e["id"] for e in bad))}


def check_text() -> dict:
    if not config.LAYOUT_LOG.exists():
        return {"id": "R-VER-09", "status": "BLOCKED", "evidence": "layout log missing"}
    data = json.loads(config.LAYOUT_LOG.read_text(encoding="utf-8"))
    logged = {e["string"] for e in data["entries"]}
    missing = [s for s in CANON_TEXT if s not in logged]
    extra = [s for s in logged if s not in CANON_TEXT]
    ocr = "tesseract not installed — OCR skipped" if not shutil.which("tesseract") else "tesseract present"
    status = "PASS" if not missing and not extra else "FAIL"
    return {"id": "R-VER-09", "status": status,
            "evidence": f"missing={missing or 'none'} extra={extra or 'none'}; {ocr}"}


def check_motion(path: Path, width: int = 480, height: int = 270) -> dict:
    times = [i * 0.5 for i in range(120)]
    frames = decode_at(path, times, width, height)
    if len(frames) < 10:
        return {"id": "R-VER-10", "status": "BLOCKED", "evidence": "could not decode enough frames"}
    diffs = [float(np.abs(frames[i + 1].astype(np.int16) - frames[i].astype(np.int16)).mean())
             for i in range(len(frames) - 1)]
    holds = [(4.0, 8.0), (8.6, 10.6), (12.8, 13.6), (15.6, 16.6), (25.7, 26.0)]
    dead = [times[i] for i, d in enumerate(diffs)
            if d == 0 and not any(a <= times[i] < b for a, b in holds)]
    return {"id": "R-VER-10", "status": "PASS" if not dead else "FAIL",
            "evidence": f"{len(diffs)} windows compared, mean abs diff min={min(diffs):.3f} "
                        f"max={max(diffs):.3f}; dead windows outside hold_frames: {dead or 'none'}"}


def check_audio_timing(mix: Path) -> dict:
    if not mix.exists():
        return {"id": "R-VER-11", "status": "BLOCKED", "evidence": f"{mix} missing — run src.mix"}
    import wave
    with wave.open(str(mix), "rb") as w:
        sr = w.getframerate()
        x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
        x = x.reshape(-1, w.getnchannels()).mean(1)
    # onset = first sample above −45 dBFS inside each declared window
    tl = config.load_timeline()
    worst = 0.0
    problems = []
    for line in tl["audio"]["vo"]["lines"]:
        start = int(line["at"] * sr)
        win = x[start : start + int(1.5 * sr)]
        if len(win) == 0:
            continue
        above = np.nonzero(np.abs(win) > 10 ** (-45 / 20))[0]
        if len(above) == 0:
            problems.append(f"{line['id']}: silent")
            continue
        off = above[0] / sr
        worst = max(worst, abs(off))
        if off > 0.05:
            problems.append(f"{line['id']}: onset +{off:.3f}s")
    status = "PASS" if not problems else "FAIL"
    return {"id": "R-VER-11", "status": status,
            "evidence": f"max |onset − declared| = {worst:.3f} s (±0.05 allowed); {problems or 'all lines on time'}"}


def check_silence(mix: Path) -> dict:
    if not mix.exists():
        return {"id": "R-VER-12", "status": "BLOCKED", "evidence": f"{mix} missing"}
    import wave
    with wave.open(str(mix), "rb") as w:
        sr = w.getframerate()
        n = w.getnframes()
        x = np.frombuffer(w.readframes(n), dtype=np.int16).astype(np.float32) / 32768
    tail = x[int(60.0 * sr) :]
    if len(tail) == 0:
        return {"id": "R-VER-12", "status": "PASS",
                "evidence": f"the mix is exactly {n / sr:.3f} s long — there is no audio after 60.000 s"}
    rms = float(np.sqrt(np.mean(tail ** 2)))
    db = 20 * np.log10(rms) if rms > 1e-9 else -120.0
    return {"id": "R-VER-12", "status": "PASS" if db < -70 else "FAIL",
            "evidence": f"tail RMS {db:.1f} dBFS after 60.0 s (limit −70)"}


def check_reproducible(scale: float = 1.0) -> dict:
    tl = config.load_timeline()
    records = layout.build_records(tl, scale)
    haze = scenes.haze_layer(scale)
    rows = []
    ok = True
    for f in (0, 900, 1800, 3000, 3599):
        a = hashlib.md5(scenes.render_frame(f, records, scale, haze).tobytes()).hexdigest()
        b = hashlib.md5(scenes.render_frame(f, records, scale, haze).tobytes()).hexdigest()
        rows.append(f"{f}:{a[:10]}{'=' if a == b else '!='}")
        ok = ok and a == b
    return {"id": "R-VER-13", "status": "PASS" if ok else "FAIL",
            "evidence": "MD5 of frames " + " ".join(rows)}


def check_fonts() -> dict:
    report = fonts.check_coverage()
    missing = [f"{f}:{g}" for f, gl in report.items() for g, ok in gl.items() if not ok]
    return {"id": "R-VER-14", "status": "PASS" if not missing else "FAIL",
            "evidence": "cmap coverage complete" if not missing else "missing " + ", ".join(missing)}


def run(path: str, report_out: str | None = None) -> list[dict]:
    p = Path(path)
    preset = "final" if "2160" in p.name else "test"
    cfg = config.PRESETS[preset]
    results: list[dict] = []
    results += check_container(p, cfg["width"], cfg["height"])
    results.append(check_loudness(p))
    times = [i * 0.5 for i in range(120)]
    frames = decode_at(p, times, 960, 540) if p.exists() else []
    if frames:
        results.append(check_palette(frames))
        results.append(check_corners(frames))
    else:
        results.append({"id": "R-VER-06", "status": "BLOCKED", "evidence": "no frames decoded"})
        results.append({"id": "R-VER-07", "status": "BLOCKED", "evidence": "no frames decoded"})
    results.append(check_safe_area())
    results.append(check_text())
    if frames:
        results.append(check_motion(p))
    else:
        results.append({"id": "R-VER-10", "status": "BLOCKED", "evidence": "no frames decoded"})
    results.append(check_audio_timing(config.RENDER_DIR / "mix.wav"))
    results.append(check_silence(config.RENDER_DIR / "mix.wav"))
    results.append(check_reproducible(1.0))
    results.append(check_fonts())
    results.sort(key=lambda r: r["id"])
    for r in results:
        print(f"{r['status']:8s} {r['id']:10s} {r['evidence'][:150]}")
    if report_out:
        Path(report_out).write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"[verify] report -> {report_out}")
    return results


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--report", default=None)
    args = ap.parse_args()
    res = run(args.video, args.report)
    return 0 if all(r["status"] != "FAIL" for r in res) else 1


if __name__ == "__main__":
    raise SystemExit(main())
