"""
config.py — constants, paths and timeline loading.

All coordinates live in the 1920x1080 reference space (R-VIS-12). The 4K
preset renders the same numbers with SCALE = 2.
"""
from __future__ import annotations

import os
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------- timing
FPS = 60                      # R-TIME-01: t = frame / 60
DURATION = 60.000             # R-TIME-02
TOTAL_FRAMES = int(round(DURATION * FPS))   # 3600 (R-VER-01)

# ---------------------------------------------------------------- geometry
REF_W, REF_H = 1920, 1080
SAFE = {"left": 96, "right": 96, "top": 54, "bottom": 54}
AUTOFIT_MAX_WIDTH = 1440      # 75 % of the frame
AUTOFIT_MIN_SIZE = 64
AUTOFIT_STEP = 4

# ---------------------------------------------------------------- palette (R-VIS-02)
BLUE = (59, 130, 246)         # #3b82f6
ORANGE = (249, 115, 22)       # #f97316
WHITE = (255, 255, 255)
NEAR_BLACK = (10, 10, 10)     # #0a0a0a
HAZE = (15, 23, 42)           # #0f172a, 40 % at the centre

PALETTE_HEX = {
    "blue": "#3b82f6",
    "orange": "#f97316",
    "white": "#ffffff",
    "near_black": "#0a0a0a",
    "haze": "#0f172a",
}

# ---------------------------------------------------------------- fx constants
SEED = 7                      # R-VIS-06
PARTICLE_CAP = 3000           # R-VIS-06
GRAIN_TILE = 512              # R-VIS-07
GRAIN_OPACITY = 0.035
VIGNETTE_CORNER = 0.25        # R-VIS-08
FOCAL = 900                   # R-VIS-09
Z_RANGE = (0, 2000)
BLOOM_BLUR = 24
BLOOM_STRENGTH = 0.35

# ---------------------------------------------------------------- audio
SR = 48000                    # R-AUD-03
CHANNELS = 2
BPM = 120                     # R-AUD-02
LOUDNORM = {"i": -14, "tp": -1, "lra": 11}
VO_RMS_DBFS = -18.0

# ---------------------------------------------------------------- fonts (R-STACK-05)
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
REQUIRED_GLYPHS = ["Ä", "ä", "Ö", "ö", "Ü", "ü", "ß", ".", ",", "%", "m"]

# ---------------------------------------------------------------- paths
TIMELINE = ROOT / "timeline.yaml"
VO_DIR = ROOT / "audio" / "vo"
RENDER_DIR = ROOT / "audio" / "render"
OUT_DIR = ROOT / "out"
LAYOUT_LOG = RENDER_DIR / "layout_log.json"

PRESETS = {
    # R-OUT-03 / R-OUT-04 — one source, two masters
    "test": {
        "name": "nealarp-ad-1080p-test.mp4",
        "scale": 1,
        "width": 1920,
        "height": 1080,
    },
    "final": {
        "name": "nealarp-ad-2160p60-final.mp4",
        "scale": 2,
        "width": 3840,
        "height": 2160,
    },
}

# R-OUT-05 — identical container spec for both presets
VIDEO_ARGS = [
    "-c:v", "libx264",
    "-profile:v", "high",
    "-pix_fmt", "yuv420p",
    "-preset", "slow",
    "-crf", "17",
    "-r", "60",
    "-g", "120",
    "-x264-params", "keyint=120:min-keyint=120:scenecut=0",
]
AUDIO_ARGS = [
    "-c:a", "aac",
    "-b:a", "192k",
    "-ar", "48000",
    "-ac", "2",
]


def load_timeline(path: os.PathLike | str = TIMELINE) -> dict:
    """timeline.yaml is the single source of truth (R-TIME-04)."""
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def ensure_dirs() -> None:
    for d in (VO_DIR, RENDER_DIR, OUT_DIR):
        d.mkdir(parents=True, exist_ok=True)
