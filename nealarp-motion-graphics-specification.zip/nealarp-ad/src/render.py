"""
render.py — R-OUT-03 / R-OUT-04 / R-OUT-06.

One source, two masters:

    python -m src.render --preset test     -> out/nealarp-ad-1080p-test.mp4   (1920x1080)
    python -m src.render --preset final    -> out/nealarp-ad-2160p60-final.mp4 (3840x2160)

Both use the identical R-OUT-05 container spec. Frames are produced by
scenes.render_frame(frame), a pure function of the frame index, and piped as
raw RGB into ffmpeg.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

from . import config, layout, scenes

GATE_REPORT = config.RENDER_DIR / "gate.json"


def gate_status() -> dict:
    """R-GATE-03: is the voiceover a real neural German voice?"""
    manifest = config.RENDER_DIR / "vo_manifest.json"
    if not manifest.exists():
        return {"placeholder": True, "reason": "audio/vo/ has not been generated yet (run src.vo)"}
    data = json.loads(manifest.read_text(encoding="utf-8"))
    return {
        "placeholder": bool(data.get("placeholder", True)),
        "engine": data.get("engine"),
        "reason": "" if not data.get("placeholder") else "voiceover is PLACEHOLDER",
    }


def render(preset: str, frames: int | None = None, dry_run: bool = False,
           skip_audio: bool = False) -> dict:
    cfg = config.PRESETS[preset]
    scale = float(cfg["scale"])
    timeline = config.load_timeline()
    records = layout.build_records(timeline, scale)
    layout.write_log(records.values(), config.LAYOUT_LOG)
    print(f"[render] layout log -> {config.LAYOUT_LOG} ({len(records)} entries)")

    if preset == "final":
        gate = gate_status()
        GATE_REPORT.parent.mkdir(parents=True, exist_ok=True)
        GATE_REPORT.write_text(json.dumps(gate, ensure_ascii=False, indent=1), encoding="utf-8")
        if gate["placeholder"]:
            print("[render] REFUSED (R-GATE-03): the 4K master needs a real German neural voice.",
                  file=sys.stderr)
            print(f"[render]   reason: {gate['reason']} — see {GATE_REPORT}", file=sys.stderr)
            return {"status": "refused", "gate": gate}

    total = frames or config.TOTAL_FRAMES
    out_path = config.OUT_DIR / cfg["name"]
    config.OUT_DIR.mkdir(parents=True, exist_ok=True)
    haze = scenes.haze_layer(scale)

    if dry_run:
        t0 = time.perf_counter()
        for f in range(min(total, 12)):
            scenes.render_frame(f, records, scale, haze)
        per = (time.perf_counter() - t0) / min(total, 12)
        return {"status": "dry-run", "seconds_per_frame": round(per, 4),
                "estimate_1080p_min": round(per * 3600 / 60, 1),
                "estimate_4k_hours": round(per * 4 * 3600 / 3600, 2)}

    import imageio_ffmpeg

    mix = config.RENDER_DIR / "mix.wav"
    audio_path = str(mix) if (mix.exists() and not skip_audio) else None
    if audio_path is None and not skip_audio:
        print("[render] WARNING audio/render/mix.wav missing — encoding video only", file=sys.stderr)

    writer = imageio_ffmpeg.write_frames(
        str(out_path),
        (cfg["width"], cfg["height"]),
        fps=config.FPS,
        quality=None,
        pix_fmt_in="rgb24",
        pix_fmt_out="yuv420p",
        codec="libx264",
        audio_path=audio_path,
        audio_codec="aac" if audio_path else None,
        audio_bitrate="192k" if audio_path else None,
        macro_block_size=1,
        output_params=config.VIDEO_ARGS,
    )
    writer.send(None)

    t0 = time.perf_counter()
    slowest = 0.0
    try:
        for f in range(total):
            frame = scenes.render_frame(f, records, scale, haze)
            writer.send(np.ascontiguousarray(frame))
            dt = time.perf_counter() - t0
            slowest = max(slowest, dt)
            if f % 120 == 0:
                elapsed = time.perf_counter() - t0
                per = elapsed / (f + 1)
                eta = per * (total - f - 1)
                print(f"[render] frame {f:4d}/{total}  {per * 1000:6.1f} ms/frame  "
                      f"ETA {eta / 60:5.1f} min", flush=True)
    finally:
        writer.close()

    elapsed = time.perf_counter() - t0
    per_frame = elapsed / total
    report = {
        "status": "ok",
        "preset": preset,
        "file": str(out_path),
        "frames": total,
        "elapsed_s": round(elapsed, 1),
        "seconds_per_frame": round(per_frame, 4),
        "estimate_4k_hours": round(per_frame * 4 * total / 3600, 2),
    }
    (config.RENDER_DIR / f"perf_{preset}.json").write_text(json.dumps(report, indent=1), encoding="utf-8")
    print(f"[render] {out_path} in {elapsed / 60:.1f} min "
          f"({per_frame * 1000:.1f} ms/frame, 4K estimate {report['estimate_4k_hours']} h)")
    # R-PERF-05
    if preset == "test" and report["estimate_4k_hours"] > 6:
        print("[render] R-PERF-05: the 4K estimate exceeds 6 h — do NOT start --preset final. "
              "Options: lower particle counts, pre-render sprites, or a longer run window.",
              file=sys.stderr)
    return report


def main() -> int:
    p = argparse.ArgumentParser(description="nealarp AD-60 renderer")
    p.add_argument("--preset", choices=("test", "final"), default="test")
    p.add_argument("--frames", type=int, default=None, help="render fewer frames (debug)")
    p.add_argument("--dry-run", action="store_true", help="time 12 frames and report the estimate")
    p.add_argument("--skip-audio", action="store_true")
    args = p.parse_args()
    report = render(args.preset, args.frames, args.dry_run, args.skip_audio)
    print(json.dumps(report, indent=1, ensure_ascii=False))
    return 0 if report.get("status") in ("ok", "dry-run") else 4


if __name__ == "__main__":
    raise SystemExit(main())
