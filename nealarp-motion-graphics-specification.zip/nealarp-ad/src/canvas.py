"""
canvas.py — numpy drawing primitives (R-PERF-02: no per-pixel Python loops).

A Canvas owns one float32 HxWx3 buffer in 0..255. Every primitive builds an
anti-aliased coverage mask with vectorised distance fields and alpha-composites
it in one slice operation.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import cv2
import numpy as np

from . import config

Color = Sequence[float]


@dataclass
class Box:
    x0: int
    y0: int
    x1: int
    y1: int

    @property
    def w(self) -> int:
        return self.x1 - self.x0

    @property
    def h(self) -> int:
        return self.y1 - self.y0


class Canvas:
    def __init__(self, width: int, height: int, scale: float = 1.0) -> None:
        self.scale = scale
        self.w = width
        self.h = height
        self.buf = np.zeros((height, width, 3), dtype=np.float32)

    # -- coordinate helper: reference px -> device px -------------------
    def s(self, v: float) -> float:
        return v * self.scale

    def box(self, x: float, y: float, w: float, h: float, pad: int = 4) -> Box:
        x0 = max(0, int(np.floor(self.s(x)) - pad))
        y0 = max(0, int(np.floor(self.s(y)) - pad))
        x1 = min(self.w, int(np.ceil(self.s(x + w)) + pad))
        y1 = min(self.h, int(np.ceil(self.s(y + h)) + pad))
        return Box(x0, y0, max(x0 + 1, x1), max(y0 + 1, y1))

    def grid(self, b: Box) -> tuple[np.ndarray, np.ndarray]:
        ys, xs = np.mgrid[b.y0 : b.y1, b.x0 : b.x1]
        return xs.astype(np.float32), ys.astype(np.float32)

    # -- primitives ------------------------------------------------------
    def fill(self, color: Color) -> None:
        self.buf[:, :] = np.asarray(color, dtype=np.float32)

    def composite(self, b: Box, mask: np.ndarray, color: Color, alpha: float = 1.0,
                  additive: bool = False) -> None:
        if b.w <= 0 or b.h <= 0 or alpha <= 0:
            return
        a = (np.clip(mask, 0.0, 1.0) * alpha)[..., None].astype(np.float32)
        region = self.buf[b.y0 : b.y1, b.x0 : b.x1]
        rgb = np.asarray(color, dtype=np.float32)[None, None, :]
        if additive:
            self.buf[b.y0 : b.y1, b.x0 : b.x1] = np.minimum(255.0, region + rgb * a)
        else:
            self.buf[b.y0 : b.y1, b.x0 : b.x1] = region * (1.0 - a) + rgb * a

    def composite_rgb(self, b: Box, mask: np.ndarray, rgb: np.ndarray, alpha: float = 1.0,
                      additive: bool = False) -> None:
        """rgb has shape (h, w, 3) in device pixels — used by gradients and sprites."""
        if b.w <= 0 or b.h <= 0 or alpha <= 0:
            return
        a = (np.clip(mask, 0.0, 1.0) * alpha)[..., None].astype(np.float32)
        region = self.buf[b.y0 : b.y1, b.x0 : b.x1]
        if additive:
            self.buf[b.y0 : b.y1, b.x0 : b.x1] = np.minimum(255.0, region + rgb * a)
        else:
            self.buf[b.y0 : b.y1, b.x0 : b.x1] = region * (1.0 - a) + rgb * a

    def rect(self, x: float, y: float, w: float, h: float, color: Color, alpha: float = 1.0,
             additive: bool = False) -> None:
        b = self.box(x, y, w, h, pad=0)
        xs, ys = self.grid(b)
        m = ((xs >= self.s(x)) & (xs < self.s(x + w)) & (ys >= self.s(y)) & (ys < self.s(y + h))).astype(np.float32)
        self.composite(b, m, color, alpha, additive)

    def rrect(self, x: float, y: float, w: float, h: float, r: float, color: Color,
              alpha: float = 1.0, stroke: float = 0.0) -> None:
        b = self.box(x, y, w, h, pad=int(self.s(stroke)) + 3)
        xs, ys = self.grid(b)
        rr = min(self.s(r), self.s(w) / 2, self.s(h) / 2)
        cx0, cy0 = self.s(x) + rr, self.s(y) + rr
        cx1, cy1 = self.s(x + w) - rr, self.s(y + h) - rr
        dx = np.maximum(np.maximum(cx0 - xs, xs - cx1), 0.0)
        dy = np.maximum(np.maximum(cy0 - ys, ys - cy1), 0.0)
        dist = np.sqrt(dx * dx + dy * dy)
        inside = np.maximum(np.minimum(xs - self.s(x), self.s(x + w) - xs),
                            np.minimum(ys - self.s(y), self.s(y + h) - ys))
        signed = np.where((xs > cx0) & (xs < cx1) | (ys > cy0) & (ys < cy1), inside, rr - dist)
        if stroke > 0:
            m = np.clip(0.5 + signed - (self.s(w) / 2 - self.s(stroke)), 0, 1) * 0  # placeholder
            m = np.clip(self.s(stroke) - np.abs(signed), 0.0, 1.0)
            self.composite(b, m, color, alpha)
        else:
            self.composite(b, np.clip(signed + 0.5, 0.0, 1.0), color, alpha)

    def circle(self, cx: float, cy: float, r: float, color: Color, alpha: float = 1.0,
               additive: bool = False) -> None:
        b = self.box(cx - r, cy - r, 2 * r, 2 * r)
        xs, ys = self.grid(b)
        d = np.sqrt((xs - self.s(cx)) ** 2 + (ys - self.s(cy)) ** 2)
        self.composite(b, np.clip(self.s(r) + 0.5 - d, 0.0, 1.0), color, alpha, additive)

    def ellipse(self, cx: float, cy: float, rx: float, ry: float, color: Color, alpha: float = 1.0,
                stroke: float = 0.0) -> None:
        b = self.box(cx - rx, cy - ry, 2 * rx, 2 * ry, pad=int(self.s(stroke)) + 3)
        xs, ys = self.grid(b)
        nx = (xs - self.s(cx)) / max(1e-6, self.s(rx))
        ny = (ys - self.s(cy)) / max(1e-6, self.s(ry))
        d = np.sqrt(nx * nx + ny * ny)
        if stroke > 0:
            w = self.s(stroke) / max(1e-6, min(self.s(rx), self.s(ry)))
            self.composite(b, np.clip(w - np.abs(d - 1.0), 0.0, 1.0), color, alpha)
        else:
            self.composite(b, np.clip(1.05 - d, 0.0, 1.0), color, alpha)

    def ring(self, cx: float, cy: float, r: float, stroke: float, color: Color,
             alpha: float = 1.0, additive: bool = False) -> None:
        self.ellipse(cx, cy, r, r, color, alpha, stroke=stroke)

    def arc(self, cx: float, cy: float, r: float, a0_deg: float, a1_deg: float, stroke: float,
            color: Color, alpha: float = 1.0, additive: bool = False) -> None:
        """Filled sweep from a0 to a1 (degrees, canvas orientation, y down)."""
        pad = stroke + 4
        b = self.box(cx - r - pad, cy - r - pad, 2 * (r + pad), 2 * (r + pad))
        xs, ys = self.grid(b)
        dx, dy = xs - self.s(cx), ys - self.s(cy)
        d = np.sqrt(dx * dx + dy * dy)
        ring = np.clip(self.s(stroke) / 2 - np.abs(d - self.s(r)), 0.0, 1.0)
        ang = np.degrees(np.arctan2(dy, dx)) % 360.0
        a0, a1 = a0_deg % 360.0, a1_deg % 360.0
        if a1 >= a0:
            inside = (ang >= a0) & (ang <= a1)
        else:
            inside = (ang >= a0) | (ang <= a1)
        self.composite(b, ring * inside, color, alpha, additive)

    def line(self, x1: float, y1: float, x2: float, y2: float, stroke: float, color: Color,
             alpha: float = 1.0, additive: bool = False) -> None:
        pad = stroke + 4
        b = self.box(min(x1, x2) - pad, min(y1, y2) - pad,
                     abs(x2 - x1) + 2 * pad, abs(y2 - y1) + 2 * pad)
        xs, ys = self.grid(b)
        ax, ay, bx, by = self.s(x1), self.s(y1), self.s(x2), self.s(y2)
        vx, vy = bx - ax, by - ay
        length2 = max(1e-6, vx * vx + vy * vy)
        t = np.clip(((xs - ax) * vx + (ys - ay) * vy) / length2, 0.0, 1.0)
        px, py = ax + t * vx, ay + t * vy
        d = np.sqrt((xs - px) ** 2 + (ys - py) ** 2)
        self.composite(b, np.clip(self.s(stroke) / 2 + 0.5 - d, 0.0, 1.0), color, alpha, additive)

    def radial(self, cx: float, cy: float, r: float, stops: Sequence[tuple[float, Color, float]],
               alpha: float = 1.0, additive: bool = True) -> None:
        """stops = [(position 0..1, rgb, stop_alpha)] — built once per call, vectorised."""
        b = self.box(cx - r, cy - r, 2 * r, 2 * r)
        xs, ys = self.grid(b)
        d = np.sqrt((xs - self.s(cx)) ** 2 + (ys - self.s(cy)) ** 2) / max(1e-6, self.s(r))
        d = np.clip(d, 0.0, 1.0)
        rgb = np.zeros((b.h, b.w, 3), dtype=np.float32)
        amask = np.zeros((b.h, b.w), dtype=np.float32)
        for i in range(len(stops) - 1):
            p0, c0, a0 = stops[i]
            p1, c1, a1 = stops[i + 1]
            span = max(1e-6, p1 - p0)
            w = np.clip((d - p0) / span, 0.0, 1.0)
            seg = (d >= p0) & (d <= p1)
            for ch in range(3):
                rgb[..., ch] = np.where(seg, c0[ch] * (1 - w) + c1[ch] * w, rgb[..., ch])
            amask = np.where(seg, a0 * (1 - w) + a1 * w, amask)
        cover = np.clip(1.05 - d, 0.0, 1.0)
        self.composite_rgb(b, cover, rgb, alpha, additive)

    def linear_gradient_rect(self, x: float, y: float, w: float, h: float,
                             c0: Color, c1: Color, alpha: float = 1.0,
                             mask: np.ndarray | None = None,
                             mid: Color | None = None) -> None:
        """
        Horizontal ramp (R-VIS-03), optionally masked by `mask`.
        With `mid` set, the ramp runs c0 -> mid -> c1, which keeps every
        saturated pixel inside the hue bands R-VER-06 allows.
        """
        b = self.box(x, y, w, h)
        xs, _ = self.grid(b)
        p = np.clip((xs - self.s(x)) / max(1e-6, self.s(w)), 0.0, 1.0)[..., None]
        a = np.asarray(c0, dtype=np.float32).reshape(1, 1, 3)
        c = np.asarray(c1, dtype=np.float32).reshape(1, 1, 3)
        if mid is None:
            rgb = a * (1 - p) + c * p
        else:
            m = np.asarray(mid, dtype=np.float32).reshape(1, 1, 3)
            lo = a + (m - a) * (p * 2.0)
            hi = m + (c - m) * ((p - 0.5) * 2.0)
            rgb = np.where(p < 0.5, lo, hi)
        m = np.ones((b.h, b.w), dtype=np.float32) if mask is None else mask
        self.composite_rgb(b, m, rgb, alpha)

    # -- layers ----------------------------------------------------------
    def blurred_copy(self, blur_px: float, quarter: bool = True) -> np.ndarray:
        """R-VIS-04: blur computed on a 1/4-scale copy, then upsampled."""
        k = 0.25 if quarter else 1.0
        small = cv2.resize(self.buf, None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
        small = cv2.GaussianBlur(small, (0, 0), max(0.4, blur_px * k / 2.0))
        return cv2.resize(small, (self.w, self.h), interpolation=cv2.INTER_LINEAR)

    def mono_text(self, text: str, x: float, y: float, size: int, color: Color,
                  alpha: float = 1.0) -> None:
        """Small mono glyphs (R-SCN-03 rule text). Rasterised with PIL, composited."""
        from PIL import Image, ImageDraw

        from . import fonts
        if alpha <= 0.01 or not text:
            return
        font = fonts.mono(int(round(size * self.scale)))
        img = Image.new("L", (max(2, int(len(text) * size * 0.62 * self.scale)),
                              max(2, int(size * 1.8 * self.scale))), 0)
        ImageDraw.Draw(img).text((0, 0), text, font=font, fill=255)
        mask = np.asarray(img, dtype=np.float32) / 255.0
        x0 = max(0, int(x * self.scale))
        y0 = max(0, int(y * self.scale))
        x1, y1 = min(self.w, x0 + mask.shape[1]), min(self.h, y0 + mask.shape[0])
        if x1 <= x0 or y1 <= y0:
            return
        m = mask[: y1 - y0, : x1 - x0] * alpha
        region = self.buf[y0:y1, x0:x1]
        self.buf[y0:y1, x0:x1] = region * (1 - m[..., None]) + np.asarray(color, np.float32) * m[..., None]

    def to_uint8(self) -> np.ndarray:
        return np.clip(self.buf, 0, 255).astype(np.uint8)
