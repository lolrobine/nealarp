"""
scenes.py — R-SCN-01 … R-SCN-11 plus the global post layers.

`render_frame(frame, ...)` is a pure function of the frame index: t = frame/60.
Nothing accumulates between calls, which is what makes R-VER-13 hold.
"""
from __future__ import annotations

import math
from typing import Sequence

import numpy as np

from . import config, layout
from .canvas import Canvas
from .easing import EASE_IO, EASE_OUT_EARLY, EXPO_OUT, active, ease, eased, lerp, prog
from .rng import Rng, grain_offsets, grain_tile

DEG = math.pi / 180.0
_de = lambda n: int(round(n))


# =====================================================================
# vectorised particle splatting (R-PERF-02)
# =====================================================================
def splat(cv: Canvas, xs: np.ndarray, ys: np.ndarray, sizes: np.ndarray,
          rgb: np.ndarray, alpha: np.ndarray) -> None:
    """Additive square splats, no per-particle Python loop."""
    X = np.floor(xs * cv.scale).astype(np.int32)
    Y = np.floor(ys * cv.scale).astype(np.int32)
    S = np.maximum(1, np.ceil(sizes * cv.scale).astype(np.int32))
    keep = (X >= 0) & (X < cv.w) & (Y >= 0) & (Y < cv.h) & (alpha > 0.004)
    if not keep.any():
        return
    X, Y, S, A = X[keep], Y[keep], S[keep], alpha[keep]
    C = rgb[keep]
    flat = cv.buf.reshape(-1, 3)
    stride = cv.w
    for size in range(1, int(S.max()) + 1):
        sel = S >= size
        if not sel.any():
            continue
        for dy in range(size):
            yy = Y[sel] + dy
            ok = yy < cv.h
            if not ok.any():
                continue
            for dx in range(size):
                xx = X[sel][ok] + dx
                okx = xx < cv.w
                if not okx.any():
                    continue
                idx = yy[ok] * stride + xx[okx]
                contrib = C[sel][ok][okx] * A[sel][ok][okx][:, None]
                np.maximum.at(flat, idx, np.minimum(255.0, flat[idx] + contrib))


# =====================================================================
# static layers, built once (R-PERF-01)
# =====================================================================
_LAYERS: dict[str, np.ndarray] = {}


def haze_layer(scale: float) -> np.ndarray:
    key = f"haze{scale}"
    if key in _LAYERS:
        return _LAYERS[key]
    cv = Canvas(config.REF_W, config.REF_H, 1.0)
    cv.fill(config.NEAR_BLACK)
    cv.radial(960, 540, 1180, [(0.0, config.HAZE, 0.40), (1.0, config.NEAR_BLACK, 0.0)], additive=False)
    img = cv.to_uint8()
    if scale != 1.0:
        import cv2
        img = cv2.resize(img, (int(config.REF_W * scale), int(config.REF_H * scale)),
                         interpolation=cv2.INTER_AREA)
    _LAYERS[key] = img.astype(np.float32)
    return _LAYERS[key]


def vignette_layer(scale: float) -> np.ndarray:
    key = f"vig{scale}"
    if key in _LAYERS:
        return _LAYERS[key]
    h, w = int(config.REF_H * scale), int(config.REF_W * scale)
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    nx = (xs - w / 2) / (w / 2)
    ny = (ys - h / 2) / (h / 2)
    d = np.clip(np.sqrt(nx * nx + ny * ny) / math.sqrt(2), 0, 1)
    vig = np.clip((d - 0.35) / 0.65, 0, 1) ** 1.6 * config.VIGNETTE_CORNER
    _LAYERS[key] = vig
    return _LAYERS[key]


def grain(scale: float) -> np.ndarray:
    key = f"grain{scale}"
    if key in _LAYERS:
        return _LAYERS[key]
    tile = grain_tile()
    if scale != 1.0:
        import cv2
        n = max(16, int(config.GRAIN_TILE * scale))
        tile = cv2.resize(tile, (n, n), interpolation=cv2.INTER_AREA)
    _LAYERS[key] = tile
    return _LAYERS[key]


# =====================================================================
# seeded fields (identical seeds to the browser preview)
# =====================================================================
def tunnel_field(n: int = 1400) -> dict[str, np.ndarray]:
    r = Rng(config.SEED)
    side = np.array([r.sign() for _ in range(n)], dtype=np.float32)
    return {
        "x": side * np.array([r.range(180, 1500) for _ in range(n)], dtype=np.float32),
        "y": np.array([r.range(-700, 700) for _ in range(n)], dtype=np.float32),
        "z": np.array([r.range(0, 2000) for _ in range(n)], dtype=np.float32),
        "size": np.array([r.range(2, 9) for _ in range(n)], dtype=np.float32),
        "blue": side < 0,
    }


TUNNEL = tunnel_field()


def galaxy_field(n: int = 2000) -> dict[str, np.ndarray]:
    r = Rng(config.SEED)
    arm = np.arange(n) % 2
    rr = np.array([r.f() for _ in range(n)], dtype=np.float32) ** 0.62
    jit = np.array([r.range(-0.22, 0.22) for _ in range(n)], dtype=np.float32)
    return {
        "a": arm * math.pi + rr * 3.1 + jit,
        "r": rr,
        "size": np.array([r.range(1.2, 3.4) for _ in range(n)], dtype=np.float32),
        "blue": np.array([r.f() for _ in range(n)]) > 0.42,
    }


GALAXY = galaxy_field()


# =====================================================================
# scenes
# =====================================================================
def scene_opening(cv: Canvas, t: float) -> None:
    cam = t * 260.0
    conv = eased(EASE_IO, t, 1.2, 2.4)
    z = np.mod(TUNNEL["z"] - cam, 2000.0)
    k = config.FOCAL / (config.FOCAL + z)
    bx = lerp_arr(TUNNEL["x"], 0.0, conv)
    by = lerp_arr(TUNNEL["y"], 0.0, conv)
    xs = 960.0 + bx * k
    ys = 540.0 + by * k
    sizes = np.maximum(0.6, TUNNEL["size"] * k)
    alpha = np.clip(0.16 + k * 1.05, 0, 1) * (1 - 0.5 * conv)
    rgb = np.where(TUNNEL["blue"][:, None], np.asarray(config.BLUE, dtype=np.float32),
                   np.asarray(config.ORANGE, dtype=np.float32))
    splat(cv, xs, ys, sizes * (1 + 2.6 * k), rgb, alpha)

    focal = clamp01(prog(t, 0.6, 2.0)) * (1 - 0.55 * clamp01(prog(t, 2.0, 4.0)))
    if focal > 0.01:
        cv.radial(960, 540, 260, [(0.0, config.WHITE, 0.95 * focal),
                                  (0.25, (180, 215, 255), 0.35 * focal),
                                  (1.0, config.BLUE, 0.0)])


def lerp_arr(a: np.ndarray, b: float, p: float) -> np.ndarray:
    return a + (b - a) * p


def clamp01(v):
    return 0.0 if v < 0 else (1.0 if v > 1 else v)


COINS = None


def coin_data() -> dict[str, np.ndarray]:
    global COINS
    if COINS is None:
        r = Rng(config.SEED)
        n = 24
        COINS = {
            "x": np.array([706 + (i % 8) * 74 + r.range(-10, 10) for i in range(n)], dtype=np.float32),
            "d": np.array([r.range(80, 110) for _ in range(n)], dtype=np.float32),
            "delay": np.array([r.range(0, 0.6) for _ in range(n)], dtype=np.float32),
            "y_end": np.array([420 + r.range(-26, 26) for _ in range(n)], dtype=np.float32),
        }
    return COINS


def scene_wallet(cv: Canvas, t: float) -> None:
    c = coin_data()
    panel = ease(EASE_OUT_EARLY, prog(t, 8.3, 8.8))
    if panel > 0.01:
        cv.rrect(660, 260, 600, 380, 28, config.WHITE, panel * 0.10)
        cv.rrect(660, 260, 600, 380, 28, config.WHITE, panel * 0.25, stroke=1.0)
    for i in range(len(c["x"])):
        pi = ease(EASE_IO, prog(t, 8.0 + float(c["delay"][i]), 8.85 + float(c["delay"][i])))
        if pi <= 0:
            continue
        y = lerp(-100.0, float(c["y_end"][i]), pi)
        d = float(c["d"][i])
        squash = 1 - 0.2 * math.sin(math.pi * clamp01(pi))
        cv.ellipse(float(c["x"][i]), y, d / 2, d / 2 * squash, config.BLUE, clamp01(pi * 4) * 0.9)
        cv.ellipse(float(c["x"][i]) - d * 0.12, y - d * 0.14, d * 0.26, d * 0.22 * squash,
                   config.WHITE, clamp01(pi * 4) * 0.85)
        cv.ellipse(float(c["x"][i]), y, d / 2, d / 2 * squash, config.ORANGE, clamp01(pi * 4), stroke=2.0)


def scene_password(cv: Canvas, t: float) -> None:
    """R-SCN-03: lock body, shackle, scrolling rule glyphs, click kick, 5 checks."""
    build = ease(EASE_OUT_EARLY, prog(t, 11.2, 11.6))
    if build <= 0.01:
        return
    kick = 1.0 if t < 11.4 else lerp(1.04, 1.0, ease(EXPO_OUT, prog(t, 11.4, 11.55)))
    shake_t = t - 11.4
    ox = math.sin(shake_t * 23 * 2 * math.pi) * 9 * max(0.0, 1 - shake_t / 0.3) if 0 <= shake_t <= 0.3 else 0.0
    oy = math.sin(shake_t * 31 * 2 * math.pi) * 6 * max(0.0, 1 - shake_t / 0.3) if 0 <= shake_t <= 0.3 else 0.0
    cx, cy = 960 + ox, 430 + oy

    def P(x: float, y: float) -> tuple[float, float]:
        return cx + (x - 960) * kick, cy + (y - 430) * kick

    # shackle: 180 deg arc, stroke 28, r 110
    sx, sy = P(960, 300)
    cv.arc(sx, sy, 110 * kick, 180, 360, 28 * kick, (232, 238, 247), build)
    cv.arc(sx, sy, 124 * kick, 180, 360, 4 * kick, config.BLUE, build * 0.45, additive=True)
    # body
    bx, by = P(800, 300)
    cv.rrect(bx, by, 320 * kick, 260 * kick, 32 * kick, (215, 226, 240), build)
    cv.rrect(bx, by, 320 * kick, 260 * kick, 32 * kick, config.WHITE, build * 0.55, stroke=2.0)
    cv.radial(cx, cy, 210 * kick, [(0.0, config.BLUE, 0.35 * build), (1.0, config.BLUE, 0.0)])
    # rule glyphs: 12 rows of 10 px mono scrolling up at 120 px/s
    r = Rng(config.SEED)
    chars = "01§%$&!?#*+abcdefghijklmnopqrstuvwxyzÄÖÜß.,"
    scroll = ((t - 11.0) * 120) % 260
    for row in range(12):
        text = "".join(chars[int(r.f() * len(chars))] for _ in range(26))
        y = 560 - ((row * 24 + scroll) % 300)
        gx, gy = P(812, y)
        cv.mono_text(text, gx, gy, 10, config.WHITE, build * 0.40)
    # five orange checkmark circles
    for i in range(5):
        st = 12.0 + i * 0.2
        p = ease(EXPO_OUT, prog(t, st, st + 0.28))
        if p <= 0:
            continue
        x = 960 + (i - 2) * 104
        cv.ring(x, 648, 36 * lerp(0.4, 1.0, p), 6, config.ORANGE, p)
        cv.circle(x, 648, 30 * lerp(0.4, 1.0, p), config.ORANGE, p * 0.18, additive=True)
        cp = clamp01((p - 0.35) / 0.65)
        cv.line(x - 16, 650, lerp(x - 16, x - 3, cp), lerp(650, 664, cp), 6, config.WHITE, p)
        if cp > 0.5:
            q = (cp - 0.5) * 2
            cv.line(x - 3, 664, lerp(x - 3, x + 18, q), lerp(664, 636, q), 6, config.WHITE, p)


def scene_deepsea(cv: Canvas, t: float) -> None:
    # vertical gradient #0a0a0a -> blue at 12 %
    cv.linear_gradient_rect(0, 160, config.REF_W, 640, config.NEAR_BLACK, config.BLUE, alpha=0.12)
    dive = ease(EASE_OUT_EARLY, prog(t, 14.0, 17.0)) * 3600.0
    r = Rng(config.SEED)
    n = 220
    bx = np.array([r.range(0, config.REF_W) for _ in range(n)], dtype=np.float32)
    by = np.array([r.range(0, config.REF_H * 2) for _ in range(n)], dtype=np.float32)
    sp = np.array([r.range(0.5, 1.4) for _ in range(n)], dtype=np.float32)
    ys = np.mod(by + dive * sp, config.REF_H * 1.4) - 200
    splat(cv, bx, ys, np.full(n, 1.6, dtype=np.float32),
          np.tile(np.asarray(config.WHITE, dtype=np.float32), (n, 1)),
          0.05 + sp * 0.10)
    # bubbles
    rb = Rng(config.SEED)
    for _ in range(60):
        x = rb.range(0, config.REF_W)
        y0 = rb.range(0, config.REF_H * 1.6)
        rad = rb.range(4, 14)
        v = rb.range(80, 160)
        y = config.REF_H + 60 - ((t - 14.0) * v + y0) % (config.REF_H + 200)
        cv.ring(x + math.sin(t * 2 + rad) * 12, y, rad, 1.4, config.WHITE, 0.5)


def scene_tempo(cv: Canvas, t: float) -> None:
    r = Rng(config.SEED)
    for _ in range(40):
        y = r.range(160, 900)
        length = r.range(200, 600)
        x0 = r.range(0, config.REF_W)
        a = r.range(0.12, 0.30)
        x = (x0 - (t - 17.0) * 2400) % (config.REF_W + 700) - 700
        cv.rect(x, y, length, 2, config.WHITE, a, additive=True)
    sweep = ease(EXPO_OUT, prog(t, 17.2, 18.4))
    cv.arc(960, 470, 300, 210, 210 + 120 * sweep, 14, config.ORANGE, 0.95, additive=True)
    cv.arc(960, 470, 300, 210, 330, 10, config.WHITE, 0.12)
    na = (210 + 120 * sweep) * DEG
    cv.line(960, 470, 960 + math.cos(na) * 236, 470 + math.sin(na) * 236, 8, config.ORANGE)
    cv.circle(960, 470, 16, config.WHITE)


def scene_asteroid(cv: Canvas, t: float) -> None:
    cv.radial(960, 560, 210, [(0.0, (143, 192, 255), 1.0), (0.5, config.BLUE, 1.0),
                              (1.0, (15, 43, 87), 1.0)], additive=False)
    cv.ring(960, 560, 211, 2, config.ORANGE)
    mp = ease(EASE_IO, prog(t, 20.3, 21.6))
    if 0 < mp < 1:
        mx, my = lerp(1500, 1000, mp), lerp(60, 470, mp)
        tx, ty = lerp(1500, 1000, max(0.0, mp - 0.22)), lerp(60, 470, max(0.0, mp - 0.22))
        cv.line(tx, ty, mx, my, 9, config.ORANGE, 0.95, additive=True)
        cv.circle(mx, my, 11, config.WHITE)
    if t >= 21.6:
        cv.ellipse(1000, 470, 74, 44, (6, 8, 12))
        cv.ellipse(1000, 470, 74, 44, config.BLUE, 1.0, stroke=3.0)
        for i in range(5):
            st = 21.6 + i * 0.12
            p = ease(EXPO_OUT, prog(t, st, st + 1.5))
            if p <= 0:
                continue
            cv.ring(1000, 470, p * 700, 3, config.ORANGE, (1 - p) * 0.85, additive=True)


def scene_circle(cv: Canvas, t: float) -> None:
    p = ease(EASE_IO, prog(t, 23.0, 24.2))
    if p > 0:
        cv.arc(960, 470, 220, -90, -90 + 360 * p, 14, config.ORANGE, 1.0, additive=True)
        cv.arc(960, 470, 216, -90, -90 + 360 * p, 4, config.WHITE, 0.40)
        a = (-90 + 360 * p) * DEG
        cv.circle(960 + math.cos(a) * 220, 470 + math.sin(a) * 220, 9, config.WHITE)
    if t >= 24.2:
        cv.ring(960, 470, 220, 2, config.WHITE, 0.5 * ease(EASE_OUT_EARLY, prog(t, 24.2, 24.5)))


def scene_lifestats(cv: Canvas, t: float) -> None:
    beat = (t - 26.0) * (72 / 60)
    phase = beat - math.floor(beat) if beat > 0 else 0.0
    pulse = 1 + 0.12 * math.exp(-phase * 7) if beat >= 0 else 1.0
    for i in range(5):
        idx = math.floor(beat) - i
        if idx < 0:
            continue
        age = beat - idx
        if age > 1.6:
            continue
        cv.ring(960, 470, (age / 1.6) * 600, 3, config.BLUE, (1 - age / 1.6) * 0.7, additive=True)
    size = 200 * pulse
    r = size * 0.25
    cv.circle(960 - r, 470 - size * 0.12, r, config.WHITE)
    cv.circle(960 + r, 470 - size * 0.12, r, config.WHITE)
    cv.ellipse(960, 470 + size * 0.16, size * 0.47, size * 0.34, config.WHITE)

    # three glass counter panels, faded in 26.2-26.6, counters ease over the cut
    panel_a = ease(EASE_OUT_EARLY, prog(t, 26.2, 26.6))
    count_p = ease(EASE_IO, prog(t, 26.6, 29.0))
    panels = ((200, 380, 440, "HERZSCHLÄGE", 889411200, config.WHITE),
              (1280, 380, 440, "ATEMZÜGE", 37843200, config.WHITE),
              (760, 640, 400, "SCHRITTE", 214500000, config.ORANGE))
    for px, py, pw, label, target, colour in panels:
        if panel_a <= 0.01:
            break
        cv.rrect(px, py, pw, 180, 24, config.WHITE, panel_a * 0.10)
        cv.rrect(px, py, pw, 180, 24, config.WHITE, panel_a * 0.25, stroke=1.0)
        cv.mono_text(label, px + 24, py + 30, 20, config.WHITE, panel_a * 0.72)
        value = f"{_de(target * count_p):,}".replace(",", ".")
        cv.mono_text(value, px + 24, py + 96, 64, colour, panel_a)


def scene_universe(cv: Canvas, t: float) -> None:
    stage_len = 0.5
    p = (t - 29.0) / stage_len
    i = min(5, max(0, int(p)))
    frac = p - i
    trans = 0.25 / stage_len
    k = ease(EXPO_OUT, clamp01(frac / trans))
    if frac < trans:
        _zoom_stage(cv, i, 1 - k, lerp(1, 0.1, k))
        if i + 1 <= 5:
            _zoom_stage(cv, i + 1, k, lerp(10, 1, k))
    else:
        _zoom_stage(cv, i, 1.0, 1.0)
    ta = ease(EASE_OUT_EARLY, prog(t, 29.5, 30.0))
    if ta > 0:
        cv.line(920, 200, 1010, 165, 6, config.WHITE, ta)
        cv.line(960, 190, 930, 240, 6, config.WHITE, ta)
        cv.line(960, 190, 990, 240, 6, config.WHITE, ta)


def _zoom_stage(cv: Canvas, i: int, a: float, sc: float) -> None:
    if a <= 0.01:
        return
    cx, cy = 960.0, 480.0

    def P(x: float, y: float) -> tuple[float, float]:
        return cx + (x - cx) * sc, cy + (y - cy) * sc

    if i == 0:
        x, y = P(960, 410)
        cv.circle(x, y, 34 * sc, config.WHITE, a)
        x, y = P(960, 527)
        cv.ellipse(x, y, 42 * sc, 75 * sc, config.WHITE, a)
    elif i == 1:
        for kk in range(6):
            w = (200 - kk * 22) * sc
            x, y = P(960, 600 - kk * 40)
            cv.rect(x - w / 2, y, w, 38 * sc, config.WHITE, a * 0.9)
    elif i == 2:
        x, y = P(960, 300)
        x2, y2 = P(1200, 620)
        x3, y3 = P(720, 620)
        cv.line(x, y, x2, y2, 6 * sc, config.WHITE, a)
        cv.line(x2, y2, x3, y3, 6 * sc, config.WHITE, a)
        cv.line(x3, y3, x, y, 6 * sc, config.WHITE, a)
    elif i == 3:
        x, y = P(960, 480)
        cv.circle(x, y, 200 * sc, config.BLUE, a)
        cv.ring(x, y, 201 * sc, 2 * sc, config.ORANGE, a)
    elif i == 4:
        x, y = P(960, 480)
        cv.radial(x, y, 240 * sc, [(0.0, config.WHITE, a), (0.35, config.ORANGE, a),
                                   (1.0, config.ORANGE, 0.0)])
    else:
        g = GALAXY
        ang = g["a"] + g["r"] * 0.9
        rr = g["r"] * 330 * sc
        xs = 960 + np.cos(ang) * rr
        ys = 480 + np.sin(ang) * rr * 0.42
        rgb = np.where(g["blue"][:, None], np.asarray(config.BLUE, dtype=np.float32),
                       np.asarray(config.ORANGE, dtype=np.float32))
        splat(cv, xs, ys, g["size"] * sc, rgb, np.full(len(xs), a * 0.75, dtype=np.float32))


# =====================================================================
# hero + CTA
# =====================================================================
def scene_hero(cv: Canvas, t: float) -> None:
    push = 1 + 0.15 * ease(EASE_IO, prog(t, 32.0, 44.0))
    star = 1 + 0.03 * math.sin(2 * math.pi * 0.5 * (t - 32))
    r = 200 * star * push
    cv.radial(960, 500, r, [(0.0, config.WHITE, 1.0), (0.22, (188, 216, 255), 1.0),
                            (0.52, config.BLUE, 1.0), (0.82, config.ORANGE, 1.0),
                            (1.0, config.ORANGE, 0.05)], additive=False)
    for i in range(8):
        ring = 420 if i < 4 else 560
        direction = 1 if i % 2 == 0 else -1
        ang = (i * math.pi / 4) + direction * 0.3 * (t - 32.0)
        x = 960 + math.cos(ang) * ring * push
        y = 500 + math.sin(ang) * ring * 0.34 * push
        cv.circle(x, y, 22 * push, config.ORANGE if i % 2 else config.BLUE, 0.85)
        cv.ring(x, y, 26 * push, 4 * push, config.WHITE, 0.7)


CTA_SEED = None


def cta_seed(n: int = 3000) -> dict[str, np.ndarray]:
    global CTA_SEED
    if CTA_SEED is None:
        r = Rng(config.SEED)
        pos = np.zeros((n, 2), dtype=np.float32)
        vel = np.zeros((n, 2), dtype=np.float32)
        col = np.zeros(n, dtype=bool)
        size = np.zeros(n, dtype=np.float32)
        for i in range(n):
            a = r.f() * 2 * math.pi
            z = r.f() * math.pi - math.pi / 2
            rr = 200 * (r.f() ** 0.4)
            pos[i] = (960 + math.cos(a) * math.cos(z) * rr, 500 + math.sin(z) * rr)
            sp = r.range(240, 1150)
            vel[i] = (math.cos(a) * math.cos(z) * sp, math.sin(z) * sp * 0.75)
            col[i] = r.f() > 0.5
            size[i] = r.range(1.8, 5.2)
        CTA_SEED = {"pos": pos, "vel": vel, "col": col, "size": size}
    return CTA_SEED


_PTS: dict[int, dict[str, np.ndarray]] = {}


def cta_targets(records: dict[str, layout.Record], n: int = 3000) -> dict[str, np.ndarray]:
    """Sample the laid-out glyphs into n target points (cached, R-PERF-03)."""
    key = id(records)
    if key in _PTS:
        return _PTS[key]
    out = {name: _sample_text(records[rid], n)
           for name, rid in (("a", "cta_bald"), ("b", "cta_ab"), ("c", "cta_url"))}
    _PTS[key] = out
    return out


def _sample_text(rec: layout.Record, n: int) -> np.ndarray:
    from PIL import Image as PILImage, ImageDraw

    from . import fonts
    w = max(2, int(rec.box[2]) + 12)
    h = max(2, int(rec.box[3]) + 12)
    img = PILImage.new("L", (w, h), 0)
    d = ImageDraw.Draw(img)
    font = fonts.bold(rec.size)
    ox, oy = 6 - rec.box[0], 6 + (rec.baseline_y - rec.box[1])
    for g in rec.glyphs:
        d.text((ox + g.x, oy), g.ch, font=font, fill=255)
    arr = np.asarray(img)
    ys, xs = np.nonzero(arr[::2, ::2] > 150)
    pts = np.stack([xs * 2 + rec.box[0] - 6, ys * 2 + rec.box[1] - 6], axis=1).astype(np.float32)
    r = Rng(config.SEED)
    idx = np.array([int(r.f() * len(pts)) % max(1, len(pts)) for _ in range(n)], dtype=np.int64)
    return pts[idx] if len(pts) else np.tile(np.array([[rec.cx, rec.baseline_y]], dtype=np.float32), (n, 1))


def scene_cta(cv: Canvas, t: float, records: dict[str, layout.Record]) -> None:
    n = 3000
    seed = cta_seed(n)
    T = cta_targets(records, n)
    tau = t - 44.0
    if tau < 0:
        return
    drag = 1.5
    k = (1 - math.exp(-drag * min(tau, 1.6))) / drag
    pos = seed["pos"] + seed["vel"] * k
    pa = ease(EASE_IO, prog(t, 45.6, 46.9))
    pb = ease(EASE_IO, prog(t, 48.2, 49.2))
    pc = ease(EASE_IO, prog(t, 49.7, 51.0))
    if tau < 1.6:
        settled = np.zeros(n, dtype=np.float32)
    elif t < 48.2:
        kb = (1 - math.exp(-drag * 1.6)) / drag
        base = seed["pos"] + seed["vel"] * kb
        pos = base + (T["a"] - base) * pa
        settled = np.full(n, pa, dtype=np.float32)
    elif t < 49.7:
        pos = T["a"] + (T["b"] - T["a"]) * pb
        settled = np.full(n, pb, dtype=np.float32)
    else:
        pos = T["b"] + (T["c"] - T["b"]) * pc
        settled = np.full(n, pc, dtype=np.float32)
    push_out = 1 + 0.05 * ease(EASE_IO, prog(t, 55, 59)) if t > 55 else 1.0
    xs = 960 + (pos[:, 0] - 960) * push_out
    ys = 540 + (pos[:, 1] - 540) * push_out
    sizes = seed["size"] * (1 - 0.58 * settled)
    alpha = np.clip(0.35 + settled * 0.6, 0, 1) * (1 - clamp01(prog(t, 58.8, 60.0)))
    rgb = np.where(seed["col"][:, None], np.asarray(config.ORANGE, dtype=np.float32),
                   np.asarray(config.BLUE, dtype=np.float32))
    splat(cv, xs, ys, sizes, rgb, alpha.astype(np.float32))


# =====================================================================
# post layers
# =====================================================================
def apply_post(cv: Canvas, frame: int, t: float) -> None:
    # anamorphic flare, one per title reveal (R-VIS-05)
    for start, end, cy in ((2.0, 2.75, 540),):
        p = prog(t, start, end)
        if 0 < p < 1:
            env = math.sin(math.pi * p)
            cv.rect(960 - 700, cy - 3, 1400, 6, config.WHITE, 0.95 * env, additive=True)
            cv.radial(960, cy, 120, [(0.0, config.WHITE, 0.75 * env), (1.0, config.BLUE, 0.0)])
    # off-screen flicker, one per act
    for at in (0.35, 8.05, 32.05, 44.05):
        d = t - at
        if 0 <= d <= 0.42:
            env = math.sin(math.pi * (d / 0.42)) * (0.5 + 0.5 * math.sin(d * 78))
            cv.rect(0, 0, config.REF_W, config.REF_H, config.BLUE, 0.05 * env, additive=True)
    # grain (R-VIS-07)
    tile = grain(cv.scale)
    ox, oy = grain_offsets(frame, tile.shape[0])
    reps = (cv.h // tile.shape[0]) + 2
    reps_x = (cv.w // tile.shape[1]) + 2
    tiled = np.tile(tile, (reps, reps_x))[: cv.h + tile.shape[0], : cv.w + tile.shape[1]]
    g = np.roll(np.roll(tiled, -oy, axis=0), -ox, axis=1)[: cv.h, : cv.w]
    cv.buf += (g[..., None] - 155.0) * config.GRAIN_OPACITY
    # vignette (R-VIS-08)
    cv.buf *= (1.0 - vignette_layer(cv.scale))[..., None]
    # fade to black (R-SCN-11)
    if t >= 59.0:
        cv.buf *= 1.0 - prog(t, 59.0, 60.0)
    np.clip(cv.buf, 0, 255, out=cv.buf)


# =====================================================================
# frame entry point
# =====================================================================
SCENE_SPANS: Sequence[tuple[float, float, str]] = (
    (0.0, 8.0, "opening"), (8.0, 11.0, "wallet"), (11.0, 14.0, "password"),
    (14.0, 17.0, "deepsea"), (17.0, 20.0, "tempo"), (20.0, 23.0, "asteroid"),
    (23.0, 26.0, "circle"), (26.0, 29.0, "lifestats"), (29.0, 32.0, "universe"),
    (32.0, 44.0, "hero"), (44.0, 60.0, "cta"),
)


def render_frame(frame: int, records: dict[str, layout.Record], scale: float,
                 haze: np.ndarray) -> np.ndarray:
    """Pure function of `frame`. Returns an (H, W, 3) uint8 RGB array."""
    t = frame / config.FPS
    cv = Canvas(int(config.REF_W * scale), int(config.REF_H * scale), scale)
    cv.buf[:] = haze
    name = SCENE_SPANS[-1][2]
    for a, b, n in SCENE_SPANS:
        if a <= t < b:
            name = n
            break

    if name == "opening":
        scene_opening(cv, t)
    elif name == "wallet":
        scene_wallet(cv, t)
    elif name == "password":
        scene_password(cv, t)
    elif name == "deepsea":
        scene_deepsea(cv, t)
    elif name == "tempo":
        scene_tempo(cv, t)
    elif name == "asteroid":
        scene_asteroid(cv, t)
    elif name == "circle":
        scene_circle(cv, t)
    elif name == "lifestats":
        scene_lifestats(cv, t)
    elif name == "universe":
        scene_universe(cv, t)
    elif name == "hero":
        scene_hero(cv, t)
    elif name == "cta":
        scene_cta(cv, t, records)

    draw_declared_text(cv, t, records)
    apply_post(cv, frame, t)
    return cv.to_uint8()


def draw_declared_text(cv: Canvas, t: float, records: dict[str, layout.Record]) -> None:
    """Every on-screen string goes through the layout system (R-TXT-02)."""
    for rec in records.values():
        if not active(t, rec.start, rec.end):
            continue
        alpha = ease(EASE_OUT_EARLY, prog(t, rec.start, rec.start + 0.35))
        if rec.glass:
            layout.draw_glass_panel(cv, rec, alpha)
        kwargs: dict[str, float] = {"alpha": alpha}
        if rec.id == "title_opening_main":
            kwargs = {"alpha": min(1.0, alpha * 2), "reveal": (t - 2.0) / 0.045,
                      "tail": 2, "tail_dist": 60 * (1 - clamp01(prog(t, 3.0, 3.8))), "glow": 0.55}
        elif rec.id == "cta_pill_label":
            kwargs = {"alpha": ease(EASE_OUT_EARLY, prog(t, 53.0, 55.0))}
        elif rec.id == "hero_brand":
            kwargs = {"alpha": ease(EASE_OUT_EARLY, prog(t, 36.5, 37.5)), "glow": 0.45}
        elif rec.id.startswith("cta_"):
            kwargs = {"alpha": 1.0, "glow": 0.4}
        layout.draw_text(cv, rec, **kwargs)
    # gradient underline sweep beneath the URL (R-SCN-11)
    url = records.get("cta_url")
    if url and t >= 51.5:
        p = ease(EASE_IO, prog(t, 51.5, 52.5))
        y = url.box[1] + url.box[3] - 6
        cv.linear_gradient_rect(url.box[0], y, url.box[2] * p, 5,
                                config.BLUE, config.ORANGE, mid=config.WHITE)
