"""
vo.py — R-AUD-01 German voiceover.

Priority order:
  1. pre-recorded / pre-generated WAVs already in audio/vo/  (vo_01.wav …)
  2. a neural de-DE engine (edge-tts) if it is installed and reachable
  3. espeak-ng  -> PLACEHOLDER, allowed for the 1080p test ONLY (R-GATE-03)

Every line is normalised to -18 dBFS RMS before mixing.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np

from . import config

MANIFEST = config.RENDER_DIR / "vo_manifest.json"
NEURAL_VOICE = "de-DE-ConradNeural"   # professional, confident, slightly deep


def load_wav(path: Path) -> np.ndarray:
    with wave.open(str(path), "rb") as w:
        assert w.getframerate() == config.SR, f"{path}: expected {config.SR} Hz"
        assert w.getnchannels() >= 1
        raw = w.readframes(w.getnframes())
        n = w.getnframes()
    x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    if w.getnchannels() == 2:
        x = x.reshape(-1, 2).mean(axis=1)
    del n
    return x


def save_wav(path: Path, x: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = np.clip(x, -1, 1)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(config.SR)
        w.writeframes((data * 32767).astype(np.int16).tobytes())


def rms_dbfs(x: np.ndarray) -> float:
    r = float(np.sqrt(np.mean(np.square(x))))
    return -120.0 if r <= 1e-9 else 20 * np.log10(r)


def normalize_rms(x: np.ndarray, target_dbfs: float = config.VO_RMS_DBFS) -> np.ndarray:
    current = rms_dbfs(x)
    if current <= -119:
        return x
    gain = 10 ** ((target_dbfs - current) / 20)
    peak = float(np.abs(x).max()) * gain
    if peak > 0.99:            # keep headroom, never clip
        gain *= 0.99 / peak
    return x * gain


def resample(x: np.ndarray, src_sr: int) -> np.ndarray:
    if src_sr == config.SR:
        return x
    n = int(len(x) * config.SR / src_sr)
    pos = np.linspace(0, len(x) - 1, n)
    return np.interp(pos, np.arange(len(x)), x).astype(np.float32)


def _espeak(text: str, out: Path) -> bool:
    exe = shutil.which("espeak-ng") or shutil.which("espeak")
    if not exe:
        return False
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".raw.wav")
    cmd = [exe, "-v", "de", "-s", "152", "-p", "38", "-w", str(tmp), text]
    if subprocess.run(cmd, capture_output=True).returncode != 0:
        return False
    with wave.open(str(tmp), "rb") as w:
        sr = w.getframerate()
        raw = w.readframes(w.getnframes())
    x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    tmp.unlink(missing_ok=True)
    save_wav(out, resample(x, sr))
    return True


def _neural(text: str, out: Path) -> bool:
    """edge-tts (Microsoft neural voices) if the package is installed."""
    try:
        import asyncio

        import edge_tts  # type: ignore
    except Exception:
        return False

    async def run() -> None:
        mp3 = out.with_suffix(".mp3")
        await edge_tts.Communicate(text, NEURAL_VOICE, rate="-4%", pitch="-2Hz").save(str(mp3))
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            try:
                import imageio_ffmpeg
                ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
            except Exception:
                return
        subprocess.run([ffmpeg, "-y", "-i", str(mp3), "-ar", str(config.SR), "-ac", "1", str(out)],
                       check=True, capture_output=True)
        mp3.unlink(missing_ok=True)

    try:
        asyncio.run(run())
        return out.exists()
    except Exception:
        return False


def generate(timeline: dict, engine: str = "auto") -> dict:
    """Produce audio/vo/<id>.wav for every declared line. Returns a manifest."""
    config.ensure_dirs()
    lines = timeline["audio"]["vo"]["lines"]
    used_engine = "none"
    rows = []
    for line in lines:
        lid, text = line["id"], line["string"]
        path = config.VO_DIR / f"{lid}.wav"
        if path.exists():
            eng = "pre-supplied"
        elif engine in ("auto", "neural") and _neural(text, path):
            eng = f"neural:{NEURAL_VOICE}"
        elif engine in ("auto", "espeak-ng") and _espeak(text, path):
            eng = "PLACEHOLDER:espeak-ng"
        else:
            eng = "MISSING"
        used_engine = eng if eng != "pre-supplied" else used_engine
        if path.exists():
            x = normalize_rms(load_wav(path))
            save_wav(path, x)
            rows.append({"id": lid, "file": str(path.relative_to(config.ROOT)),
                         "engine": eng, "seconds": round(len(x) / config.SR, 3),
                         "rms_dbfs": round(rms_dbfs(x), 2), "string": text})
        else:
            rows.append({"id": lid, "file": None, "engine": eng, "string": text})
    placeholder = any(r["engine"].startswith("PLACEHOLDER") or r["engine"] == "MISSING" for r in rows)
    manifest = {
        "engine": used_engine,
        "placeholder": placeholder,
        "normalize_target_dbfs": config.VO_RMS_DBFS,
        "gate": "R-GATE-03 blocks the 4K master while placeholder is true",
        "lines": rows,
    }
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    return manifest


def main() -> int:
    from .config import load_timeline
    engine = "auto"
    if "--engine" in sys.argv:
        engine = sys.argv[sys.argv.index("--engine") + 1]
    m = generate(load_timeline(), engine)
    print(json.dumps({k: v for k, v in m.items() if k != "lines"}, ensure_ascii=False, indent=1))
    for row in m["lines"]:
        print(f"  {row['id']:6s} {row['engine']:24s} {row.get('seconds', '-'):>7} s  {row['string'][:48]}")
    return 0 if not m["placeholder"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
