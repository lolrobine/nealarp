"""
audio.py — R-AUD-02 (music) and R-AUD-03 (sfx), generated in code at 48 kHz.

No samples, no licensed material (R-NEG-07). Every sound is a synthesised
oscillator or filtered noise burst. Filtering is done in the frequency domain
so there is no per-sample Python loop (R-PERF-02).
"""
from __future__ import annotations

import math

import numpy as np

from . import config
from .rng import mulberry32

SR = config.SR


# ------------------------------------------------------------------ helpers
def t_axis(dur: float) -> np.ndarray:
    return np.arange(int(dur * SR), dtype=np.float64) / SR


def sine(f0: float, f1: float | None, dur: float) -> np.ndarray:
    """Sine with an exponential frequency sweep (f1=None → constant)."""
    t = t_axis(dur)
    if f1 is None or f1 == f0:
        phase = 2 * math.pi * f0 * t
    else:
        k = math.log(max(1e-6, f1) / max(1e-6, f0)) / max(1e-6, dur)
        phase = 2 * math.pi * f0 * (np.exp(k * t) - 1) / k
    return np.sin(phase)


def noise(dur: float, seed: int = config.SEED, brown: bool = False) -> np.ndarray:
    n = int(dur * SR)
    rnd = np.random.default_rng(seed)
    w = rnd.standard_normal(n)
    if not brown:
        return w
    b = np.cumsum(w)
    b -= np.linspace(b[0], b[-1], n)
    return b / max(1e-9, np.abs(b).max())


def _fft_filter(x: np.ndarray, response) -> np.ndarray:
    spec = np.fft.rfft(x)
    freqs = np.fft.rfftfreq(len(x), 1.0 / SR)
    return np.fft.irfft(spec * response(freqs), n=len(x))


def lowpass(x: np.ndarray, hz: float, q: float = 0.707) -> np.ndarray:
    def r(f):
        return 1.0 / np.sqrt(1.0 + (f / max(1.0, hz)) ** (2 * 2)) ** q
    return _fft_filter(x, r)


def bandpass(x: np.ndarray, f0: float, f1: float, q: float = 1.2) -> np.ndarray:
    lo, hi = min(f0, f1), max(f0, f1)

    def r(f):
        return np.exp(-0.5 * ((np.log(np.maximum(f, 1.0)) - np.log(max(1.0, math.sqrt(lo * hi))))
                              / max(0.05, math.log(max(1.05, hi / lo)) / q)) ** 2)
    return _fft_filter(x, r)


def env_ad(n: int, attack: float, decay: float) -> np.ndarray:
    e = np.ones(n)
    a = max(1, int(attack * SR))
    d = max(1, int(decay * SR))
    e[:a] = np.linspace(0, 1, a)
    e[-d:] *= np.linspace(1, 0, d)
    return e


def peak_db(x: np.ndarray, db: float) -> np.ndarray:
    m = np.abs(x).max()
    return x * (10 ** (db / 20)) / max(1e-9, m)


def pad_to(x: np.ndarray, n: int) -> np.ndarray:
    if len(x) >= n:
        return x[:n]
    return np.concatenate([x, np.zeros(n - len(x))])


def place(bus: np.ndarray, x: np.ndarray, at: float) -> None:
    i = int(round(at * SR))
    if i >= len(bus):
        return
    seg = x[: len(bus) - i]
    bus[i : i + len(seg)] += seg


def echo(x: np.ndarray, delay: float = 0.25, feedback: float = 0.3, taps: int = 6) -> np.ndarray:
    """R-AUD-02 echo: delay 0.25 s, feedback 0.3."""
    out = x.copy()
    d = int(delay * SR)
    g = feedback
    for _ in range(taps):
        delayed = np.zeros(len(x) + d)
        delayed[d:] = x * g
        out = pad_to(out, len(delayed)) + delayed
        g *= feedback
    return out


# ------------------------------------------------------------------ sfx recipes (R-AUD-03)
def sfx(recipe: str, dur: float | None = None) -> np.ndarray:
    if recipe == "sfx_pop":
        x = sine(1200, 600, 0.08) * env_ad(int(0.08 * SR), 0.002, 0.07)
        x = pad_to(x, int(0.09 * SR))
        x[: int(0.005 * SR)] += noise(0.005, 11) * 0.35
        return peak_db(x, -6)
    if recipe == "sfx_click":
        x = bandpass(noise(0.029, 12), 2000, 4000) * env_ad(int(0.029 * SR), 0.001, 0.025)
        return peak_db(x, -8)
    if recipe == "sfx_coin_clink":
        j = 1 + (mulberry32(13)() * 0.06 - 0.03)
        n = int(0.3 * SR)
        x = sine(3000 * j, None, 0.3) * env_ad(n, 0.001, 0.29)
        x += sine(4500 * j, None, 0.3) * env_ad(n, 0.001, 0.29) * 0.6
        return peak_db(x, -10)
    if recipe == "sfx_lock_clunk":
        x = sine(90, 55, 0.18) * env_ad(int(0.18 * SR), 0.002, 0.17)
        out = pad_to(x, int(0.25 * SR))
        place(out, sfx("sfx_click"), 0.0)
        return peak_db(out, -6)
    if recipe == "sfx_bubble":
        length = dur or 0.06 + mulberry32(17)() * 0.06
        n = int(length * SR)
        return peak_db(sine(300, 900, length) * env_ad(n, 0.004, int(length) and n // 2), -14)
    if recipe == "sfx_whirr":
        length = dur or 3.0
        n = int(length * SR)
        t = t_axis(length)
        x = np.zeros(n)
        for i in range(8):
            f = 200 * (1 + i * 0.004) * np.power(6.0, t / length)
            x += np.sin(2 * math.pi * np.cumsum(f) / SR) / 8
        return peak_db(x * env_ad(n, 0.4, 0.3), -12)
    if recipe == "sfx_boom":
        n = int(1.5 * SR)
        x = pad_to(sine(60, None, 1.2) * env_ad(int(1.2 * SR), 0.005, 1.1), n)
        x += lowpass(noise(1.5, 21, brown=True), 600) * env_ad(n, 0.004, int(1.4 * SR)) * 0.7
        return peak_db(x, -4)
    if recipe == "sfx_pen_draw":
        length = dur or 1.2
        n = int(length * SR)
        t = t_axis(length)
        x = bandpass(noise(length, 23), 2000, 5000)
        x *= (0.5 + 0.5 * np.sin(2 * math.pi * 18 * t)) * env_ad(n, 0.05, 0.2)
        return peak_db(x, -18)
    if recipe == "sfx_heartbeat":
        n = int(0.55 * SR)
        out = np.zeros(n)
        place(out, peak_db(sine(55, None, 0.12) * env_ad(int(0.12 * SR), 0.006, 0.1), -8), 0.0)
        place(out, peak_db(sine(55, None, 0.12) * env_ad(int(0.12 * SR), 0.006, 0.1), -10), 0.3)
        return out
    if recipe == "sfx_whoosh_zoom":
        length = dur or 1.2
        n = int(length * SR)
        x = noise(length, 29)
        # sweep the band 300 → 3000 Hz in chunks, envelope rises then falls
        out = np.zeros(n)
        chunks = 24
        for i in range(chunks):
            f0 = 300 * (10 ** (i / chunks))
            f1 = 300 * (10 ** ((i + 1) / chunks))
            seg = bandpass(x[i * n // chunks : (i + 1) * n // chunks], f0, f1)
            out[i * n // chunks : (i + 1) * n // chunks] = seg
        out *= np.sin(np.pi * np.arange(n) / n) ** 1.2
        return peak_db(out, -10)
    if recipe == "sfx_bass_drop":
        n = int(1.5 * SR)
        return peak_db(sine(120, 35, 1.5) * env_ad(n, 0.01, 1.2), -4)
    if recipe == "sfx_bass_hit":
        n = int(0.8 * SR)
        x = sine(45, None, 0.8) * env_ad(n, 0.003, 0.7)
        x[: int(0.02 * SR)] += noise(0.02, 31) * 0.6
        x = peak_db(x, -3)
        return pad_to(echo(x, 0.25, 0.3), int(2.0 * SR))
    raise KeyError(recipe)


# ------------------------------------------------------------------ music (R-AUD-02)
SCALE = [0, 3, 5, 7, 10, 12, 15, 12, 10, 7, 5, 3]
ROOTS = [110.0, 98.0, 87.31, 110.0]


def arp_note(freq: float, dur: float, cutoff: float, warmth: float) -> np.ndarray:
    """8 detuned sines through a lowpass; warmth raises the harmonic emphasis."""
    n = int(dur * SR)
    x = np.zeros(n)
    for i in range(8):
        f = freq * (1 if i < 4 else 2) * (1 + (i - 3.5) * 0.0022)
        g = 0.32 if i < 4 else 0.08 + warmth * 0.20
        x += sine(f, None, dur) * g
    x = lowpass(x, cutoff)
    return x * env_ad(n, 0.008, int(dur * 0.9 * SR))


def music(duration: float = config.DURATION) -> np.ndarray:
    n = int(duration * SR)
    out = np.zeros(n)
    step = 60.0 / config.BPM / 4          # 16th at 120 BPM
    total_steps = int(duration / step)
    for s in range(total_steps):
        t = s * step
        i = int(round(t * SR))
        section = 0 if t < 8 else 1 if t < 32 else 2 if t < 44 else 3
        warmth = min(1.0, max(0.0, (t - 8) / 24))
        cutoff = 2000 + warmth * 2600
        amp = {0: 0.10, 1: 0.15, 2: 0.17, 3: 0.09 * max(0.0, 1 - (t - 44) / 16)}[section]
        if amp <= 0.001:
            continue
        root = ROOTS[int(t // 8) % 4]
        semis = SCALE[s % len(SCALE)] + (12 if int(t // 8) % 4 == 2 else 0)
        f = root * 2 ** (semis / 12)
        note = arp_note(f, step * 1.7, cutoff, warmth) * amp
        out[i : i + min(len(note), n - i)] += note[: n - i]
        if t >= 8 and s % 4 == 0 and t < 58:
            kick = sine(96 if t < 44 else 70, 40, 0.26) * env_ad(int(0.26 * SR), 0.002, 0.24) * 0.5
            out[i : i + min(len(kick), n - i)] += kick[: n - i]
    # risers into the act boundaries
    for a, b, peak in ((5.5, 8.0, 0.16), (30.0, 32.0, 0.20), (40.0, 44.0, 0.30)):
        length = b - a
        x = bandpass(noise(length, 37), 400, 6200) * np.linspace(0.02, peak, int(length * SR)) ** 1.6
        place(out, x, a)
    # 32-44 swell pad
    for a in np.arange(32.0, 44.0, 4.0):
        pad = np.zeros(int(4.0 * SR))
        for mult in (1, 1.5, 2, 2.996):
            pad += lowpass(sine(110 * mult, None, 4.0) * 0.05, 900)
        pad *= env_ad(len(pad), 2.0, 2.0)
        place(out, pad, a)
    # 0.0 s bass drop and 44.0 s bass hit with echo
    place(out, sfx("sfx_bass_drop"), 0.0)
    place(out, sfx("sfx_bass_hit"), 44.0)
    # fade to silence by 60.000 s
    fade = int(2.0 * SR)
    out[-fade:] *= np.linspace(1, 0, fade)
    return out


def sfx_bus(timeline: dict) -> np.ndarray:
    n = int(config.DURATION * SR)
    bus = np.zeros(n)
    events: list[tuple[float, str, float | None]] = []
    for scene in timeline.get("scenes", []):
        for e in (scene.get("audio", {}) or {}).get("sfx", []) or []:
            until = e.get("until")
            dur = (until - e["at"]) if until else None
            events.append((float(e["at"]), e["id"], dur))
    for at, recipe, dur in events:
        x = sfx(recipe, dur)
        place(bus, x, at)
    return peak_db(bus, -3) if np.abs(bus).max() > 0 else bus
