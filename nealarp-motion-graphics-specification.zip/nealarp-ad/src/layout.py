"""
layout.py — the text layout system (R-VIS-12, R-TXT-02, R-TXT-03).

Scenes never draw text themselves. They ask for a declared text id; this module
measures it, auto-fits it, logs it and rasterises it. The JSON log is what
R-VER-08 and R-VER-09 are checked against.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Sequence

import numpy as np
from PIL import Image, ImageDraw

from . import config, fonts
from .canvas import Canvas
from .easing import clamp01

# ------------------------------------------------------------------ templates
@dataclass(frozen=True)
class Template:
    size: int
    fill: str                      # gradient | white | orange
    cx: float
    y: float
    anchor: str                    # baseline | middle
    tracking: float                # em
    uppercase: bool
    glass_pad_x: int = 0
    glass_pad_y: int = 0
    glass_radius: int = 0


TEMPLATES: dict[str, Template] = {
    "title_lower_third": Template(96, "gradient", 960, 880, "baseline", 0.04, True, 48, 28, 24),
    "title_opening":     Template(180, "gradient", 960, 540, "middle", 0.04, True),
    "counter_center":    Template(160, "white", 960, 520, "middle", 0.02, False),
    "claim_white":       Template(112, "white", 960, 540, "middle", 0.02, True),
    "claim_gradient":    Template(96, "gradient", 960, 540, "middle", 0.04, True),
    "url":               Template(72, "white", 960, 600, "middle", 0.01, False),
    "cta_button_label":  Template(44, "white", 960, 780, "middle", 0.06, True),
    # documented additions (see README §Deviations)
    "panel_label":       Template(34, "white", 960, 430, "middle", 0.14, True),
    "score_orange_160":  Template(160, "orange", 1480, 470, "middle", 0.0, False),
}

CAP_RATIO = 0.365


@dataclass
class Glyph:
    ch: str
    x: float       # reference px, left edge
    w: float


@dataclass
class Record:
    id: str
    string: str
    layout: str
    start: float
    end: float
    base_size: int
    size: int
    autofit: bool
    autofit_steps: int
    width: float
    cx: float
    baseline_y: float
    tracking: float
    fill: str
    glyphs: list[Glyph] = field(default_factory=list)
    box: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)
    glass: tuple[int, int, int] | None = None
    safe_area_ok: bool = True
    safe_area_note: str = ""


def _measure(size: int, text: str, tracking_em: float) -> tuple[float, list[Glyph]]:
    font = fonts.bold(size)
    img = Image.new("L", (8, 8))
    d = ImageDraw.Draw(img)
    track = tracking_em * size
    glyphs: list[Glyph] = []
    total = 0.0
    for ch in text:
        w = d.textlength(ch, font=font)
        glyphs.append(Glyph(ch, total, w))
        total += w + track
    return max(0.0, total - track), glyphs


def build_records(timeline: dict, scale: float = 1.0) -> dict[str, Record]:
    """Measure + auto-fit every declared text entry, once, before rendering."""
    records: dict[str, Record] = {}
    for scene in timeline.get("scenes", []):
        for entry in scene.get("text", []) or []:
            tpl = TEMPLATES[entry["layout"]]
            raw = entry["string"]
            text = raw.upper() if tpl.uppercase else raw
            props = entry.get("props", {}) or {}
            cx = float(props.get("cx", tpl.cx))
            size = int(props.get("size", tpl.size))
            base = size
            width, glyphs = _measure(size, text, tpl.tracking)
            steps = 0
            # R-TXT-03
            while width > config.AUTOFIT_MAX_WIDTH and size - config.AUTOFIT_STEP >= config.AUTOFIT_MIN_SIZE:
                size -= config.AUTOFIT_STEP
                steps += 1
                width, glyphs = _measure(size, text, tpl.tracking)
            cy = float(props.get("cy", tpl.y))
            baseline = tpl.y if tpl.anchor == "baseline" else cy + CAP_RATIO * size
            track = tpl.tracking * size
            x0 = cx - width / 2.0
            for g in glyphs:
                g.x += x0
            font = fonts.bold(size)
            ascent, descent = font.getmetrics()
            pad_x, pad_y = tpl.glass_pad_x, tpl.glass_pad_y
            box = (x0 - pad_x, baseline - ascent - pad_y, width + 2 * pad_x, ascent + descent + 2 * pad_y)
            inside = (
                box[0] >= config.SAFE["left"] - 0.5
                and box[0] + box[2] <= config.REF_W - config.SAFE["right"] + 0.5
                and box[1] >= config.SAFE["top"] - 0.5
                and box[1] + box[3] <= config.REF_H - config.SAFE["bottom"] + 0.5
            )
            records[entry["id"]] = Record(
                id=entry["id"], string=raw, layout=entry["layout"],
                start=float(entry["start"]), end=float(entry["end"]),
                base_size=base, size=size, autofit=steps > 0, autofit_steps=steps,
                width=width, cx=cx, baseline_y=baseline, tracking=tpl.tracking, fill=tpl.fill,
                glyphs=glyphs, box=box,
                glass=(pad_x, pad_y, tpl.glass_radius) if tpl.glass_radius else None,
                safe_area_ok=inside,
                safe_area_note=(f"ok x[{box[0]:.0f}..{box[0]+box[2]:.0f}] y[{box[1]:.0f}..{box[1]+box[3]:.0f}]"
                                if inside else "OUTSIDE SAFE AREA"),
            )
    return records


def write_log(records: Sequence[Record], path=config.LAYOUT_LOG) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for r in records:
        d = asdict(r)
        d["glyphs"] = [{"ch": g.ch, "x": round(g.x, 3), "w": round(g.w, 3)} for g in r.glyphs]
        rows.append(d)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"scale_note": "reference px (1920x1080)", "entries": rows}, fh, ensure_ascii=False, indent=1)


# ------------------------------------------------------------------ drawing
def _glyph_alpha_image(rec: Record, reveal: float | None, scale: float) -> Image.Image:
    """Rasterise the whole run with tracking into an L image (device pixels)."""
    from PIL import ImageChops

    pad = int(6 * scale)
    w = max(2, int(rec.box[2] * scale) + pad * 2)
    h = max(2, int(rec.box[3] * scale) + pad * 2)
    img = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(img)
    font = fonts.bold(int(round(rec.size * scale)))
    ox = pad - rec.box[0] * scale                     # reference x -> device x
    oy = pad + (rec.baseline_y - rec.box[1]) * scale  # baseline -> device y
    for i, g in enumerate(rec.glyphs):
        px, py = ox + g.x * scale, oy
        a = 1.0 if reveal is None else clamp01(reveal - i)
        if a <= 0:
            continue
        if a >= 1.0:
            d.text((px, py), g.ch, font=font, fill=255)
            continue
        layer = Image.new("L", (w, h), 0)
        ImageDraw.Draw(layer).text((px, py), g.ch, font=font, fill=int(round(255 * a)))
        img = ImageChops.lighter(img, layer)
    return img


def draw_text(cv: Canvas, rec: Record, alpha: float = 1.0, reveal: float | None = None,
              tail: int = 0, tail_dist: float = 0.0, glow: float = 0.0,
              pulse: float = 1.0) -> None:
    """
    Rasterise a record into the canvas:
      * per-glyph tracking, optional staggered reveal (R-SCN-01)
      * motion-blur tail on the last `tail` glyphs
      * gradient / white / orange fill (R-VIS-03)
      * additive glow (R-VIS-05 bloom)
    """
    if alpha <= 0.004 or not rec.glyphs:
        return
    sc = cv.scale * pulse
    mask = _glyph_alpha_image(rec, reveal, sc).astype(np.float32) / 255.0

    if tail > 0 and tail_dist > 0.5:
        n = len(rec.glyphs)
        for k in range(5, 0, -1):
            off = int(-tail_dist * sc * k / 5.0)
            partial = _tail_mask(rec, n - tail, sc)
            shifted = np.roll(partial, off, axis=1)
            if off < 0:
                shifted[:, off:] = 0
            mask = np.maximum(mask, shifted * 0.16 * (1 - k / 6.0))

    x0 = int(rec.box[0] * sc) - 6
    y0 = int(rec.box[1] * sc) - 6
    h, w = mask.shape
    x0 = max(0, min(cv.w - w, x0))
    y0 = max(0, min(cv.h - h, y0))
    x1, y1 = min(cv.w, x0 + w), min(cv.h, y0 + h)
    m = mask[: y1 - y0, : x1 - x0]

    if glow > 0:
        blurred = cv2_gaussian(m, config.BLOOM_BLUR * sc)
        _blit(cv, x0, y0, blurred, _fill_rgb(rec, cv, x0, x1), alpha * glow * config.BLOOM_STRENGTH, True)
    _blit(cv, x0, y0, m, _fill_rgb(rec, cv, x0, x1), alpha, False)


def _tail_mask(rec: Record, from_index: int, sc: float) -> np.ndarray:
    pad = int(6 * sc)
    w = int(rec.box[2] * sc) + pad * 2
    h = int(rec.box[3] * sc) + pad * 2
    img = Image.new("L", (max(2, w), max(2, h)), 0)
    d = ImageDraw.Draw(img)
    font = fonts.bold(int(rec.size * sc))
    origin_x = (-rec.box[0]) * sc + pad
    origin_y = (rec.baseline_y - rec.box[1]) * sc + pad
    for g in rec.glyphs[from_index:]:
        d.text((origin_x + g.x * sc, origin_y), g.ch, font=font, fill=255)
    return np.asarray(img, dtype=np.float32) / 255.0


def _fill_rgb(rec: Record, cv: Canvas, x0: int, x1: int) -> np.ndarray:
    """
    (1, span, 3) colour ramp for the device columns [x0, x1).
    R-VIS-03: the gradient runs blue -> orange across the whole text run, so a
    clipped blit still samples the correct part of the ramp.
    """
    span = max(1, x1 - x0)
    if rec.fill == "white":
        return np.full((1, span, 3), config.WHITE, dtype=np.float32)
    if rec.fill == "orange":
        return np.full((1, span, 3), config.ORANGE, dtype=np.float32)
    gx0 = rec.box[0] * cv.scale
    gx1 = gx0 + max(1e-6, rec.width * cv.scale)
    cols = np.arange(x0, x0 + span, dtype=np.float32) + 0.5
    p = np.clip((cols - gx0) / (gx1 - gx0), 0.0, 1.0)[None, :, None]
    # blue -> white -> orange (documented deviation, README §6): a direct lerp
    # crosses ~12-15 deg hue at 40 % saturation, which R-VER-06 rejects.
    blue = np.asarray(config.BLUE, dtype=np.float32).reshape(1, 1, 3)
    white = np.asarray(config.WHITE, dtype=np.float32).reshape(1, 1, 3)
    orange = np.asarray(config.ORANGE, dtype=np.float32).reshape(1, 1, 3)
    lo = np.where(p < 0.5, blue + (white - blue) * (p * 2.0), white)
    hi = np.where(p < 0.5, white, white + (orange - white) * ((p - 0.5) * 2.0))
    return np.where(p < 0.5, lo, hi).astype(np.float32)


def _blit(cv: Canvas, x0: int, y0: int, mask: np.ndarray, rgb: np.ndarray,
          alpha: float, additive: bool) -> None:
    h, w = mask.shape
    x0 = max(0, min(cv.w - 1, x0))
    y0 = max(0, min(cv.h - 1, y0))
    x1, y1 = min(cv.w, x0 + w), min(cv.h, y0 + h)
    if x1 <= x0 or y1 <= y0:
        return
    m = mask[: y1 - y0, : x1 - x0]
    r = rgb[:, : m.shape[1], :]
    a = (m * alpha)[..., None]
    region = cv.buf[y0:y1, x0:x1]
    if additive:
        cv.buf[y0:y1, x0:x1] = np.minimum(255.0, region + r * a)
    else:
        cv.buf[y0:y1, x0:x1] = region * (1.0 - a) + r * a


def cv2_gaussian(m: np.ndarray, sigma: float) -> np.ndarray:
    import cv2
    return cv2.GaussianBlur(m, (0, 0), max(0.3, sigma / 2.0))


def draw_glass_panel(cv: Canvas, rec: Record, alpha: float, backdrop: np.ndarray | None = None) -> None:
    """R-VIS-04: 10 % white fill, 1 px 25 % border, r24, inner shadow, 1/4-scale blur."""
    if not rec.glass or alpha <= 0.01:
        return
    x, y, w, h = rec.box
    radius = float(rec.glass[2])
    if backdrop is not None:
        cv.buf[:] = backdrop  # the caller passes the pre-blurred backdrop layer
    cv.rrect(x, y, w, h, radius, config.WHITE, alpha * 0.10)
    cv.rrect(x, y, w, h, radius, config.WHITE, alpha * 0.25, stroke=1.0)
    # inner shadow: 20 % black, offset (0,4), blur 12
    cv.rrect(x + 1, y + 5, w - 2, h - 6, radius, (0, 0, 0), alpha * 0.20, stroke=6.0)
