"""
easing.py — R-VIS-10, exact definitions.

  EASE_IO        = cubic-bezier(0.65, 0.00, 0.35, 1.00)
  EASE_OUT_EARLY = cubic-bezier(0.25, 0.80, 0.25, 1.00)
  EXPO_OUT       = 1 - 2^(-10 t)
  STEP           = hold the start value, snap at the end
"""
from __future__ import annotations

from typing import Callable

EASE_IO = "EASE_IO"
EASE_OUT_EARLY = "EASE_OUT_EARLY"
EXPO_OUT = "EXPO_OUT"
STEP = "STEP"


def clamp01(v: float) -> float:
    return 0.0 if v < 0.0 else (1.0 if v > 1.0 else v)


def lerp(a: float, b: float, p: float) -> float:
    return a + (b - a) * p


def cubic_bezier(x1: float, y1: float, x2: float, y2: float) -> Callable[[float], float]:
    """Newton-Raphson solve of the CSS cubic-bezier timing function."""

    def a(c1: float, c2: float) -> float:
        return 1.0 - 3.0 * c2 + 3.0 * c1

    def b(c1: float, c2: float) -> float:
        return 3.0 * c2 - 6.0 * c1

    def c(c1: float) -> float:
        return 3.0 * c1

    def calc(t: float, c1: float, c2: float) -> float:
        return ((a(c1, c2) * t + b(c1, c2)) * t + c(c1)) * t

    def slope(t: float, c1: float, c2: float) -> float:
        return 3.0 * a(c1, c2) * t * t + 2.0 * b(c1, c2) * t + c(c1)

    def solve(x: float) -> float:
        if x <= 0.0:
            return 0.0
        if x >= 1.0:
            return 1.0
        t = x
        for _ in range(8):
            s = slope(t, x1, x2)
            if abs(s) < 1e-6:
                break
            err = calc(t, x1, x2) - x
            if abs(err) < 1e-7:
                break
            t -= err / s
        return calc(t, y1, y2)

    return solve


_IO = cubic_bezier(0.65, 0.00, 0.35, 1.00)
_OUT_EARLY = cubic_bezier(0.25, 0.80, 0.25, 1.00)


def expo_out(p: float) -> float:
    return 1.0 if p >= 1.0 else 1.0 - 2.0 ** (-10.0 * p)


_TABLE: dict[str, Callable[[float], float]] = {
    EASE_IO: _IO,
    EASE_OUT_EARLY: _OUT_EARLY,
    EXPO_OUT: expo_out,
    STEP: lambda p: 1.0 if p >= 1.0 else 0.0,
}


def ease(name: str, p: float) -> float:
    return _TABLE[name](clamp01(p))


def prog(t: float, start: float, end: float) -> float:
    return clamp01((t - start) / max(1e-6, end - start))


def eased(name: str, t: float, start: float, end: float) -> float:
    return ease(name, prog(t, start, end))


def active(t: float, start: float, end: float) -> bool:
    return start <= t < end
