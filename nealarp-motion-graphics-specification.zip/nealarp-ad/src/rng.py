"""
rng.py — deterministic randomness (R-VIS-06, R-VIS-07).

The same mulberry32 stream is used by the browser preview so both stacks agree
bit-for-bit on every particle position.
"""
from __future__ import annotations

import numpy as np

from . import config


def mulberry32(seed: int):
    """Generator function identical to src/ad/rng.ts in the preview."""
    state = np.uint32(seed & 0xFFFFFFFF)

    def _next() -> float:
        nonlocal state
        state = np.uint32((int(state) + 0x6D2B79F5) & 0xFFFFFFFF)
        t = int(state)
        t = (t ^ (t >> 15)) * (t | 1) & 0xFFFFFFFF
        t = (t ^ (t + ((t ^ (t >> 7)) * (t | 61) & 0xFFFFFFFF))) & 0xFFFFFFFF
        return ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296.0

    return _next


class Rng:
    def __init__(self, seed: int = config.SEED) -> None:
        self._next = mulberry32(seed)

    def f(self) -> float:
        return self._next()

    def range(self, lo: float, hi: float) -> float:
        return lo + (hi - lo) * self._next()

    def int(self, lo: int, hi: int) -> int:
        return int(lo + (hi - lo + 1) * self._next()) % (hi + 1)

    def sign(self) -> int:
        return -1 if self._next() < 0.5 else 1


def grain_tile(size: int = config.GRAIN_TILE, seed: int = config.SEED) -> np.ndarray:
    """One pre-generated seeded grayscale tile, built once (R-PERF-01)."""
    rng = np.random.default_rng(seed)
    base = 110 + rng.integers(0, 90, size=(size, size), dtype=np.uint8)
    return base.astype(np.float32)


def grain_offsets(frame: int, size: int = config.GRAIN_TILE) -> tuple[int, int]:
    return (frame * 137) % size, (frame * 311) % size
