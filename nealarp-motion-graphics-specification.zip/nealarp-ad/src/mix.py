"""
mix.py — R-AUD-04: sum the voiceover, music and effects buses, duck the music
under the VO, then run ffmpeg's two-pass loudnorm to the R-OUT-05 targets.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np

from . import audio, config, vo

PRE = config.RENDER_DIR / "mix_pre.wav"
OUT = config.RENDER_DIR / "mix.wav"
STATS = config.RENDER_DIR / "loudnorm_stats.json"


def ffmpeg() -> str:
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def vo_bus(timeline: dict) -> np.ndarray:
    n = int(config.DURATION * config.SR)
    bus = np.zeros(n, dtype=np.float64)
    for line in timeline["audio"]["vo"]["lines"]:
        path = config.VO_DIR / f"{line['id']}.wav"
        if not path.exists():
            print(f"[mix] WARNING missing VO {path} — bus stays silent there", file=sys.stderr)
            continue
        x = vo.normalize_rms(vo.load_wav(path)).astype(np.float64)
        i = int(round(float(line["at"]) * config.SR))
        bus[i : i + min(len(x), n - i)] += x[: n - i]
    return bus


def duck(music: np.ndarray, timeline: dict, amount_db: float = -6.0) -> np.ndarray:
    """R-AUD-02: music bus ducked by 6 dB while voiceover plays."""
    out = music.copy()
    gain = 10 ** (amount_db / 20)
    ramp = int(0.12 * config.SR)
    for line in timeline["audio"]["vo"]["lines"]:
        a = int(round(float(line["at"]) * config.SR)) - int(0.08 * config.SR)
        b = a + int(round(float(line.get("dur", 3.0)) * config.SR)) + int(0.2 * config.SR)
        a, b = max(0, a), min(len(out), b)
        curve = np.ones(b - a)
        head = min(ramp, len(curve) // 2)
        if head:
            curve[:head] = np.linspace(1, gain, head)
            curve[-head:] = np.linspace(gain, 1, head)
            curve[head:-head] = gain
        else:
            curve[:] = gain
        out[a:b] *= curve
    return out


def build(timeline: dict) -> np.ndarray:
    # derive each VO line's real duration from its file so ducking is exact
    for line in timeline["audio"]["vo"]["lines"]:
        path = config.VO_DIR / f"{line['id']}.wav"
        if path.exists():
            line["dur"] = round(len(vo.load_wav(path)) / config.SR, 3)
    music = duck(audio.music(), timeline)
    sfx = audio.sfx_bus(timeline)
    voice = vo_bus(timeline)
    mix = music * 0.55 + sfx * 0.85 + voice * 1.0
    peak = float(np.abs(mix).max())
    if peak > 0.985:
        mix *= 0.985 / peak
    return mix


def loudnorm_two_pass(pre: Path, out: Path) -> dict:
    """Pass 1 measures, pass 2 applies the measured values linearly."""
    ff = ffmpeg()
    target = config.LOUDNORM
    first = subprocess.run(
        [ff, "-hide_banner", "-nostats", "-i", str(pre), "-af",
         f"loudnorm=I={target['i']}:TP={target['tp']}:LRA={target['lra']}:print_format=json",
         "-f", "null", "-"],
        capture_output=True, text=True, check=True,
    )
    blob = first.stderr[first.stderr.rindex("{") : first.stderr.rindex("}") + 1]
    stats = json.loads(blob)
    STATS.parent.mkdir(parents=True, exist_ok=True)
    STATS.write_text(json.dumps(stats, indent=1), encoding="utf-8")
    subprocess.run(
        [ff, "-y", "-hide_banner", "-loglevel", "error", "-i", str(pre), "-af",
         (f"loudnorm=I={target['i']}:TP={target['tp']}:LRA={target['lra']}:"
          f"measured_I={stats['input_i']}:measured_TP={stats['input_tp']}:"
          f"measured_LRA={stats['input_lra']}:measured_thresh={stats['input_thresh']}:"
          f"offset={stats['target_offset']}:linear=true:print_format=summary"),
         "-ar", str(config.SR), "-ac", str(config.CHANNELS), str(out)],
        check=True,
    )
    return stats


def main() -> int:
    timeline = config.load_timeline()
    config.ensure_dirs()
    mix = build(timeline)
    stereo = np.repeat(mix[:, None], 2, axis=1)
    with __import__("wave").open(str(PRE), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(config.SR)
        w.writeframes((np.clip(stereo, -1, 1) * 32767).astype(np.int16).tobytes())
    print(f"[mix] wrote {PRE} ({len(mix) / config.SR:.3f} s)")
    stats = loudnorm_two_pass(PRE, OUT)
    print(f"[mix] loudnorm pass 1: I={stats['input_i']} LUFS TP={stats['input_tp']} dBTP")
    print(f"[mix] wrote {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
