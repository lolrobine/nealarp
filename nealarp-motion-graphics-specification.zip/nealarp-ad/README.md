# nealarp — AD-60

A **60.000-second** cinematic motion-graphics advertisement for **nealarp**, a site with
eight interactive web games, announcing that it becomes available on
**12 October 2026**. German copy, German voiceover.

Everything is **code**: every frame is a pure function of `t = frame / 60`, driven by
[`timeline.yaml`](timeline.yaml). Nothing is AI-generated video (R-OUT-02).

> **Status: the pipeline is complete, the renders have not been executed.**
> See [`checklist.md`](checklist.md) — 29 requirement IDs are marked BLOCKED with the
> exact command that produces their evidence. No result is invented (R-NEG-09).

---

## 1. Environment (R-STACK)

### Host reachability — R-STACK-01 (measured, not assumed)

| Host | Result | Evidence |
|---|---|---|
| `pypi.org` | **reachable** | `GET https://pypi.org/simple/imageio-ffmpeg/` → HTTP 200, full release listing served |
| `registry.npmjs.org` | **reachable** | `GET https://registry.npmjs.org/react` → HTTP 200, package metadata JSON served |
| `files.pythonhosted.org` | **inconclusive** | `GET https://files.pythonhosted.org/` → error page (the host serves no directory index, which is expected). A real wheel fetch must be confirmed on the render host. |

Re-run on the render host and paste the codes here:

```bash
for h in pypi.org files.pythonhosted.org registry.npmjs.org; do
  printf '%-28s ' "$h"
  curl -s -o /dev/null -w '%{http_code}\n' --max-time 8 "https://$h/"
done
# wheel path, the one that actually matters:
curl -sI https://files.pythonhosted.org/packages/source/i/imageio-ffmpeg/imageio-ffmpeg-0.6.0.tar.gz | head -1
```

### Stack decision — R-STACK-03

npm **is** reachable, a headless browser **is not** available in this environment, therefore
**Remotion is not used** and the **default stack** is the one that ships:

Python 3.11 · numpy · Pillow · opencv-python-headless · imageio-ffmpeg (bundles ffmpeg) ·
PyYAML · pytest — inside a virtualenv at `nealarp-ad/.venv/`.
No GPU-only library is used anywhere (R-STACK-04); the target is 2 CPU cores / ~3 GB RAM.

```bash
cd nealarp-ad
python3.11 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
```

### Fonts — R-STACK-05 / R-STACK-06

Titles: `/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf`
Code-style glyphs: `/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf`
Both are loaded **by absolute path** with `ImageFont.truetype()` in `src/fonts.py` — no
system default is ever consulted.

Coverage check (recorded result):

```bash
python -m src.fonts --check
```

The `cmap` table of both files was parsed and all eleven required characters are present —
`Ä ä Ö ö Ü ü ß . , % m` → **PASS**. The same check is reproduced live in the browser
console (`R-VER-14`) against the identical DejaVu release, so the result is evidenced even
on a host without the font files installed.

---

## 2. Render (R-OUT-06) — one documented command, both masters

```bash
. .venv/bin/activate

python -m src.vo                     # 1. voiceover  -> audio/vo/*.wav + manifest
python -m src.mix                    # 2. audio mix  -> audio/render/mix.wav (two-pass loudnorm)
python -m src.render --preset test   # 3. out/nealarp-ad-1080p-test.mp4     1920x1080 60p
python -m src.render --preset final  # 4. out/nealarp-ad-2160p60-final.mp4  3840x2160 60p

pytest -q tests                      # 5. deterministic checks
python -m src.verify out/nealarp-ad-1080p-test.mp4 --report report.json
```

`--preset test` and `--preset final` render **the same source tree**; the only difference is
`scale` (1 vs 2), applied to the 1920×1080 reference space (R-VIS-12). Both write the
identical container spec (R-OUT-05): H.264 **High**, `yuv420p`, 60/1, AAC 48 kHz stereo,
−14 LUFS integrated, −1 dBTP true peak, no letterboxing.

Timing a run before committing to it:

```bash
python -m src.render --preset test --dry-run
# -> seconds per frame at 1080p, and the 4x estimate for 4K (R-PERF-04)
```

If the 4K estimate exceeds 6 hours the renderer prints the R-PERF-05 warning and the 4K job
must not be started.

---

## 3. The approval gate (R-GATE) — currently HOLDING

| Rule | State |
|---|---|
| R-GATE-01 stop after the 1080p test + report | **holding** — nothing has been encoded |
| R-GATE-02 4K only on explicit approval | **waiting** for the user's message |
| R-GATE-03 real German neural voice before 4K | **BLOCKED** — see §5 |
| R-GATE-04 no 1080p upscale as a 4K master | **enforced** — no upscale path exists in `src/render.py` |

`src/render.py --preset final` refuses to run while `audio/render/vo_manifest.json` says
`placeholder: true`. That refusal is deliberate, not a bug.

---

## 4. Layout

```
nealarp-ad/
  README.md            this file
  timeline.yaml        the authoritative schedule (R-TIME-04)
  checklist.md         every requirement ID with PASS / FAIL / BLOCKED + evidence
  requirements.txt
  .gitignore           out/, audio/render/, *.mp4, *.wav, frames/  (R-REPO-03)
  reference/README.md  R-REF-02 techniques; no inspiration image exists
  src/
    config.py          constants, palette, presets, encoder flags
    rng.py             seeded RNG (seed 7) + grain tile          (R-VIS-06/07)
    easing.py          the four named easings, exact             (R-VIS-10)
    fonts.py           DejaVu by absolute path + cmap coverage   (R-STACK-05/06)
    canvas.py          numpy drawing primitives, no pixel loops  (R-PERF-02)
    layout.py          text templates, auto-fit, layout log      (R-VIS-12, R-TXT)
    scenes.py          R-SCN-01 … R-SCN-11 + post layers
    audio.py           music and the 12 sfx recipes              (R-AUD-02/03)
    vo.py              German voiceover, −18 dBFS RMS            (R-AUD-01)
    mix.py             bus sum, ducking, two-pass loudnorm       (R-AUD-04)
    render.py          frame loop -> ffmpeg, both presets        (R-OUT)
    verify.py          R-VER-01 … R-VER-14
  audio/vo/            voiceover clips (git-ignored)
  audio/render/        rendered mix + perf/gate reports (git-ignored)
  tests/               pytest suite, no render needed
  out/                 MP4 masters (git-ignored)
```

---

## 5. Voiceover — the one real blocker

R-AUD-01 demands a professional German neural voice. None is reachable from this
environment, so per the rule the fallback applies:

* `src/vo.py` tries, in order: **pre-supplied WAVs** in `audio/vo/`, **edge-tts**
  (`de-DE-ConradNeural`, −4 % rate, −2 Hz pitch), then **espeak-ng -v de**.
* Anything produced by espeak-ng is labelled `PLACEHOLDER:espeak-ng` in
  `audio/render/vo_manifest.json`.
* PLACEHOLDER speech is allowed **for the 1080p test only**. R-GATE-03 blocks the 4K master.

To unblock: drop eight WAVs named `vo_01.wav … vo_08.wav` (48 kHz mono) into `audio/vo/`,
or `pip install edge-tts` on a host with network access. The manifest then flips to
`placeholder: false` and the final render is permitted.

The eight lines, exactly as declared:

| at | string |
|---|---|
| 0.5 | Alles, was du jemals im Internet machen wolltest … an einem Ort. |
| 9.0 | Gib eine Billion Dollar aus. |
| 11.5 | Brich jede Passwortregel. |
| 14.5 | Tauche 11.000 Meter tief in die Tiefsee. |
| 20.5 | Schleudere Asteroiden. Zeichne perfekte Kreise. |
| 26.0 | Entdecke deine Lebensstatistik. |
| 32.5 | Acht Spiele. Keine Downloads. Eine Adresse. |
| 44.8 | Ab dem 12. Oktober erhältlich auf nealarp.vercel.app. |

---

## 6. Deviations from the spec (all documented, none silent)

1. **The house gradient runs blue → white → orange.** R-VIS-03 defines two stops,
   `#3b82f6` at 0 % and `#f97316` at 100 %. A direct RGB lerp between them crosses
   hues around 12–15° at ~40 % saturation, and R-VER-06 rejects exactly those pixels —
   on a 96 px lower third that band alone costs several percent of the saturated pixel
   budget and fails the 1 % limit. Inserting a white mid-stop (white is a house colour,
   and R-REF-02 asks for a "hot-white core fading into colour at its edges") keeps every
   saturated pixel inside 195–235° or 15–35°. Endpoints and direction are unchanged.
2. **Two extra text templates.** `panel_label` (the R-SCN-08 panel captions) and
   `score_orange_160` (the R-SCN-07 `98 %`) are required by the scene specs but absent from
   the template list. They live in the same table, go through the same auto-fit and are
   written to the same log, so R-TXT-02 still holds.
3. **`100 MEGATONNEN` at y = 220.** `claim_white` is defined at y = 540; R-SCN-06 explicitly
   demands y = 220. The entry carries a logged `cy` override rather than a new template.
4. **Depth counter ramp.** R-SCN-04 asks for a count-up between the four declared depth
   values. The four canonical strings are laid out and logged; the 0.3 s ramp is a numeric
   interpolation of that same element and lands exactly on the declared string, so no string
   outside R-TXT-01 ever appears.
5. **Browser harness hashes with SHA-256.** WebCrypto has no MD5. `src/verify.py` uses MD5
   exactly as R-VER-13 specifies; the browser preview console uses SHA-256 and says so.
6. **The browser preview can export WebM only.** MediaRecorder cannot produce H.264/AAC.
   That export is labelled a review artefact everywhere and is never presented as an R-OUT
   master.
7. **Voiceover is PLACEHOLDER** (§5), which is what R-AUD-01 prescribes when no neural
   de-DE voice is available, and what R-GATE-03 then acts on.

---

## 7. Report format (R-REPORT)

The final report follows the required order:

1. checklist status for every requirement ID — [`checklist.md`](checklist.md)
2. render commands used — §2 above
3. timings: average seconds per frame at 1080p, the 4× 4K estimate, actual totals —
   written to `audio/render/perf_test.json` by `src/render.py`
4. verification results R-VER-01 … R-VER-14 — `report.json` from `src/verify.py`
5. deviations — §6
6. open items for the user — §3, §5 and `checklist.md § Open items`

---

## 8. Pacing observation (R-TIME-03 — reported, not changed)

Nothing was added, removed or re-timed. One observation for the record: the hero act
(32.0–44.0 s) runs 12 seconds with a single discrete event, the `nealarp` reveal at
36.5–37.5 s. It is the longest low-event stretch in the ad. The orbiting sprites and the
0.5 Hz star pulse carry it, but if it reads as a drag on review, the fix belongs in
`timeline.yaml`, not in the renderer.
