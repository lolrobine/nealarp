"""
tests/test_pipeline.py — fast, deterministic checks that need no render.

    pytest -q tests

The media-level checks (R-VER-01…05, 10…12) live in src/verify.py because they
need the encoded MP4/WAV.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pytest

from src import audio, config, easing, layout, rng, scenes

HAS_DEJAVU = Path(config.FONT_BOLD).exists() and Path(config.FONT_MONO).exists()


@pytest.fixture(scope="module")
def timeline() -> dict:
    return config.load_timeline()


# ------------------------------------------------------------ R-TIME
def test_frame_rate_model():
    """R-TIME-01: t = frame / 60 and 3600 frames make exactly 60.000 s."""
    assert config.FPS == 60
    assert config.TOTAL_FRAMES == 3600
    assert config.TOTAL_FRAMES / config.FPS == pytest.approx(60.0, abs=1e-9)


def test_act_structure(timeline):
    """R-TIME-02: acts tile 0–60 and the showcase is 8 cuts of 3.000 s."""
    acts = timeline["acts"]
    assert [a["id"] for a in acts] == ["opening", "showcase", "hero", "cta"]
    assert acts[0]["start"] == 0.0 and acts[-1]["end"] == 60.0
    for a, b in zip(acts, acts[1:]):
        assert a["end"] == b["start"]
    showcase = [s for s in timeline["scenes"] if s["scene"].startswith("game_")]
    assert len(showcase) == 8
    assert all(abs(s["end"] - s["start"] - 3.0) < 1e-9 for s in showcase)


def test_scene_coverage(timeline):
    """R-TIME-04: every element, text and sfx entry declares start/end inside its scene."""
    cursor = 0.0
    for s in timeline["scenes"]:
        assert s["start"] == pytest.approx(cursor), f"gap before {s['scene']}"
        cursor = s["end"]
        for e in s.get("elements", []) or []:
            assert "start" in e and "end" in e and e["end"] >= e["start"]
            assert e["ease"] in (easing.EASE_IO, easing.EASE_OUT_EARLY, easing.EXPO_OUT, easing.STEP)
        for txt in s.get("text", []) or []:
            assert txt["start"] >= s["start"] and txt["end"] <= s["end"] + 1e-9
    assert cursor == pytest.approx(60.0)


# ------------------------------------------------------------ R-VIS-10 easing
def test_easings_exact():
    assert easing.ease(easing.EASE_IO, 0) == 0.0
    assert easing.ease(easing.EASE_IO, 1) == 1.0
    assert easing.ease(easing.EASE_IO, 0.5) == pytest.approx(0.5, abs=1e-3)
    assert easing.ease(easing.EXPO_OUT, 1.0) == 1.0
    assert easing.expo_out(0.5) == pytest.approx(1 - 2 ** -5, abs=1e-9)
    assert easing.ease(easing.STEP, 0.999) == 0.0
    assert easing.ease(easing.STEP, 1.0) == 1.0
    # EASE_OUT_EARLY peaks early: at t=0.25 it is already past halfway
    assert easing.ease(easing.EASE_OUT_EARLY, 0.25) > 0.5


def test_projection_formula():
    """R-VIS-09: screen x = cx + x·f/(f+z) with f = 900."""
    assert config.FOCAL == 900
    x, z = 400.0, 900.0
    assert 960 + x * 900 / (900 + z) == pytest.approx(1160.0)


def test_particle_cap():
    """R-VIS-06: the largest single burst is exactly the 3000 cap."""
    assert config.PARTICLE_CAP == 3000
    assert scenes.cta_seed(3000)["pos"].shape == (3000, 2)


def test_rng_is_seeded_and_repeatable():
    a = [rng.Rng(7).f() for _ in range(4)]
    b = [rng.Rng(7).f() for _ in range(4)]
    assert a == b
    assert rng.Rng(8).f() != a[0]


def test_grain_tile_is_deterministic():
    t1 = rng.grain_tile()
    t2 = rng.grain_tile()
    assert t1.shape == (512, 512)
    assert np.array_equal(t1, t2)


# ------------------------------------------------------------ R-TXT
CANON = [
    "SPIELE UND ZEUG", "GELD AUSGEBEN", "DAS PASSWORT-SPIEL", "DIE TIEFSEE",
    "0 m", "1.000 m", "5.000 m", "11.034 m", "TEMPO", "ASTEROIDEN-WERFER",
    "100 MEGATONNEN", "PERFEKTER KREIS", "98 %", "LEBENSSTATISTIK",
    "HERZSCHLÄGE", "ATEMZÜGE", "SCHRITTE", "GRÖSSE DES WELTALLS", "nealarp",
    "BALD VERFÜGBAR", "AB 12. OKTOBER", "nealarp.vercel.app",
    "ERHÄLTLICH AB 12. OKTOBER",
]


def test_canonical_strings_declared(timeline):
    """R-TXT-01: the timeline declares exactly these strings, no others."""
    declared = [t["string"] for s in timeline["scenes"] for t in (s.get("text") or [])]
    missing = [s for s in CANON if s not in declared]
    extra = [s for s in declared if s not in CANON]
    assert not missing, f"missing: {missing}"
    assert not extra, f"extra: {extra}"


def test_every_declared_string_has_a_layout(timeline):
    """R-TXT-02: no text outside the layout templates."""
    for s in timeline["scenes"]:
        for t in s.get("text") or []:
            assert t["layout"] in layout.TEMPLATES, f"{t['id']} uses unknown layout {t['layout']}"


def test_german_only(timeline):
    """R-NEG-03: the umlaut/ß strings that prove it is German are present."""
    declared = " ".join(t["string"] for s in timeline["scenes"] for t in (s.get("text") or []))
    for needle in ("GRÖSSE", "HERZSCHLÄGE", "ATEMZÜGE", "VERFÜGBAR", "ERHÄLTLICH"):
        assert needle in declared


@pytest.mark.skipif(not HAS_DEJAVU, reason="DejaVu Sans Bold is not installed on this host")
def test_autofit_and_safe_area(timeline):
    """R-TXT-03 + R-VER-08."""
    records = layout.build_records(timeline, 1.0)
    assert records, "no records built"
    for r in records.values():
        assert r.size >= config.AUTOFIT_MIN_SIZE
        if r.autofit:
            assert r.base_size - r.size == r.autofit_steps * config.AUTOFIT_STEP
        assert r.safe_area_ok, f"{r.id}: {r.safe_area_note}"
    # the 180 px opening title must shrink below the 1440 px limit
    opening = records["title_opening_main"]
    assert opening.autofit and opening.width <= config.AUTOFIT_MAX_WIDTH


# ------------------------------------------------------------ R-AUD
def test_sfx_recipes_exist_and_are_bounded():
    recipes = ["sfx_pop", "sfx_click", "sfx_coin_clink", "sfx_lock_clunk", "sfx_bubble",
               "sfx_whirr", "sfx_boom", "sfx_pen_draw", "sfx_heartbeat", "sfx_whoosh_zoom",
               "sfx_bass_drop", "sfx_bass_hit"]
    peaks = {"sfx_pop": -6, "sfx_click": -8, "sfx_coin_clink": -10, "sfx_lock_clunk": -6,
             "sfx_bubble": -14, "sfx_whirr": -12, "sfx_boom": -4, "sfx_pen_draw": -18,
             "sfx_heartbeat": -8, "sfx_whoosh_zoom": -10, "sfx_bass_drop": -4, "sfx_bass_hit": -3}
    for r in recipes:
        x = audio.sfx(r, 3.0 if r in ("sfx_whirr", "sfx_pen_draw") else None)
        assert len(x) > 0
        db = 20 * math.log10(max(1e-9, float(np.abs(x).max())))
        assert db <= peaks[r] + 0.6, f"{r} peaks at {db:.1f} dBFS, expected ≈{peaks[r]}"


def test_music_length_and_bpm():
    """R-AUD-02: 60.000 s at 120 BPM."""
    m = audio.music()
    assert len(m) == int(60.0 * config.SR)
    assert abs(60.0 / config.BPM - 0.5) < 1e-9
    # silence at the very end (fade to silence by 60.000 s)
    assert float(np.abs(m[-int(0.05 * config.SR):]).max()) < 1e-3


def test_vo_lines_never_overlap(timeline):
    """R-AUD-01 / R-VER-11: ≥ 0.5 s between lines, declared onsets ascending."""
    lines = timeline["audio"]["vo"]["lines"]
    durs = {l["id"]: l.get("dur", 2.5) for l in lines}
    for a, b in zip(lines, lines[1:]):
        gap = b["at"] - (a["at"] + durs[a["id"]])
        assert b["at"] > a["at"]
        assert gap >= -1e-9, f"{a['id']} overlaps {b['id']}"


def test_no_more_than_two_stacked_sfx(timeline):
    """R-AUD-03: at most two effects sounding at once."""
    events = [(float(e["at"]), e["id"], float(e.get("until", e["at"] + 0.5)))
              for s in timeline["scenes"] for e in (s.get("audio", {}).get("sfx") or [])]
    for at, _, _ in events:
        concurrent = sum(1 for a, _i, b in events if a <= at < b)
        assert concurrent <= 2, f"{concurrent} effects stacked at {at}s"


def test_cut_pops(timeline):
    """R-SCN: every game cut starts with a pop."""
    for s in timeline["scenes"]:
        if not s["scene"].startswith("game_"):
            continue
        pops = [e for e in s["audio"]["sfx"] if e["id"] == "sfx_pop"]
        assert pops and pops[0]["at"] == pytest.approx(s["start"])


# ------------------------------------------------------------ R-VIS-02 palette
def test_palette_is_four_colours_only():
    assert config.BLUE == (59, 130, 246)
    assert config.ORANGE == (249, 115, 22)
    assert config.WHITE == (255, 255, 255)
    assert config.NEAR_BLACK == (10, 10, 10)
    banned = ("gold", "yellow", "green", "red", "magenta", "cyan", "purple")
    src = (config.__file__ or "")
    text = open(src, encoding="utf-8").read().lower()
    for b in banned:
        assert b not in text.split("r-vis-02")[-1], f"palette mentions {b}"


def test_no_emoji_in_sources():
    """R-NEG-02 / R-NEG-03."""
    import pathlib
    for p in pathlib.Path(config.ROOT).rglob("*.py"):
        if ".venv" in p.parts:
            continue
        for ch in p.read_text(encoding="utf-8"):
            assert not (0x1F000 <= ord(ch) <= 0x1FAFF), f"emoji in {p}"
