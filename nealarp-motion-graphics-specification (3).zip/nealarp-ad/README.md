# nealarp-ad

60.000-second cinematic motion-graphics ad for **nealarp** — 8 interactive web
games, launch **12. Oktober 2026**. Every frame is computed from
[`timeline.yaml`](timeline.yaml) by a pure function of time. No stock footage,
no AI video, no licensed audio.

- Test master: `out/nealarp-ad-1080p-test.mp4` — 1920x1080, 60 fps
- Final master: `out/nealarp-ad-2160p60-final.mp4` — 3840x2160, 60 fps (only
  after explicit approval, see R-GATE)
- Both: 16:9, 60.000 s, H.264 High, yuv420p, AAC 48 kHz stereo,
  integrated −14 LUFS, true peak −1 dBTP

---

## 1. Environment reachability (R-STACK-01)

> **Status in the authoring environment: BLOCKED (no shell / no network).**
> Run this on the target machine and paste the results here:

| Host                     | Reachable? | Evidence |
|--------------------------|-----------|----------|
| pypi.org                 | _pending_ | `curl -sI https://pypi.org/simple/ \| head -1` |
| files.pythonhosted.org   | _pending_ | `curl -sI https://files.pythonhosted.org/ \| head -1` |
| registry.npmjs.org       | _pending_ | `curl -sI https://registry.npmjs.org/ \| head -1` |

Per R-STACK-03 the **default Python stack** is used (Remotion requires npm + a
headless browser; the check could not be performed ⇒ default stack). The stack
will not be switched after the first rendered frame.

## 2. Setup (R-STACK-02)

```bash
cd nealarp-ad
python3.11 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

Fonts (R-STACK-05) must exist at:
- `/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf`
- `/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf`

Font coverage check (R-STACK-06) — glyphs Ä ä Ö ö Ü ü ß . , % m — runs in the
test suite (`pytest -q`, `test_font_coverage`) and on render start;
`text_layout.py` aborts loudly if a glyph is missing.

## 3. The one render command (R-OUT-06)

```bash
python render.py
```

Produces `out/nealarp-ad-1080p-test.mp4` **and** the audio mix from the same
`timeline.yaml` source, then stops (R-GATE-01). After explicit approval:

```bash
python render.py --final --approve-4k
```

adds `out/nealarp-ad-2160p60-final.mp4`. `--final` refuses when
`vo_status.json.real_neural != true` (R-GATE-03), when the 4K time estimate
exceeds 6 h (R-PERF-05), or without the approval flag (R-GATE-02). There is no
upscale path (R-GATE-04); the final renders natively at scale 2 (R-VIS-12).

Useful variants:

```bash
python render.py --test            # force only the 1080p test
python render.py --frames 0 900 1800 3000 3599 --png   # determinism probes (R-VER-13)
python render.py --mix-only        # rebuild audio + mux without re-rendering
```

## 4. Voiceover (R-AUD-01)

`src/vo.py` builds lines in this order:

1. **edge-tts** — `de-DE-ConradNeural` / `de-DE-KatjaNeural` (needs network).
2. **piper** (local, offline) with a de_DE voice model if `piper` + model found.
3. **espeak-ng -v de** — PLACEHOLDER, allowed for the 1080p test only.

Each line is normalized to −18 dBFS RMS before mixing. The chosen engine is
recorded in `vo_status.json`; the 4K gate reads `real_neural`.

## 5. Audio pipeline (R-AUD-02 .. 04)

- Music: `src/audio_synth.py::render_music` — 120 BPM; bass drop at 0.0 s;
  8-detuned-sine arpeggios under a 2 kHz lowpass warming toward orange
  harmonics by 32 s; cinematic risers 32–44 s; confident 45 Hz bass hit at
  44.0 s with 0.25 s / 0.3-feedback echo; bus ducked −6 dB under VO; fades to
  silence by 60.000 s.
- SFX: all 13 recipes at 48 kHz with the specified peak levels; never more
  than two effects overlapping (validated by unit test).
- Mix: bus sum → two-pass ffmpeg `loudnorm` (I=−14, TP=−1.0, LRA=11) →
  verification print of the second-pass values + `ebur128` true-peak readout.

## 6. Verification (R-VER)

```bash
pytest -q
```

covers R-VER-01 … R-VER-14 as listed in `checklist.md`. Results from the
authoring environment: **BLOCKED** (no runtime here) — nothing is faked
(R-NEG-09). Run after the first render; the suite skips render-dependent tests
cleanly when `out/` artifacts are absent and reports them as blocked.

## 7. Performance notes (R-PERF)

Static layers (background + haze, grain tile, vignette, blurred glass bases)
are precomputed once; sprites are cached by `(kind, size, scale)`; particles
are pure numpy. After the test render, `render.py` prints average s/frame and
the 4K estimate (4×). If the estimate exceeds 6 h, the 4K render is not
started and options are printed.

## 8. Deviations from the spec

1. **Two additional text layout templates** — `panel_label` (28 px, white 60%,
   for the three glass-panel labels) and `score_badge` (160 px orange at
   (1480, 470)) — because R-TXT-02 forbids drawing strings outside the layout
   system while the spec's template list has no entries for these strings.
   Both follow the template style and are logged like all others.
2. **Cut-7 counters** (R-SCN-08) specify "count up" but give no landing
   values, while R-NEG-03 forbids on-screen strings beyond R-TXT-01. Per
   R-PRI rule 1, counters show *transient* numeric readouts that fade during
   transition-out; no unlisted string persists.
3. Counter target values for cut 7 are renderer-internal numbers
   (3.250.000.000 / 780.000.000 / 180.000.000) because the spec defines none;
   they are transient per deviation 2.

## 9. Repo layout

```
nealarp-ad/
  README.md  timeline.yaml  checklist.md  requirements.txt  .gitignore
  render.py
  src/        timeline.py  easing.py  rng.py  palette.py  effects.py
              text_layout.py  sprites.py  scenes.py  renderer.py
              audio_synth.py  vo.py  mix.py
  audio/vo/   (voiceover clips — espeak/piper/edge outputs)
  audio/render/  (rendered mix; git-ignored)
  reference/  README.md (inspiration description, R-REF)
  tests/      test_units.py  test_verify.py
  out/        (MP4 outputs; git-ignored)
```
