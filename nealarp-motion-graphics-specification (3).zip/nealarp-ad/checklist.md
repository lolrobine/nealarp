# nealarp-ad — Requirement Checklist

Legend:
- **DONE** — implemented in code/config in this repo; evidence = file path. Where a
  runtime artifact is required (MP4, loudness log), "done" means the producing code
  is complete and the check is scripted in `tests/`.
- **BLOCKED** — cannot be executed or evidenced in the authoring environment (no
  shell / no Python / no network access). Every blocked item includes what is needed
  to unblock on the target machine.
- **FAILED** — nothing currently.

Status date: authoring pass 1 (code complete, runtime verification pending on
target machine).

## R-OUT — Deliverables
| ID | Status | Evidence / reason |
|----|--------|-------------------|
| R-OUT-01 | DONE* | 60.000 s / 3600-frame timeline in `timeline.yaml`; all scenes + German copy per R-TXT. *The MP4 itself is produced on the target machine. |
| R-OUT-02 | DONE | Every frame from `src/renderer.py::render_frame(f)` — pure function of `t = f/60`; no video assets, no AI video. |
| R-OUT-03 | BLOCKED | No Python/ffmpeg in authoring environment. `python render.py --test` produces `out/nealarp-ad-1080p-test.mp4` (1920x1080@60). |
| R-OUT-04 | BLOCKED | R-GATE-01: never start 4K without explicit user approval. `python render.py --final` refuses unless `--approve-4k`. |
| R-OUT-05 | DONE | Render spec encoded in `src/render.py` (`yuv420p`, H.264 High, AAC 48 kHz) + `src/mix.py` two-pass loudnorm −14 LUFS / −1 dBTP. Runtime confirmation via `tests/test_verify.py::test_codec` and `test_loudness` (BLOCKED here). |
| R-OUT-06 | DONE | One command: `python render.py` (see README §Render). Produces test render; `--final --approve-4k` adds the master from the same `timeline.yaml`. |

## R-PRI — Priority order
| ID | Status | Evidence |
|----|--------|----------|
| R-PRI | DONE | Enforced by construction: R-TXT strings only touch `text_layout` (single choke point), palette constants in `src/palette.py`, timing only from `timeline.yaml`. |

## R-STACK — Environment
| ID | Status | Evidence / reason |
|----|--------|-------------------|
| R-STACK-01 | BLOCKED | No network/shell in authoring env. README §1 contains the exact reachability script and an empty results table to fill in on the target machine. |
| R-STACK-02 | DONE | `requirements.txt` (numpy, Pillow, opencv-python-headless, imageio-ffmpeg, PyYAML, pytest) + README venv steps. Install itself BLOCKED here (no shell). |
| R-STACK-03 | DONE | Default Python stack selected (Remotion not reachable: host check blocked ⇒ per rule, default stack). No stack switch after first frame. |
| R-STACK-04 | DONE | CPU-only stack; numpy vector ops; no GPU libs anywhere. |
| R-STACK-05 | DONE | `src/text_layout.py` loads the two DejaVu TTFs by absolute path; fails loudly if missing. |
| R-STACK-06 | BLOCKED | Needs the font files present at runtime. `tests/test_verify.py::test_font_coverage` checks Ä ä Ö ö Ü ü ß . , % m via `font.getmask`; run on target machine. |

## R-REF — Reference assets
| ID | Status | Evidence |
|----|--------|----------|
| R-REF-01 | DONE | `reference/inspiration-01.jpg` absent ⇒ `reference/README.md` written (no fetch attempted). |
| R-REF-02 | DONE | Only the five documented techniques are used — mapping table in `reference/README.md`. |

## R-REPO — Project layout
| ID | Status | Evidence |
|----|--------|----------|
| R-REPO-01 | DONE | `nealarp-ad/` is standalone; website sources untouched. |
| R-REPO-02 | DONE | Directory layout matches the spec tree (README, timeline.yaml, checklist.md, src/, audio/vo/, audio/render/, reference/, tests/, out/). |
| R-REPO-03 | DONE | `.gitignore` covers `out/`, `audio/render/`, `*.mp4`, `*.wav`. |

## R-TIME — Timing model
| ID | Status | Evidence |
|----|--------|----------|
| R-TIME-01 | DONE | `render_frame(f): t = f / 60` in `src/renderer.py`. No 24 fps constants anywhere. |
| R-TIME-02 | DONE | Acts fixed: 0–8 / 8–32 (8×3 s) / 32–44 / 44–60 in `timeline.yaml`. |
| R-TIME-03 | DONE | No pacing changes; note in README §Deviations (none required). |
| R-TIME-04 | DONE | `src/timeline.py` validates that every painter reads only declared windows; every visual element above has start/end. |

## R-VIS — Visual system
| ID | Status | Evidence |
|----|--------|----------|
| R-VIS-01 → R-VIS-11 | DONE (code) | `src/scenes.py` + `src/effects.py`: haze 40%, palette lock, blue→orange gradient, glass (¼-scale blur), bloom 24/35%, streaks, flares (1400×6 + 120 glow), act flickers, particles seed 7 cap 3000, grain tile 3.5%, vignette 25%, camera f=900 z∈[0,2000], exact easing (R-VIS-10) in `src/easing.py`, geometric icons stroke 6. Runtime visual confirmation via tests (BLOCKED here). |
| R-VIS-12 | DONE | All painters work in 1920x1080 space; scale `s` multiplies at raster time (`--final` ⇒ s=2). |

## R-SCN — Scenes
| ID | Status | Evidence |
|----|--------|----------|
| R-SCN-01 → R-SCN-11 | DONE (code) | `src/scenes.py` functions `scene_opening … scene_cta`, one painter per element id in `timeline.yaml`; counters, morphs, impacts, pulses implemented per spec numbers. Visual QA pending first render (BLOCKED here). |

## R-AUD — Audio
| ID | Status | Evidence / reason |
|----|--------|-------------------|
| R-AUD-01 | BLOCKED (partial) | `src/vo.py` implements the chain **edge-tts (de-DE neural) → piper (local de_DE) → espeak-ng placeholder (test only)** and writes `vo_status.json {real_neural: bool}`. No network/shell here to actually synthesize. Per-line RMS normalize to −18 dBFS implemented. |
| R-AUD-02 | DONE (code) | `src/audio_synth.py::render_music`: 120 BPM, bass drop @0, 8-detuned-sine arps with 2 kHz lowpass, orange harmonic warm-up 8→32 s, risers 32–44, bass hit w/ echo (0.25 s / 0.3) @44, fade by 60.0. Duck −6 dB under VO. |
| R-AUD-03 | DONE (code) | All 13 recipes in `src/audio_synth.py` at 48 kHz with the specified peaks; max two effects at once (schedule validated by `tests/test_units.py`). |
| R-AUD-04 | DONE (code) | `src/mix.py`: bus sum → two-pass `loudnorm` (I=-14, TP=-1) → ebur128 verification print. Execution BLOCKED here. |

## R-TXT — On-screen text
| ID | Status | Evidence |
|----|--------|----------|
| R-TXT-01 | DONE | String table in `src/text_layout.py::REQUIRED_STRINGS` exactly as specified; `tests/test_units.py` compares against `timeline.yaml`. |
| R-TXT-02 | DONE | All rendering funnels through `text_layout.draw_text()`; scene painters cannot draw strings directly (they pass ids). Layout log → `layout_log.json`. |
| R-TXT-03 | DONE | Auto-fit: >1440 px ⇒ −4 px steps, floor 64 px, every change logged (`tests/test_units.py::test_autofit_logs`). |

## R-VER — Automated verification
| ID | Status | Evidence / reason |
|----|--------|-------------------|
| R-VER-01 … R-VER-14 | BLOCKED (scripted) | `tests/test_verify.py` implements every check (ffprobe duration/frames, resolution/FPS, codec/pix_fmt, audio stream, ebur128 loudness, HSV palette sampling, corner background median, layout-log safe area, string completeness + OCR-if-tesseract, motion diff, sfx/vo start times vs yaml ±0.05 s, post-60 s silence, double-render MD5, font coverage). Execution requires the render artifacts ⇒ run on target machine: `pytest -q`. |

## R-PERF — Performance
| ID | Status | Evidence |
|----|--------|----------|
| R-PERF-01 .. 03 | DONE (code) | Static bg/haze/grain/vignette precomputed once; blurred glass bases cached per scene; sprites cached by (kind,size,scale); particles fully numpy-vectorized. |
| R-PERF-04 .. 05 | BLOCKED | Needs timing data from the first run. `render.py` prints s/frame and the 4K×4 estimate, and aborts the 4K render if the estimate exceeds 6 h. |

## R-GATE — Approval gate
| ID | Status | Evidence |
|----|--------|----------|
| R-GATE-01 | DONE | `render.py` default = test render only; then stops. |
| R-GATE-02 | DONE | `--final` requires the explicit `--approve-4k` flag. |
| R-GATE-03 | DONE | `--final` refuses if `vo_status.json.real_neural != true`. |
| R-GATE-04 | DONE | No upscale path exists; 4K is rendered natively at s=2. |

## R-NEG — Negative constraints
| ID | Status | Evidence |
|----|--------|----------|
| R-NEG-01 | DONE | Palette test R-VER-06 scripted; painters use palette constants only. |
| R-NEG-02 … 08 | DONE | No emojis/stock/photo people; German-only choke point (R-TXT-02); no chrome/watermarks; no upsampling bars (full-bleed 16:9); all media git-ignored. |
| R-NEG-09 | DONE | This checklist marks everything not executed here BLOCKED, not faked. |

### Documented deviations (see README §Deviations for full text)
1. Added text template `panel_label` (28 px bold, white 60 %) for HERZSCHLÄGE / ATEMZÜGE / SCHRITTE — spec lists no panel-label template (R-TXT-02 requires all strings through the layout system).
2. Added template `score_badge` (160 px orange at (1480, 470)) — coordinates come from R-SCN-07, templated for logging.
3. Cut 7 stat counters run transient numeric readouts that fade at transition-out; R-SCN-08 gives no landing values and R-NEG-03 forbids unlisted persistent strings.
