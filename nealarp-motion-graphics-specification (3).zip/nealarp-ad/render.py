#!/usr/bin/env python3
"""nealarp-ad — the one render command (R-OUT-06, R-GATE).

    python render.py                      # 1080p test from timeline.yaml, then stop
    python render.py --test               # explicit test render
    python render.py --final --approve-4k # adds 2160p master (gates enforced)
    python render.py --frames 0 900 ... --png   # determinism probes (R-VER-13)
    python render.py --mix-only           # audio + mux only
"""
import argparse
import sys
import time
from src.timeline import load_timeline
from src import renderer, mix, vo


def gates_for_final(tl) -> tuple[bool, str]:
    status = vo.read_status()
    if not status.get("real_neural"):
        return False, "R-GATE-03: voiceover is not a real German neural voice (see audio/vo/vo_status.json)."
    return True, "ok"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--test", action="store_true")
    ap.add_argument("--final", action="store_true")
    ap.add_argument("--approve-4k", action="store_true")
    ap.add_argument("--mix-only", action="store_true")
    ap.add_argument("--frames", nargs="*", type=int, default=None)
    ap.add_argument("--png", action="store_true")
    args = ap.parse_args()

    tl = load_timeline("timeline.yaml")

    if args.frames is not None:
        renderer.render_probe_frames(tl, args.frames, png=args.png)
        return 0

    if args.mix_only:
        mix.rebuild_and_mux(tl, test_only=not args.final)
        return 0

    # ---- 1080p test -----------------------------------------------------
    t0 = time.time()
    stats = renderer.render_video(tl, scale=1.0, out="out/nealarp-ad-1080p-test.mp4")
    mix.rebuild_and_mux(tl, test_only=True)
    dt = time.time() - t0
    spf = dt / tl["meta"]["frames"]
    est_4k = spf * 4 * tl["meta"]["frames"] / 3600
    print(f"[perf] 1080p average: {spf:.3f} s/frame ({dt/60:.1f} min total)")
    print(f"[perf] 4K estimate  : {est_4k:.2f} h")

    if not args.final:
        print("[gate] R-GATE-01: stopping after the test render. Approve the 4K render explicitly.")
        return 0

    # ---- 4K final -------------------------------------------------------
    if not args.approve_4k:
        print("[gate] R-GATE-02: --final requires the explicit --approve-4k flag.")
        return 2
    ok, why = gates_for_final(tl)
    if not ok:
        print(f"[gate] {why}")
        return 2
    if est_4k > 6:
        print("[perf] R-PERF-05: 4K estimate > 6 h — not starting. Options: lower particle counts, pre-rendered sprites, longer run window.")
        return 2
    renderer.render_video(tl, scale=2.0, out="out/nealarp-ad-2160p60-final.mp4")
    mix.rebuild_and_mux(tl, test_only=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
