# Reference — R-REF

`reference/inspiration-01.jpg` does **not** exist in this project (checked by
directory listing; this environment cannot fetch or store external media, and
TikTok pages must not be fetched — they return HTTP 403). Per R-REF-01, this
file documents the intended inspiration instead.

## Description of the inspiration (R-REF-02)

- Near-black background (#0a0a0a).
- A glowing hot-white core subject that fades into color toward its edges.
- Gradient display title with a different color per letter.
- Motion-blur tails on the final letters of a word.
- Film grain and bloom over the whole frame.

## Where each technique is used (and ONLY these techniques)

| Technique                     | Where implemented                                       |
|------------------------------|---------------------------------------------------------|
| Near-black background        | `src/scenes.py` base layer + R-VIS-01 haze              |
| Hot-white core → color edges | Hero sphere (R-SCN-10), coin chrome falls, sun stage    |
| Gradient display title       | `src/text_layout.py` gradient fills (R-VIS-03)          |
| Motion-blur tails (final letters) | Opening title `blur_tail_last: 2` (R-SCN-01)        |
| Film grain                   | Seeded 512² tile + per-frame offset (R-VIS-07)          |
| Bloom                        | Bright-pass blur 24 px, additive 35 % (R-VIS-05)        |

No creator handles, watermarks, or layouts are copied (R-REF-02, R-NEG-04).
