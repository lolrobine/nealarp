"""Offline checks — run before any render. pytest -q tests/test_units.py"""
import math
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import easing, palette, scenes, audio_synth, text_layout
from src.timeline import load_timeline

TL = load_timeline(os.path.join(os.path.dirname(__file__), "..", "timeline.yaml"))


# ------------------------------------------------------------ timing (R-TIME)
def test_acts_fixed():
    bounds = [(s["start"], s["end"]) for s in TL["scenes"]]
    assert bounds[0] == (0.0, 8.0)
    assert bounds[1:9] == [(8 + 3 * i, 11 + 3 * i) for i in range(8)]
    assert bounds[9:] == [(32.0, 44.0), (44.0, 60.0)]


def test_everything_timed():
    for s in TL["scenes"]:
        for el in s["elements"]:
            assert el["start"] <= el["end"]
            assert s["start"] <= el["start"] and el["end"] <= s["end"]
        for tx in s["text"]:
            assert tx["start"] <= tx["end"]


# ------------------------------------------------------------ easing (R-VIS-10)
def test_easing_exact():
    assert easing.EASE_IO(0.0) == pytest.approx(0.0, abs=1e-4)
    assert easing.EASE_IO(1.0) == pytest.approx(1.0, abs=1e-4)
    assert easing.EASE_IO(0.5) == pytest.approx(0.5, abs=1e-3)   # symmetric curve
    assert easing.EXPO_OUT(1.0) == 1.0
    assert easing.EXPO_OUT(0.0) == 0.0
    assert easing.STEP(0.999) == 0.0
    assert easing.STEP(1.0) == 1.0
    # EASE_OUT_EARLY peaks early: value at p=.3 already past linear
    assert easing.EASE_OUT_EARLY(0.3) > 0.5


# ------------------------------------------------------------- palette (R-VIS-02)
def test_palette_exact():
    assert palette.hex_of(palette.BLUE) == "#3b82f6"
    assert palette.hex_of(palette.ORANGE) == "#f97316"
    assert palette.hex_of(palette.WHITE) == "#ffffff"
    assert palette.hex_of(palette.INK) == "#0a0a0a"


# ------------------------------------------------------------- painters registry
def test_all_types_have_painters():
    types = {el["type"] for s in TL["scenes"] for el in s["elements"]}
    missing = types - set(scenes.PAINTERS)
    assert not missing, f"missing painters: {missing}"


# ------------------------------------------------------------- text (R-TXT)
def test_text_strings_match_spec_list():
    yaml_strings = {tx["string"] for s in TL["scenes"] for tx in s["text"]}
    assert yaml_strings == set(text_layout.REQUIRED_STRINGS)


def test_all_layouts_known():
    for s in TL["scenes"]:
        for tx in s["text"]:
            assert tx["layout"] in text_layout.TEMPLATES


@pytest.mark.skipif(not os.path.exists(text_layout.FONT_BOLD),
                    reason="BLOCKED: DejaVu fonts not installed here (R-STACK-05)")
def test_autofit_logs():
    text_layout._log.clear()
    sprite, bbox, meta = text_layout.render_text_sprite(
        "GRÖSSE DES WELTALLS", "title_lower_third", 1.0)
    assert bbox[2] <= 1440 + 4
    assert any(e.get("event") == "autofit" for e in text_layout.log_for_tests()) \
        or meta["size"] == 96  # may already fit at 96 on some builds


# ------------------------------------------------------------- sfx (R-AUD-03)
RECIPE_PEAKS = {
    "sfx_pop": -6, "sfx_click": -8, "sfx_coin_clink": -10, "sfx_lock_clunk": -6,
    "sfx_bubble": -14, "sfx_whirr": -12, "sfx_boom": -4, "sfx_pen_draw": -18,
    "sfx_heartbeat": -8, "sfx_whoosh_zoom": -10, "sfx_bass_drop": -4,
    "sfx_bass_hit": -3,
}


def test_all_sfx_ids_have_recipes():
    ids = {ident for ident, _ in TL["_audio_index"]["sfx"]}
    assert ids <= set(RECIPE_PEAKS)


def test_sfx_peak_levels():
    r = np.random.default_rng(7)
    for name, peak in RECIPE_PEAKS.items():
        fn = audio_synth.SFX[name]
        sig = fn(r) if name != "sfx_whirr" else fn(r, dur=3.0)
        got = 20 * math.log10(np.max(np.abs(sig)) + 1e-12)
        assert got == pytest.approx(peak, abs=0.6), f"{name}: {got:.1f} dBFS != {peak}"


def test_max_two_sfx_at_once():
    """R-AUD-03: never more than two effects overlapping."""
    events = []
    r = np.random.default_rng(7)
    for ident, at in TL["_audio_index"]["sfx"]:
        fn = audio_synth.SFX[ident]
        dur = len(fn(r)) / audio_synth.SR
        events.append((at, at + dur))
    times = sorted({t for e in events for t in e})
    for i in range(len(times) - 1):
        mid = (times[i] + times[i + 1]) / 2
        live = sum(1 for a, b in events if a <= mid < b)
        assert live <= 2, f"{live} sfx live at {mid:.2f}s"


# ------------------------------------------------------------- vo schedule
def test_voiceover_schedule_monotonic():
    times = [at for _, at in TL["_audio_index"]["vo"]]
    assert times == sorted(times)
    strings = [s for sc in TL["scenes"] for s in sc["audio"]["vo"]]
    assert len(strings) == 8
    assert all(x["string"].strip() for x in strings)
