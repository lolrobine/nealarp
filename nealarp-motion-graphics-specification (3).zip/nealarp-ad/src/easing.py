"""R-VIS-10 — named easing functions, exact.

EASE_IO        = cubic-bezier(0.65, 0.00, 0.35, 1.00)
EASE_OUT_EARLY = cubic-bezier(0.25, 0.80, 0.25, 1.00)
EXPO_OUT       = 1 - 2^(-10 t)
STEP           = hold start value until end time, then snap
"""
from __future__ import annotations


def _bezier(p1: float, p2: float, p3: float, p4: float):
    """Cubic-bezier(0, p1y, p2y, 1)-style curve with x control points p1..p4
    approached via Newton solve on x(t), matching CSS cubic-bezier semantics."""
    x1, y1, x2, y2 = p1, p2, p3, p4

    def sample(t: float) -> float:
        inv = 1.0 - t
        x = 3 * inv * inv * t * x1 + 3 * inv * t * t * x2 + t * t * t
        y = 3 * inv * inv * t * y1 + 3 * inv * t * t * y2 + t * t * t
        return x, y

    def evaluate(progress: float) -> float:
        x = min(max(progress, 0.0), 1.0)
        t = x  # good initial guess for monotonic beziers
        for _ in range(24):
            sx, sy = sample(t)
            err = sx - x
            if abs(err) < 1e-6:
                return sy
            # derivative of x(t)
            dx = (3 * x1 * (1 - t) ** 2 + 6 * x2 * t * (1 - t) + 3 * x2 * t * t
                  - 3 * x1 * (1 - t) ** 2) or 1e-6
            dxd = 3 * (1 - t) ** 2 * x1 + 6 * (1 - t) * t * (x2 - x1) + 3 * t * t * (1 - x2)
            if abs(dxd) < 1e-6:
                return sy
            t = min(max(t - err / dxd, 0.0), 1.0)
        return sample(t)[1]

    return evaluate


EASE_IO = _bezier(0.65, 0.00, 0.35, 1.00)
EASE_OUT_EARLY = _bezier(0.25, 0.80, 0.25, 1.00)


def EXPO_OUT(p: float) -> float:
    p = min(max(p, 0.0), 1.0)
    if p >= 1.0:
        return 1.0
    return 1.0 - 2.0 ** (-10.0 * p)


def STEP(p: float) -> float:
    return 0.0 if p < 1.0 else 1.0


EASINGS = {
    "EASE_IO": EASE_IO,
    "EASE_OUT_EARLY": EASE_OUT_EARLY,
    "EXPO_OUT": EXPO_OUT,
    "STEP": STEP,
}


def windowed(t: float, start: float, end: float, ease: str) -> float:
    """Progress of t inside [start, end] through the named easing (clamped)."""
    if t <= start:
        return 0.0
    if t >= end:
        return 1.0
    p = (t - start) / max(end - start, 1e-9)
    return EASINGS[ease](p)
