"""R-PERF-03 — sprites cached at the scale they are used."""
from __future__ import annotations
import math
from PIL import Image, ImageDraw, ImageFilter

from .palette import BLUE, ORANGE, WHITE, INK

_cache: dict = {}


def _get(key, builder):
    if key not in _cache:
        _cache[key] = builder()
    return _cache[key]


def glow_sprite(color, size_px: int) -> Image.Image:
    """Soft radial glow disc (for particles, creatures, sphere halo)."""
    def build():
        s = max(4, size_px)
        img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse([s * 0.18, s * 0.18, s * 0.82, s * 0.82], fill=color + (255,))
        return img.filter(ImageFilter.GaussianBlur(s * 0.16))
    return _get(("glow", color, size_px), build())


def coin_sprite(d: int, scale: float) -> Image.Image:
    """R-SCN-02: chrome coin — white center, blue mid, orange rim 2 px."""
    px = max(4, round(d * scale))

    def build():
        img = Image.new("RGBA", (px, px), (0, 0, 0, 0))
        dr = ImageDraw.Draw(img)
        # fake radial shading via concentric rings (cheap, deterministic)
        steps = 14
        for i in range(steps, 0, -1):
            f = i / steps
            col = tuple(int(WHITE[c] * (1 - f) + BLUE[c] * f) for c in range(3))
            r = px / 2 * f
            dr.ellipse([px / 2 - r, px / 2 - r, px / 2 + r, px / 2 + r], fill=col + (255,))
        rim = max(1, round(2 * scale))
        dr.ellipse([rim / 2, rim / 2, px - rim / 2, px - rim / 2],
                   outline=ORANGE + (255,), width=rim)
        highlight = ImageDraw.Draw(img)
        highlight.arc([px * 0.15, px * 0.12, px * 0.85, px * 0.8],
                      200, 320, fill=WHITE + (140,), width=max(1, round(2 * scale)))
        return img
    return _get(("coin", px), build())


def creature_sprite(w: int, h: int, color) -> Image.Image:
    """R-SCN-04: bioluminescent creature — rounded glowing ellipse."""
    key = ("creature", w, h, color)

    def build():
        img = Image.new("RGBA", (w * 2, h * 2), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([w * 0.4, h * 0.5, w * 1.6, h * 1.5],
                            radius=h * 0.5, fill=color + (235,))
        core = ImageDraw.Draw(img)
        core.ellipse([w * 0.75, h * 0.8, w * 1.25, h * 1.2], fill=WHITE + (200,))
        out = img.filter(ImageFilter.GaussianBlur(min(w, h) * 0.18))
        out.alpha_composite(img.resize((w, h)))
        return out.resize((w, h * 2))
    return _get(key, build())


def heart_sprite(size: int, scale: float) -> Image.Image:
    """R-SCN-08: two circles + triangle, white with blue glow."""
    px = max(8, round(size * scale))

    def build():
        g = Image.new("RGBA", (px, px), (0, 0, 0, 0))
        dg = ImageDraw.Draw(g)
        r = px * 0.24
        dg.ellipse([px * 0.5 - 2 * r * 0.98 - r * 0.0, px * 0.18, px * 0.5, px * 0.18 + 2 * r], fill=WHITE + (220,))
        dg.ellipse([px * 0.5, px * 0.18, px * 0.5 + 2 * r * 0.98, px * 0.18 + 2 * r], fill=WHITE + (220,))
        dg.polygon([(px * 0.16, px * 0.48), (px * 0.84, px * 0.48), (px * 0.5, px * 0.86)],
                   fill=WHITE + (220,))
        g = g.filter(ImageFilter.GaussianBlur(px * 0.02))
        glow = g.filter(ImageFilter.GaussianBlur(px * 0.07))
        tinted = Image.new("RGBA", (px, px), (0, 0, 0, 0))
        tinted.paste(Image.new("RGBA", (px, px), BLUE + (255,)), (0, 0),
                     glow.getchannel("A").point(lambda a: a // 2))
        base = Image.new("RGBA", (px, px), (0, 0, 0, 0))
        base.alpha_composite(tinted)
        base.alpha_composite(g)
        return base
    return _get(("heart", px), build())


def morph_glyph(kind: str, size: int, scale: float) -> Image.Image:
    """R-SCN-05 geometric glyphs: snail / cheetah / rocket / light_beam."""
    px = max(8, round(size * scale))
    sw = max(2, round(6 * scale))

    def build():
        img = Image.new("RGBA", (px, px), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        c = px / 2
        if kind == "snail":
            for i in range(3):
                rr = px * (0.12 + 0.10 * i)
                d.arc([c - rr, c - rr, c + rr, c + rr], start=-90 + 40 * i,
                      end=270, fill=ORANGE + (255,), width=sw)
        elif kind == "cheetah":
            for i, rr in enumerate((0.10, 0.16, 0.22)):
                x = c - px * 0.25 + i * px * 0.22
                r = px * rr * 0.5
                d.ellipse([x - r, c - r, x + r, c + r], fill=BLUE + (255,))
            d.polygon([(c + px * 0.18, c - px * 0.12), (c + px * 0.4, c),
                       (c + px * 0.18, c + px * 0.12)], fill=ORANGE + (255,))
        elif kind == "rocket":
            d.rectangle([c - px * 0.09, c - px * 0.05, c + px * 0.09, c + px * 0.3],
                        fill=WHITE + (255,))
            d.polygon([(c - px * 0.14, c - px * 0.05), (c + px * 0.14, c - px * 0.05),
                       (c, c - px * 0.3)], fill=ORANGE + (255,))
        elif kind == "light_beam":
            for x in range(-sw * 2, sw * 2 + 1):
                f = 1 - abs(x) / (sw * 2 + 1)
                d.line([(c + x, c - px * 0.34), (c + x, c + px * 0.34)],
                       fill=(WHITE[0], WHITE[1], WHITE[2], int(255 * f)), width=1)
            tip = Image.new("RGBA", img.size, (0, 0, 0, 0))
            td = ImageDraw.Draw(tip)
            td.ellipse([c - sw * 1.6, c - px * 0.36 - sw * 1.6, c + sw * 1.6, c - px * 0.36 + sw * 1.6],
                       fill=BLUE + (255,))
            img.alpha_composite(tip)
        return img
    return _get(("glyph", kind, px), build())


def orbiter_sprite(kind: str, scale: float) -> Image.Image:
    """R-SCN-10 small orbit sprites."""
    key = ("orbiter", kind, round(scale, 3))

    def build():
        s = round(64 * scale)
        if kind == "coin":
            return coin_sprite(64, scale)
        if kind == "heart":
            return heart_sprite(64, scale)
        if kind == "ring":
            img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            d.ellipse([3 * scale, 3 * scale, s - 3 * scale, s - 3 * scale],
                      outline=ORANGE + (255,), width=max(2, round(5 * scale)))
            return img
        if kind == "planet":
            img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            d.ellipse([s * 0.1, s * 0.1, s * 0.9, s * 0.9], fill=BLUE + (255,))
            d.arc([s * 0.02, s * 0.5, s * 0.98, s * 0.95], 180, 360,
                  fill=ORANGE + (255,), width=max(2, round(3 * scale)))
            return img
        if kind == "meteor":
            img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            d.ellipse([s * 0.32, s * 0.32, s * 0.62, s * 0.62], fill=WHITE + (255,))
            d.line([s * 0.47, s * 0.47, s * 0.95, s * 0.1], fill=ORANGE + (230,),
                   width=max(2, round(5 * scale)))
            return img
        if kind == "lock":
            img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            d.rounded_rectangle([s * 0.25, s * 0.45, s * 0.75, s * 0.85],
                                radius=s * 0.1, fill=WHITE + (255,))
            d.arc([s * 0.3, s * 0.12, s * 0.7, s * 0.55], 180, 360,
                  fill=ORANGE + (255,), width=max(2, round(6 * scale)))
            return img
        if kind == "speedometer":
            img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            d.arc([s * 0.12, s * 0.12, s * 0.88, s * 0.88], 150, 390,
                  fill=BLUE + (255,), width=max(2, round(5 * scale)))
            d.line([s * 0.5, s * 0.5, s * 0.72, s * 0.26], fill=WHITE + (255,),
                   width=max(2, round(4 * scale)))
            return img
        # creature fallback
        return creature_sprite(max(8, round(46 * scale)), max(8, round(30 * scale)), ORANGE)
    return _get(key, build())


def telescope_sprite(height_px: int, scale: float, progress: float) -> Image.Image:
    """R-VIS-11: tube + tripod, stroke 6 ref px, drawn 0..progress."""
    h = round(height_px * scale)
    w = round(height_px * 1.3 * scale)
    sw = max(2, round(6 * scale))
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    parts = []
    # tube rotated ~ -30 deg (decompose into a line with thickness)
    x0, y0 = w * 0.28, h * 0.42
    x1, y1 = w * 0.78, h * 0.14
    parts.append(("line", (x0, y0, x1, y1), WHITE, sw * 2.6))
    parts.append(("line", (w * 0.5, h * 0.30, w * 0.5, h * 0.52), WHITE, sw))
    parts.append(("line", (w * 0.5, h * 0.52, w * 0.24, h * 0.95), WHITE, sw))
    parts.append(("line", (w * 0.5, h * 0.52, w * 0.76, h * 0.95), WHITE, sw))
    n = len(parts)
    up_to = progress * n
    for i, (shape, coords, col, width) in enumerate(parts):
        f = max(0.0, min(1.0, up_to - i))
        if f <= 0:
            continue
        if shape == "line":
            (a, b, c2, e) = coords
            c2 = a + (c2 - a) * f
            e = b + (e - b) * f
            d.line([a, b, c2, e], fill=col + (255,), width=round(width))
    return img
