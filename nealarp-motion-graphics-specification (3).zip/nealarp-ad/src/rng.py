"""R-VIS-06 — one seeded generator family, fixed seed 7, deterministic.

Every procedural element derives its stream from SeedSequence([7, tag]) so a
re-render of any frame is byte-identical (R-VER-13).
"""
from __future__ import annotations
import numpy as np

SEED = 7


def stream(tag: int) -> np.random.Generator:
    return np.random.default_rng(np.random.SeedSequence([SEED, tag]))


def frame_offset_stream() -> np.random.Generator:
    """Per-frame grain offsets — precomputed deterministically."""
    return stream(999)
