"""R-VIS-02 — the palette is the whole palette. RGB tuples."""
INK = (10, 10, 10)          # #0a0a0a background
BLUE = (59, 130, 246)       # #3b82f6
ORANGE = (249, 115, 22)     # #f97316
WHITE = (255, 255, 255)
HAZE_CENTER = (15, 23, 42)  # #0f172a, used only at 40% opacity (R-VIS-01)

NAMED = {"blue": BLUE, "orange": ORANGE, "white": WHITE, "ink": INK}


def hex_of(rgb):
    return "#%02x%02x%02x" % rgb
