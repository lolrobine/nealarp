"""Scene painters — one function per element `type` in timeline.yaml.

Every painter is a pure function of (layer, el, t, scale, ctx). Positions are
computed in 1920x1080 reference units and multiplied by `scale` when stamped
(R-VIS-12). All randomness flows from src/rng.py seed 7 streams.
"""
from __future__ import annotations
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from . import easing, effects, rng, sprites
from .palette import BLUE, ORANGE, WHITE, INK
from . import text_layout

W, H = 1920.0, 1080.0


# ------------------------------------------------------------- utilities ----
def _win(el, t):
    s, e = el["start"], el["end"]
    if t <= s:
        return 0.0
    if t >= e:
        return 1.0
    return (t - s) / max(e - s, 1e-9)


def _prog(el, t, ease=None):
    return easing.EASINGS[ease or el.get("ease", "EASE_IO")](_win(el, t))


def scatter(layer_arr, xs, ys, sizes, color, alpha):
    """Vectorized soft dots on a float32 RGBA numpy image (reference coords
    are passed pre-scaled). Deterministic, no per-pixel Python loops."""
    h, w = layer_arr.shape[:2]
    for (x, y, s) in zip(xs, ys, sizes):
        if s < 0.5 or x < -s or y < -s or x > w + s or y > h + s:
            continue
        x0, y0 = max(0, int(x - s)), max(0, int(y - s))
        x1, y1 = min(w, int(x + s) + 1), min(h, int(y + s) + 1)
        if x1 <= x0 or y1 <= y0:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        d2 = ((xx - x) ** 2 + (yy - y) ** 2) / max(s * s, 1e-6)
        k = np.exp(-2.2 * d2) * alpha
        for c in range(3):
            layer_arr[y0:y1, x0:x1, c] += k * color[c]
        layer_arr[y0:y1, x0:x1, 3] = np.maximum(layer_arr[y0:y1, x0:x1, 3], k * 255)


def _stamp(frame: Image.Image, sprite: Image.Image, cx, cy, scale_px=1.0, alpha=1.0, s=1.0):
    sp = sprite
    if scale_px != 1.0:
        sp = sp.resize((max(1, round(sp.width * scale_px)), max(1, round(sp.height * scale_px))))
    if alpha < 0.999:
        sp = sp.copy()
        sp.putalpha(sp.getchannel("A").point(lambda a: int(a * alpha)))
    frame.alpha_composite(sp, (round(cx * s - sp.width / 2), round(cy * s - sp.height / 2)))


# ---------------------------------------------------------------- opening ---
def particle_tunnel(layer, el, t, s, ctx):
    p = el["props"]
    count, speed = p["count"], p["speed"]
    key = ("tunnel", count)
    if key not in ctx:
        r = rng.stream(11)
        ctx[key] = dict(
            ang=r.uniform(0, 2 * math.pi, count),
            rad=r.uniform(160, 900, count),
            z0=r.uniform(0, 2000, count),
            tgt=np.zeros((count, 2)),
            has_tgt=np.zeros(count, bool),
        )
    st = ctx[key]
    if "tgt_ready" not in st:
        pts = text_points(p["converge_target"], "title_opening", 1.0, 420, ctx)
        n = min(420, len(pts))
        st["tgt"][:n] = pts[:n]
        st["has_tgt"][:n] = True
        st["tgt_ready"] = True
    z = (st["z0"] - speed * t) % 2000.0
    x = np.cos(st["ang"]) * st["rad"]
    y = np.sin(st["ang"]) * st["rad"] * 0.62
    sx, sy, k = effects.project(x, y, z)
    sizes = np.clip(6 * k, 0.4, 7) * s
    focal = p.get("focal", [960, 540])
    c0, c1 = np.clip(t / 0.45, 0, 1), None
    conv = easing.windowed(t, p["converge_start"], p["converge_end"], "EASE_IO")
    cs, ce = p["converge_start"], p["converge_end"]
    arr = np.zeros((layer.height and int(H * s) or 0, 0, 0))
    # draw per particle in two color batches
    np_img = np.zeros((int(H * s), int(W * s), 4), np.float32)
    left = np.cos(st["ang"]) * st["rad"] < 0
    for mask, color in ((left, BLUE), (~left, ORANGE)):
        for i in np.nonzero(mask)[0]:
            px, py = sx[i], sy[i]
            if st["has_tgt"][i]:
                delay = (i % 40) * 0.011
                c = easing.windowed(t, cs + delay, ce, "EASE_IO")
                if c > 0:
                    tx, ty = st["tgt"][i]
                    shimmer = math.sin(t * 3 + i) * 1.5 if t >= ce else 0.0
                    px = px + (tx - px) * c
                    py = py + (ty - py) * c + shimmer
            fade = min(1.0, (2000 - z[i]) / 400) if not st["has_tgt"][i] else 1.0
            scatter(np_img, [px * s], [py * s], [sizes[i]], color, 0.75 * fade)
    # white focal point
    fp = min(1.0, t / 1.6)
    scatter(np_img, [focal[0] * s], [focal[1] * s], [10 * s * (1 + 0.2 * math.sin(t * 2))],
            WHITE, 0.9 * fp)
    layer.alpha_composite(_np_to_img(np_img))


def _np_to_img(arr):
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGBA")


# ------------------------------------------------------------- game cuts ----
def coin_cascade(layer, el, t, s, ctx):
    p = el["props"]
    key = ("coins", p["count"])
    if key not in ctx:
        r = rng.stream(21)
        n = p["count"]
        ctx[key] = dict(x=np.sort(r.uniform(700, 1220, n)),
                        delay=r.uniform(0, p["stagger_max"], n),
                        d=r.uniform(p["d_var"][0], p["d_var"][1], n))
    st = ctx[key]
    for i, (x, dl, d) in enumerate(zip(st["x"], st["delay"], st["d"])):
        pr = easing.windowed(t, 8.0 + dl, 8.0 + dl + 1.1, "EASE_IO")
        y = p["y_from"] + (p["y_to"] - p["y_from"]) * pr
        rot = math.sin(t * 2.4 + i * 1.3) * 0.35
        sp = sprites.coin_sprite(d, s)
        sw = max(0.25, abs(math.cos(rot)))
        squash = sp.resize((max(1, round(sp.width * sw)), sp.height))
        _stamp(layer, squash, x, y, 1.0, 0.98, s)


def glass_panel(layer, el, t, s, ctx):
    p = el["props"]
    x, y, w, h = el["rect"]
    r = p.get("radius", 24)
    key = ("glass", int(w), int(h), r, round(s, 2))
    if key not in ctx:
        # R-VIS-04: backdrop blur computed on a 1/4-scale copy, then upsampled
        bg = effects.base_background(int(W * s), int(H * s))
        small = bg.resize((bg.width // 4, bg.height // 4)).filter(
            ImageFilter.GaussianBlur(20 * s / 4)).resize(bg.size)
        patch = small.crop((int(x * s), int(y * s), int((x + w) * s), int((y + h) * s))).copy()
        mask = Image.new("L", patch.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, patch.width, patch.height],
                                               radius=r * s, fill=255)
        panel = Image.new("RGBA", patch.size, (0, 0, 0, 0))
        panel.paste(patch, (0, 0), mask)
        fill = Image.new("RGBA", patch.size, (0, 0, 0, 0))
        fd = ImageDraw.Draw(fill)
        fd.rounded_rectangle([0, 0, patch.width - 1, patch.height - 1], radius=r * s,
                             fill=(255, 255, 255, 26),
                             outline=(255, 255, 255, 64), width=max(1, round(s)))
        # inner shadow: 20% black, offset (0,4), blur 12
        sh = Image.new("L", patch.size, 0)
        ImageDraw.Draw(sh).rounded_rectangle([0, -8 * s, patch.width, patch.height - 8 * s],
                                             radius=r * s, fill=0)
        sh = Image.composite(Image.new("L", patch.size, 160), sh, mask)
        dark = Image.new("RGBA", patch.size, (0, 0, 0, 0))
        dark.putalpha(sh.filter(ImageFilter.GaussianBlur(12 * s)).point(lambda a: int(a * 0.2)))
        panel.alpha_composite(dark)
        panel.alpha_composite(fill)
        ctx[key] = panel
    fade = easing.windowed(t, el["start"], p.get("fade_end", el["end"]), "EASE_OUT_EARLY")
    panel = ctx[key]
    if fade < 0.999:
        panel = panel.copy()
        panel.putalpha(panel.getchannel("A").point(lambda a: int(a * fade)))
    layer.alpha_composite(panel, (int(x * s), int(y * s)))


def lock_body(layer, el, t, s, ctx):
    p = el["props"]
    x, y, w, h = el["rect"]
    build = easing.windowed(t, 11.2, 11.7, "EXPO_OUT")
    click = easing.windowed(t, p["click_at"], p["click_at"] + p["click_dur"], "EXPO_OUT")
    sc = (p["click_scale"][0] + (p["click_scale"][1] - p["click_scale"][0]) * click)
    cx, cy = (x + w / 2), (y + h / 2)
    ww, hh = w * build * sc, h * build * sc
    img = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    box = [(cx - ww / 2) * s, (cy - hh / 2) * s, (cx + ww / 2) * s, (cy + hh / 2) * s]
    grad = Image.new("RGBA", (int(box[2] - box[0]) + 2, int(box[3] - box[1]) + 2), WHITE + (255,))
    gmask = Image.new("L", grad.size, 0)
    ImageDraw.Draw(gmask).rounded_rectangle([1, 1, grad.width - 1, grad.height - 1],
                                            radius=p["radius"] * s, fill=255)
    img.paste(grad, (int(box[0]), int(box[1])), gmask)
    glow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow).rounded_rectangle([box[0] + 8 * s, box[1] + 8 * s, box[2] - 8 * s, box[3] - 8 * s],
                                           radius=(p["radius"] - 4) * s,
                                           outline=BLUE + (200,), width=max(2, round(4 * s)))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(16 * s)))
    layer.alpha_composite(img)


def lock_shackle(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy = el["center"]
    build = easing.windowed(t, 11.2, 11.8, "EXPO_OUT")
    r = p["radius"] * build
    img = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.arc([(cx - r) * s, (cy - r) * s, (cx + r) * s, (cy + r) * s],
          180, 360, fill=WHITE + (255,), width=max(2, round(p["stroke"] * s)))
    layer.alpha_composite(img)


def rule_text_scroll(layer, el, t, s, ctx):
    p = el["props"]
    x, y, w, h = el["rect"]
    key = ("rules",)
    if key not in ctx:
        r = rng.stream(31)
        rows = []
        for _ in range(p["rows"]):
            rows.append("".join(r.choice(list("01#$%&*+=?/\\ABCDEF"), size=26)))
        ctx[key] = rows
    font = text_layout._font(p["glyph_px"], s, mono=True)
    strip = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(strip)
    dy = p["glyph_px"] * 1.9
    off = (t * p["speed_px_s"]) % dy
    for i, row in enumerate(ctx[key]):
        yy = y * s + i * dy * s - off * s if False else (y + i * p["glyph_px"] * 1.9 - (off)) * s
        # recompute cleanly in ref units below
        pass
    strip = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(strip)
    row_h = p["glyph_px"] * 1.9
    off = (t * p["speed_px_s"]) % row_h
    for i in range(-1, p["rows"] + 2):
        row = ctx[key][(i % len(ctx[key]))]
        yy = (y - row_h + i * row_h - off) * s
        d.text(((x + 14) * s, yy), row, font=font,
               fill=(255, 255, 255, int(0.4 * 255)))
    # clip to lock body
    clip = Image.new("L", layer.size, 0)
    ImageDraw.Draw(clip).rounded_rectangle([x * s, y * s, (x + w) * s, (y + h) * s],
                                           radius=32 * s, fill=255)
    strip.putalpha(Image.composite(strip.getchannel("A"), Image.new("L", layer.size, 0), clip))
    layer.alpha_composite(strip)


def check_circles(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy = el["center"]
    n, rr = p["count"], p["radius"]
    total_w = n * rr * 2 + (n - 1) * rr * 0.6
    for i, at in enumerate(p["times"]):
        pr = easing.windowed(t, at, at + 0.25, "EASE_OUT_EARLY")
        if pr <= 0:
            continue
        x = cx - total_w / 2 + rr + i * (rr * 2.6)
        img = Image.new("RGBA", layer.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        r_i = rr * pr
        d.ellipse([(x - r_i) * s, (cy - r_i) * s, (x + r_i) * s, (cy + r_i) * s],
                  outline=ORANGE + (255,), width=max(2, round(5 * s)))
        if pr > 0.6:
            f = (pr - 0.6) / 0.4
            p0 = (x - r_i * 0.45) * s, cy * s
            p1 = (x - r_i * 0.45 + r_i * 0.35 * 2 * f) * s, (cy + r_i * 0.35 * min(1, 2 * f)) * s
            d.line([p0, ((x - r_i * 0.1) * s, (cy + r_i * 0.3) * s), ((x + r_i * 0.5) * s, (cy - r_i * 0.35) * s)],
                   fill=ORANGE + (255,), width=max(2, round(5 * s)), joint="curve")
        glow = img.filter(ImageFilter.GaussianBlur(6 * s))
        layer.alpha_composite(glow)
        layer.alpha_composite(img)


def sea_background(layer, el, t, s, ctx):
    key = ("sea", round(s, 2))
    if key not in ctx:
        h = int(H * s)
        a = (np.linspace(0, 1, h) ** 2 * 0.12 * 255).astype(np.uint8)
        arr = np.zeros((h, int(W * s), 4), np.uint8)
        arr[..., 0] = BLUE[0]
        arr[..., 1] = BLUE[1]
        arr[..., 2] = BLUE[2]
        arr[..., 3] = a[:, None]
        ctx[key] = Image.fromarray(arr, "RGBA")
    layer.alpha_composite(ctx[key])


def particle_drift_up(layer, el, t, s, ctx):
    p = el["props"]
    key = ("dive", p["count"])
    if key not in ctx:
        r = rng.stream(41)
        ctx[key] = dict(x=r.uniform(0, W, p["count"]), y0=r.uniform(0, H, p["count"]),
                        sp=r.uniform(0.6, 1.4, p["count"]), sz=r.uniform(1.5, 5, p["count"]),
                        col=r.integers(0, 2, p["count"]))
    st = ctx[key]
    ease_p = 1.0  # continuous
    np_img = np.zeros((int(H * s), int(W * s), 4), np.float32)
    for i in range(p["count"]):
        y = (st["y0"][i] - t * p["speed_px_s"] * st["sp"][i]) % (H + 100) - 50
        color = BLUE if st["col"][i] == 0 else WHITE
        scatter(np_img, [st["x"][i] * s], [y * s], [st["sz"][i] * s], color, 0.5)
    layer.alpha_composite(_np_to_img(np_img))


def glow_creatures(layer, el, t, s, ctx):
    p = el["props"]
    key = ("creatures", p["count"])
    if key not in ctx:
        r = rng.stream(43)
        ctx[key] = [dict(x=r.uniform(120, 1800), y=r.uniform(160, 800),
                         w=r.uniform(p["size_px"][0], p["size_px"][1]),
                         color=BLUE if r.random() < 0.7 else ORANGE,
                         ph=r.uniform(0, 6.28), z=r.uniform(0, 2000)) for _ in range(p["count"])]
    for c in ctx[key]:
        bob = math.sin(t * 0.9 + c["ph"]) * 14
        k = effects.F / (effects.F + c["z"])
        sp = sprites.creature_sprite(round(c["w"]), round(c["w"] * 0.55), c["color"])
        _stamp(layer, sp, c["x"] * k + 480 * (1 - k), c["y"] * k + 160 * (1 - k) + bob,
               k, 0.85, s)


def bubbles(layer, el, t, s, ctx):
    p = el["props"]
    key = ("bub", p["count"])
    if key not in ctx:
        r = rng.stream(47)
        ctx[key] = dict(x=r.uniform(0, W, p["count"]), y0=r.uniform(0, H, p["count"]),
                        sp=r.uniform(p["speed_px_s"][0], p["speed_px_s"][1], p["count"]),
                        rr=r.uniform(p["radius_px"][0], p["radius_px"][1], p["count"]))
    st = ctx[key]
    d = ImageDraw.Draw(layer)
    for i in range(p["count"]):
        y = (st["y0"][i] - st["sp"][i] * t) % (H + 60) - 30
        rr = st["rr"][i] * s
        d.ellipse([(st["x"][i] * s - rr), (y * s - rr), (st["x"][i] * s + rr), (y * s + rr)],
                  outline=(255, 255, 255, 120), width=max(1, round(s)))


def depth_counter(layer, el, t, s, ctx):
    p = el["props"]
    steps = p["steps"]
    val = steps[0][1]
    for i, (ts, v) in enumerate(steps):
        if t >= ts:
            if i + 1 < len(steps):
                nv = steps[i + 1][1]
                f = easing.windowed(t, ts, ts + p["ramp_s"], "EASE_IO")
                val = v + (nv - v if t < steps[i + 1][0] + p["ramp_s"] else 0) * f
                if t >= ts + p["ramp_s"]:
                    val = v if i + 1 < len(steps) and t < steps[i + 1][0] else val
                    if t >= steps[i + 1][0]:
                        val = v + (steps[i + 1][1] - v) * easing.windowed(t, steps[i + 1][0], steps[i + 1][0] + p["ramp_s"], "EASE_IO")
            else:
                val = v
    txt = f"{int(round(val)):,}".replace(",", ".") + " m"
    sprite, bbox, meta = text_layout.render_text_sprite(txt, "counter_center", s)
    x, y, bw, bh = bbox
    layer.alpha_composite(sprite, (int(x * s), int(y * s)))


def speedometer(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy = el["center"]
    r = p["radius"]
    a0, a1 = p["arc_deg"]
    d = ImageDraw.Draw(layer)
    d.arc([(cx - r) * s, (cy - r) * s, (cx + r) * s, (cy + r) * s],
          a1, a0, fill=BLUE + (255,), width=max(3, round(10 * s)))
    for i in range(p["ticks"] + 1):
        ang = math.radians(a0 + (a1 - a0) * i / p["ticks"])
        x0, y0 = cx + math.cos(ang) * (r - 18), cy + math.sin(ang) * (r - 18)
        x1, y1 = cx + math.cos(ang) * (r + 8), cy + math.sin(ang) * (r + 8)
        d.line([(x0 * s, y0 * s), (x1 * s, y1 * s)], fill=(255, 255, 255, 160),
               width=max(2, round(3 * s)))
    prog = easing.windowed(t, p["sweep_start"], p["sweep_start"] + p["sweep_dur"], "EXPO_OUT")
    ang = math.radians(a0 + (a1 - a0) * prog)
    tip = (cx + math.cos(ang) * (r - 40)) * s, (cy + math.sin(ang) * (r - 40)) * s
    d.line([(cx * s, cy * s), tip], fill=WHITE + (255,), width=max(2, round(8 * s)))
    hub = 14 * s
    d.ellipse([cx * s - hub, cy * s - hub, cx * s + hub, cy * s + hub], fill=ORANGE + (255,))


def motion_streaks(layer, el, t, s, ctx):
    p = el["props"]
    key = ("mstreak", p["count"])
    if key not in ctx:
        r = rng.stream(53)
        ctx[key] = dict(x=r.uniform(0, W + 600, p["count"]), y=r.uniform(0, H, p["count"]),
                        ln=r.uniform(p["length_px"][0], p["length_px"][1], p["count"]))
    st = ctx[key]
    d = ImageDraw.Draw(layer)
    for i in range(p["count"]):
        x = (st["x"][i] - t * p["speed_px_s"]) % (W + 700) - 350
        ln = st["ln"][i]
        grad = Image.new("L", (max(2, int(ln * s)), 1), 0)
        for xx in range(grad.width):
            grad.putpixel((xx, 0), int(255 * (xx / grad.width)))
        line = Image.new("RGBA", (grad.width, max(1, round(2 * s))), (255, 255, 255, 0))
        la = np.asarray(line)
        la[..., 3] = (np.asarray(grad)[:, None] * 0.3).astype(np.uint8)
        line = Image.fromarray(la, "RGBA")
        layer.alpha_composite(line, (int(x * s), int(st["y"][i] * s)))


def morph_glyph(layer, el, t, s, ctx):
    p = el["props"]
    fin = easing.windowed(t, el["start"], el["start"] + p["crossfade"], "EASE_IO")
    fout = 1.0 - easing.windowed(t, el["end"] - p["crossfade"], el["end"], "EASE_IO")
    a = min(fin, fout)
    if a <= 0:
        return
    sp = sprites.morph_glyph(p["glyph"], 220, s)
    cx, cy = el["center"]
    _stamp(layer, sp, cx, cy - 120, 1.0, a, s)


def earth_disk(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy, r = el["center"][0], el["center"][1], p["radius"]
    key = ("earth", round(s, 2))
    if key not in ctx:
        d = int(2 * p["radius"] * s)
        img = Image.new("RGBA", (d, d), (0, 0, 0, 0))
        dr = ImageDraw.Draw(img)
        steps = 16
        for i in range(steps, 0, -1):
            f = i / steps
            col = tuple(int(min(255, BLUE[c] * f + 14 * (1 - f))) for c in range(3))
            rr = d / 2 * f
            dr.ellipse([d / 2 - rr, d / 2 - rr, d / 2 + rr, d / 2 + rr], fill=col + (255,))
        dr.ellipse([1, 1, d - 2, d - 2], outline=ORANGE + (255,), width=max(1, round(2 * s)))
        for _ in range(7):
            pass
        ctx[key] = img
    _stamp(layer, ctx[key], cx, cy, 1.0, 1.0, s)


def meteor(layer, el, t, s, ctx):
    p = el["props"]
    pr = easing.windowed(t, el["start"], el["end"], "EASE_IO")
    if pr <= 0:
        return
    fx, fy, tx, ty = *p["from"], *p["to"]
    x, y = fx + (tx - fx) * pr, fy + (ty - fy) * pr
    d = ImageDraw.Draw(layer)
    for k in range(22):
        f = k / 22
        bx, by = x + (fx - x) * f * 0.35, y + (fy - y) * f * 0.35
        rr = (10 * (1 - f) + 2) * s
        a = int(255 * (1 - f) * pr)
        d.ellipse([bx * s - rr, by * s - rr, bx * s + rr, by * s + rr], fill=ORANGE + (a,))
    hd = 14 * s
    d.ellipse([x * s - hd, y * s - hd, x * s + hd, y * s + hd], fill=WHITE + (255,))


def shockwave_rings(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy = el["center"]
    d = ImageDraw.Draw(layer)
    for i in range(p["rings"]):
        delay = i * 0.07
        pr = easing.windowed(t, el["start"] + delay, el["start"] + delay + p["dur"], "EXPO_OUT")
        if pr <= 0:
            continue
        rr = p["radius_to"] * pr * (1 - i * 0.07)
        a = int(255 * (1 - pr) * (1 - i * 0.12))
        d.ellipse([(cx - rr) * s, (cy - rr) * s, (cx + rr) * s, (cy + rr) * s],
                  outline=ORANGE + (a,), width=max(1, round(p["stroke"] * s)))


def crater(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy = el["center"]
    pr = easing.windowed(t, el["start"], el["start"] + 0.25, "EASE_OUT_EARLY")
    if pr <= 0:
        return
    rx, ry = p["rx"] * pr, p["ry"] * pr
    d = ImageDraw.Draw(layer)
    d.ellipse([(cx - rx) * s, (cy - ry) * s, (cx + rx) * s, (cy + ry) * s], fill=INK + (255,))
    d.ellipse([(cx - rx) * s, (cy - ry) * s, (cx + rx) * s, (cy + ry) * s],
              outline=BLUE + (255,), width=max(1, round(3 * s)))


def arc_draw(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy, r = el["center"][0], el["center"][1], p["radius"]
    pr = easing.windowed(t, p["draw_start"], p["draw_start"] + p["draw_dur"], "EASE_IO")
    deg = 360 * pr
    d = ImageDraw.Draw(layer)
    box = [(cx - r) * s, (cy - r) * s, (cx + r) * s, (cy + r) * s]
    if deg > 0:
        d.arc(box, -90, -90 + deg, fill=ORANGE + (255,), width=max(2, round(p["stroke"] * s)))
        ri = r - 16
        d.arc([(cx - ri) * s, (cy - ri) * s, (cx + ri) * s, (cy + ri) * s],
              -90, -90 + deg, fill=(255, 255, 255, int(0.4 * 255)),
              width=max(1, round(p["core_stroke"] * s)))
        tip = (-90 + deg) * math.pi / 180
        tx, ty = (cx + r * math.cos(tip)) * s, (cy + r * math.sin(tip)) * s
        hd = (p["stroke"] / 2 + 3) * s
        d.ellipse([tx - hd, ty - hd, tx + hd, ty + hd], fill=WHITE + (255,))


def dashed_ring(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy, r = el["center"][0], el["center"][1], p["radius"]
    a = easing.windowed(t, el["start"], el["start"] + 0.3, "EASE_OUT_EARLY")
    if a <= 0:
        return
    d = ImageDraw.Draw(layer)
    step = p["dash"] + p["gap"]
    n = int(2 * math.pi * r / step)
    alpha = int(p["alpha"] * 255 * a)
    for i in range(n):
        a0 = i * step / r
        a1 = a0 + p["dash"] / r
        d.arc([(cx - r) * s, (cy - r) * s, (cx + r) * s, (cy + r) * s],
              math.degrees(a0), math.degrees(a1), fill=(255, 255, 255, alpha),
              width=max(1, round(p["stroke"] * s)))


def heart_pulse(layer, el, t, s, ctx):
    p = el["props"]
    sp = sprites.heart_sprite(p["size_px"], s)
    scale_now = 1.0
    for b in p["beats"]:
        dtb = t - b
        if 0 <= dtb < 0.5:
            scale_now = 1.0 + (p["scale_to"] - 1.0) * math.sin(math.pi * dtb / 0.5)
    cx, cy = el["center"]
    _stamp(layer, sp, cx, cy, scale_now, 1.0, s)


def pulse_rings(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy = el["center"]
    d = ImageDraw.Draw(layer)
    for b in p["beats"]:
        dtb = t - b
        if dtb <= 0:
            continue
        pr = easing.windowed(t, b, b + 0.833, "EASE_IO")
        if 0 < pr < 1:
            rr = p["radius_to"] * pr
            a = int(200 * (1 - pr))
            d.ellipse([(cx - rr) * s, (cy - rr) * s, (cx + rr) * s, (cy + rr) * s],
                      outline=BLUE + (a,), width=max(1, round(p["stroke"] * s)))


def stat_counters(layer, el, t, s, ctx):
    p = el["props"]
    build = easing.windowed(t, el["start"], el["start"] + 2.2, "EASE_IO")
    font = text_layout._font(p["font_px"], s)
    for (rect, target) in zip(p["panels"], p["targets"]):
        x, y, w, h = rect
        v = target * build
        txt = f"{int(round(v)):,}".replace(",", ".")
        tw = font.getlength(txt)
        d = ImageDraw.Draw(layer)
        d.text(((x + w / 2) * s - tw / 2, (y + h / 2) * s - font.getmetrics()[0] / 2 + 16 * s),
               txt, font=font, fill=WHITE + (255,))


def zoom_out_stages(layer, el, t, s, ctx):
    p = el["props"]
    stages = p["stages"]
    dur = p["stage_dur"]
    idx = min(len(stages) - 1, int((t - el["start"]) / dur))
    local = (t - el["start"]) / dur - idx
    tr = easing.windowed(local * dur, dur - p["transition"], dur, "EXPO_OUT")
    cx, cy = el["center"]

    def draw_stage(kind, scale_factor, alpha):
        if alpha <= 0.01:
            return
        d = ImageDraw.Draw(layer)
        bb = 1.0 / max(scale_factor, 1e-3)  # bigger factor = zoomed IN view of prev
        pul = 1.0 + 0.0
        if kind == "human":
            hh = 260 * bb
            cxp, cyp = cx * s, cy * s
            hr = hh * 0.16
            d.ellipse([cxp - hr, cyp - hh / 2 - hr, cxp + hr, cyp - hh / 2 + hr], fill=(255, 255, 255, int(255 * alpha)))
            d.rounded_rectangle([cxp - hh * 0.15, cyp - hh / 2 + hr * 1.2, cxp + hh * 0.15, cyp + hh / 2],
                                radius=hh * 0.08, fill=(255, 255, 255, int(255 * alpha)))
        elif kind == "building":
            bw, bh = 300 * bb, 340 * bb
            cxp, cyp = cx * s, cy * s
            d.rectangle([cxp - bw / 2, cyp - bh / 2, cxp + bw / 2, cyp + bh / 2], fill=(59, 130, 246, int(255 * alpha)))
            for rr in range(4):
                for cc in range(3):
                    wx = cxp - bw / 2 + bw * (0.15 + cc * 0.3)
                    wy = cyp - bh / 2 + bh * (0.12 + rr * 0.24)
                    d.rectangle([wx, wy, wx + bw * 0.12, wy + bh * 0.1], fill=(10, 10, 10, int(255 * alpha)))
        elif kind == "mountain":
            bw, bh = 520 * bb, 300 * bb
            cxp, cyp = cx * s, cy * s
            d.polygon([(cxp - bw / 2, cyp + bh / 2), (cxp, cyp - bh / 2), (cxp + bw / 2, cyp + bh / 2)],
                      fill=(255, 255, 255, int(255 * alpha)))
            d.polygon([(cxp - bw * 0.13, cyp - bh * 0.28), (cxp, cyp - bh / 2), (cxp + bw * 0.13, cyp - bh * 0.28)],
                      fill=(59, 130, 246, int(255 * alpha)))
        elif kind == "earth":
            rr = 190 * bb
            sp = ctx.get("earth_s")
            if sp is None:
                e = Image.new("RGBA", (400, 400), (0, 0, 0, 0))
                ed = ImageDraw.Draw(e)
                ed.ellipse([10, 10, 390, 390], fill=BLUE + (255,))
                ctx["earth_s"] = e
                sp = e
            rr2 = sp.resize((max(2, int(380 * bb * s)), max(2, int(380 * bb * s))))
            tmp = rr2.copy()
            tmp.putalpha(tmp.getchannel("A").point(lambda a: int(a * alpha)))
            layer.alpha_composite(tmp, (int(cx * s - tmp.width / 2), int(cy * s - tmp.height / 2)))
        elif kind == "sun":
            rr = 200 * bb * s
            d2 = ImageDraw.Draw(layer)
            core = rr * 0.42
            glow_img = Image.new("RGBA", (int(rr * 2.6) + 2, int(rr * 2.6) + 2), (0, 0, 0, 0))
            gd = ImageDraw.Draw(glow_img)
            gd.ellipse([4, 4, glow_img.width - 4, glow_img.height - 4], fill=ORANGE + (int(90 * alpha),))
            glow_img = glow_img.filter(ImageFilter.GaussianBlur(24 * s))
            layer.alpha_composite(glow_img, (int(cx * s - glow_img.width / 2), int(cy * s - glow_img.height / 2)))
            d2.ellipse([cx * s - rr, cy * s - rr, cx * s + rr, cy * s + rr], fill=ORANGE + (int(255 * alpha),))
            d2.ellipse([cx * s - core, cy * s - core, cx * s + core, cy * s + core], fill=WHITE + (int(255 * alpha),))
        elif kind == "galaxy":
            key = ("galaxy", p["galaxy_particles"], round(s, 2))
            if key not in ctx:
                r = rng.stream(61)
                n = p["galaxy_particles"]
                ang = r.uniform(0, 4 * math.pi, n)
                rad = r.uniform(4, 660, n) ** 1.02
                arm = (ang * 3 + rad / 90) % (2 * math.pi)
                ctx[key] = (arm, rad, r.uniform(0.8, 2.6, n) * s, r.integers(0, 2, n))
            arm, rad, sz, colb = ctx[key]
            np_img = np.zeros((int(H * s), int(W * s), 4), np.float32)
            n = len(arm)
            for i in range(n):
                f = rad[i] / 660
                color = WHITE if f < 0.25 else (BLUE if colb[i] else ORANGE)
                px = (cx + math.cos(arm[i]) * rad[i] * bb)
                py = (cy + math.sin(arm[i]) * rad[i] * 0.42 * bb)
                scatter(np_img, [px * s], [py * s], [sz[i] * bb], color, 0.85 * alpha)
            layer.alpha_composite(_np_to_img(np_img))

    cur, nxt = stages[idx], stages[idx + 1] if idx + 1 < len(stages) else None
    if nxt and tr > 0:
        draw_stage(cur, 1.0 + 9.0 * tr, 1.0 - tr)
        draw_stage(nxt, 0.12 + 0.88 * tr, tr)
    else:
        draw_stage(cur, 1.0, 1.0 if nxt else min(1.0, (t - el["start"]) / dur - idx + 0.001 or 1.0))


def telescope_icon(layer, el, t, s, ctx):
    p = el["props"]
    pr = easing.windowed(t, p["draw_start"], p["draw_start"] + p["draw_dur"], "EASE_IO")
    if pr <= 0:
        return
    sp = sprites.telescope_sprite(p["height_px"], s, pr)
    cx, cy = el["center"]
    _stamp(layer, sp, cx, cy, 1.0, 1.0, s)


# ------------------------------------------------------------------ hero ----
def hero_sphere(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy, r0 = el["center"][0], el["center"][1], p["radius"]
    pulse = 1.0 + p["pulse_amp"] * math.sin(2 * math.pi * p["pulse_hz"] * t)
    push = easing.windowed(t, 32.0, 44.0, "EASE_IO")
    sc = p["push_scale"][0] + (p["push_scale"][1] - p["push_scale"][0]) * push
    r = r0 * pulse * sc
    key = ("sphere", round(s, 2))
    if key not in ctx:
        d = int(2.6 * p["radius"] * s)
        img = Image.new("RGBA", (d, d), (0, 0, 0, 0))
        steps = 22
        dd = ImageDraw.Draw(img)
        for i in range(steps, 0, -1):
            f = i / steps
            if f > 0.55:
                col = tuple(int(BLUE[c] * (f - 0.55) / 0.45 + WHITE[c] * (1 - (f - 0.55) / 0.45)) for c in range(3))
            else:
                col = tuple(int(ORANGE[c] * f / 0.55 + WHITE[c] * (1 - f / 0.55)) for c in range(3))
            rr = d / 2 * f
            dd.ellipse([d / 2 - rr, d / 2 - rr, d / 2 + rr, d / 2 + rr], fill=col + (255,))
        ctx[key] = img
    sp = ctx[key]
    scale_now = (r * 2.6 * s) / sp.width
    _stamp(layer, sp, cx, cy, scale_now, 1.0, 1.0)
    glow = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([(cx - r * 1.35) * s, (cy - r * 1.35) * s, (cx + r * 1.35) * s, (cy + r * 1.35) * s],
               fill=BLUE + (40,))
    layer.alpha_composite(glow.filter(ImageFilter.GaussianBlur(40 * s)))


def orbiters(layer, el, t, s, ctx):
    p = el["props"]
    kinds = p["kinds"]
    cx, cy = el["center"]
    push = easing.windowed(t, 32.0, 44.0, "EASE_IO")
    grow = 1.0 + 0.15 * push
    for i, kind in enumerate(kinds):
        ring = p["rings"][0] if i < 4 else p["rings"][1]
        direction = 1 if i % 2 == 0 else -1
        ang = (i / len(kinds)) * 2 * math.pi + direction * p["angular_speed"] * t
        x = cx + math.cos(ang) * ring * grow
        y = cy + math.sin(ang) * ring * 0.62 * grow
        sp = sprites.orbiter_sprite(kind, s)
        _stamp(layer, sp, x, y, grow, 0.95, s)


# ------------------------------------------------------------------- cta ----
def _explosion_positions(count, t, s, ctx):
    key = ("explosion", count)
    if key not in ctx:
        r = rng.stream(71)
        ctx[key] = dict(ang=r.uniform(0, 2 * math.pi, count),
                        sp=r.uniform(300, 1600, count),
                        size=r.uniform(2, 9, count),
                        col=r.integers(0, 2, count),
                        wob=r.uniform(0, 6.28, count))
    st = ctx[key]
    prog = easing.EXPO_OUT(min(1.0, max(0.0, (t - 44.0) / 2.0)))
    prog = easing.windowed(t, 44.0, 46.0, "EASE_OUT_EARLY")
    dist = st["sp"] * prog
    life = 1 - easing.windowed(t, 44.4, 46.0, "EASE_IO")
    x = 960 + np.cos(st["ang"]) * dist
    y = 500 + np.sin(st["ang"]) * dist * 0.8
    return x, y, st["size"] * life, st["col"], life


def particle_explosion(layer, el, t, s, ctx):
    p = el["props"]
    x, y, sz, colidx, life = _explosion_positions(p["count"], t, s, ctx)
    np_img = np.zeros((int(H * s), int(W * s), 4), np.float32)
    for i in range(p["count"]):
        color = BLUE if colidx[i] == 0 else ORANGE
        scatter(np_img, [x[i] * s], [y[i] * s], [max(0.5, sz[i]) * s], color, 0.85)
    layer.alpha_composite(_np_to_img(np_img))


def text_points(string, layout, scale_ref, n, ctx):
    """Sample up to n points from a text sprite's alpha mask (reference units)."""
    key = ("points", string, layout)
    if key in ctx:
        return ctx[key]
    sprite, bbox, meta = text_layout.render_text_sprite(string, layout, 1.0, {})
    a = np.asarray(sprite.getchannel("A"))
    ys, xs = np.nonzero(a > 100)
    pts = np.stack([xs + bbox[0], ys + bbox[1]], 1).astype(np.float32)
    if len(pts) > n:
        idx = rng.stream(73).choice(len(pts), n, replace=False)
        pts = pts[idx]
    ctx[key] = pts
    return pts


def particle_text_form(layer, el, t, s, ctx):
    p = el["props"]
    string, layout = p["string"], p.get("layout", "claim_white")
    n = 3000
    targets = text_points(string, layout, 1.0, n, ctx)
    src_key = ("form_src", el["id"])
    if src_key not in ctx:
        sx, sy, _, _, _ = _explosion_positions(n, min(t, p.get("form_start", el["start"])), s, ctx)
        if el["id"] != "reform_bald":
            prev_key = ("form_pts", el["id"] + "_prev")
            sx, sy = ctx.get(prev_key, (sx, sy))
        ctx[src_key] = (sx.copy(), sy.copy())
    sx, sy = ctx[src_key]
    f0 = p.get("form_start", el["start"])
    pr = easing.windowed(t, f0, f0 + p["form_dur"], "EASE_IO")
    m = min(len(targets), n)
    px = sx[:m] + (targets[:m, 0] - sx[:m]) * pr
    py = sy[:m] + (targets[:m, 1] - sy[:m]) * pr
    if el["id"] == "reform_oktober":
        colors = [BLUE, ORANGE]
        np_img = np.zeros((int(H * s), int(W * s), 4), np.float32)
        for i in range(m):
            gx = targets[i, 0]
            fx = np.clip((gx - 300) / 1320, 0, 1)
            col = tuple(int(BLUE[c] + (ORANGE[c] - BLUE[c]) * fx) for c in range(3))
            scatter(np_img, [px[i] * s], [py[i] * s], [4.5 * s], col, 0.8)
        layer.alpha_composite(_np_to_img(np_img))
    else:
        np_img = np.zeros((int(H * s), int(W * s), 4), np.float32)
        np.random.seed(0)
        for i in range(m):
            scatter(np_img, [px[i] * s], [py[i] * s], [4.5 * s], WHITE, 0.8)
        layer.alpha_composite(_np_to_img(np_img))
    ctx[("form_pts", el["id"] + "_next")] = (px, py)


def gradient_underline(layer, el, t, s, ctx):
    p = el["props"]
    x, y, w, h = el["rect"]
    pr = easing.windowed(t, el["start"], el["start"] + p["sweep_dur"], "EASE_IO")
    if pr <= 0:
        return
    ww = w * pr
    grad = Image.new("RGBA", (int(w * s), int(h * s) + 2), (0, 0, 0, 0))
    gp = grad.load()
    for xx in range(grad.width):
        f = xx / max(grad.width - 1, 1)
        col = tuple(int(BLUE[c] + (ORANGE[c] - BLUE[c]) * f) for c in range(3)) + (255,)
        for yy2 in range(grad.height):
            gp[xx, yy2] = col
    grad = grad.crop((0, 0, max(1, int(ww * s)), grad.height))
    layer.alpha_composite(grad, (int(x * s), int(y * s)))


def cta_pill(layer, el, t, s, ctx):
    p = el["props"]
    cx, cy = el["center"]
    fade = easing.windowed(t, el["start"], p["fade_end"], "EASE_OUT_EARLY")
    sc = 1.0
    if p["pulse_at"] <= t <= p["pulse_at"] + p["pulse_dur"]:
        f = math.sin(math.pi * (t - p["pulse_at"]) / p["pulse_dur"])
        sc = 1.0 + (p["pulse_scale"] - 1.0) * f
    w, h = p["w"] * sc, p["h"] * sc
    d = ImageDraw.Draw(layer)
    a = int(255 * fade)
    d.rounded_rectangle([(cx - w / 2) * s, (cy - h / 2) * s, (cx + w / 2) * s, (cy + h / 2) * s],
                        radius=p["radius"] * sc * s, fill=ORANGE + (a,))


def particle_drift(layer, el, t, s, ctx):
    p = el["props"]
    key = ("drift", p["count"])
    if key not in ctx:
        r = rng.stream(79)
        ctx[key] = dict(x=r.uniform(0, W, p["count"]), y=r.uniform(0, H, p["count"]),
                        ph=r.uniform(0, 6.28, p["count"]), col=r.integers(0, 2, p["count"]))
    st = ctx[key]
    np_img = np.zeros((int(H * s), int(W * s), 4), np.float32)
    for i in range(p["count"]):
        x = (st["x"][i] + math.sin(t * 0.3 + st["ph"][i]) * 30 + t * p["speed_px_s"]) % W
        y = st["y"][i] + math.cos(t * 0.23 + st["ph"][i]) * 22
        color = BLUE if st["col"][i] == 0 else ORANGE
        scatter(np_img, [x * s], [y * s], [2.4 * s], color, 0.45)
    layer.alpha_composite(_np_to_img(np_img))


def _noop(layer, el, t, s, ctx):
    return None


PAINTERS = {
    "particle_tunnel": particle_tunnel,
    "light_streaks": lambda L, el, t, s, c: effects.light_streaks(
        L, el["props"]["count"], t, el["props"]["drift_px_s"], s, hash(el["id"]) % 997),
    "anamorphic_flare": lambda L, el, t, s, c: effects.draw_flare(
        L, el["center"], el["props"], t, s, _win(el, t)),
    "off_screen_flicker": _noop,      # handled by renderer post stage
    "cut_pop": _noop,                 # scene-level transform (renderer)
    "cut_envelope": _noop,            # scene-level alpha (renderer)
    "camera_shake": _noop,            # scene-level offset (renderer)
    "camera_push": _noop,             # scene-level scale (renderer)
    "fade_to_black": _noop,           # post stage (renderer)
    "title_pulse": _noop,             # text-layer transform (renderer)
    "coin_cascade": coin_cascade,
    "glass_panel": glass_panel,
    "lock_body": lock_body,
    "lock_shackle": lock_shackle,
    "rule_text_scroll": rule_text_scroll,
    "check_circles": check_circles,
    "sea_background": sea_background,
    "particle_drift_up": particle_drift_up,
    "glow_creatures": glow_creatures,
    "bubbles": bubbles,
    "depth_counter": depth_counter,
    "speedometer": speedometer,
    "motion_streaks": motion_streaks,
    "morph_glyph": morph_glyph,
    "earth_disk": earth_disk,
    "meteor": meteor,
    "shockwave_rings": shockwave_rings,
    "crater": crater,
    "arc_draw": arc_draw,
    "dashed_ring": dashed_ring,
    "heart_pulse": heart_pulse,
    "pulse_rings": pulse_rings,
    "stat_counters": stat_counters,
    "zoom_out_stages": zoom_out_stages,
    "telescope_icon": telescope_icon,
    "hero_sphere": hero_sphere,
    "orbiters": orbiters,
    "particle_explosion": particle_explosion,
    "particle_text_form": particle_text_form,
    "gradient_underline": gradient_underline,
    "cta_pill": cta_pill,
    "particle_drift": particle_drift,
}
