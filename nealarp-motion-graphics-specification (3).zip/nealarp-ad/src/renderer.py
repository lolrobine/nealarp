"""R-OUT-02 / R-TIME-01 — every frame is a pure function of t = frame / 60.

render_frame(timeline, frame_index, scale) -> PIL.Image (RGB)
render_video(timeline, scale, out)      -> streams into ffmpeg (H.264 silent master)
render_probe_frames(timeline, frames)   -> double-render MD5 probes (R-VER-13)
"""
from __future__ import annotations
import hashlib
import io
import math
import subprocess
import sys
import os
import numpy as np
import imageio_ffmpeg
from PIL import Image

from . import easing, effects, scenes, text_layout

W_REF, H_REF = 1920, 1080
FPS = 60


# ------------------------------------------------------------ frame core ----
def _scene_at(tl, t: float):
    for sc in tl["scenes"]:
        if sc["start"] <= t < sc["end"]:
            return sc
    return tl["scenes"][-1]


def _scene_modifiers(scene, t):
    """Scene-level transforms declared in yaml: pop scale, cut envelopes,
    camera shake / push, title pulse, fade-to-black, flicker."""
    scale = 1.0
    alpha = 1.0
    dx = dy = 0.0
    title_scale = 1.0
    fade = 0.0
    flicker = 0.0
    for el in scene.get("elements", []):
        ty = el["type"]
        if not (el["start"] <= t <= el["end"]):
            continue
        p = el.get("props", {})
        pr = (t - el["start"]) / max(el["end"] - el["start"], 1e-9)
        ease = easing.EASINGS[el.get("ease", "EASE_IO")]
        if ty == "cut_pop":
            k = 1.0 - ease(min(pr, 1.0))
            scale *= p["scale_from"] + (1.0 - p["scale_from"]) * (1 - k)
        elif ty == "cut_envelope":
            a0, a1 = p["alpha"]
            k = ease(min(pr, 1.0))
            alpha *= a0 + (a1 - a0) * k
            dy += p.get("slide_y", 0) * k * (-1 if a1 < a0 else 1)
        elif ty == "camera_shake":
            amp = p["amplitude_px"] * (1 - pr)
            dx += math.sin(t * 91.0) * amp
            dy += math.cos(t * 83.0) * amp * 0.7
        elif ty == "camera_push":
            sc0, sc1 = p["scale"]
            scale *= sc0 + (sc1 - sc0) * ease(min(pr, 1.0))
        elif ty == "title_pulse":
            for pt in p["times"]:
                if pt <= t <= pt + p["dur"]:
                    f = math.sin(math.pi * (t - pt) / p["dur"])
                    title_scale = 1.0 + (p["scale_to"] - 1.0) * f
        elif ty == "fade_to_black":
            fade = ease(min(pr, 1.0))
        elif ty == "off_screen_flicker":
            flicker = p["alpha"] * math.sin(math.pi * pr)
    return scale, alpha, dx, dy, title_scale, fade, flicker


def render_frame(tl, frame_index: int, scale: float = 1.0) -> Image.Image:
    t = frame_index / FPS
    w, h = round(W_REF * scale), round(H_REF * scale)

    base = effects.base_background(w, h)
    scene = _scene_at(tl, t)
    ctx_cache = _CTX.setdefault("scene_ctx", {})

    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    for el in scene.get("elements", []):
        if el["start"] <= t <= el["end"]:
            scenes.PAINTERS[el["type"]](layer, el, t, scale, ctx_cache)

    # text layer (single choke point, R-TXT-02)
    text_layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    _, _, _, _, title_scale, _, _ = _scene_modifiers(scene, t)
    for entry in scene.get("text", []):
        if not (entry["start"] <= t <= entry["end"]):
            continue
        a_in = easing.windowed(t, entry["start"], min(entry["start"] + 0.4, entry["end"]), "EASE_IO")
        a_out = 1.0
        props = entry.get("props", {})
        if "fade_out_from" in props:
            a_out = 1.0 - easing.windowed(t, props["fade_out_from"], entry["end"], "EASE_IO")
        else:
            a_out = 1.0 - easing.windowed(t, entry["end"] - 0.4, entry["end"], "EASE_IO")
        a = min(1.0, a_in, a_out)
        if a <= 0.001 and frame_index % 40:  # still log once every 40 frames
            if (entry["id"], frame_index // 40) not in _CTX.setdefault("logged_once", set()):
                _CTX["logged_once"].add((entry["id"], frame_index // 40))
                text_layout.draw_text(text_layer, entry, scale, 1.0)
            continue
        if title_scale != 1.0 and entry["layout"] == "title_lower_third":
            tmp = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            text_layout.draw_text(tmp, entry, scale, a)
            ch = tmp.crop((0, int(720 * scale), w, h))
            nw = int(ch.width * title_scale)
            ch = ch.resize((nw, ch.height))
            text_layer.alpha_composite(ch, (int((w - nw) / 2), int(720 * scale)))
        else:
            text_layout.draw_text(text_layer, entry, scale, a)

    sc, alpha, dx, dy, _, fade, flicker = _scene_modifiers(scene, t)
    content = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    content.alpha_composite(layer)
    content.alpha_composite(text_layer)
    if sc != 1.0:
        nw, nh = max(2, int(w * sc)), max(2, int(h * sc))
        content = content.resize((nw, nh))
        canvas = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        canvas.alpha_composite(content, (int((w - nw) / 2 + dx * scale),
                                         int((h - nh) / 2 + dy * scale)))
        content = canvas
    elif dx or dy:
        content = Image.fromarray(np.roll(np.asarray(content), (int(dy), int(dx)), (0, 1)))
    if alpha < 0.999:
        content.putalpha(content.getchannel("A").point(lambda a: int(a * alpha)))

    frame = base
    frame.alpha_composite(content)

    # post chain: bloom -> flicker -> grain -> vignette -> fade
    frame = effects.bloom(frame, scale)
    if flicker > 0:
        flash = Image.new("RGBA", (w, h), (255, 255, 255, int(255 * flicker)))
        frame.alpha_composite(flash)
    arr = np.asarray(frame.convert("RGB"), np.float32)
    effects.apply_grain(arr, frame_index)
    if fade > 0:
        arr *= (1.0 - fade)
    effects.apply_vignette(arr)
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB")


_CTX: dict = {}


# ------------------------------------------------------------ video out -----
def render_video(tl, scale: float, out: str) -> dict:
    os.makedirs(os.path.dirname(out), exist_ok=True)
    w, h = round(W_REF * scale), round(H_REF * scale)
    silent = out.replace(".mp4", ".silent.mp4")
    fps, n = tl["meta"]["fps"], tl["meta"]["frames"]
    cmd = [
        imageio_ffmpeg.get_ffmpeg_exe(), "-y",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps),
        "-i", "-", "-an", "-c:v", "libx264", "-profile:v", "high",
        "-pix_fmt", "yuv420p", "-r", str(fps), "-crf", "17" if scale == 1 else "15",
        "-preset", "medium", "-movflags", "+faststart", silent,
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)
    for f in range(n):
        img = render_frame(tl, f, scale)
        proc.stdin.write(np.asarray(img, np.uint8).tobytes())
        if f % 300 == 0:
            print(f"[render] {out}: frame {f}/{n}", flush=True)
    proc.stdin.close()
    proc.wait()
    print(f"[render] silent master ready: {silent}")
    # text layout log for R-VER-08/09
    for f in range(0, n, 7):
        render_frame  # no-op: log was already filled during render
    text_layout.flush_log()
    return {"silent": silent, "w": w, "h": h, "frames": n, "fps": fps}


def render_probe_frames(tl, frames, png: bool = False) -> None:
    """R-VER-13: render each probe twice, compare MD5 of PNG bytes."""
    os.makedirs("out/probes", exist_ok=True)
    for f in frames:
        digests = []
        for tag in ("a", "b"):
            img = render_frame(tl, f, 1.0)
            buf = io.BytesIO()
            img.save(buf, "PNG")
            data = buf.getvalue()
            digests.append(hashlib.md5(data).hexdigest())
            if png:
                with open(f"out/probes/frame_{f:04d}_{tag}.png", "wb") as fh:
                    fh.write(data)
        print(f"[probe] frame {f}: {digests[0]} == {digests[1]} ->",
              "IDENTICAL" if digests[0] == digests[1] else "MISMATCH")
