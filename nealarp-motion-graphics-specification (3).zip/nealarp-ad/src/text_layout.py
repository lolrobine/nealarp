"""R-TXT + R-VIS-12 — the ONLY place text is drawn. Everything is logged.

Fonts load by absolute path (R-STACK-05). Glyph coverage for Ä ä Ö ö Ü ü ß . , % m
is asserted at import-free call time (R-STACK-06). Auto-fit: width > 1440 ref px
-> reduce size in 4 px steps to a 64 px floor; every change logged (R-TXT-03).
"""
from __future__ import annotations
import json
import os
from PIL import Image, ImageDraw, ImageFont

from .palette import BLUE, ORANGE, WHITE, INK

FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
GLYPH_CHECK = "ÄäÖöÜüß.,%m"
TRACKING = 0.04  # em
MAX_W = 1440
MIN_SIZE = 64

# R-TXT-01 — exact strings; the renderer may draw these and only these.
REQUIRED_STRINGS = [
    "SPIELE UND ZEUG", "GELD AUSGEBEN", "DAS PASSWORT-SPIEL", "DIE TIEFSEE",
    "0 m", "1.000 m", "5.000 m", "11.034 m", "TEMPO", "ASTEROIDEN-WERFER",
    "100 MEGATONNEN", "PERFEKTER KREIS", "98 %", "LEBENSSTATISTIK",
    "HERZSCHLÄGE", "ATEMZÜGE", "SCHRITTE", "GRÖSSE DES WELTALLS",
    "nealarp", "BALD VERFÜGBAR", "AB 12. OKTOBER", "nealarp.vercel.app",
    "ERHÄLTLICH AB 12. OKTOBER",
]

# name -> (size, fill, anchor-cx, anchor-cy, mode)  — sizes in reference px
TEMPLATES = {
    "title_lower_third": dict(size=96, fill="gradient", cx=960, cy=880, anchor="baseline_baseline", glass=True),
    "title_opening":     dict(size=180, fill="gradient", cx=960, cy=540, anchor="center", glass=False),
    "counter_center":    dict(size=160, fill="white", cx=960, cy=520, anchor="center", glass=False),
    "claim_white":       dict(size=112, fill="white", cx=960, cy=540, anchor="center", glass=False),
    "claim_gradient":    dict(size=96, fill="gradient", cx=960, cy=540, anchor="center", glass=False),
    "url":               dict(size=72, fill="white", cx=960, cy=600, anchor="center", glass=False),
    "cta_button_label":  dict(size=44, fill="white", cx=960, cy=780, anchor="center", glass=False),
    # documented additions (see README §8):
    "panel_label":       dict(size=28, fill="white60", cx=None, cy=None, anchor="center", glass=False),
    "score_badge":       dict(size=160, fill="orange", cx=1480, cy=470, anchor="center", glass=False),
}

_fonts: dict[tuple[str, int], ImageFont.FreeTypeFont] = {}
_log: list[dict] = []
_sprite_cache: dict[tuple, tuple] = {}


def _font(size_ref: int, scale: float, mono: bool = False):
    path = FONT_MONO if mono else FONT_BOLD
    px = max(1, round(size_ref * scale))
    key = (path, px)
    if key not in _fonts:
        if not os.path.exists(path):
            raise FileNotFoundError(f"R-STACK-05: font missing at {path}")
        ft = ImageFont.truetype(path, px)
        missing = [g for g in GLYPH_CHECK if ft.getmask(g).getbbox() is None]
        if missing:
            raise RuntimeError(f"R-STACK-06: {path} lacks glyphs {missing}")
        _fonts[key] = ft
    return _fonts[key]


def _measure(s: str, size: int, scale: float, mono=False):
    """Width incl. +0.04 em tracking; returns (w, asc, desc)."""
    f = _font(size, scale, mono)
    asc, desc = f.getmetrics()
    w = 0.0
    for ch in s:
        w += f.getlength(ch) + TRACKING * size * scale
    return w - TRACKING * size * scale if s else 0.0, asc, desc


def _autofit(s: str, size: int, scale: float, layout: str) -> tuple[int, float]:
    w, asc, _ = _measure(s, size, scale)
    orig = size
    while w > MAX_W * scale and size > MIN_SIZE:
        size -= 4
        w, asc, _ = _measure(s, size, scale)
    if size != orig:
        _log.append({"event": "autofit", "layout": layout, "string": s,
                     "from": orig, "to": size})
    return size, w


def _gradient_image(w: int, h: int) -> Image.Image:
    """Linear blue->orange (R-VIS-03) horizontal gradient."""
    base = Image.new("RGB", (1, 1))
    grad = Image.linear_gradient("L").resize((max(w, 2), max(h, 2)))
    lut = []
    for i in range(256):
        f = i / 255
        lut.extend([int(BLUE[c] + (ORANGE[c] - BLUE[c]) * f) for c in range(3)])
    grad = grad.convert("RGB")
    grad.putpalette if False else None
    px = grad.load()
    for y in range(grad.height):
        for x in range(grad.width):
            f = x / max(grad.width - 1, 1)
            px[x, y] = tuple(int(BLUE[c] + (ORANGE[c] - BLUE[c]) * f) for c in range(3))
    return grad


def render_text_sprite(string: str, layout: str, scale: float,
                       overrides: dict | None = None) -> tuple[Image.Image, tuple, dict]:
    """Returns (sprite RGBA, bbox_ref_xywh, meta). Sprite content is cached."""
    cfg = dict(TEMPLATES[layout])
    ov = overrides or {}
    size = int(ov.get("size_px", cfg["size"]))
    fill = cfg["fill"]
    cache_key = (string, layout, size, round(scale, 3), fill)
    if cache_key in _sprite_cache:
        sprite, bbox, meta = _sprite_cache[cache_key]
    else:
        size, w = _autofit(string, size, scale, layout)
        f = _font(size, scale)
        asc, desc = f.getmetrics()
        h = asc + desc
        pad = int(48 * scale)  # glass padding horizontal
        img = Image.new("RGBA", (int(w) + 4, h + 4), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        # letter-by-letter so tracking is exact and per-letter color is possible
        mask = Image.new("L", img.size, 0)
        dm = ImageDraw.Draw(mask)
        x = 2.0
        for ch in string:
            dx = f.getlength(ch)
            dm.text((x, 2), ch, font=f, fill=255)
            x += dx + TRACKING * size * scale
        if fill == "gradient":
            color_img = _gradient_image(int(w) + 4, h + 4).convert("RGBA")
            img.paste(color_img, (0, 0), mask)
        else:
            color = {"white": WHITE, "orange": ORANGE, "white60": (255, 255, 255)}[fill]
            solid = Image.new("RGBA", img.size, color + ((153,) if fill == "white60" else (255,)))
            img.paste(solid, (0, 0), mask)
        # bbox in reference units (content only)
        cx = ov.get("center", [cfg["cx"], cfg["cy"]])[0] if cfg["cx"] is None else cfg["cx"]
        cy = ov.get("center", [cfg["cx"], cfg["cy"]])[1] if cfg["cy"] is None else cfg["cy"]
        if "y" in ov:
            cy = ov["y"]
        cx = ov.get("x", cx)
        bw, bh = (w + 4) / scale, (h + 4) / scale
        if cfg["anchor"] == "baseline_baseline":
            bbox = (cx - bw / 2, cy - (asc + 2) / scale, bw, bh)
        else:  # center
            bbox = (cx - bw / 2, cy - bh / 2, bw, bh)
        meta = {"size": size, "asc": asc / scale, "desc": desc / scale, "cx": cx, "cy": cy,
                "anchor": cfg["anchor"], "glass": cfg["glass"], "pad": pad}
        sprite = (img, tuple(bbox), meta)
        _sprite_cache[cache_key] = sprite
    return sprite


def draw_text(frame: Image.Image, entry: dict, scale: float, alpha: float = 1.0,
              glass_bg: Image.Image | None = None) -> tuple:
    """Composite one declared text entry. Returns its bounding box (ref units)."""
    sprite, bbox, meta = render_text_sprite(entry["string"], entry["layout"],
                                            scale, entry.get("props"))
    x, y, bw, bh = bbox
    s = scale
    lay = entry["layout"]
    if meta["glass"] and lay == "title_lower_third":
        pad_x, pad_y = 48 * s, 28 * s
        gx, gy = x * s - pad_x, y * s - pad_y + (meta["asc"]) * s * 0
        gw, gh = bw * s + 2 * pad_x, bh * s + 2 * pad_y - meta["desc"] * s * 0.5
        panel = Image.new("RGBA", frame.size, (0, 0, 0, 0))
        pd = ImageDraw.Draw(panel)
        pd.rounded_rectangle([gx, gy, gx + gw, gy + gh], radius=24 * s,
                             fill=(255, 255, 255, int(0.10 * 255 * alpha)),
                             outline=(255, 255, 255, int(0.25 * 255 * alpha)),
                             width=max(1, round(s)))
        frame.alpha_composite(panel)
    if alpha >= 0.999:
        frame.alpha_composite(sprite, (int(x * s), int(y * s)))
    else:
        faded = sprite.copy()
        faded.putalpha(faded.getchannel("A").point(lambda a: int(a * alpha)))
        frame.alpha_composite(faded, (int(x * s), int(y * s)))
    _log.append({"id": entry["id"], "string": entry["string"], "layout": lay,
                 "size": meta["size"], "bbox": [round(v, 2) for v in bbox],
                 "start": entry["start"], "end": entry["end"]})
    return bbox


def flush_log(path: str = "layout_log.json") -> None:
    # de-duplicate per (id, size): rendering logs once per first draw
    seen, out = set(), []
    for item in _log:
        key = (item.get("id"), item.get("size"), item.get("string"))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)


def log_for_tests() -> list[dict]:
    return list(_log)
