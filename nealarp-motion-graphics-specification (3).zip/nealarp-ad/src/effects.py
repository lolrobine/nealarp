"""Shared visual effects — each computed per spec, cached where static."""
from __future__ import annotations
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from .palette import INK, HAZE_CENTER, BLUE, ORANGE, WHITE
from . import rng

F = 900.0  # R-VIS-09 perspective focal length (reference px)
_cache: dict = {}


# ---------------------------------------------------------------- camera ----
def project(x: np.ndarray, y: np.ndarray, z: np.ndarray, cx=960.0, cy=540.0):
    """R-VIS-09: sx = cx + x * f / (f + z). z in [0, 2000]."""
    k = F / (F + np.clip(z, 0.0, 2000.0))
    return cx + x * k, cy + y * k, k


# ------------------------------------------------------------ static bg -----
def base_background(w: int, h: int) -> Image.Image:
    """R-VIS-01: near-black + radial haze to #0f172a at 40% opacity (once)."""
    key = ("haze", w, h)
    if key in _cache:
        return _cache[key].copy()
    yy, xx = np.mgrid[0:h, 0:w]
    d = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2)
    a = np.clip(1.0 - d, 0.0, 1.0) ** 1.6 * 0.40
    arr = np.empty((h, w, 3), np.float32)
    for c in range(3):
        arr[..., c] = INK[c] * (1 - a) + HAZE_CENTER[c] * a
    img = Image.fromarray(arr.astype(np.uint8), "RGB").convert("RGBA")
    _cache[key] = img
    return img.copy()


def grain_tile() -> np.ndarray:
    """R-VIS-07: one seeded 512x512 grayscale tile."""
    if "grain" not in _cache:
        r = rng.stream(70)
        _cache["grain"] = r.integers(0, 256, (512, 512), dtype=np.uint8)
    return _cache["grain"]


def apply_grain(arr: np.ndarray, frame_index: int) -> None:
    """Tile grain with a deterministic per-frame offset; opacity 3.5%."""
    tile = grain_tile()
    r = rng.stream(1000 + frame_index)
    ox, oy = int(r.integers(0, 512)), int(r.integers(0, 512))
    rolled = np.roll(np.roll(tile, oy, 0), ox, 1)
    h, w = arr.shape[:2]
    reps = np.tile(rolled, (h // 512 + 1, w // 512 + 1))[:h, :w].astype(np.float32)
    arr[..., :3] = arr[..., :3] * (1 - 0.035) + reps[..., None] * 0.035


def vignette_mask(w: int, h: int) -> np.ndarray:
    """R-VIS-08: 0% center -> 25% black at corners."""
    key = ("vig", w, h)
    if key not in _cache:
        yy, xx = np.mgrid[0:h, 0:w]
        d = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2)
        _cache[key] = 1.0 - 0.25 * np.clip((d - 0.35) / 0.75, 0, 1) ** 1.8
    return _cache[key]


def apply_vignette(arr: np.ndarray) -> None:
    arr[..., :3] *= vignette_mask(arr.shape[1], arr.shape[0])[..., None]


# ---------------------------------------------------------------- bloom -----
def bloom(img: Image.Image, scale: float) -> Image.Image:
    """R-VIS-05: bright-pass blur 24 ref px, additive at 35%. Quarter-scale blur."""
    small = img.convert("RGB").resize((img.width // 4, img.height // 4))
    arr = np.asarray(small, np.int16)
    bright = np.clip(arr - 140, 0, 255).astype(np.uint8)
    bi = Image.fromarray(bright).filter(ImageFilter.GaussianBlur(6))  # 24/4
    bi = bi.resize(img.size)
    out = np.asarray(img.convert("RGB"), np.int16) + (np.asarray(bi, np.int16) * 35) // 100
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).convert("RGBA")


# ---------------------------------------------------------------- flare -----
def anamorphic_flare(length: int, height: int, glow: int, scale: float) -> Image.Image:
    """R-VIS-05: 1400x6 streak + 120 px glow, blue-white core."""
    key = ("flare", round(scale, 3))
    if key in _cache:
        return _cache[key]
    L, G = int(length * scale), int(glow * scale)
    H = int(height * scale) + 2 * G
    img = Image.new("RGBA", (L + 2 * G, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = G  # left pad is glow
    # glow band
    for i in range(G, 0, -1):
        a = int(70 * (1 - i / G) ** 2)
        d.line([(cx, G + 3 - i), (cx + L, G + 3 - i)],
               fill=(BLUE[0], BLUE[1], BLUE[2], a), width=1)
        d.line([(cx, G + 3 + i), (cx + L, G + 3 + i)],
               fill=(ORANGE[0], ORANGE[1], ORANGE[2], a), width=1)
    # streak: white core fading at tips
    core = Image.new("L", (L, 1), 0)
    cpx = core.load()
    for x in range(L):
        f = 1.0 - abs(x / L - 0.5) * 2
        cpx[x, 0] = int(255 * f ** 1.6)
    core = core.resize((L, max(1, int(height * scale))))
    white_streak = Image.new("RGBA", (L, max(1, int(height * scale))), WHITE + (255,))
    img.paste(white_streak, (cx, G + 3 - max(1, int(height * scale)) // 2), core)
    _cache[key] = img
    return img


def draw_flare(frame: Image.Image, center, p: dict, t: float, scale: float,
               progress: float) -> None:
    fl = anamorphic_flare(p.get("length", 1400), p.get("height", 6),
                          p.get("glow", 120), scale)
    a = 1.0 - progress  # fade across its window
    if a < 1:
        fl = fl.copy()
        fl.putalpha(fl.getchannel("A").point(lambda q: int(q * a)))
    frame.alpha_composite(fl, (int(center[0] * scale - fl.width / 2),
                               int(center[1] * scale - fl.height / 2)))


def light_streaks(frame: Image.Image, count: int, t: float, drift: float,
                  scale: float, seed_tag: int) -> None:
    """R-VIS-05: horizontal streaks in blue and orange."""
    r = rng.stream(seed_tag)
    w, h = frame.size
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for i in range(count):
        y = r.uniform(0.08, 0.92) * h
        ln = r.uniform(0.15, 0.4) * w
        col = BLUE if i % 2 == 0 else ORANGE
        x0 = (((r.uniform(0, 1) + t * drift / max(w, 1)) % 1.3) - 0.15) * w
        a = int(r.uniform(18, 46))
        d.line([(x0, y), (x0 + ln, y)], fill=col + (a,), width=max(1, round(2 * scale)))
    frame.alpha_composite(layer.filter(ImageFilter.GaussianBlur(1.5 * scale)))
