"""R-AUD-01 — German voiceover chain with an honest neural gate.

Priority: edge-tts (de-DE neural, network) -> piper (offline neural) ->
espeak-ng (PLACEHOLDER; allowed for the 1080p test ONLY).
Writes audio/vo/vo_XX.wav (48 kHz mono, normalized to -18 dBFS RMS) and
vo_status.json {engine, real_neural} — the 4K gate reads `real_neural`.
"""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import numpy as np
import imageio_ffmpeg

from .audio_synth import SR, N

STATUS = "vo_status.json"


def _rms_normalize(x: np.ndarray, target_db: float = -18.0) -> np.ndarray:
    rms = np.sqrt(np.mean(x ** 2)) or 1.0
    return x * (10 ** (target_db / 20) / rms)


def _decode_to_mono(path: str) -> np.ndarray:
    """Decode any media file to 48 kHz mono float32 via ffmpeg."""
    raw = subprocess.run(
        [imageio_ffmpeg.get_ffmpeg_exe(), "-v", "quiet", "-i", path,
         "-f", "f32le", "-ac", "1", "-ar", str(SR), "-"],
        capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).copy()


def _try_edge(line_id: str, text: str, out_mp3: str) -> bool:
    try:
        import edge_tts  # type: ignore
        import asyncio
        voice = "de-DE-ConradNeural"
        async def go():
            await edge_tts.Communicate(text, voice).save(out_mp3)
        asyncio.run(go())
        return os.path.exists(out_mp3) and os.path.getsize(out_mp3) > 1000
    except Exception:
        return False


def _try_piper(line_id: str, text: str, out_wav: str) -> bool:
    bin_ = shutil.which("piper")
    model = os.environ.get("PIPER_DE_MODEL", "")
    if not bin_ or not model or not os.path.exists(model):
        return False
    try:
        subprocess.run([bin_, "--model", model, "--output_file", out_wav],
                       input=text.encode(), check=True, capture_output=True)
        return os.path.exists(out_wav)
    except Exception:
        return False


def _try_espeak(line_id: str, text: str, out_wav: str) -> bool:
    bin_ = shutil.which("espeak-ng") or shutil.which("espeak")
    if not bin_:
        return False
    try:
        subprocess.run([bin_, "-v", "de", "-s", "150", "-w", out_wav, text],
                       check=True, capture_output=True)
        return os.path.exists(out_wav)
    except Exception:
        return False


def build_all(tl) -> dict:
    os.makedirs("audio/vo", exist_ok=True)
    engines = []
    for line_id, _at in tl["_audio_index"]["vo"]:
        text = next(l["string"] for s in tl["scenes"] for l in s["audio"]["vo"]
                    if l["id"] == line_id)
        wav = f"audio/vo/{line_id}.wav"
        if _try_edge(line_id, text, wav + ".mp3"):
            _write_wav(_rms_normalize(_decode_to_mono(wav + ".mp3")), wav)
            engines.append((line_id, "edge-tts", True))
        elif _try_piper(line_id, text, wav):
            _write_wav(_rms_normalize(_decode_to_mono(wav)), wav)
            engines.append((line_id, "piper", True))
        elif _try_espeak(line_id, text, wav + ".raw.wav"):
            _write_wav(_rms_normalize(_decode_to_mono(wav + ".raw.wav")), wav)
            engines.append((line_id, "espeak-ng PLACEHOLDER", False))
        else:
            _write_wav(np.zeros(int(1.2 * SR), np.float32), wav)
            engines.append((line_id, "SILENT (no tts available)", False))
    real = all(e[2] for e in engines) and len(engines) == len(tl["_audio_index"]["vo"])
    status = {"engine": engines[0][1] if engines else "none",
              "real_neural": real, "lines": engines}
    with open(STATUS, "w") as fh:
        json.dump(status, fh, indent=2, ensure_ascii=False)
    return status


def read_status() -> dict:
    if os.path.exists(STATUS):
        with open(STATUS) as fh:
            return json.load(fh)
    return {"real_neural": False, "engine": "not-built"}


def _write_wav(x: np.ndarray, path: str) -> None:
    import wave
    pcm = np.clip(x, -1, 1)
    pcm = (pcm * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def vo_bus_and_duck(tl) -> tuple[np.ndarray, np.ndarray]:
    """Sum VO lines at their times; return (bus, duck_curve 0/1)."""
    bus = np.zeros(N)
    duck = np.zeros(N)
    for line_id, at in tl["_audio_index"]["vo"]:
        path = f"audio/vo/{line_id}.wav"
        if not os.path.exists(path):
            continue
        x = _decode_to_mono(path)
        i = int(at * SR)
        j = min(N, i + len(x))
        bus[i:j] += x[:j - i]
        pad = int(0.25 * SR)
        duck[max(0, i - pad):min(N, j + pad)] = 1.0
    # smooth the duck curve
    k = np.hanning(int(0.1 * SR))
    k /= k.sum() or 1
    duck = np.clip(np.convolve(duck, k, "same") * 3, 0, 1)
    return bus, duck
