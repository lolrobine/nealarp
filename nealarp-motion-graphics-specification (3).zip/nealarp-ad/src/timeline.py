"""Timeline loader + validator (R-TIME-02, R-TIME-04).

Guarantees:
- acts are exactly 0-8 / 8-32 (8x3) / 32-44 / 44-60
- every element and text has start <= end, no element outside its scene
- nothing animates outside a declared window (painters receive only elements)
"""
from __future__ import annotations
import yaml

ACTS = [(0.0, 8.0), (8.0, 32.0), (32.0, 44.0), (44.0, 60.0)]
FPS = 60


class TimelineError(ValueError):
    pass


def _check_window(kind: str, ident: str, s: float, e: float, ss: float, se: float) -> None:
    if s is None or e is None:
        raise TimelineError(f"{kind} '{ident}' missing start/end (R-TIME-04)")
    if s > e:
        raise TimelineError(f"{kind} '{ident}': start {s} > end {e}")
    if s < ss - 1e-9 or e > se + 1e-9:
        raise TimelineError(f"{kind} '{ident}' [{s},{e}] outside scene window [{ss},{se}]")


def load_timeline(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    meta = data["meta"]
    assert meta["fps"] == FPS and meta["duration"] == 60.0 and meta["frames"] == 3600

    scenes = data["scenes"]
    bounds = [(s["start"], s["end"]) for s in scenes]
    expected = [(0.0, 8.0)] + [(8.0 + 3 * i, 11.0 + 3 * i) for i in range(8)] + [(32.0, 44.0), (44.0, 60.0)]
    if bounds != expected:
        raise TimelineError(f"R-TIME-02 violated: scene bounds {bounds} != {expected}")

    sfx_seen: list[tuple[str, float]] = []
    vo_seen: list[tuple[str, float]] = []
    for s in scenes:
        ss, se = s["start"], s["end"]
        for el in s.get("elements", []):
            _check_window("element", el["id"], el.get("start"), el.get("end"), ss, se)
        for tx in s.get("text", []):
            _check_window("text", tx["id"], tx.get("start"), tx.get("end"), ss, se)
        au = s.get("audio", {})
        for fx in au.get("sfx", []):
            sfx_seen.append((fx["id"], float(fx["at"])))
        for line in au.get("vo", []):
            vo_seen.append((line["id"], float(line["at"])))

    # voiceover lines must not overlap (validation helper for R-VER-11);
    # durations are filled in after vo.py synthesis.
    data["_audio_index"] = {"sfx": sfx_seen, "vo": vo_seen}
    return data


def active(items: list[dict], t: float) -> list[dict]:
    return [el for el in items if el["start"] <= t <= el["end"]]
