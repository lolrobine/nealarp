"""R-AUD-04 — bus sum, VO ducking, two-pass loudnorm to -14 LUFS / -1 dBTP.
Muxes the mix into the silent video master and prints ebur128 verification.
"""
from __future__ import annotations
import json
import os
import subprocess
import numpy as np
import imageio_ffmpeg

from . import audio_synth, vo

SR = audio_synth.SR
FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()


def _write_wav_stereo(x: np.ndarray, path: str) -> None:
    import wave
    x = np.clip(x, -1, 1)
    right = np.roll(x, int(0.0003 * SR))           # slight decorrelation
    pcm = np.empty((len(x), 2), np.float32)
    pcm[:, 0] = x
    pcm[:, 1] = right
    data = (pcm * 32767).astype(np.int16)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


def build_mix(tl) -> str:
    vo_status = vo.build_all(tl)
    print(f"[vo] engine: {vo_status['engine']} (real_neural={vo_status['real_neural']})")
    music = audio_synth.render_music()
    sfx = audio_synth.render_sfx_bus(tl)
    vob, duck = vo.vo_bus_and_duck(tl)
    # duck music by 6 dB wherever VO plays (R-AUD-02)
    music *= (1.0 - duck) + duck * (10 ** (-6 / 20))
    mix = music + sfx + vob * 0.95
    # honesty: hard silence after 60.0 s is guaranteed by fixed length N.
    pre = "audio/render/mix_pre.wav"
    _write_wav_stereo(mix, pre)
    return pre


def loudnorm_two_pass(pre: str, final: str) -> dict:
    p1 = subprocess.run(
        [FFMPEG, "-y", "-i", pre, "-af",
         "loudnorm=I=-14:TP=-1.0:LRA=11:print_format=json", "-f", "null", "-"],
        capture_output=True, text=True)
    tail = p1.stderr[p1.stderr.rfind("{"):p1.stderr.rfind("}") + 1]
    measured = json.loads(tail)
    af = (
        "loudnorm=I=-14:TP=-1.0:LRA=11:linear=true:"
        f"measured_I={measured['input_i']}:measured_TP={measured['input_tp']}:"
        f"measured_LRA={measured['input_lra']}:measured_thresh={measured['input_thresh']}:"
        f"offset={measured['target_offset']}"
    )
    subprocess.run([FFMPEG, "-y", "-i", pre, "-af", af, "-ar", "48000",
                    "-ac", "2", "-c:a", "pcm_s16le", final], check=True,
                   capture_output=True)
    # verification readout (R-VER-05 evidence)
    p3 = subprocess.run([FFMPEG, "-i", final, "-af", "ebur128=peak=true",
                         "-f", "null", "-"], capture_output=True, text=True)
    print("[loudnorm] post-mix analysis:\n" + p3.stderr[-1200:])
    return measured


def mux(silent: str, wav: str, out: str) -> None:
    subprocess.run(
        [FFMPEG, "-y", "-i", silent, "-i", wav, "-map", "0:v:0", "-map", "1:a:0",
         "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
         "-shortest", "-movflags", "+faststart", out],
        check=True, capture_output=True)
    print(f"[mux] wrote {out}")


def rebuild_and_mux(tl, test_only: bool = True) -> None:
    pre = build_mix(tl)
    final_wav = "audio/render/mix_final.wav"
    loudnorm_two_pass(pre, final_wav)
    mux("out/nealarp-ad-1080p-test.silent.mp4", final_wav, "out/nealarp-ad-1080p-test.mp4")
    if not test_only and os.path.exists("out/nealarp-ad-2160p60-final.silent.mp4"):
        mux("out/nealarp-ad-2160p60-final.silent.mp4", final_wav,
            "out/nealarp-ad-2160p60-final.mp4")
