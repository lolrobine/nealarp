"""R-AUD-02 / R-AUD-03 — all sound is synthesized here. 48 kHz float32 mono.
No samples, no licenses. Peak levels are the spec's dBFS values.
"""
from __future__ import annotations
import numpy as np

SR = 48000
DURATION = 60.0
N = int(SR * DURATION)


def _db(db: float) -> float:
    return 10 ** (db / 20.0)


def _place(bus: np.ndarray, at: float, sig: np.ndarray) -> None:
    i = int(at * SR)
    j = min(N, i + len(sig))
    if j > i:
        bus[i:j] += sig[: j - i]


def _norm_peak(sig: np.ndarray, peak_db: float) -> np.ndarray:
    m = np.max(np.abs(sig)) or 1.0
    return sig * (_db(peak_db) / m)


def _sweep(f0: float, f1: float, dur: float) -> np.ndarray:
    n = int(dur * SR)
    t = np.arange(n) / SR
    phase = 2 * np.pi * (f0 * t + (f1 - f0) * t * t / (2 * dur))
    return np.sin(phase)


def _noise(n: int, rng: np.random.Generator, brown=False) -> np.ndarray:
    x = rng.standard_normal(n)
    if brown:
        x = np.cumsum(x)
        x = x / (np.max(np.abs(x)) or 1.0)
    return x


def _bandpass(x: np.ndarray, lo: float, hi: float) -> np.ndarray:
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    X[(f < lo) | (f > hi)] = 0
    return np.fft.irfft(X, len(x))


def _lowpass_1pole(x: np.ndarray, fc: float) -> np.ndarray:
    a = 1 - np.exp(-2 * np.pi * fc / SR)
    y = np.empty_like(x)
    acc = 0.0
    for i in range(len(x)):
        acc += a * (x[i] - acc)
        y[i] = acc
    return y


def _exp_env(n: int, decay: float) -> np.ndarray:
    t = np.arange(n) / SR
    return np.exp(-t / max(decay, 1e-4))


# ----------------------------------------------------------- sfx recipes ----
def sfx_pop(r):    return _norm_peak(_sweep(1200, 600, .080) * _exp_env(int(.08 * SR), .03) +
                                     np.concatenate([_noise(int(.005 * SR), r), np.zeros(int(.075 * SR))]) * .6, -6)

def sfx_click(r):
    n = int(.029 * SR)
    return _norm_peak(_bandpass(_noise(n, r), 2000, 4000) * _exp_env(n, .007), -8)

def sfx_coin_clink(r):
    dt = 1 + r.uniform(-.03, .03, 2)
    n = int(.3 * SR)
    t = np.arange(n) / SR
    return _norm_peak((np.sin(2 * np.pi * 3000 * dt[0] * t) + .8 * np.sin(2 * np.pi * 4500 * dt[1] * t)) *
                      _exp_env(n, .09), -10)

def sfx_lock_clunk(r):
    body = _sweep(90, 55, .18) * _exp_env(int(.18 * SR), .06)
    click = sfx_click(r)
    out = np.zeros(max(len(body), len(click)))
    out[:len(body)] += body
    out[:len(click)] += click * .8
    return _norm_peak(out, -6)

def sfx_bubble(r):
    dur = r.uniform(.06, .12)
    n = int(dur * SR)
    env = np.sin(np.pi * np.arange(n) / n) ** 0.7
    return _norm_peak(_sweep(300, 900, dur) * env, -14)

def sfx_whirr(r, dur=3.0):
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for k in range(8):
        det = 1 + (k - 4) * .006
        out += np.sin(2 * np.pi * (200 * det * t + (1200 - 200) * det * t * t / (2 * dur))) / 8
    env = np.clip(np.arange(n) / (0.25 * SR), 0, 1) * np.clip((n - np.arange(n)) / (0.4 * SR), 0, 1)
    return _norm_peak(out * env, -12)

def sfx_boom(r):
    n1 = int(1.2 * SR)
    n2 = int(1.5 * SR)
    t = np.arange(n1) / SR
    tone = np.sin(2 * np.pi * 60 * t) * _exp_env(n1, .35)
    brown = _lowpass_1pole(_noise(n2, r, brown=True), 600) * _exp_env(n2, .5)
    out = np.zeros(n2)
    out[:n1] += tone
    out += brown * .8
    return _norm_peak(out, -4)

def sfx_pen_draw(r):
    n = int(1.2 * SR)
    t = np.arange(n) / SR
    am = 0.6 + 0.4 * np.sin(2 * np.pi * 18 * t)
    return _norm_peak(_bandpass(_noise(n, r), 2000, 5000) * am, -18)

def sfx_heartbeat(r):
    n = int(.68 * SR)
    out = np.zeros(n)
    for at in (0.0, 0.3):
        m = int(.12 * SR)
        t = np.arange(m) / SR
        thump = np.sin(2 * np.pi * 55 * t) * _exp_env(m, .04)
        i = int(at * SR)
        out[i:i + m] += thump
    return _norm_peak(out, -8)

def sfx_whoosh_zoom(r):
    n = int(1.2 * SR)
    t = np.arange(n) / SR / 1.2
    x = _noise(n, r)
    # moving bandpass center 300 -> 3000
    seg = 2048
    out = np.zeros(n)
    for start in range(0, n - seg, seg // 2):
        f = (start / n)
        c = 300 + (3000 - 300) * f
        out[start:start + seg] += _bandpass(x[start:start + seg], max(60, c - 500), c + 500) * np.hanning(seg)
    env = np.sin(np.pi * np.clip(np.arange(n) / n, 0, 1)) ** 1.2
    return _norm_peak(out * env, -10)

def sfx_bass_drop(r):
    n = int(1.5 * SR)
    return _norm_peak(_sweep(120, 35, 1.5) * _exp_env(n, .55), -4)

def sfx_bass_hit(r):
    n1 = int(.8 * SR)
    t = np.arange(n1) / SR
    body = np.sin(2 * np.pi * 45 * t) * _exp_env(n1, .25)
    tr = np.zeros(int(.02 * SR))
    tr[:int(.004 * SR)] = 1
    out = np.concatenate([tr, np.zeros(n1 - len(tr))]) * .5 + body
    # echo: delay 0.25 s, feedback 0.3 (R-AUD-02 echo spec re-used)
    echo = np.zeros(n1 + int(2 * .25 * SR))
    echo[:n1] = out
    d = int(.25 * SR)
    echo[d:d + n1] += out * .3
    echo[2 * d:2 * d + n1] += out * .09
    return _norm_peak(echo, -3)


SFX = {name: fn for name, fn in list(globals().items()) if name.startswith("sfx_")}


# ---------------------------------------------------------------- music -----
def render_music(rng_seed: int = 7) -> np.ndarray:
    """R-AUD-02: 120 BPM. Deep bass drop at 0; cold arpeggios warming toward
    orange harmonics by 32 s; risers 32-44; bass hit at 44 with echo; fade by 60."""
    r = np.random.default_rng(7)
    music = np.zeros(N)
    bpm_step = 60.0 / 120 / 4            # 16th at 120 BPM
    notes = [110.0, 130.81, 164.81, 220.0, 261.63, 329.63]   # Am add color
    step_n = int(bpm_step * SR)

    def arp_note(f0, n, warmth):
        t = np.arange(n) / SR
        out = np.zeros(n)
        for k in range(8):                       # 8 detuned sines
            det = 1 + (k - 4) * 0.0018
            out += np.sin(2 * np.pi * f0 * det * t) / 8
        out += warmth * 0.25 * np.sin(2 * np.pi * f0 * 2 * t)   # harmonics warm-up
        out += warmth * 0.15 * np.sin(2 * np.pi * f0 * 3 * t)
        env = _exp_env(n, .18)
        return out * env

    total_steps = int(DURATION / bpm_step)
    for i in range(total_steps):
        t = i * bpm_step
        if t >= 44.0:
            continue                                # post-hit: only fading tails
        warmth = np.clip((t - 8.0) / 24.0, 0, 1)    # colder -> warmer to 32 s
        f0 = notes[(i * 3 + (i // 8) % 3) % len(notes)] * (1 if i % 8 < 4 else 2)
        note = arp_note(f0, step_n, warmth)
        start = int(t * SR)
        j = min(N, start + step_n)
        music[start:j] += note[:j - start] * (0.16 if t < 8 else 0.2)

    music[:N] = _lowpass_1pole(music, 2000)

    # bass drop at 0.0
    _place(music, 0.0, sfx_bass_drop(r) * .9)
    # risers 32-44: two noise sweeps
    for at, dur in ((32.0, 6.0), (38.0, 6.0)):
        n = int(dur * SR)
        sweep = _bandpass(r.standard_normal(n), 400, 6000)
        env = (np.arange(n) / n) ** 2
        sig = _norm_peak(sweep * env, -16)
        _place(music, at, sig)
    # confident bass hit at 44 with echo
    _place(music, 44.0, sfx_bass_hit(r))
    # pad tail 44 -> 60 fading
    n = int(16 * SR)
    t = np.arange(n) / SR
    pad = (np.sin(2 * np.pi * 110 * t) + .5 * np.sin(2 * np.pi * 220 * t)) * \
          np.clip((1 - t / 16), 0, 1) ** 1.5 * 0.05
    _place(music, 44.0, pad)
    # final fade to silence by 60.000
    fade = np.ones(N)
    tail = int(1.2 * SR)
    fade[-tail:] = np.linspace(1, 0, tail)
    return music * fade


def render_sfx_bus(tl) -> np.ndarray:
    bus = np.zeros(N)
    r = np.random.default_rng(7)
    for ident, at in tl["_audio_index"]["sfx"]:
        fn = SFX.get(ident) or SFX.get("sfx_" + ident.replace("sfx_", ""))
        if fn is None:
            raise KeyError(f"unknown sfx recipe: {ident}")
        sig = fn(r) if ident != "sfx_whirr" else fn(r, dur=3.0)
        _place(bus, at, sig)
    return bus
