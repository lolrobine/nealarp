// Verification dashboards: what can honestly be proven in the browser is
// measured LIVE; what needs a shell is shown as BLOCKED with the unblock path.
import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import {
  CheckCircle2, Ban, CircleDashed, Palette, Activity, Type, Timer,
  FileVideo, Lock, AudioLines, Boxes, ClipboardList,
} from "lucide-react";
import { TEXTS, SCENES, SFX, VO, FRAMES } from "../ad/timeline";
import { layoutLog } from "../ad/engine";
import { playerStore } from "../ad/store";

// ------------------------------------------------------------- primitives --
function Pill({ ok, label }: { ok: boolean | null; label: string }) {
  const cls =
    ok === null
      ? "border-white/20 text-white/60"
      : ok
        ? "border-[#3b82f6]/60 text-[#3b82f6]"
        : "border-[#f97316] text-[#f97316]";
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[9px] tracking-[0.15em] ${cls}`}>
      {ok === null ? <CircleDashed className="h-3 w-3" /> : ok ? <CheckCircle2 className="h-3 w-3" /> : <Ban className="h-3 w-3" />}
      {label}
    </span>
  );
}

function Section({ icon: Icon, kicker, title, children }: {
  icon: React.ComponentType<{ className?: string }>;
  kicker: string; title: string; children: React.ReactNode;
}) {
  return (
    <section className="border-t border-white/10 py-16 md:py-24">
      <div className="mb-3 flex items-center gap-2.5 font-mono text-[10px] tracking-[0.3em] text-[#f97316]">
        <Icon className="h-4 w-4" />
        {kicker}
      </div>
      <h2 className="mb-10 font-display text-4xl uppercase leading-[0.95] md:text-6xl">{title}</h2>
      {children}
    </section>
  );
}

// ----------------------------------------------------------- live checks ---
interface Sample {
  sat: number;
  bad: number;
  lastDiff: number;
  zeroDiffWindows: number;
  windows: number;
}

export function LiveChecks({ getCanvas }: { getCanvas: () => HTMLCanvasElement | null }) {
  const snap = useSyncExternalStore(playerStore.subscribe, playerStore.getSnapshot);
  const [agg, setAgg] = useState<Sample>({ sat: 0, bad: 0, lastDiff: 0, zeroDiffWindows: 0, windows: 0 });
  const prev = useRef<Float32Array | null>(null);

  useEffect(() => {
    const off = document.createElement("canvas");
    off.width = 160;
    off.height = 90;
    const g = off.getContext("2d", { willReadFrequently: true })!;
    const id = window.setInterval(() => {
      const c = getCanvas();
      if (!c) return;
      g.drawImage(c, 0, 0, 160, 90);
      const d = g.getImageData(0, 0, 160, 90).data;
      let sat = 0, bad = 0, diff = 0;
      const lum = new Float32Array(160 * 90);
      for (let i = 0; i < d.length; i += 4) {
        const r = d[i] / 255, gg = d[i + 1] / 255, b = d[i + 2] / 255;
        const mx = Math.max(r, gg, b), mn = Math.min(r, gg, b);
        const v = mx, s = mx === 0 ? 0 : (mx - mn) / mx;
        lum[i / 4] = v;
        if (s > 0.35 && v > 0.3) {
          sat++;
          const dl = mx - mn;
          let h = 0;
          if (dl !== 0) {
            if (mx === r) h = ((gg - b) / dl) % 6;
            else if (mx === gg) h = (b - r) / dl + 2;
            else h = (r - gg) / dl + 4;
            h *= 60;
            if (h < 0) h += 360;
          }
          const ok = (h >= 195 && h <= 235) || (h >= 15 && h <= 35);
          if (!ok) bad++;
        }
      }
      if (prev.current) {
        for (let i = 0; i < lum.length; i++) diff += Math.abs(lum[i] - prev.current[i]);
        diff /= lum.length;
      }
      prev.current = lum;
      setAgg((a) => ({
        sat: a.sat + sat,
        bad: a.bad + bad,
        lastDiff: diff,
        windows: a.windows + 1,
        zeroDiffWindows: a.zeroDiffWindows + (prev.current && diff === 0 ? 1 : 0),
      }));
    }, 500);
    return () => clearInterval(id);
  }, [getCanvas]);

  const ratio = agg.sat ? agg.bad / agg.sat : 0;
  const paletteOk = agg.sat === 0 ? null : ratio <= 0.01;
  const motionOk = agg.windows < 2 ? null : agg.zeroDiffWindows === 0;

  const rows: { id: string; de: string; pill: React.ReactNode; note: string }[] = [
    { id: "R-VER-06", de: "Palette (HSV-Raster alle 0.5 s, live)",
      pill: <Pill ok={paletteOk} label={agg.sat === 0 ? "WARTE AUF FRAMES" : `VERSTÖSSE ${(ratio * 100).toFixed(3)} % / LIMIT 1 %`} />,
      note: `${agg.sat.toLocaleString("de-DE")} gesättigte Pixel geprüft · Farbton muss 195–235° (Blau) oder 15–35° (Orange) sein.` },
    { id: "R-VER-10", de: "Bewegung (Frame-Differenz)",
      pill: <Pill ok={motionOk} label={agg.windows < 2 ? "WARTE" : agg.zeroDiffWindows === 0 ? "ÜBERALL BEWEGUNG" : "HOLDS GEFUNDEN"} />,
      note: `Fenster geprüft: ${agg.windows} · letzte mittlere Differenz: ${agg.lastDiff.toFixed(2)} · hold_frames ist leer, also muss überall Bewegung sein.` },
    { id: "R-VER-08", de: "Text-Safe-Area (Layout-Log)",
      pill: <Pill ok={layoutLog.length === 0 ? null : layoutLog.every((e) => e.safe)} label={layoutLog.length ? `${layoutLog.filter((e) => e.safe).length}/${TEXTS.length} IM SAFE AREA` : "WARTE"} />,
      note: "96 px links/rechts, 54 px oben/unten — jede Bounding Box des Layout-Logs geprüft." },
    { id: "R-VER-09", de: "Text-Vollständigkeit (23 Strings)",
      pill: <Pill ok={TEXTS.every((t) => layoutLog.some((l) => l.string === t.string))} label={`${layoutLog.length}/${TEXTS.length} GELOGGT`} />,
      note: "Jeder String läuft durch das Layout-System (R-TXT-02). OCR via tesseract läuft separat in pytest." },
    { id: "R-VER-01/02", de: "Dauer / Frames / Auflösung",
      pill: <Pill ok label={`${FRAMES} FRAMES · 1920×1080 · 60 FPS`} />,
      note: "Per Konstruktion: t = frame/60, harte Klammer bei 60.000 s. ffprobe-Nachweis läuft in pytest (BLOCKED hier)." },
  ];

  return (
    <div className="space-y-3">
      {rows.map((r) => (
        <div key={r.id} className="grid gap-2 rounded-lg border border-white/10 bg-white/[0.02] p-4 md:grid-cols-12 md:items-center">
          <div className="font-mono text-[10px] tracking-[0.2em] text-[#3b82f6] md:col-span-2">{r.id}</div>
          <div className="text-sm font-medium md:col-span-4">{r.de}</div>
          <div className="md:col-span-3">{r.pill}</div>
          <div className="font-mono text-[10px] leading-relaxed text-white/50 md:col-span-3">{r.note}</div>
        </div>
      ))}
      <p className="pt-2 font-mono text-[10px] leading-relaxed text-white/40">
        Hier läuft die Canvas-Variante derselben Timeline, nicht der Python-Renderer.
        Zeit = {snap.t.toFixed(2)} s · aktive Layouts: {layoutLog.length}. Die MP4-Nachweise
        (Codec, Lautheit, OCR, MD5-Doppelrender) gehören zur Shell-Suite unten.
      </p>
    </div>
  );
}

// --------------------------------------------------------- timeline strip --
export function TimelineStrip() {
  const snap = useSyncExternalStore(playerStore.subscribe, playerStore.getSnapshot);
  return (
    <div>
      <div className="relative h-24 overflow-hidden rounded-lg border border-white/10">
        {SCENES.map((s) => {
          const left = (s.start / 60) * 100;
          const width = ((s.end - s.start) / 60) * 100;
          const isActive = snap.t >= s.start && snap.t < s.end;
          return (
            <div
              key={s.id}
              className="absolute top-0 flex h-full flex-col justify-center border-r border-white/10 px-2"
              style={{ left: `${left}%`, width: `${width}%`, background: isActive ? "rgba(249,115,22,0.14)" : "rgba(255,255,255,0.02)" }}
            >
              <span className={`truncate font-mono text-[8px] tracking-[0.1em] ${isActive ? "text-[#f97316]" : "text-white/40"}`} style={{ fontSize: width < 6 ? 7 : 9 }}>
                {s.de}
              </span>
              <span className="font-mono text-[8px] text-white/30">{s.start}–{s.end}s</span>
            </div>
          );
        })}
        <div
          className="absolute top-0 h-full w-px bg-[#3b82f6] transition-[left] duration-100"
          style={{ left: `${(snap.t / 60) * 100}%` }}
        />
      </div>
      <div className="mt-2 flex justify-between font-mono text-[9px] tracking-[0.2em] text-white/40">
        <span>0.000</span><span>8 AKT-I-ENDE</span><span>32 AKT-III</span><span>44 AKT-IV</span><span>60.000</span>
      </div>
    </div>
  );
}

// ------------------------------------------------------------- audio spec --
export function AudioSpec() {
  return (
    <div className="grid gap-px overflow-hidden rounded-lg border border-white/10 bg-white/10 md:grid-cols-2">
      <div className="bg-black p-5">
        <div className="mb-4 flex items-center gap-2 font-mono text-[10px] tracking-[0.25em] text-[#3b82f6]">
          <AudioLines className="h-4 w-4" /> MUSIK — 120 BPM, GENERATIV
        </div>
        {[
          ["0.0–8.0 s", "Bass-Drop (120→35 Hz), kalte Arpeggios: 8 verstimmte Sines, Lowpass 2 kHz, Riser"],
          ["8.0–32.0 s", "Arpeggios laufen weiter; Obertongewichtung → warmes Orange bis 32 s"],
          ["32.0–44.0 s", "Elektronischer Swell + zwei Riser Richtung Crescendo"],
          ["44.0–60.0 s", "Bass-Hit 45 Hz + Echo (0.25 s / 0.3), Fade zu Stille bis 60.000 s"],
        ].map(([t, d]) => (
          <div key={t} className="flex gap-4 border-t border-white/10 py-2.5 first:border-0">
            <span className="w-24 shrink-0 font-mono text-[10px] text-[#f97316]">{t}</span>
            <span className="text-xs leading-relaxed text-white/70">{d}</span>
          </div>
        ))}
        <div className="mt-3 rounded border border-white/10 p-3 font-mono text-[10px] leading-relaxed text-white/50">
          Ducking: −6 dB unter jeder VO-Zeile · 2 Punk loudnorm −14 LUFS / −1 dBTP (zweipassig, ffmpeg)
        </div>
      </div>
      <div className="bg-black p-5">
        <div className="mb-4 flex items-center gap-2 font-mono text-[10px] tracking-[0.25em] text-[#f97316]">
          <Timer className="h-4 w-4" /> {SFX.length} SFX-EVENTS · {VO.length} VO-ZEILEN (DEUTSCH)
        </div>
        <div className="max-h-64 overflow-y-auto pr-2">
          {[...SFX.map((e) => ({ at: e.at, de: `sfx_${e.id.toUpperCase()}` })),
            ...VO.map((v, i) => ({ at: v.at, de: `VO ${i + 1} — „${v.de}“` }))]
            .sort((a, b) => a.at - b.at)
            .map((e, i) => (
              <div key={i} className="flex gap-4 border-t border-white/10 py-1.5 first:border-0">
                <span className="w-16 shrink-0 font-mono text-[10px] tabular-nums text-[#3b82f6]">
                  {e.at.toFixed(3).padStart(6, "0")}s
                </span>
                <span className="truncate font-mono text-[10px] text-white/60">{e.de}</span>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

// -------------------------------------------------------------- text grid --
export function TextGrid() {
  const snap = useSyncExternalStore(playerStore.subscribe, playerStore.getSnapshot);
  void snap;
  const autofits = layoutLog.filter((l) => l.autofitFrom);
  return (
    <div>
      <div className="grid gap-px overflow-hidden rounded-lg border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
        {TEXTS.map((t2) => {
          const log = layoutLog.find((l) => l.id === t2.id);
          return (
            <div key={t2.id} className="bg-black p-4">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[9px] tracking-[0.2em] text-[#3b82f6]">{t2.layout}</span>
                <span className="font-mono text-[9px] text-white/40">{t2.start}–{t2.end}s</span>
              </div>
              <div className="mt-2 font-display text-lg uppercase leading-tight text-white">{t2.string}</div>
              <div className="mt-2 font-mono text-[9px] text-white/40">
                {log
                  ? `${log.size}px · [${log.bbox.map((v) => Math.round(v)).join(", ")}] ${log.safe ? "✓ safe" : "✗ UNSAFE"}`
                  : "noch nicht gerendert"}
                {log?.autofitFrom ? ` · AUTO-FIT ${log.autofitFrom}→${log.size}` : ""}
              </div>
            </div>
          );
        })}
      </div>
      <p className="mt-3 font-mono text-[10px] text-white/50">
        AUTO-FIT-Log: {autofits.length === 0 ? "noch keine Reduktion nötig" : autofits.map((a) => `${a.string}: ${a.autofitFrom}→${a.size}px`).join(" · ")}
        {" "}· Schwellwert 1440 px, Schritt −4 px, Minimum 64 px (R-TXT-03).
      </p>
    </div>
  );
}

// ------------------------------------------------------------ deliverables --
export function Deliverables() {
  const files = [
    { name: "nealarp-ad-1080p-test.mp4", spec: "1920×1080 · 60 fps · H.264 High · yuv420p · AAC 48 kHz · −14 LUFS / −1 dBTP", state: "BLOCKED — kein ffmpeg hier" },
    { name: "nealarp-ad-2160p60-final.mp4", spec: "3840×2160 · 60 fps · nativ bei Scale 2 gerendert — KEIN Upscale (R-GATE-04)", state: "BLOCKED — R-GATE-01/02/03" },
    { name: "timeline.yaml → beide Dateien", spec: "Ein Befehl: python render.py (R-OUT-06)", state: "DONE — Source steht" },
  ];
  return (
    <div className="space-y-3">
      {files.map((f) => (
        <div key={f.name} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-white/10 bg-white/[0.02] p-4">
          <div className="flex items-center gap-3">
            <FileVideo className="h-5 w-5 text-[#3b82f6]" />
            <div>
              <div className="font-mono text-sm">{f.name}</div>
              <div className="font-mono text-[10px] text-white/50">{f.spec}</div>
            </div>
          </div>
          <span className={`flex items-center gap-2 font-mono text-[10px] tracking-[0.15em] ${f.state.startsWith("DONE") ? "text-[#3b82f6]" : "text-[#f97316]"}`}>
            {f.state.startsWith("DONE") ? <CheckCircle2 className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
            {f.state}
          </span>
        </div>
      ))}
      <div className="rounded-lg border border-[#f97316]/40 bg-[#f97316]/5 p-4 font-mono text-[11px] leading-relaxed text-white/80">
        <span className="text-[#f97316]">R-GATE — FREIGABEPROTOKOLL:</span> Der 4K-Render startet nicht
        von allein. Er braucht (1) deine explizite Freigabe in einer Nachricht, (2) eine echte deutsche
        Neuralstimme (kein Platzhalter), (3) eine 4K-Zeitschätzung ≤ 6 h aus dem Testlauf.
      </div>
    </div>
  );
}

// ------------------------------------------------------------- checklist ---
const GROUPS: { name: string; items: [string, string, "DONE" | "BLOCKED"][] }[] = [
  { name: "R-OUT — DELIVERABLES", items: [
    ["R-OUT-01", "60.000 s Spot, Deutsch, Launch 12. Okt 2026 — Timeline + Copy stehen", "DONE"],
    ["R-OUT-02", "Reine Funktion von t (frame/60) in Python UND im Canvas-Player", "DONE"],
    ["R-OUT-03", "MP4 1080p-Test — Renderer fertig, Ausführung braucht Shell", "BLOCKED"],
    ["R-OUT-04", "MP4 2160p60-Final — Gate respektiert, wartet auf Freigabe", "BLOCKED"],
    ["R-OUT-05", "Codec/Lautheit-Spec in render.py + mix.py kodiert", "DONE"],
    ["R-OUT-06", "Ein Render-Befehl: python render.py (README §3)", "DONE"],
  ]},
  { name: "R-STACK — UMGEBUNG", items: [
    ["R-STACK-01", "Host-Reachability — Skript + Tabelle im README, hier nicht ausführbar", "BLOCKED"],
    ["R-STACK-02", "Python-Stack (numpy/Pillow/cv2/imageio-ffmpeg) per requirements.txt", "DONE"],
    ["R-STACK-03", "Default-Stack gewählt (Remotion nicht erreichbar ⇒ Regel greift)", "DONE"],
    ["R-STACK-04", "Keine GPU-Bibliotheken — alles CPU/numpy", "DONE"],
    ["R-STACK-05", "Dejavu-Fonts per Absolutpfad geladen", "DONE"],
    ["R-STACK-06", "Glyph-Assertion ÄäÖöÜüß . , % m — pytest-Test, braucht Laufzeit", "BLOCKED"],
  ]},
  { name: "R-TIME — TIMING", items: [
    ["R-TIME-01..04", "Akte fix 0–8/8–32/32–44/44–60; jedes Element hat Start/Ende; keine Pacing-Änderung", "DONE"],
  ]},
  { name: "R-VIS / R-SCN — BILDSYSTEM & SZENEN", items: [
    ["R-VIS-01..12", "Haze 40 %, Palette, Glas (¼-Scale-Blur), Bloom, Flares, Flicker, Partikel seed 7, Grain 3.5 %, Vignette 25 %, Kamera f=900, exakte Easing-Kurven, Referenzraum 1920×1080", "DONE"],
    ["R-SCN-01..11", "Alle 11 Szenen als Painter-Registry (Python) + Canvas-Pendants", "DONE"],
  ]},
  { name: "R-AUD / R-TXT — AUDIO & TEXT", items: [
    ["R-AUD-01", "VO-Kette edge-tts → piper → espeak-Platzhalter + Neural-Gate — Synthese braucht Netz/Shell", "BLOCKED"],
    ["R-AUD-02/03/04", "Musik generativ, 13 SFX-Rezepte mit exakten Peaks, 2-Pass-loudnorm — kodiert, Verifikation per pytest", "DONE"],
    ["R-TXT-01..03", "23 Strings exakt, alle durchs Layout-System, Auto-Fit mit Log", "DONE"],
  ]},
  { name: "R-VER — VERIFIKATION (14 Tests)", items: [
    ["R-VER-01..05", "Dauer/Frames/Codec/Audio/Lautheit — pytest-Suite fertig, Artefakte fehlen hier", "BLOCKED"],
    ["R-VER-06..10", "Palette/Hintergrund/Safe-Area/Text/Motion — Suite fertig; Palette+Motion+Safe-Area zusätzlich LIVE oben", "BLOCKED"],
    ["R-VER-11..14", "Timing/Stille/Reproduzierbarkeit/Fonts — Suite fertig, braucht Shell", "BLOCKED"],
  ]},
  { name: "R-PERF / R-GATE / R-NEG", items: [
    ["R-PERF-01..03", "Vorberechnete Layer, Vektorisierung, Sprite-Caches", "DONE"],
    ["R-PERF-04/05", "s/Frame-Messung + 6-h-Grenze im Renderer — Messung braucht Laufzeit", "BLOCKED"],
    ["R-GATE-01..04", "Test-Stop, Freigabe-Flag, Neural-VO-Pflicht, kein Upscale-Pfad", "DONE"],
    ["R-NEG-01..09", "Farb-Lock, keine Emojis/Stock/UI, Nur-Deutsch, keine Medien im Git, nichts vorgetäuscht", "DONE"],
  ]},
];

export function Checklist() {
  const done = GROUPS.flatMap((g) => g.items).filter((i) => i[2] === "DONE").length;
  const blocked = GROUPS.flatMap((g) => g.items).filter((i) => i[2] === "BLOCKED").length;
  return (
    <div>
      <div className="mb-8 flex flex-wrap gap-3">
        <span className="flex items-center gap-2 rounded-full border border-[#3b82f6]/50 px-4 py-2 font-mono text-[10px] tracking-[0.2em] text-[#3b82f6]">
          <CheckCircle2 className="h-4 w-4" /> {done} DONE (durch Code belegt)
        </span>
        <span className="flex items-center gap-2 rounded-full border border-[#f97316]/60 px-4 py-2 font-mono text-[10px] tracking-[0.2em] text-[#f97316]">
          <Lock className="h-4 w-4" /> {blocked} BLOCKED (braucht Shell/Netz/Freigabe)
        </span>
        <span className="flex items-center gap-2 rounded-full border border-white/20 px-4 py-2 font-mono text-[10px] tracking-[0.2em] text-white/50">
          <Ban className="h-4 w-4" /> 0 FAILED · 0 vorgetäuscht (R-NEG-09)
        </span>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {GROUPS.map((g) => (
          <div key={g.name} className="rounded-lg border border-white/10 bg-white/[0.02] p-5">
            <div className="mb-4 flex items-center gap-2 font-mono text-[10px] tracking-[0.25em] text-white/70">
              <ClipboardList className="h-4 w-4 text-[#f97316]" />
              {g.name}
            </div>
            {g.items.map(([id, de, st]) => (
              <div key={id} className="flex items-start gap-3 border-t border-white/5 py-2.5 first:border-0">
                <span className={`mt-0.5 h-2 w-2 shrink-0 rounded-full ${st === "DONE" ? "bg-[#3b82f6]" : "bg-[#f97316]"}`} />
                <div>
                  <span className="font-mono text-[10px] tracking-[0.15em] text-white/80">{id}</span>
                  <p className="mt-0.5 text-xs leading-relaxed text-white/55">{de}</p>
                </div>
                <span className={`ml-auto font-mono text-[9px] tracking-[0.2em] ${st === "DONE" ? "text-[#3b82f6]" : "text-[#f97316]"}`}>{st}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export function RepoTree() {
  const lines = [
    ["nealarp-ad/", ""],
    ["├─ timeline.yaml", "Quelle aller Frames — 424 Zeilen, alles deklariert"],
    ["├─ README.md · checklist.md · requirements.txt · render.py", "ein Befehl rendert beide Dateien"],
    ["├─ src/", "timeline·easing·rng·palette·effects·text_layout·sprites·scenes·renderer·audio_synth·vo·mix"],
    ["├─ audio/vo/ · audio/render/ (git-ignored)", "VO-Kette + Mixdown"],
    ["├─ reference/README.md", "Inspirations-Beschreibung (R-REF-01: Datei fehlt)"],
    ["├─ tests/", "test_units.py (offline) · test_verify.py (R-VER-01…14)"],
    ["└─ out/ (git-ignored)", "MP4-Master — entstehen auf der Zielmaschine"],
  ];
  return (
    <div className="rounded-lg border border-white/10 bg-white/[0.02] p-5 font-mono text-[11px] leading-relaxed">
      {lines.map(([a, b]) => (
        <div key={a} className="flex flex-wrap gap-x-4 border-b border-white/5 py-1.5 last:border-0">
          <span className="text-white/85">{a}</span>
          <span className="text-white/40">{b}</span>
        </div>
      ))}
      <div className="mt-4 flex items-center gap-2 text-[10px] tracking-[0.15em] text-white/50">
        <Boxes className="h-4 w-4 text-[#3b82f6]" />
        DIE WEBSITE-REPO WURDE NICHT ANGEFASST (R-REPO-01) — nealarp-ad/ IST EIN SEPARATER ORDNER.
      </div>
    </div>
  );
}

export { Section, Palette, Activity, Type };
