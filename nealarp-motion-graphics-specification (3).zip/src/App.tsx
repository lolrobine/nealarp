// nealarp — Der Werbespot ist Code.
// A spec-compliant delivery site: live deterministic canvas player of the same
// timeline.yaml + honest PASS/BLOCKED reporting (R-NEG-09).
import { Gamepad2, Sparkles, FileVideo, Palette, Activity, Type, AudioLines, ClipboardList, FolderGit2, TerminalSquare, ArrowDown } from "lucide-react";
import Player, { getStageCanvas } from "./ad/Player";
import {
  Section, LiveChecks, TimelineStrip, AudioSpec, TextGrid,
  Deliverables, Checklist, RepoTree,
} from "./components/Spec";

const NUMBERS: [string, string][] = [
  ["60.000", "SEKUNDEN — EXAKT"],
  ["3.600", "FRAMES @ 60 FPS"],
  ["23", "STRINGS (EXAKT, DE)"],
  ["7", "SEED — REPRODUZIERBAR"],
  ["13", "SFX-REZEPTE"],
  ["4", "FARBEN. MEHR NICHT."],
];

export default function App() {
  return (
    <div className="relative min-h-screen bg-ink font-body text-paper">
      <div className="noise pointer-events-none fixed inset-0 z-50 opacity-[0.05]" />

      {/* header */}
      <header className="flex items-center justify-between border-b border-white/10 px-5 py-4 md:px-10">
        <div className="flex items-center gap-2.5">
          <Gamepad2 className="h-5 w-5 text-[#3b82f6]" />
          <span className="font-display text-xl tracking-[0.04em]">
            nealarp<span className="text-[#f97316]">.</span>
          </span>
        </div>
        <div className="hidden font-mono text-[10px] tracking-[0.3em] text-white/50 md:block">
          AB 12. OKTOBER 2026 · NEALARP.VERCEL.APP
        </div>
        <div className="font-mono text-[10px] tracking-[0.25em] text-white/50">
          SPEC-COMPLIANT BUILD
        </div>
      </header>

      {/* hero */}
      <section className="relative overflow-hidden px-5 pb-16 pt-16 md:px-10 md:pt-24">
        <div
          className="pointer-events-none absolute -left-40 top-10 h-96 w-[130%] -rotate-6 opacity-20"
          style={{ background: "linear-gradient(90deg, transparent, #3b82f6 40%, #f97316 60%, transparent)" }}
        />
        <div className="relative">
          <div className="mb-5 flex items-center gap-2 font-mono text-[10px] tracking-[0.35em] text-[#f97316]">
            <Sparkles className="h-4 w-4" />
            WERBESPOT ALS REINE FUNKTION VON t — KEINE KI-VIDEOS, KEINE KAMERAS
          </div>
          <h1 className="max-w-6xl font-display text-[13.5vw] uppercase leading-[0.88] md:text-[7.6vw]">
            Der Spot ist{" "}
            <span className="grad-bo bg-clip-text text-transparent">Code</span> —
            <br />
            hier läuft er{" "}
            <span className="text-stroke">live</span>.
          </h1>
          <p className="mt-8 max-w-2xl text-base leading-relaxed text-white/65 md:text-lg">
            60 Sekunden Werbung für acht Web-Games, berechnet aus einer einzigen
            <span className="font-mono text-white"> timeline.yaml</span>. Unten spielt
            der Canvas-Renderer die komplette Timeline deterministisch ab — derselbe
            Zeitstrahl, aus dem der Python-Master die MP4s schreibt. Jede Anforderung
            der Spec ist unten als DONE oder ehrlich als BLOCKED ausgewiesen.
          </p>
          <div className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-white/10 bg-white/10 sm:grid-cols-3 lg:grid-cols-6">
            {NUMBERS.map(([n, l]) => (
              <div key={l} className="bg-black p-4">
                <div className="font-mono text-2xl font-bold tabular-nums md:text-3xl">{n}</div>
                <div className="mt-1 font-mono text-[8px] tracking-[0.2em] text-white/45">{l}</div>
              </div>
            ))}
          </div>
          <div className="mt-8 flex items-center gap-2 font-mono text-[10px] tracking-[0.25em] text-white/40">
            <ArrowDown className="h-4 w-4 animate-bounce text-[#3b82f6]" />
            PLAYER — TON EINSCHALTEN FÜR SYNTH-AUDIO & DEUTSCHE VO
          </div>
        </div>
      </section>

      {/* player */}
      <main className="px-5 md:px-10">
        <Section icon={FileVideo} kicker="01 — DER SPOT" title="60.000 Sekunden, f(t)-pur">
          <Player />
          <p className="mt-4 font-mono text-[10px] leading-relaxed text-white/40">
            Render-Loop: t = frame/60, hart bei 60.000 s geklemmt · Referenzraum 1920×1080 ·
            Grain (Seed-7-Kachel, 3.5 %), Vignette 25 %, Bloom-Ersatz über additive
            Glow-Sprites · unter der Haube identische Konstanten wie nealarp-ad/src/*.
          </p>
        </Section>

        <Section icon={Activity} kicker="02 — TIMELINE" title="Vier Akte, harte Schnitte">
          <TimelineStrip />
          <div className="mt-8 grid gap-px overflow-hidden rounded-lg border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["AKT I — ERÖFFNUNG", "0.0–8.0 s", "Partikeltunnel konvergiert zu SPIELE UND ZEUG. Buchstabenstagger 45 ms, Blur-Tail auf den letzten zwei Glyphen, Flare bei 2.0 s."],
              ["AKT II — 8 CUTS", "8.0–32.0 s", "Acht harte Schnitte à 3.0 s: Pop 0.2, Build 0.6, Hold 2.0, Out 0.4. Jeder Cut: Titel + Glass-Panel + ein eigenes SFX."],
              ["AKT III — HERO", "32.0–44.0 s", "Sphäre pulsiert 0.5 Hz ±3 %, acht Orbiter auf zwei Ringen (0.3 rad/s), Push-in ×1.15, Marke einblendend ab 36.5 s."],
              ["AKT IV — CTA", "44.0–60.0 s", "Explosion: ~3.000 Partikel formen dreimal Text neu, Pill-CTA bei 53 s, Push-out 55–59, Fade + Stille ab 59/60 s."],
            ].map(([a, b, c]) => (
              <div key={a} className="bg-black p-5">
                <div className="font-mono text-[10px] tracking-[0.2em] text-[#3b82f6]">{a}</div>
                <div className="mt-1 font-mono text-lg font-bold">{b}</div>
                <p className="mt-2 text-xs leading-relaxed text-white/55">{c}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section icon={Palette} kicker="03 — LIVE-VERIFIKATION" title="Was der Browser beweisen kann">
          <LiveChecks getCanvas={getStageCanvas} />
        </Section>

        <Section icon={Type} kicker="04 — TEXTLOG" title="23 Strings, ein Choke Point">
          <TextGrid />
        </Section>

        <Section icon={AudioLines} kicker="05 — AUDIO" title="Alles synthetisiert">
          <AudioSpec />
        </Section>

        <Section icon={FileVideo} kicker="06 — DELIVERABLES & GATE" title="MP4s baut die Zielmaschine">
          <Deliverables />
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            <RepoTree />
            <div className="rounded-lg border border-white/10 bg-white/[0.02] p-5">
              <div className="mb-3 flex items-center gap-2 font-mono text-[10px] tracking-[0.25em] text-[#3b82f6]">
                <TerminalSquare className="h-4 w-4" /> DER EINE RENDER-BEFEHL (R-OUT-06)
              </div>
              <pre className="overflow-x-auto rounded bg-black p-4 font-mono text-[11px] leading-relaxed text-white/85">
{`cd nealarp-ad
python3.11 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python render.py          # → out/nealarp-ad-1080p-test.mp4, dann Stop (Gate)
pytest -q                 # → R-VER-01…14

python render.py --final --approve-4k   # NUR nach deiner Freigabe + echter DE-Stimme`}
              </pre>
              <p className="mt-3 font-mono text-[10px] leading-relaxed text-white/45">
                Abweichungen (README §8): zwei zusätzliche Text-Templates (panel_label, score_badge),
                Cut-7-Zähler zeigen transiente Ziffern statt nicht spezifizierter Endwerte (R-PRI-1
                vor R-NEG-03). Alle drei dokumentiert, nichts still geändert.
              </p>
            </div>
          </div>
        </Section>

        <Section icon={ClipboardList} kicker="07 — CHECKLISTE" title="Jede ID, ehrlich markiert">
          <Checklist />
        </Section>
      </main>

      <footer className="border-t border-white/10 px-5 py-10 md:px-10">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <FolderGit2 className="h-4 w-4 text-[#f97316]" />
            <span className="font-mono text-[10px] tracking-[0.25em] text-white/60">
              NEALARP-AD — BUILD 001 · WEBSITE-REPO UNVERÄNDERT
            </span>
          </div>
          <span className="font-mono text-[10px] tracking-[0.25em] text-white/40">
            AB 12. OKTOBER 2026 — NEALARP.VERCEL.APP
          </span>
        </div>
      </footer>
    </div>
  );
}
