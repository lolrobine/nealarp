// Canvas render engine — deterministic, seeded (7), pure functions of t.
import {
  BLUE, ORANGE, WHITE, INK, HAZE, W, H,
  EASE_IO, win, type TextEntry, type LayoutId,
} from "./timeline";

// ---------------------------------------------------------------- seeded rng
export function rng(tag: number) {
  let a = (7 * 2654435761 + tag * 2246822519) >>> 0 || 1;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ------------------------------------------------------------ layout logging
export interface LayoutLog {
  id: string;
  string: string;
  layout: LayoutId;
  size: number;
  bbox: [number, number, number, number];
  safe: boolean;
  autofitFrom?: number;
}
export const layoutLog: LayoutLog[] = [];
const loggedOnce = new Set<string>();

function record(entry: LayoutLog) {
  const key = `${entry.id}|${entry.size}`;
  if (loggedOnce.has(key)) return;
  loggedOnce.add(key);
  layoutLog.push(entry);
}

// ---------------------------------------------------------------- text core
export const FONT = (size: number, bold = true) =>
  `${bold ? "bold " : ""}${size}px "DejaVu Sans", Arial, "Helvetica Neue", sans-serif`;
export const MONO = (size: number) =>
  `${size}px "DejaVu Sans Mono", "JetBrains Mono", monospace`;

const TRACKING = 0.04;
const ctxMeasure = document.createElement("canvas").getContext("2d")!;

export function trackedWidth(s: string, size: number, mono = false): number {
  ctxMeasure.font = mono ? MONO(size) : FONT(size);
  let w = 0;
  for (const ch of s) w += ctxMeasure.measureText(ch).width + TRACKING * size;
  return s.length ? w - TRACKING * size : 0;
}

export function autofit(s: string, size: number, mono = false) {
  const from = size;
  let w = trackedWidth(s, size, mono);
  while (w > 1440 && size > 64) {
    size -= 4;
    w = trackedWidth(s, size, mono);
  }
  return { size, w, fitted: size !== from, from };
}

export function drawTracked(
  ctx: CanvasRenderingContext2D, s: string, cx: number, yBaseline: number,
  size: number, fill: string | CanvasGradient, alpha = 1, mono = false,
) {
  ctx.save();
  ctx.font = mono ? MONO(size) : FONT(size);
  ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
  ctx.fillStyle = fill;
  ctx.textBaseline = "alphabetic";
  const w = trackedWidth(s, size, mono);
  let x = cx - w / 2;
  for (const ch of s) {
    ctx.fillText(ch, x, yBaseline);
    x += ctx.measureText(ch).width + TRACKING * size;
  }
  ctx.restore();
  return w;
}

const TPL: Record<LayoutId, { size: number; fill: "grad" | "white" | "orange" | "white60"; cx: number; cy: number; mode: "center" | "baseline"; glass?: boolean }> = {
  title_opening: { size: 180, fill: "grad", cx: 960, cy: 540, mode: "center" },
  title_lower_third: { size: 96, fill: "grad", cx: 960, cy: 880, mode: "baseline", glass: true },
  counter_center: { size: 160, fill: "white", cx: 960, cy: 520, mode: "center" },
  claim_white: { size: 112, fill: "white", cx: 960, cy: 540, mode: "center" },
  claim_gradient: { size: 96, fill: "grad", cx: 960, cy: 540, mode: "center" },
  url: { size: 72, fill: "white", cx: 960, cy: 600, mode: "center" },
  cta_button_label: { size: 44, fill: "white", cx: 960, cy: 780, mode: "center" },
  panel_label: { size: 28, fill: "white60", cx: 960, cy: 540, mode: "center" },
  score_badge: { size: 160, fill: "orange", cx: 1480, cy: 470, mode: "center" },
};

export function roundRect(
  ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function textAlpha(e: TextEntry, t: number): number {
  const aIn = EASE_IO(win(t, e.start, Math.min(e.start + 0.4, e.end)));
  const props = e.props ?? {};
  const aOut = props.fadeOutFrom
    ? 1 - EASE_IO(win(t, props.fadeOutFrom as number, e.end))
    : 1 - EASE_IO(win(t, e.end - 0.4, e.end));
  return Math.min(aIn, aOut);
}

export function recordLayout(e: TextEntry) {
  // measure + log bbox without drawing (opening title is drawn manually for
  // per-letter stagger, but must still appear in the layout log — R-TXT-02)
  const cfg = TPL[e.layout];
  const size0 = ((e.props ?? {}) as { size?: number }).size ?? cfg.size;
  const { size, w, fitted, from } = autofit(e.string, size0);
  const props = (e.props ?? {}) as { y?: number; center?: number[] };
  const cx = props.center ? props.center[0] : cfg.cx;
  const cy = props.y ?? (props.center ? props.center[1] : cfg.cy);
  const asc = size * 0.76;
  const h = size * 1.02;
  const bbox: [number, number, number, number] =
    cfg.mode === "baseline"
      ? [cx - w / 2, cy - asc, w, asc + size * 0.24]
      : [cx - w / 2, cy - h / 2, w, h];
  const safe =
    bbox[0] >= 96 && bbox[0] + bbox[2] <= 1824 && bbox[1] >= 54 && bbox[1] + bbox[3] <= 1026;
  record({ id: e.id, string: e.string, layout: e.layout, size, bbox, safe, autofitFrom: fitted ? from : undefined });
}

export function drawLayoutText(ctx: CanvasRenderingContext2D, e: TextEntry, t: number) {
  if (t < e.start || t > e.end) return;
  const a = textAlpha(e, t);
  if (a <= 0.003) {
    recordLayout(e); // keep the log complete even when currently invisible
    return;
  }
  const cfg = TPL[e.layout];
  const props = (e.props ?? {}) as { y?: number; size?: number; center?: number[] };
  const size0 = props.size ?? cfg.size;
  const { size, w, fitted, from } = autofit(e.string, size0);
  const cx = props.center ? props.center[0] : cfg.cx;
  const cy = props.y ?? (props.center ? props.center[1] : cfg.cy);
  const asc = size * 0.76;
  const h = size * 1.02;
  const bbox: [number, number, number, number] =
    cfg.mode === "baseline"
      ? [cx - w / 2, cy - asc, w, asc + size * 0.24]
      : [cx - w / 2, cy - h / 2, w, h];
  const safe =
    bbox[0] >= 96 && bbox[0] + bbox[2] <= 1824 && bbox[1] >= 54 && bbox[1] + bbox[3] <= 1026;

  if (cfg.glass) {
    ctx.save();
    ctx.globalAlpha = a;
    roundRect(ctx, bbox[0] - 48, bbox[1] - 28, bbox[2] + 96, bbox[3] + 56, 24);
    ctx.fillStyle = "rgba(255,255,255,0.10)";
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.25)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
  }

  let fill: string | CanvasGradient = WHITE;
  if (cfg.fill === "grad") {
    const g = ctx.createLinearGradient(bbox[0], 0, bbox[0] + bbox[2], 0);
    g.addColorStop(0, BLUE);
    g.addColorStop(1, ORANGE);
    fill = g;
  } else if (cfg.fill === "orange") fill = ORANGE;
  else if (cfg.fill === "white60") fill = "rgba(255,255,255,0.6)";

  const baseline = cfg.mode === "baseline" ? cy : cy + asc / 2 - size * 0.03;
  drawTracked(ctx, e.string, cx, baseline, size, fill, a);
  record({ id: e.id, string: e.string, layout: e.layout, size, bbox, safe, autofitFrom: fitted ? from : undefined });
}

// ---------------------------------------------------------------- backdrop
export function paintBase(ctx: CanvasRenderingContext2D) {
  ctx.fillStyle = INK;
  ctx.fillRect(0, 0, W, H);
  // R-VIS-01 radial haze to #0f172a @ 40%
  const g = ctx.createRadialGradient(960, 540, 120, 960, 540, 1150);
  g.addColorStop(0, hexA(HAZE, 0.4));
  g.addColorStop(1, hexA(HAZE, 0));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

export function hexA(hex: string, a: number) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${a})`;
}

// grain tile (R-VIS-07) — pre-generated once, new offset per frame
const grain = document.createElement("canvas");
grain.width = grain.height = 512;
{
  const g = grain.getContext("2d")!;
  const img = g.createImageData(512, 512);
  const r = rng(70);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = (r() * 255) | 0;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
}
let frameCounter = 0;
export function applyGrain(ctx: CanvasRenderingContext2D) {
  frameCounter++;
  const r = rng(1000 + frameCounter);
  const ox = r() * 512;
  const oy = r() * 512;
  ctx.save();
  ctx.globalAlpha = 0.035;
  for (let x = -ox; x < W; x += 512)
    for (let y = -oy; y < H; y += 512) ctx.drawImage(grain, x, y);
  ctx.restore();
}

let vignette: CanvasGradient | null = null;
export function applyVignette(ctx: CanvasRenderingContext2D) {
  if (!vignette) {
    vignette = ctx.createRadialGradient(960, 540, 420, 960, 540, 1180);
    vignette.addColorStop(0, "rgba(0,0,0,0)");
    vignette.addColorStop(1, "rgba(0,0,0,0.25)");
  }
  ctx.save();
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}

// ---------------------------------------------------------------- sprites
function makeGlow(color: string, size = 32) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grad.addColorStop(0, color);
  grad.addColorStop(0.35, hexA(color === WHITE ? "#ffffff" : color, 0.55));
  grad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, size, size);
  return c;
}
export const SPRITES = {
  glowBlue: makeGlow(BLUE),
  glowOrange: makeGlow(ORANGE),
  glowWhite: makeGlow(WHITE),
};

export function dot(
  ctx: CanvasRenderingContext2D, x: number, y: number, r: number,
  sprite: HTMLCanvasElement, alpha: number,
) {
  if (r <= 0.2 || alpha <= 0.01 || x < -64 || y < -64 || x > W + 64 || y > H + 64) return;
  ctx.globalAlpha = Math.min(1, alpha);
  ctx.drawImage(sprite, x - r, y - r, r * 2, r * 2);
}

export function flare(ctx: CanvasRenderingContext2D, cx: number, cy: number, progress: number) {
  if (progress <= 0 || progress >= 1) return;
  const a = Math.sin(Math.PI * progress);
  ctx.save();
  ctx.globalAlpha = a;
  ctx.translate(cx, cy);
  // 1400x6 white-hot streak with blue/orange fringe + 120 glow
  const glow = ctx.createRadialGradient(0, 0, 0, 0, 0, 120);
  glow.addColorStop(0, "rgba(255,255,255,0.8)");
  glow.addColorStop(1, "rgba(59,130,246,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(-120, -120, 240, 240);
  const streak = ctx.createLinearGradient(-700, 0, 700, 0);
  streak.addColorStop(0, "rgba(59,130,246,0)");
  streak.addColorStop(0.2, "rgba(59,130,246,0.6)");
  streak.addColorStop(0.5, "rgba(255,255,255,0.95)");
  streak.addColorStop(0.8, "rgba(249,115,22,0.6)");
  streak.addColorStop(1, "rgba(249,115,22,0)");
  ctx.fillStyle = streak;
  ctx.fillRect(-700, -3, 1400, 6);
  ctx.restore();
}

export { frameCounter as _grainFrame };
export function resetGrainCounter() {
  frameCounter = 0;
}
