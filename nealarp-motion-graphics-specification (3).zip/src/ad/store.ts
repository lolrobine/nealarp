// Tiny external store for the ad playhead (avoids re-render storms).
export type PlayState = "idle" | "playing" | "paused" | "ended";

type Snapshot = { t: number; frame: number; state: PlayState };

let snap: Snapshot = { t: 0, frame: 0, state: "idle" };
const listeners = new Set<() => void>();

export const playerStore = {
  getSnapshot: (): Snapshot => snap,
  set(next: Snapshot) {
    snap = next;
    listeners.forEach((l) => l());
  },
  subscribe(l: () => void) {
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  },
};
