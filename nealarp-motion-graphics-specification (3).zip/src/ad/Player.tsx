// The deterministic 60-second player. drawFrame(t) is a pure function of time;
// the wall clock only decides WHICH t gets shown (t = frame/60).
import { useEffect, useRef, useSyncExternalStore } from "react";
import {
  Play, Pause, RotateCcw, Volume2, VolumeX, Gauge, FunctionSquare, Film,
} from "lucide-react";
import { FPS, FRAMES, DUR, W, H, sceneAt, SCENES } from "./timeline";
import * as E from "./engine";
import * as S from "./scenes";
import { AdAudio } from "./audio";
import { playerStore } from "./store";

export const audio = new AdAudio();

let stageCanvas: HTMLCanvasElement | null = null;
export const getStageCanvas = () => stageCanvas;

function drawFrame(ctx: CanvasRenderingContext2D, t: number) {
  // cta push-out wrapper (55-59) needs whole-frame scale
  const pushOut = t >= 55 ? 1 - 0.04 * Math.sin((Math.PI * Math.min(t - 55, 4)) / 4) : 1;
  E.resetGrainCounter();
  ctx.save();
  ctx.translate(960, 540);
  ctx.scale(pushOut, pushOut);
  ctx.translate(-960, -540);
  E.paintBase(ctx);
  const sc = sceneAt(t);
  switch (sc.id) {
    case "opening": S.sceneOpening(ctx, t); break;
    case "g1": S.sceneWallet(ctx, t); break;
    case "g2": S.scenePasswort(ctx, t); break;
    case "g3": S.sceneTiefsee(ctx, t); break;
    case "g4": S.sceneTempo(ctx, t); break;
    case "g5": S.sceneAsteroiden(ctx, t); break;
    case "g6": S.sceneKreis(ctx, t); break;
    case "g7": S.sceneStats(ctx, t); break;
    case "g8": S.sceneWeltall(ctx, t); break;
    case "hero": S.sceneHero(ctx, t); break;
    default: S.sceneCta(ctx, t);
  }
  ctx.restore();
  E.applyGrain(ctx);
  E.applyVignette(ctx);
  if (t >= 59) {
    ctx.save();
    ctx.globalAlpha = (t - 59) / 1;
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }
}

export default function Player() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const raf = useRef(0);
  const base = useRef({ t: 0, startedAt: 0, playing: false, muted: true });
  const snap = useSyncExternalStore(playerStore.subscribe, playerStore.getSnapshot);

  const drawAt = (t: number) => {
    const c = canvasRef.current;
    const g = c?.getContext("2d");
    if (!c || !g) return;
    drawFrame(g, Math.min(t, DUR));
  };

  const publish = (t: number) => {
    playerStore.set({
      t,
      frame: Math.min(FRAMES - 1, Math.round(t * FPS)),
      state: base.current.playing ? "playing" : t >= DUR ? "ended" : t > 0 ? "paused" : "idle",
    });
  };

  const loop = () => {
    if (!base.current.playing) return;
    const t = Math.min(DUR, (performance.now() - base.current.startedAt) / 1000 + base.current.t);
    if (t >= DUR) {
      base.current.playing = false;
      base.current.t = DUR;
      drawAt(DUR);
      publish(DUR);
      audio.stopAll();
      return;
    }
    drawAt(t);
    raf.current = requestAnimationFrame(loop);
  };

  const play = () => {
    if (base.current.playing) return;
    if (base.current.t >= DUR) base.current.t = 0;
    base.current.playing = true;
    base.current.startedAt = performance.now();
    publish(base.current.t);
    if (!base.current.muted) audio.start(base.current.t);
    raf.current = requestAnimationFrame(loop);
  };

  const pause = () => {
    if (!base.current.playing) return;
    base.current.t = Math.min(DUR, (performance.now() - base.current.startedAt) / 1000 + base.current.t);
    base.current.playing = false;
    cancelAnimationFrame(raf.current);
    audio.stopAll();
    publish(base.current.t);
  };

  const seek = (t: number) => {
    base.current.t = t;
    base.current.startedAt = performance.now();
    if (base.current.playing && !base.current.muted) {
      audio.stopAll();
      audio.start(t);
    }
    drawAt(t);
    publish(t);
  };

  const toggleMute = () => {
    base.current.muted = !base.current.muted;
    if (base.current.muted) audio.stopAll();
    else if (base.current.playing) audio.start(base.current.t);
    publish(base.current.t);
  };

  useEffect(() => {
    stageCanvas = canvasRef.current;
    drawAt(0);
    publish(0);
    return () => {
      cancelAnimationFrame(raf.current);
      audio.stopAll();
      stageCanvas = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const sc = sceneAt(snap.t);
  const active = (): boolean => base.current.playing;
  void active;

  return (
    <div className="w-full">
      {/* stage */}
      <div className="relative overflow-hidden rounded-xl border border-white/15 bg-black shadow-[0_0_120px_-30px_rgba(59,130,246,0.35)]">
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          className="block h-auto w-full"
          aria-label="nealarp Werbespot — 60 Sekunden, als Code gerendert"
        />
        {/* HUD top strip */}
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between bg-gradient-to-b from-black/70 to-transparent px-4 py-3 font-mono text-[10px] tracking-[0.2em] text-white/70 md:px-6">
          <span className="flex items-center gap-2">
            <span className={`inline-block h-1.5 w-1.5 rounded-full ${snap.state === "playing" ? "bg-[#f97316] pulse-soft" : "bg-white/30"}`} />
            {sc.de} — {sc.act}
          </span>
          <span className="hidden items-center gap-4 sm:flex">
            <span className="flex items-center gap-1.5">
              <FunctionSquare className="h-3 w-3 text-[#3b82f6]" />
              f(t) REIN
            </span>
            <span className="flex items-center gap-1.5">
              <Film className="h-3 w-3 text-[#f97316]" />
              {String(snap.frame).padStart(4, "0")}/3600
            </span>
          </span>
        </div>
        {/* transport */}
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent px-4 pb-3 pt-10 md:px-6">
          <input
            type="range"
            min={0}
            max={FRAMES - 1}
            value={snap.frame}
            onChange={(e) => seek(Number(e.target.value) / FPS)}
            className="w-full accent-[#f97316]"
            aria-label="Frame-Suche"
          />
          <div className="mt-2 flex items-center justify-between font-mono text-[10px] tracking-[0.18em] text-white/70">
            <div className="flex items-center gap-2">
              <button
                onClick={snap.state === "playing" ? pause : play}
                className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-full bg-[#f97316] text-black transition-transform hover:scale-105"
                aria-label={snap.state === "playing" ? "Pause" : "Abspielen"}
              >
                {snap.state === "playing" ? <Pause className="h-4 w-4" /> : <Play className="ml-0.5 h-4 w-4" />}
              </button>
              <button
                onClick={() => { pause(); seek(0); }}
                className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-full border border-white/25 text-white/80 hover:bg-white/10"
                aria-label="Zum Anfang"
              >
                <RotateCcw className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={toggleMute}
                className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-full border border-white/25 text-white/80 hover:bg-white/10"
                aria-label="Ton umschalten"
              >
                {base.current.muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5 text-[#3b82f6]" />}
              </button>
              <span className="ml-2 hidden md:inline">
                {audio.status.engine}
              </span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-base tabular-nums text-white">
                {snap.t.toFixed(3).padStart(6, "0")}
                <span className="text-white/50"> s</span>
              </span>
              <span className="hidden items-center gap-1.5 sm:flex">
                <Gauge className="h-3 w-3 text-[#3b82f6]" />
                1920×1080 @ 60
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* scene chips */}
      <div className="mt-4 flex flex-wrap gap-1.5">
        {SCENES.map((s) => (
          <button
            key={s.id}
            onClick={() => { seek(s.start); if (!base.current.playing) return; }}
            className={`rounded-md border px-2.5 py-1.5 font-mono text-[9px] tracking-[0.15em] transition-colors ${
              sc.id === s.id
                ? "border-[#f97316] bg-[#f97316] text-black"
                : "border-white/15 text-white/60 hover:border-white/40 hover:text-white"
            }`}
          >
            {String(s.start).padStart(2, "0")}s — {s.de}
          </button>
        ))}
      </div>
    </div>
  );
}
