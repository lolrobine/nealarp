// TypeScript mirror of nealarp-ad/timeline.yaml — same numbers, same source of truth.
export const FPS = 60;
export const DUR = 60.0;
export const FRAMES = 3600;
export const W = 1920;
export const H = 1080;

export const BLUE = "#3b82f6";
export const ORANGE = "#f97316";
export const WHITE = "#ffffff";
export const INK = "#0a0a0a";
export const HAZE = "#0f172a";

// ---------------------------------------------------------- R-VIS-10 easing --
function bezier(x1: number, y1: number, x2: number, y2: number) {
  const sample = (t: number): [number, number] => {
    const i = 1 - t;
    return [
      3 * i * i * t * x1 + 3 * i * t * t * x2 + t * t * t,
      3 * i * i * t * y1 + 3 * i * t * t * y2 + t * t * t,
    ];
  };
  return (p: number): number => {
    const x = Math.min(Math.max(p, 0), 1);
    let t = x;
    for (let k = 0; k < 24; k++) {
      const [sx, sy] = sample(t);
      const err = sx - x;
      if (Math.abs(err) < 1e-6) return sy;
      const dxd =
        3 * (1 - t) ** 2 * x1 + 6 * (1 - t) * t * (x2 - x1) + 3 * t * t * (1 - x2);
      if (Math.abs(dxd) < 1e-6) return sy;
      t = Math.min(Math.max(t - err / dxd, 0), 1);
    }
    return sample(t)[1];
  };
}

export const EASE_IO = bezier(0.65, 0, 0.35, 1);
export const EASE_OUT_EARLY = bezier(0.25, 0.8, 0.25, 1);
export const EXPO_OUT = (p: number) => (p >= 1 ? 1 : p <= 0 ? 0 : 1 - 2 ** (-10 * p));
export const STEP = (p: number) => (p < 1 ? 0 : 1);

export const win = (t: number, s: number, e: number) =>
  t <= s ? 0 : t >= e ? 1 : (t - s) / (e - s);

// -------------------------------------------------------------- text list ---
export type LayoutId =
  | "title_opening"
  | "title_lower_third"
  | "counter_center"
  | "claim_white"
  | "claim_gradient"
  | "url"
  | "cta_button_label"
  | "panel_label"
  | "score_badge";

export interface TextEntry {
  id: string;
  string: string;
  layout: LayoutId;
  start: number;
  end: number;
  props?: Record<string, unknown>;
}

export const TEXTS: TextEntry[] = [
  { id: "t_open", string: "SPIELE UND ZEUG", layout: "title_opening", start: 2.0, end: 8.0 },
  { id: "t_01", string: "GELD AUSGEBEN", layout: "title_lower_third", start: 8.3, end: 11.0 },
  { id: "t_02", string: "DAS PASSWORT-SPIEL", layout: "title_lower_third", start: 11.3, end: 14.0 },
  { id: "t_03", string: "DIE TIEFSEE", layout: "title_lower_third", start: 14.3, end: 17.0 },
  { id: "c_0", string: "0 m", layout: "counter_center", start: 14.0, end: 14.3 },
  { id: "c_1", string: "1.000 m", layout: "counter_center", start: 14.3, end: 15.0 },
  { id: "c_2", string: "5.000 m", layout: "counter_center", start: 15.0, end: 15.6 },
  { id: "c_3", string: "11.034 m", layout: "counter_center", start: 15.6, end: 17.0 },
  { id: "t_04", string: "TEMPO", layout: "title_lower_third", start: 17.3, end: 20.0 },
  { id: "t_05", string: "ASTEROIDEN-WERFER", layout: "title_lower_third", start: 20.3, end: 23.0 },
  { id: "t_mega", string: "100 MEGATONNEN", layout: "claim_white", start: 21.8, end: 23.0, props: { y: 220 } },
  { id: "t_06", string: "PERFEKTER KREIS", layout: "title_lower_third", start: 23.3, end: 26.0 },
  { id: "t_score", string: "98 %", layout: "score_badge", start: 24.5, end: 26.0 },
  { id: "t_07", string: "LEBENSSTATISTIK", layout: "title_lower_third", start: 26.3, end: 29.0 },
  { id: "l_herz", string: "HERZSCHLÄGE", layout: "panel_label", start: 26.2, end: 29.0, props: { center: [420, 425] } },
  { id: "l_atem", string: "ATEMZÜGE", layout: "panel_label", start: 26.2, end: 29.0, props: { center: [1500, 425] } },
  { id: "l_schritte", string: "SCHRITTE", layout: "panel_label", start: 26.2, end: 29.0, props: { center: [960, 685] } },
  { id: "t_08", string: "GRÖSSE DES WELTALLS", layout: "title_lower_third", start: 29.3, end: 32.0 },
  { id: "t_brand", string: "nealarp", layout: "claim_white", start: 36.5, end: 44.0, props: { size: 144, y: 500, fadeOutFrom: 43.6 } },
  { id: "t_bald", string: "BALD VERFÜGBAR", layout: "claim_white", start: 46.0, end: 48.5 },
  { id: "t_okt", string: "AB 12. OKTOBER", layout: "claim_gradient", start: 48.5, end: 50.0 },
  { id: "t_url", string: "nealarp.vercel.app", layout: "url", start: 50.0, end: 59.0 },
  { id: "t_pill", string: "ERHÄLTLICH AB 12. OKTOBER", layout: "cta_button_label", start: 53.0, end: 59.0 },
];

// ---------------------------------------------------------- scene schedule --
export interface SceneDef {
  id: string;
  de: string;
  start: number;
  end: number;
  act: string;
}
export const SCENES: SceneDef[] = [
  { id: "opening", de: "ERÖFFNUNG", start: 0, end: 8, act: "AKT I" },
  { id: "g1", de: "GELD AUSGEBEN", start: 8, end: 11, act: "AKT II" },
  { id: "g2", de: "DAS PASSWORT-SPIEL", start: 11, end: 14, act: "AKT II" },
  { id: "g3", de: "DIE TIEFSEE", start: 14, end: 17, act: "AKT II" },
  { id: "g4", de: "TEMPO", start: 17, end: 20, act: "AKT II" },
  { id: "g5", de: "ASTEROIDEN-WERFER", start: 20, end: 23, act: "AKT II" },
  { id: "g6", de: "PERFEKTER KREIS", start: 23, end: 26, act: "AKT II" },
  { id: "g7", de: "LEBENSSTATISTIK", start: 26, end: 29, act: "AKT II" },
  { id: "g8", de: "GRÖSSE DES WELTALLS", start: 29, end: 32, act: "AKT II" },
  { id: "hero", de: "NEALARP", start: 32, end: 44, act: "AKT III" },
  { id: "cta", de: "CALL TO ACTION", start: 44, end: 60, act: "AKT IV" },
];
export const sceneAt = (t: number) =>
  SCENES.find((s) => t >= s.start && t < s.end) ?? SCENES[SCENES.length - 1];

// ---------------------------------------------------------- audio schedule --
export interface SfxEvent {
  id: string;
  at: number;
}
export const SFX: SfxEvent[] = [
  { id: "bass_drop", at: 0.0 },
  { id: "pop", at: 8.0 },
  { id: "coin", at: 8.2 }, { id: "coin", at: 8.5 }, { id: "coin", at: 8.9 }, { id: "coin", at: 9.3 },
  { id: "pop", at: 11.0 }, { id: "clunk", at: 11.4 },
  { id: "pop", at: 14.0 },
  { id: "bubble", at: 14.2 }, { id: "bubble", at: 14.55 }, { id: "bubble", at: 14.9 },
  { id: "bubble", at: 15.25 }, { id: "bubble", at: 15.6 }, { id: "bubble", at: 15.95 },
  { id: "bubble", at: 16.3 }, { id: "bubble", at: 16.65 },
  { id: "pop", at: 17.0 }, { id: "whirr", at: 17.0 },
  { id: "pop", at: 20.0 }, { id: "boom", at: 21.6 },
  { id: "pop", at: 23.0 }, { id: "pen", at: 23.0 },
  { id: "pop", at: 26.0 },
  { id: "heartbeat", at: 26.0 }, { id: "heartbeat", at: 26.833 },
  { id: "heartbeat", at: 27.667 }, { id: "heartbeat", at: 28.5 },
  { id: "pop", at: 29.0 }, { id: "whoosh", at: 29.0 },
  { id: "bass_hit", at: 44.0 },
];

export const VO: { at: number; de: string }[] = [
  { at: 0.5, de: "Alles, was du jemals im Internet machen wolltest … an einem Ort." },
  { at: 9.0, de: "Gib eine Billion Dollar aus." },
  { at: 11.5, de: "Brich jede Passwortregel." },
  { at: 14.5, de: "Tauche 11.000 Meter tief in die Tiefsee." },
  { at: 20.5, de: "Schleudere Asteroiden. Zeichne perfekte Kreise." },
  { at: 26.0, de: "Entdecke deine Lebensstatistik." },
  { at: 32.5, de: "Acht Spiele. Keine Downloads. Eine Adresse." },
  { at: 44.8, de: "Ab dem 12. Oktober erhältlich auf nealarp.vercel.app." },
];

export const BEATS = [26.0, 26.833, 27.667, 28.5];
export const BUBBLES8 = [14.2, 14.55, 14.9, 15.25, 15.6, 15.95, 16.3, 16.65];
