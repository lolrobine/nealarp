// Scene painters — pure functions of t in 1920x1080 reference space.
// Mirror of nealarp-ad/src/scenes.py.
import {
  BLUE, ORANGE, WHITE, INK, W, H,
  EASE_IO, EASE_OUT_EARLY, EXPO_OUT, win,
  TEXTS, BEATS,
} from "./timeline";
import * as E from "./engine";

type Ctx = CanvasRenderingContext2D;

// ---------------------------------------------------------------- shared ----
const F_PERSP = 900;

function cutEnvelope(t: number, s: number) {
  // pop 0-0.2 / build 0.2-0.6 / hold to +2.6 / out 2.6-3.0
  const pop = 1 + 0.03 * (1 - EASE_OUT_EARLY(win(t, s, s + 0.2)));
  const aIn = EASE_OUT_EARLY(win(t, s + 0.2, s + 0.6));
  const aOut = 1 - EASE_IO(win(t, s + 2.6, s + 3.0));
  return { scale: pop, alpha: Math.min(aIn, aOut), dy: 40 * (1 - aOut) };
}

function applyCut(ctx: Ctx, t: number, s: number, draw: () => void) {
  const { scale, alpha, dy } = cutEnvelope(t, s);
  ctx.save();
  ctx.globalAlpha *= Math.max(0, alpha);
  ctx.translate(960, 540 - dy);
  ctx.scale(scale, scale);
  ctx.translate(-960, -540);
  draw();
  ctx.restore();
}

function shakeOffset(t: number, start: number, amp: number): [number, number] {
  const d = t - start;
  if (d < 0 || d > 0.3) return [0, 0];
  const k = 1 - d / 0.3;
  return [Math.sin(t * 91) * amp * k, Math.cos(t * 83) * amp * 0.7 * k];
}

function streaksAmbient(ctx: Ctx, t: number, tag: number, count = 4, drift = 60) {
  const r0 = E.rng(tag);
  ctx.save();
  for (let i = 0; i < count; i++) {
    const y = (0.1 + r0() * 0.8) * H;
    const len = (0.15 + r0() * 0.25) * W;
    const col = i % 2 === 0 ? BLUE : ORANGE;
    const x0 = (((r0() + (t * drift) / W) % 1.3) - 0.15) * W;
    ctx.globalAlpha = 0.12 + r0() * 0.1;
    ctx.strokeStyle = col;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x0, y);
    ctx.lineTo(x0 + len, y);
    ctx.stroke();
  }
  ctx.restore();
}

function drawTitle(ctx: Ctx, id: string, t: number, pulseTimes?: number[]) {
  const e = TEXTS.find((x) => x.id === id)!;
  if (pulseTimes?.length) {
    let sc = 1;
    for (const pt of pulseTimes) {
      const d = t - pt;
      if (d >= 0 && d <= 0.2) sc = 1 + 0.08 * Math.sin((Math.PI * d) / 0.2);
    }
    ctx.save();
    ctx.translate(960, 880);
    ctx.scale(sc, sc);
    ctx.translate(-960, -880);
    E.drawLayoutText(ctx, e, t);
    ctx.restore();
  } else {
    E.drawLayoutText(ctx, e, t);
  }
}

// text point sampler for particle text forms (opening + CTA)
const pointCache = new Map<string, [number, number][]>();
export function textPoints(str: string, size: number, cx: number, cy: number, n: number): [number, number][] {
  const key = `${str}|${size}|${cx}|${cy}`;
  const hit = pointCache.get(key);
  if (hit) return hit;
  const off = document.createElement("canvas");
  off.width = 900;
  off.height = 260;
  const g = off.getContext("2d")!;
  const w = E.autofit(str, size).size;
  E.drawTracked(g, str, 450, 160, w, WHITE, 1);
  const data = g.getImageData(0, 0, 900, 260).data;
  const pts: [number, number][] = [];
  const tw = E.trackedWidth(str, w);
  for (let y = 0; y < 260; y += 3)
    for (let x = 0; x < 900; x += 3)
      if (data[(y * 900 + x) * 4 + 3] > 120)
        pts.push([cx - tw / 2 + (x - 450 + tw / 2), cy - 80 + (y - 160)]);
  const r = E.rng(73 + str.length);
  while (pts.length > n) pts.splice((r() * pts.length) | 0, 1);
  while (pts.length < n && pts.length > 0) pts.push(pts[(r() * pts.length) | 0]);
  pointCache.set(key, pts);
  return pts;
}

// ---------------------------------------------------------------- opening ---
const TUNNEL_N = 1300;
const tunnel = (() => {
  const r = E.rng(11);
  return Array.from({ length: TUNNEL_N }, (_, i) => ({
    ang: r() * Math.PI * 2,
    rad: 160 + r() * 740,
    z0: r() * 2000,
    tgt: -1,
    i,
  }));
})();
let tunnelTargets: [number, number][] = [];

export function sceneOpening(ctx: Ctx, t: number) {
  if (!tunnelTargets.length) {
    tunnelTargets = textPoints("SPIELE UND ZEUG", 180, 960, 540, 420);
    tunnel.forEach((p, i) => {
      p.tgt = i < tunnelTargets.length ? i : -1;
    });
  }
  // tunnel with perspective projection (R-VIS-09)
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (const p of tunnel) {
    const z = ((p.z0 - 1500 * t) % 2000 + 2000) % 2000;
    const k = F_PERSP / (F_PERSP + z);
    const x = Math.cos(p.ang) * p.rad;
    const y = Math.sin(p.ang) * p.rad * 0.62;
    let sx = 960 + x * k;
    let sy = 540 + y * k;
    let alpha = Math.min(1, (2000 - z) / 400) * 0.8;
    let size = Math.min(7, Math.max(0.6, 6 * k));
    let spr = Math.cos(p.ang) * p.rad < 0 ? E.SPRITES.glowBlue : E.SPRITES.glowOrange;
    if (p.tgt >= 0) {
      const delay = (p.i % 40) * 0.011;
      const c = EASE_IO(win(t, 2.0 + delay, 4.0));
      const [tx, ty] = tunnelTargets[p.tgt];
      const wob = t >= 4 ? Math.sin(t * 3 + p.i) * 1.5 : 0;
      sx += (tx - sx) * c;
      sy += (ty - sy) * c + wob;
      alpha = 0.85;
      spr = p.i % 2 ? E.SPRITES.glowBlue : E.SPRITES.glowOrange;
    }
    E.dot(ctx, sx, sy, size, spr, alpha);
  }
  // white focal point
  const fp = Math.min(1, t / 1.6);
  E.dot(ctx, 960, 540, 10 * (1 + 0.2 * Math.sin(t * 2)), E.SPRITES.glowWhite, 0.9 * fp);
  ctx.restore();

  streaksAmbient(ctx, t, 19, 6, 60);

  // title with letter stagger + gradient + motion-blur tail on final 2 letters
  const e = TEXTS.find((x) => x.id === "t_open")!;
  if (t >= e.start && t <= e.end) {
    const word = e.string;
    const { size } = E.autofit(word, 180);
    ctx.save();
    ctx.font = E.FONT(size);
    const ws: number[] = [];
    let total = 0;
    for (const ch of word) {
      const cw = ctx.measureText(ch).width;
      ws.push(cw);
      total += cw + 0.04 * size;
    }
    total -= 0.04 * size;
    let x = 960 - total / 2;
    word.split("").forEach((ch, i) => {
      const pr = EASE_IO(win(t, e.start + i * 0.045, e.start + i * 0.045 + 0.6));
      const grad = ctx.createLinearGradient(960 - total / 2, 0, 960 + total / 2, 0);
      grad.addColorStop(0, BLUE);
      grad.addColorStop(1, ORANGE);
      const fadeTail = 1 - EASE_IO(win(t, 7.55, 8.0));
      // motion-blur tail on the last two non-space letters
      const isTail = i >= word.length - 2;
      ctx.save();
      ctx.globalAlpha = pr * fadeTail;
      ctx.fillStyle = grad;
      ctx.textBaseline = "middle";
      ctx.fillText(ch, x, 540);
      if (isTail && pr > 0.15 && pr < 1) {
        for (let b = 1; b <= 3; b++) {
          ctx.globalAlpha = pr * fadeTail * 0.22 * (1 - b / 4);
          ctx.fillText(ch, x + b * 14 * (1 - pr), 540);
        }
      }
      ctx.restore();
      x += ws[i] + 0.04 * size;
    });
    ctx.restore();
    E.recordLayout(e);
  }
  E.flare(ctx, 960, 540, win(t, 2.0, 2.9));
  flicker(ctx, t, 7.55, 7.7, 0.06);
}

function flicker(ctx: Ctx, t: number, s: number, e: number, a: number) {
  if (t < s || t > e) return;
  ctx.save();
  ctx.globalAlpha = a * Math.sin(Math.PI * win(t, s, e));
  ctx.fillStyle = WHITE;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}

function flareAt(ctx: Ctx, at: number, y: number, t: number) {
  E.flare(ctx, 960, y, win(t, at, at + 0.8));
}

// ------------------------------------------------------------------ cut 1 ---
const COINS = (() => {
  const r = E.rng(21);
  return Array.from({ length: 24 }, (_, i) => ({
    x: 700 + ((i / 23) * 520 + (r() - 0.5) * 60),
    delay: r() * 0.6,
    d: 80 + r() * 30,
    spin: r() * 6,
  })).sort((a, b) => a.x - b.x);
})();

function glass(ctx: Ctx, x: number, y: number, w: number, h: number, r: number, alpha: number) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  E.roundRect(ctx, x, y, w, h, r);
  ctx.fillStyle = "rgba(255,255,255,0.10)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.25)";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.restore();
}

export function sceneWallet(ctx: Ctx, t: number) {
  applyCut(ctx, t, 8, () => {
    glass(ctx, 660, 260, 600, 380, 28, EASE_OUT_EARLY(win(t, 8.3, 8.8)));
    for (let i = 0; i < COINS.length; i++) {
      const c = COINS[i];
      const pr = EASE_IO(win(t, 8 + c.delay, 8 + c.delay + 1.1));
      const y = -100 + (420 - -100) * pr;
      const wob = Math.sin(t * 2.4 + c.spin) * 0.35;
      const squash = Math.max(0.3, Math.abs(Math.cos(wob)));
      ctx.save();
      ctx.translate(c.x, y);
      ctx.scale(squash, 1);
      // chrome coin: white core -> blue -> 2px orange rim
      const g = ctx.createRadialGradient(-c.d * 0.15, -c.d * 0.2, c.d * 0.05, 0, 0, c.d * 0.55);
      g.addColorStop(0, WHITE);
      g.addColorStop(0.45, "#9dbcff");
      g.addColorStop(0.9, BLUE);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(0, 0, c.d / 2, c.d / 2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = ORANGE;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
      E.dot(ctx, c.x, y, c.d * 0.8, E.SPRITES.glowBlue, 0.14);
    }
  });
  drawTitle(ctx, "t_01", t);
  flareAt(ctx, 8.3, 880, t);
}

// ------------------------------------------------------------------ cut 2 ---
const RULES = (() => {
  const r = E.rng(31);
  const glyphs = "01#$%&*+=?/\\ABCFG";
  return Array.from({ length: 14 }, () =>
    Array.from({ length: 26 }, () => glyphs[(r() * glyphs.length) | 0]).join(""));
})();

export function scenePasswort(ctx: Ctx, t: number) {
  const [sx, sy] = shakeOffset(t, 11.4, 10);
  ctx.save();
  ctx.translate(sx, sy);
  applyCut(ctx, t, 11, () => {
    const build = EXPO_OUT(win(t, 11.2, 11.7));
    const click = EXPO_OUT(win(t, 11.4, 11.4 + 0.15));
    const sc = build * (1.04 - 0.04 * click);
    ctx.save();
    ctx.translate(960, 430);
    ctx.scale(sc, sc);
    ctx.translate(-960, -430);
    // shackle
    ctx.strokeStyle = WHITE;
    ctx.lineWidth = 28;
    ctx.beginPath();
    ctx.arc(960, 300, 110, Math.PI, Math.PI * 2);
    ctx.stroke();
    // body
    ctx.save();
    ctx.shadowColor = BLUE;
    ctx.shadowBlur = 16;
    E.roundRect(ctx, 800, 300, 320, 260, 32);
    const g = ctx.createLinearGradient(800, 300, 800, 560);
    g.addColorStop(0, WHITE);
    g.addColorStop(1, "#bcd3ff");
    ctx.fillStyle = g;
    ctx.fill();
    ctx.restore();
    // scrolling rule glyphs clipped to body
    ctx.save();
    E.roundRect(ctx, 800, 300, 320, 260, 32);
    ctx.clip();
    ctx.font = E.MONO(10);
    ctx.globalAlpha = 0.4;
    ctx.fillStyle = INK;
    const rowH = 10 * 1.9;
    const off = (t * 120) % rowH;
    for (let i = -1; i <= 15; i++) {
      ctx.fillText(RULES[((i % RULES.length) + RULES.length) % RULES.length], 814, 300 + 18 + i * rowH - off);
    }
    ctx.restore();
    ctx.restore();
    // five orange check circles
    const n = 5, rr = 36;
    const totalW = n * rr * 2 + (n - 1) * rr * 0.6;
    [12.0, 12.2, 12.4, 12.6, 12.8].forEach((at, i) => {
      const pr = EASE_OUT_EARLY(win(t, at, at + 0.25));
      if (pr <= 0) return;
      const x = 960 - totalW / 2 + rr + i * rr * 2.6;
      ctx.save();
      ctx.shadowColor = ORANGE;
      ctx.shadowBlur = 18;
      ctx.strokeStyle = ORANGE;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(x, 430 + 190, rr * pr, 0, Math.PI * 2);
      ctx.stroke();
      if (pr > 0.6) {
        ctx.beginPath();
        ctx.moveTo(x - 16, 620);
        ctx.lineTo(x - 3, 633);
        ctx.lineTo(x + 18, 607);
        ctx.stroke();
      }
      ctx.restore();
    });
  });
  drawTitle(ctx, "t_02", t);
  flareAt(ctx, 11.3, 880, t);
  ctx.restore();
}

// ------------------------------------------------------------------ cut 3 ---
const DIVE = (() => {
  const r = E.rng(41);
  return Array.from({ length: 420 }, () => ({
    x: r() * W, y0: r() * H, sp: 0.6 + r() * 0.8, s: 1.5 + r() * 3.5, c: r() < 0.7,
  }));
})();
const CREATURES = (() => {
  const r = E.rng(43);
  return Array.from({ length: 12 }, () => ({
    x: 120 + r() * 1680, y: 180 + r() * 620, w: 60 + r() * 80,
    color: r() < 0.7 ? 0 : 1, ph: r() * 6.28, z: r() * 2000,
  }));
})();
const BUBS = (() => {
  const r = E.rng(47);
  return Array.from({ length: 60 }, () => ({
    x: r() * W, y0: r() * H, sp: 80 + r() * 80, rr: 4 + r() * 10,
  }));
})();

const DEPTH_STEPS: [number, number][] = [[14.0, 0], [14.3, 1000], [15.0, 5000], [15.6, 11034]];
function depthAt(t: number): number {
  let v = DEPTH_STEPS[0][1];
  for (let i = 0; i < DEPTH_STEPS.length; i++) {
    const [ts, tv] = DEPTH_STEPS[i];
    if (t >= ts) {
      const nxt = DEPTH_STEPS[i + 1];
      if (nxt && t >= nxt[0]) continue;
      if (nxt) v = tv + (nxt[1] - tv) * EASE_IO(win(t, nxt[0], nxt[0] + 0.3));
      else v = tv;
    }
  }
  return v;
}
const fmtDe = (v: number) => v.toLocaleString("de-DE", { maximumFractionDigits: 0 });

export function sceneTiefsee(ctx: Ctx, t: number) {
  // vertical gradient: ink -> blue 12% at bottom
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, "rgba(59,130,246,0)");
  g.addColorStop(1, "rgba(59,130,246,0.12)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  applyCut(ctx, t, 14, () => {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const p of DIVE) {
      const y = (((p.y0 - t * 1200 * p.sp) % (H + 100)) + H + 100) % (H + 100) - 50;
      E.dot(ctx, p.x, y, p.s, p.c ? E.SPRITES.glowBlue : E.SPRITES.glowWhite, 0.5);
    }
    ctx.restore();
    for (const c of CREATURES) {
      const bob = Math.sin(t * 0.9 + c.ph) * 14;
      const k = F_PERSP / (F_PERSP + c.z);
      ctx.save();
      ctx.translate(480 + (c.x - 480) * k + 480 * (1 - k), c.y * k + 160 * (1 - k) + bob);
      ctx.scale(k, k);
      ctx.shadowBlur = 22;
      ctx.shadowColor = c.color ? ORANGE : BLUE;
      E.roundRect(ctx, -c.w / 2, -c.w * 0.27, c.w, c.w * 0.55, c.w * 0.27);
      ctx.fillStyle = c.color ? ORANGE : BLUE;
      ctx.globalAlpha = 0.85;
      ctx.fill();
      ctx.fillStyle = WHITE;
      ctx.beginPath();
      ctx.ellipse(c.w * 0.08, 0, c.w * 0.1, c.w * 0.1, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    for (const b of BUBS) {
      const y = (((b.y0 - b.sp * t) % (H + 60)) + H + 60) % (H + 60) - 30;
      ctx.beginPath();
      ctx.arc(b.x, y, b.rr, 0, Math.PI * 2);
      ctx.globalAlpha = 0.45;
      ctx.stroke();
    }
    ctx.restore();
    // depth counter (transient digits between the declared strings)
    const v = depthAt(t);
    E.drawTracked(ctx, `${fmtDe(v)} m`, 960, 520 + 60, 160, WHITE, 1);
  });
  drawTitle(ctx, "t_03", t);
  flareAt(ctx, 14.3, 880, t);
}

// ------------------------------------------------------------------ cut 4 ---
const T_STREAKS = (() => {
  const r = E.rng(53);
  return Array.from({ length: 40 }, () => ({
    x: r() * (W + 600), y: r() * H, ln: 200 + r() * 400,
  }));
})();

function drawGlyph(ctx: Ctx, kind: string, t: number, start: number, end: number) {
  const aIn = EASE_IO(win(t, start, start + 0.15));
  const aOut = 1 - EASE_IO(win(t, end - 0.15, end));
  const a = Math.min(aIn, aOut);
  if (a <= 0) return;
  ctx.save();
  ctx.globalAlpha = a;
  ctx.translate(960, 350);
  ctx.lineWidth = 6;
  if (kind === "snail") {
    ctx.strokeStyle = ORANGE;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(0, 0, 22 + 20 * i, -Math.PI / 2 + 0.7 * i, Math.PI * 1.5);
      ctx.stroke();
    }
  } else if (kind === "cheetah") {
    [0.1, 0.16, 0.22].forEach((rr, i) => {
      ctx.fillStyle = BLUE;
      ctx.beginPath();
      ctx.arc(-50 + i * 44, 0, rr * 50, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.fillStyle = ORANGE;
    ctx.beginPath();
    ctx.moveTo(80, -24);
    ctx.lineTo(120, 0);
    ctx.lineTo(80, 24);
    ctx.fill();
  } else if (kind === "rocket") {
    ctx.fillStyle = WHITE;
    ctx.fillRect(-18, -8, 36, 60);
    ctx.fillStyle = ORANGE;
    ctx.beginPath();
    ctx.moveTo(-26, -8);
    ctx.lineTo(26, -8);
    ctx.lineTo(0, -58);
    ctx.fill();
  } else {
    const g = ctx.createLinearGradient(0, -70, 0, 70);
    g.addColorStop(0, "rgba(59,130,246,0)");
    g.addColorStop(0.5, WHITE);
    g.addColorStop(1, "rgba(249,115,22,0)");
    ctx.fillStyle = g;
    ctx.fillRect(-4, -70, 8, 140);
    ctx.fillStyle = BLUE;
    ctx.beginPath();
    ctx.arc(0, -70, 10, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function sceneTempo(ctx: Ctx, t: number) {
  applyCut(ctx, t, 17, () => {
    // streaks under everything
    ctx.save();
    for (const st of T_STREAKS) {
      const x = (((st.x - t * 2400) % (W + 700)) + W + 700) % (W + 700) - 350;
      const g = ctx.createLinearGradient(x, 0, x + st.ln, 0);
      g.addColorStop(0, "rgba(255,255,255,0)");
      g.addColorStop(1, "rgba(255,255,255,0.3)");
      ctx.fillStyle = g;
      ctx.fillRect(x, st.y, st.ln, 2);
    }
    ctx.restore();
    // speedometer: arc 210 -> -30, needle EXPO_OUT 17.2 + 1.2s
    ctx.strokeStyle = BLUE;
    ctx.lineWidth = 10;
    ctx.beginPath();
    // 210° -> -30° over the top (240° sweep), anticlockwise
    ctx.arc(960, 470, 300, (210 * Math.PI) / 180, (-30 * Math.PI) / 180, true);
    ctx.stroke();
    for (let i = 0; i <= 12; i++) {
      const ang = ((210 + (-30 - 210) * (i / 12)) * Math.PI) / 180;
      ctx.strokeStyle = "rgba(255,255,255,0.6)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(960 + Math.cos(ang) * 282, 470 + Math.sin(ang) * 282);
      ctx.lineTo(960 + Math.cos(ang) * 308, 470 + Math.sin(ang) * 308);
      ctx.stroke();
    }
    const prog = EXPO_OUT(win(t, 17.2, 17.2 + 1.2));
    const ang = ((210 + (-30 - 210) * prog) * Math.PI) / 180;
    ctx.strokeStyle = WHITE;
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(960, 470);
    ctx.lineTo(960 + Math.cos(ang) * 260, 470 + Math.sin(ang) * 260);
    ctx.stroke();
    ctx.fillStyle = ORANGE;
    ctx.beginPath();
    ctx.arc(960, 470, 14, 0, Math.PI * 2);
    ctx.fill();
    // morphs
    drawGlyph(ctx, "snail", t, 17.2, 17.8);
    drawGlyph(ctx, "cheetah", t, 17.8, 18.4);
    drawGlyph(ctx, "rocket", t, 18.4, 19.0);
    drawGlyph(ctx, "light", t, 19.0, 19.6);
  });
  drawTitle(ctx, "t_04", t, [17.2, 17.8, 18.4, 19.0]);
  flareAt(ctx, 17.3, 880, t);
}

// ------------------------------------------------------------------ cut 5 ---
export function sceneAsteroiden(ctx: Ctx, t: number) {
  const [sx, sy] = shakeOffset(t, 21.6, 14);
  ctx.save();
  ctx.translate(sx, sy);
  applyCut(ctx, t, 20, () => {
    // earth — radial blue + 2px orange atmosphere
    const eg = ctx.createRadialGradient(880, 480, 40, 960, 560, 210);
    eg.addColorStop(0, "#bcd3ff");
    eg.addColorStop(0.5, BLUE);
    eg.addColorStop(1, "#14244d");
    ctx.fillStyle = eg;
    ctx.beginPath();
    ctx.arc(960, 560, 210, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = ORANGE;
    ctx.lineWidth = 2;
    ctx.stroke();
    // meteor with orange trail (alpha 1 -> 0)
    const pr = EASE_IO(win(t, 20.4, 21.6));
    if (pr > 0) {
      const x = 1500 + (1000 - 1500) * pr;
      const y = 60 + (470 - 60) * pr;
      for (let k = 0; k < 22; k++) {
        const f = k / 22;
        const bx = x + (1500 - x) * f * 0.35;
        const by = y + (60 - y) * f * 0.35;
        ctx.globalAlpha = (1 - f) * pr;
        ctx.fillStyle = ORANGE;
        ctx.beginPath();
        ctx.arc(bx, by, 10 * (1 - f) + 2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.fillStyle = WHITE;
      ctx.beginPath();
      ctx.arc(x, y, 14, 0, Math.PI * 2);
      ctx.fill();
    }
    // impact: crater + shockwave rings
    if (t >= 21.6) {
      const cp = EASE_OUT_EARLY(win(t, 21.6, 21.85));
      ctx.fillStyle = INK;
      ctx.beginPath();
      ctx.ellipse(1000, 470, 120 * cp, 42 * cp, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = BLUE;
      ctx.lineWidth = 3;
      ctx.stroke();
      for (let i = 0; i < 5; i++) {
        const rp = EXPO_OUT(win(t, 21.6 + i * 0.07, 21.6 + i * 0.07 + 1.5));
        if (rp <= 0 || rp >= 1) continue;
        ctx.globalAlpha = (1 - rp) * (1 - i * 0.12);
        ctx.strokeStyle = ORANGE;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(1000, 470, 700 * rp * (1 - i * 0.07), 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
  });
  E.drawLayoutText(ctx, TEXTS.find((x) => x.id === "t_mega")!, t);
  drawTitle(ctx, "t_05", t);
  flareAt(ctx, 20.3, 880, t);
  ctx.restore();
}

// ------------------------------------------------------------------ cut 6 ---
export function sceneKreis(ctx: Ctx, t: number) {
  applyCut(ctx, t, 23, () => {
    const pr = EASE_IO(win(t, 23.0, 23.0 + 1.2));
    const deg = 360 * pr;
    ctx.strokeStyle = ORANGE;
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.arc(960, 470, 220, -Math.PI / 2, -Math.PI / 2 + (deg * Math.PI) / 180);
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,0.4)";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(960, 470, 204, -Math.PI / 2, -Math.PI / 2 + (deg * Math.PI) / 180);
    ctx.stroke();
    const tip = (-90 + deg) * (Math.PI / 180);
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.arc(960 + 220 * Math.cos(tip), 470 + 220 * Math.sin(tip), 10, 0, Math.PI * 2);
    ctx.fill();
    // dashed guide ring at 24.2
    const ga = EASE_OUT_EARLY(win(t, 24.2, 24.5));
    if (ga > 0) {
      ctx.save();
      ctx.globalAlpha = 0.5 * ga;
      ctx.strokeStyle = WHITE;
      ctx.lineWidth = 2;
      ctx.setLineDash([12, 10]);
      ctx.beginPath();
      ctx.arc(960, 470, 220, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  });
  E.drawLayoutText(ctx, TEXTS.find((x) => x.id === "t_score")!, t);
  drawTitle(ctx, "t_06", t);
  flareAt(ctx, 23.3, 880, t);
}

// ------------------------------------------------------------------ cut 7 ---
const STAT_TARGETS = [3250000000, 780000000, 180000000];

export function sceneStats(ctx: Ctx, t: number) {
  applyCut(ctx, t, 26, () => {
    const fade = EASE_OUT_EARLY(win(t, 26.2, 26.6));
    // heart
    let hs = 1;
    for (const b of BEATS) {
      const d = t - b;
      if (d >= 0 && d < 0.5) hs = 1 + 0.12 * Math.sin((Math.PI * d) / 0.5);
    }
    ctx.save();
    ctx.translate(960, 280);
    ctx.scale(hs, hs);
    ctx.shadowColor = BLUE;
    ctx.shadowBlur = 26;
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.arc(-25, -10, 24, 0, Math.PI * 2);
    ctx.arc(25, -10, 24, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-46, 2);
    ctx.lineTo(46, 2);
    ctx.lineTo(0, 58);
    ctx.fill();
    ctx.restore();
    // pulse rings per beat
    for (const b of BEATS) {
      const rp = EASE_IO(win(t, b, b + 0.833));
      if (rp <= 0 || rp >= 1) continue;
      ctx.globalAlpha = (1 - rp) * 0.8;
      ctx.strokeStyle = BLUE;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(960, 280, 600 * rp * 0.55, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
    // panels + transient counters
    const panels: [number, number, number, number][] = [[200, 380, 440, 180], [1280, 380, 440, 180], [760, 640, 400, 180]];
    panels.forEach((r) => glass(ctx, r[0], r[1], r[2], r[3], 24, fade));
    const build = EASE_IO(win(t, 26.2, 27.8));
    ctx.save();
    ctx.globalAlpha = fade;
    STAT_TARGETS.forEach((target, i) => {
      const r = panels[i];
      const v = Math.round(target * build);
      E.drawTracked(ctx, fmtDe(v), r[0] + r[2] / 2, r[1] + 118, 60, WHITE, 1);
    });
    ctx.restore();
  });
  ["l_herz", "l_atem", "l_schritte"].forEach((id) =>
    E.drawLayoutText(ctx, TEXTS.find((x) => x.id === id)!, t));
  drawTitle(ctx, "t_07", t);
  flareAt(ctx, 26.3, 880, t);
}

// ------------------------------------------------------------------ cut 8 ---
const GALAXY = (() => {
  const r = E.rng(61);
  return Array.from({ length: 2000 }, () => {
    const rad = Math.pow(r(), 1.02) * 660;
    const ang = r() * Math.PI * 4;
    return { arm: (ang * 3 + rad / 90) % (Math.PI * 2), rad, s: 0.8 + r() * 1.8, b: r() < 0.5 };
  });
})();

function stageShape(ctx: Ctx, kind: string, bb: number, alpha: number) {
  ctx.save();
  ctx.globalAlpha = Math.min(1, alpha);
  ctx.translate(960, 540);
  if (kind === "human") {
    const hh = 260 * bb;
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.arc(0, -hh / 2, hh * 0.16, 0, Math.PI * 2);
    ctx.fill();
    E.roundRect(ctx, -hh * 0.15, -hh / 2 + hh * 0.2, hh * 0.3, hh, hh * 0.08);
    ctx.fill();
  } else if (kind === "building") {
    const bw = 300 * bb, bh = 340 * bb;
    ctx.fillStyle = BLUE;
    ctx.fillRect(-bw / 2, -bh / 2, bw, bh);
    ctx.fillStyle = INK;
    for (let rI = 0; rI < 4; rI++)
      for (let cI = 0; cI < 3; cI++)
        ctx.fillRect(-bw / 2 + bw * (0.15 + cI * 0.3), -bh / 2 + bh * (0.12 + rI * 0.24), bw * 0.12, bh * 0.1);
  } else if (kind === "mountain") {
    const bw = 520 * bb, bh = 300 * bb;
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.moveTo(-bw / 2, bh / 2);
    ctx.lineTo(0, -bh / 2);
    ctx.lineTo(bw / 2, bh / 2);
    ctx.fill();
    ctx.fillStyle = BLUE;
    ctx.beginPath();
    ctx.moveTo(-bw * 0.13, -bh * 0.28);
    ctx.lineTo(0, -bh / 2);
    ctx.lineTo(bw * 0.13, -bh * 0.28);
    ctx.fill();
  } else if (kind === "earth") {
    const rr = 190 * bb;
    const g = ctx.createRadialGradient(-rr * 0.3, -rr * 0.3, rr * 0.1, 0, 0, rr);
    g.addColorStop(0, "#bcd3ff");
    g.addColorStop(1, BLUE);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, rr, 0, Math.PI * 2);
    ctx.fill();
  } else if (kind === "sun") {
    const rr = 200 * bb;
    ctx.shadowColor = ORANGE;
    ctx.shadowBlur = 60 * bb;
    ctx.fillStyle = ORANGE;
    ctx.beginPath();
    ctx.arc(0, 0, rr, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.arc(0, 0, rr * 0.42, 0, Math.PI * 2);
    ctx.fill();
  } else if (kind === "galaxy") {
    ctx.globalCompositeOperation = "lighter";
    for (const p of GALAXY) {
      const f = p.rad / 660;
      const spr = f < 0.25 ? E.SPRITES.glowWhite : p.b ? E.SPRITES.glowBlue : E.SPRITES.glowOrange;
      E.dot(ctx, Math.cos(p.arm) * p.rad * bb, Math.sin(p.arm) * p.rad * 0.42 * bb, p.s * 2.4 * bb, spr, 0.85);
    }
  }
  ctx.restore();
}

const STAGES = ["human", "building", "mountain", "earth", "sun", "galaxy"];

export function sceneWeltall(ctx: Ctx, t: number) {
  applyCut(ctx, t, 29, () => {
    const dur = 0.417;
    const idx = Math.min(STAGES.length - 1, Math.floor((t - 29) / dur));
    const local = (t - 29) / dur - idx;
    const tr = EXPO_OUT(win(local * dur, dur - 0.25, dur));
    const cur = STAGES[idx];
    const nxt = STAGES[idx + 1] as string | undefined;
    if (nxt && tr > 0) {
      stageShape(ctx, cur, 1 + 9 * tr, 1 - tr);
      stageShape(ctx, nxt, 0.12 + 0.88 * tr, tr);
    } else {
      stageShape(ctx, cur, 1, 1);
    }
    // telescope drawn 29.5-30.0 (stroke 6)
    const pr = EASE_IO(win(t, 29.5, 30.0));
    if (pr > 0) {
      ctx.save();
      ctx.translate(960, 180);
      ctx.strokeStyle = WHITE;
      ctx.lineWidth = 6;
      ctx.lineCap = "round";
      const parts: [number, number, number, number, number][] = [
        [-36, -10, 30, -36, 16],
        [0, -22, 0, 0, 6],
        [0, 0, -30, 52, 6],
        [0, 0, 30, 52, 6],
      ];
      parts.forEach((p, i) => {
        const f = Math.max(0, Math.min(1, pr * parts.length - i));
        if (f <= 0) return;
        ctx.lineWidth = p[4];
        ctx.beginPath();
        ctx.moveTo(p[0], p[1]);
        ctx.lineTo(p[0] + (p[2] - p[0]) * f, p[1] + (p[3] - p[1]) * f);
        ctx.stroke();
      });
      ctx.restore();
    }
  });
  drawTitle(ctx, "t_08", t);
  flareAt(ctx, 29.3, 880, t);
}

// ------------------------------------------------------------------- hero ---
const ORBIT_KINDS = ["coin", "lock", "creature", "speedo", "heart", "ring", "planet", "meteor"];

function orbiterIcon(ctx: Ctx, kind: string, x: number, y: number, sc: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(sc, sc);
  ctx.lineWidth = 5;
  if (kind === "coin") {
    ctx.fillStyle = BLUE;
    ctx.beginPath(); ctx.arc(0, 0, 22, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = ORANGE; ctx.lineWidth = 2; ctx.stroke();
  } else if (kind === "lock") {
    ctx.fillStyle = WHITE;
    E.roundRect(ctx, -18, -4, 36, 26, 6); ctx.fill();
    ctx.strokeStyle = ORANGE;
    ctx.beginPath(); ctx.arc(0, -4, 12, Math.PI, Math.PI * 2); ctx.stroke();
  } else if (kind === "creature") {
    ctx.fillStyle = ORANGE;
    E.roundRect(ctx, -24, -12, 48, 24, 12); ctx.fill();
  } else if (kind === "speedo") {
    ctx.strokeStyle = BLUE;
    ctx.beginPath(); ctx.arc(0, 0, 22, Math.PI * 0.85, Math.PI * 2.15); ctx.stroke();
    ctx.strokeStyle = WHITE; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(12, -14); ctx.stroke();
  } else if (kind === "heart") {
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.arc(-7, -4, 8, 0, Math.PI * 2); ctx.arc(7, -4, 8, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(14, 0); ctx.lineTo(0, 14); ctx.fill();
  } else if (kind === "ring") {
    ctx.strokeStyle = ORANGE;
    ctx.beginPath(); ctx.arc(0, 0, 20, 0, Math.PI * 2); ctx.stroke();
  } else if (kind === "planet") {
    ctx.fillStyle = BLUE;
    ctx.beginPath(); ctx.arc(0, 0, 20, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = ORANGE; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.ellipse(0, 6, 28, 8, 0, Math.PI, Math.PI * 2); ctx.stroke();
  } else {
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.arc(0, 0, 9, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = ORANGE;
    ctx.beginPath(); ctx.moveTo(4, 4); ctx.lineTo(26, -20); ctx.stroke();
  }
  ctx.restore();
}

export function sceneHero(ctx: Ctx, t: number) {
  streaksAmbient(ctx, t, 97, 4, 40);
  const push = 1 + 0.15 * EASE_IO(win(t, 32, 44));
  const pulse = 1 + 0.03 * Math.sin(2 * Math.PI * 0.5 * t);
  const r = 200 * pulse * push;
  // glow
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  E.dot(ctx, 960, 500, r * 1.9, E.SPRITES.glowBlue, 0.25);
  ctx.restore();
  // sphere: radial white core -> blue -> orange
  const g = ctx.createRadialGradient(960, 500, r * 0.05, 960, 500, r);
  g.addColorStop(0, WHITE);
  g.addColorStop(0.45, "#9dbcff");
  g.addColorStop(0.62, BLUE);
  g.addColorStop(1, ORANGE);
  ctx.save();
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(960, 500, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  // 8 orbiters, rings 420 / 560, alternating direction, 0.3 rad/s
  ORBIT_KINDS.forEach((kind, i) => {
    const ring = i < 4 ? 420 : 560;
    const dir = i % 2 === 0 ? 1 : -1;
    const ang = (i / 8) * Math.PI * 2 + dir * 0.3 * t;
    const x = 960 + Math.cos(ang) * ring * push;
    const y = 500 + Math.sin(ang) * ring * 0.62 * push;
    orbiterIcon(ctx, kind, x, y, push);
  });
  E.drawLayoutText(ctx, TEXTS.find((x) => x.id === "t_brand")!, t);
  E.flare(ctx, 960, 500, win(t, 36.5, 37.3));
  flicker(ctx, t, 43.55, 43.7, 0.06);
}

// -------------------------------------------------------------------- cta ---
const EXP_N = 3000;
const EXP = (() => {
  const r = E.rng(71);
  return Array.from({ length: EXP_N }, (_, i) => ({
    ang: r() * Math.PI * 2,
    sp: 300 + r() * 1300,
    s: 2 + r() * 7,
    c: i % 2,
  }));
})();
const DRIFT = (() => {
  const r = E.rng(79);
  return Array.from({ length: 360 }, () => ({ x: r() * W, y: r() * H, ph: r() * 6.28, c: r() < 0.5 }));
})();

let ctaTargets: Record<string, [number, number][]> = {};
function ensureCtaTargets() {
  if (ctaTargets.bald) return;
  ctaTargets = {
    bald: textPoints("BALD VERFÜGBAR", 112, 960, 540, EXP_N),
    okt: textPoints("AB 12. OKTOBER", 96, 960, 540, EXP_N),
    url: textPoints("nealarp.vercel.app", 72, 960, 600, EXP_N),
  };
}

export function sceneCta(ctx: Ctx, t: number) {
  ensureCtaTargets();
  // ambient drift
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (const p of DRIFT) {
    const x = (p.x + Math.sin(t * 0.3 + p.ph) * 30 + t * 25) % W;
    const y = p.y + Math.cos(t * 0.23 + p.ph) * 22;
    E.dot(ctx, x, y, 2.4, p.c ? E.SPRITES.glowBlue : E.SPRITES.glowOrange, 0.45);
  }
  ctx.restore();

  // explosion 44 -> 46 (start positions for the first form)
  const prog = EASE_OUT_EARLY(win(t, 44, 46));
  const pos: number[][] = [];
  const life = 1 - EASE_IO(win(t, 44.4, 46));
  for (const p of EXP) {
    const d = p.sp * prog;
    pos.push([960 + Math.cos(p.ang) * d, 500 + Math.sin(p.ang) * d * 0.8, Math.max(0.3, p.s * life), p.c]);
  }

  // particle text forms: bald (45.5+1.0), okt (48.5+0.7), url (50+0.7)
  type Form = { key: "bald" | "okt" | "url"; start: number; dur: number; fill: "white" | "grad" | "particlesBlueOrange" };
  const forms: Form[] = [
    { key: "bald", start: 45.5, dur: 1.0, fill: "particlesBlueOrange" },
    { key: "okt", start: 48.5, dur: 0.7, fill: "grad" },
    { key: "url", start: 50.0, dur: 0.7, fill: "white" },
  ];
  let startPts: number[][] | null = pos;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (const f of forms) {
    const targets = ctaTargets[f.key];
    const pr = EASE_IO(win(t, f.start, f.start + f.dur));
    const holdOut = f.key === "bald" ? 1 - EASE_IO(win(t, 48.5, 49.2))
      : f.key === "okt" ? 1 - EASE_IO(win(t, 50.0, 50.7)) : 1;
    if (pr <= 0 || holdOut <= 0) { startPts = null; continue; }
    for (let i = 0; i < EXP_N && i < targets.length; i++) {
      const src = startPts ? startPts[i] : pos[i];
      const tx = targets[i][0], ty2 = targets[i][1];
      const x = src[0] + (tx - src[0]) * pr;
      const y = src[1] + (ty2 - src[1]) * pr;
      const size = Math.max(0.4, 3.2 * (0.3 + 0.7 * pr)) + (src[2] ?? 0) * (1 - pr);
      let spr = E.SPRITES.glowWhite;
      let alpha = 0.75 * holdOut;
      if (f.fill === "particlesBlueOrange") spr = i % 2 ? E.SPRITES.glowBlue : E.SPRITES.glowOrange;
      else if (f.fill === "grad") spr = tx < 960 ? E.SPRITES.glowBlue : E.SPRITES.glowOrange;
      E.dot(ctx, x, y, size, spr, alpha);
    }
    break; // only the first active form draws (chronological)
  }
  ctx.restore();

  // crisp text layers (R-TXT-02: through the layout system, logged)
  ["t_bald", "t_okt", "t_url"].forEach((id) =>
    E.drawLayoutText(ctx, TEXTS.find((x) => x.id === id)!, t));

  // underline sweep 51.5-52.5 (1.0 s)
  const up = EASE_IO(win(t, 51.5, 52.5));
  if (up > 0) {
    const g = ctx.createLinearGradient(560, 0, 1360, 0);
    g.addColorStop(0, BLUE);
    g.addColorStop(1, ORANGE);
    ctx.save();
    ctx.fillStyle = g;
    ctx.fillRect(560, 660, 800 * up, 8);
    ctx.restore();
  }

  // pill 53 -> 55 fade, pulse at 55
  const fadeP = EASE_OUT_EARLY(win(t, 53, 55));
  let pillS = 1;
  if (t >= 55 && t <= 55.4) pillS = 1 + 0.06 * Math.sin((Math.PI * (t - 55)) / 0.4);
  if (fadeP > 0) {
    ctx.save();
    ctx.globalAlpha = fadeP;
    ctx.translate(960, 780);
    ctx.scale(pillS, pillS);
    E.roundRect(ctx, -500, -60, 1000, 120, 60);
    ctx.fillStyle = ORANGE;
    ctx.fill();
    ctx.restore();
  }
  E.drawLayoutText(ctx, TEXTS.find((x) => x.id === "t_pill")!, t);

  // slow push-out 55-59
  const po = EASE_IO(win(t, 55, 59));
  if (po > 0) {
    ctx.save();
    ctx.globalCompositeOperation = "destination-over";
    ctx.restore();
  }
  // fade to black 59-60 (drawn in frame post, here for completeness)
  const fb = EASE_IO(win(t, 59, 60));
  if (fb > 0) {
    ctx.save();
    ctx.globalAlpha = fb;
    ctx.fillStyle = INK;
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }
  flicker(ctx, t, 58.55, 58.7, 0.05);
}

// push-out needs whole-frame scale — handled in frame(): cta scale wrapper.
export { win as _win };
