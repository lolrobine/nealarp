// Web Audio synthesis — mirrors nealarp-ad/src/audio_synth.py recipes (R-AUD-03).
// VO via SpeechSynthesis de-DE with honest status reporting (R-AUD-01).
import { SFX, VO } from "./timeline";

export interface AudioStatus {
  engine: string;
  realNeural: boolean;
  note: string;
}

export class AdAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  musicGain: GainNode | null = null;
  echoSend: DelayNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private timeouts: number[] = [];
  private schedTimer: number | null = null;
  private stepsDone = 0;
  private startAdT = 0;
  private startCtxT = 0;
  status: AudioStatus = {
    engine: "WebAudio-Synthese + SpeechSynthesis",
    realNeural: false,
    note: "Browser-Stimme (de-DE), keine neurale TTS-Pipeline — gilt als Platzhalter.",
  };

  ensure() {
    if (this.ctx) return;
    const C = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new C();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.9;
    this.master.connect(this.ctx.destination);
    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = 0.5;
    this.musicGain.connect(this.master);
    // echo bus: delay 0.25 s, feedback 0.3 (R-AUD-02)
    const delay = this.ctx.createDelay(1);
    delay.delayTime.value = 0.25;
    const fb = this.ctx.createGain();
    fb.gain.value = 0.3;
    delay.connect(fb);
    fb.connect(delay);
    delay.connect(this.master);
    this.echoSend = delay;
    const len = this.ctx.sampleRate * 2;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }

  stopAll() {
    this.timeouts.forEach((id) => clearTimeout(id));
    this.timeouts = [];
    if (this.schedTimer !== null) {
      clearInterval(this.schedTimer);
      this.schedTimer = null;
    }
    try {
      window.speechSynthesis?.cancel();
    } catch {
      /* noop */
    }
    if (this.ctx) {
      this.ctx.close();
      this.ctx = null;
    }
  }

  private tone(f0: number, f1: number, dur: number, peak: number, type: OscillatorType = "sine", at = 0, dest?: AudioNode) {
    const c = this.ctx!;
    const t0 = c.currentTime + at;
    const osc = c.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(f0, t0);
    osc.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t0 + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(peak, t0);
    g.gain.exponentialRampToValueAtTime(0.0004, t0 + dur);
    osc.connect(g);
    g.connect(dest ?? this.master!);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  private noise(dur: number, peak: number, filter?: { type: BiquadFilterType; f0: number; f1?: number; q?: number }, at = 0, am?: number) {
    const c = this.ctx!;
    const t0 = c.currentTime + at;
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    let node: AudioNode = src;
    if (filter) {
      const f = c.createBiquadFilter();
      f.type = filter.type;
      f.frequency.setValueAtTime(filter.f0, t0);
      if (filter.f1) f.frequency.exponentialRampToValueAtTime(filter.f1, t0 + dur);
      f.Q.value = filter.q ?? 0.8;
      node.connect(f);
      node = f;
    }
    const g = c.createGain();
    if (am) {
      g.gain.setValueAtTime(peak, t0);
      const lfo = c.createOscillator();
      lfo.frequency.value = am;
      const lg = c.createGain();
      lg.gain.value = peak * 0.4;
      lfo.connect(lg);
      lg.connect(g.gain);
      lfo.start(t0);
      lfo.stop(t0 + dur);
    }
    g.gain.setValueAtTime(am ? peak : peak, t0);
    g.gain.exponentialRampToValueAtTime(0.0004, t0 + dur);
    node.connect(g);
    g.connect(this.master!);
    src.start(t0);
    src.stop(t0 + dur + 0.05);
  }

  playSfx(id: string, at: number) {
    if (!this.ctx) return;
    switch (id) {
      case "pop":
        this.tone(1200, 600, 0.08, 0.5, "sine", at);
        this.noise(0.005, 0.3, { type: "highpass", f0: 2000 }, at);
        break;
      case "click":
        this.noise(0.025, 0.4, { type: "bandpass", f0: 3000, q: 2 }, at);
        break;
      case "coin": {
        const dt = () => 1 + (Math.random() * 0.06 - 0.03);
        this.tone(3000 * dt(), 3000 * dt(), 0.3, 0.22, "sine", at);
        this.tone(4500 * dt(), 4500 * dt(), 0.3, 0.18, "sine", at);
        break;
      }
      case "clunk":
        this.tone(90, 55, 0.18, 0.7, "sine", at);
        this.noise(0.025, 0.35, { type: "bandpass", f0: 3000, q: 2 }, at);
        break;
      case "bubble":
        this.tone(300, 900, 0.06 + Math.random() * 0.06, 0.25, "sine", at);
        break;
      case "whirr":
        this.tone(200, 1200, 2.6, 0.14, "sawtooth", at);
        this.tone(203, 1218, 2.6, 0.1, "sawtooth", at);
        break;
      case "boom":
        this.tone(60, 60, 1.2, 0.9, "sine", at);
        this.noise(1.5, 0.5, { type: "lowpass", f0: 600 }, at);
        break;
      case "pen":
        this.noise(1.2, 0.16, { type: "bandpass", f0: 3500, q: 1 }, at, 18);
        break;
      case "heartbeat":
        this.tone(55, 55, 0.12, 0.8, "sine", at);
        this.tone(55, 55, 0.12, 0.8, "sine", at + 0.3);
        break;
      case "whoosh":
        this.noise(1.2, 0.4, { type: "bandpass", f0: 300, f1: 3000, q: 1.2 }, at);
        break;
      case "bass_drop":
        this.tone(120, 35, 1.5, 0.9, "sine", at);
        break;
      case "bass_hit":
        this.tone(45, 45, 0.8, 1.0, "sine", at, this.echoSend ?? undefined);
        this.tone(45, 45, 0.8, 0.9, "sine", at);
        this.noise(0.02, 0.3, { type: "highpass", f0: 2000 }, at);
        break;
    }
  }

  // ---- music: 120 BPM sequencer, warming harmonics, risers, fades ---------
  private scheduleMusic() {
    if (!this.ctx || !this.musicGain) return;
    const c = this.ctx;
    const step = 60 / 120 / 4; // 16th
    const notes = [110, 130.81, 164.81, 220, 261.63, 329.63];
    this.schedTimer = window.setInterval(() => {
      if (!this.ctx) return;
      const adT = this.startAdT + (c.currentTime - this.startCtxT);
      let scheduledTo = this.startAdT + this.stepsDone * step;
      while (scheduledTo < adT + 0.3) {
        const i = this.stepsDone;
        const t = scheduledTo;
        if (t < 44) {
          const warmth = Math.min(1, Math.max(0, (t - 8) / 24));
          const f0 = notes[(i * 3 + (Math.floor(i / 8) % 3)) % notes.length] * (i % 8 < 4 ? 1 : 2);
          const at = Math.max(0, t - adT);
          this.tone(f0, f0, step * 1.4, 0.09 + 0.03 * warmth, "sine", at, this.musicGain!);
          if (warmth > 0.15) {
            this.tone(f0 * 2, f0 * 2, step * 1.2, 0.05 * warmth, "sine", at, this.musicGain!);
            this.tone(f0 * 3, f0 * 3, step, 0.03 * warmth, "sine", at, this.musicGain!);
          }
        }
        this.stepsDone++;
        scheduledTo = this.startAdT + this.stepsDone * step;
      }
      // master fade 59 -> 60
      if (adT > 59 && this.master) {
        const k = Math.min(1, Math.max(0, (60 - adT) / 1));
        this.master.gain.setTargetAtTime(0.9 * k, c.currentTime, 0.03);
      }
    }, 90);
  }

  /** Schedule every event from ad time t0. */
  start(t0: number) {
    this.ensure();
    this.ctx!.resume();
    const c = this.ctx!;
    this.startAdT = t0;
    this.startCtxT = c.currentTime;
    this.stepsDone = Math.max(0, Math.floor(t0 / (60 / 120 / 4)));
    this.scheduleMusic();

    for (const ev of SFX) {
      if (ev.at < t0 - 0.1) continue;
      const delay = Math.max(0, (ev.at - t0) * 1000);
      const id = window.setTimeout(() => this.playSfx(ev.id, 0), delay);
      this.timeouts.push(id);
    }

    // risers (music layer) 32->44
    for (const at of [32, 38]) {
      if (at >= t0) {
        const id = window.setTimeout(
          () => this.noise(6, 0.0, { type: "bandpass", f0: 500, f1: 6000, q: 1.5 }, 0),
          (at - t0) * 1000
        );
        this.timeouts.push(id);
      }
    }

    // VO via speechSynthesis de-DE
    const synth = window.speechSynthesis;
    if (synth) {
      const voices = synth.getVoices();
      const de = voices.find((v) => v.lang === "de-DE") ?? voices.find((v) => v.lang.startsWith("de"));
      if (de) this.status = { ...this.status, engine: `SpeechSynthesis (${de.name})`, note: "Systemstimme — neurale Qualität je nach Plattform; zählt nicht als Produk­tions-VO." };
      for (const line of VO) {
        if (line.at < t0 - 0.2) continue;
        const id = window.setTimeout(() => {
          const u = new SpeechSynthesisUtterance(line.de);
          u.lang = "de-DE";
          if (de) u.voice = de;
          u.rate = 0.98;
          u.pitch = 0.9;
          u.onstart = () => this.musicGain?.gain.setTargetAtTime(0.5 * 0.5, c.currentTime, 0.15);
          u.onend = () => this.musicGain?.gain.setTargetAtTime(0.5, c.currentTime, 0.4);
          synth.speak(u);
        }, Math.max(0, (line.at - t0) * 1000));
        this.timeouts.push(id);
      }
    }
  }

  duckForPreview(active: boolean) {
    if (!this.musicGain || !this.ctx) return;
    this.musicGain.gain.setTargetAtTime(active ? 0.25 : 0.5, this.ctx.currentTime, 0.2);
  }
}
